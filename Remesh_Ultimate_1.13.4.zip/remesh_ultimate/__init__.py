# Remesh Ultimate - smart one-click quad remesher for Blender
# Engines: QuadWild (bundled for Windows + Linux, best edge flow) and Blender's QuadriFlow.
# License: GPL-3.0-or-later

bl_info = {
    "name": "Remesh Ultimate",
    "author": "Drimah",
    "version": (1, 13, 4),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Remesh Ultimate",
    "description": "One-click smart quad remesher: auto-repair, turbo pre-pass, "
                   "QuadWild or QuadriFlow engine, surface-locked relax, exact symmetry, one-click Polish, quality report",
    "category": "Mesh",
}

import bpy
import bmesh
import os
import math
import re
import time
import heapq
import colorsys
import json as _json
import shutil
import numpy as np
from mathutils import Vector, Matrix, Color
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy.props import (IntProperty, FloatProperty, BoolProperty,
                       EnumProperty, PointerProperty, StringProperty)
from bpy.types import Operator, Panel, PropertyGroup, AddonPreferences

ADDON_ID = __package__ or __name__
VERSION_STR = ".".join(str(v) for v in bl_info["version"])
TEMP_COLL = "RU_TEMP_WORK"
RESULT_SUFFIX = "_RU"


# --------------------------------------------------------------------------
#  Presets
# --------------------------------------------------------------------------
PRESETS = {
    'FAST':     dict(target_faces=800, tries=1, relax_iterations=3,
                     sharp_mode='AUTO', turbo=True),
    'BALANCED': dict(target_faces=2000, tries=2, relax_iterations=5,
                     sharp_mode='AUTO', turbo=True),
    'QUALITY':  dict(target_faces=3500, tries=4, relax_iterations=8,
                     sharp_mode='AUTO', turbo=True),
    'HARD':     dict(target_faces=2500, tries=3, relax_iterations=4,
                     sharp_mode='ON', turbo=True),
    'ORGANIC':  dict(target_faces=3000, tries=2, relax_iterations=10,
                     sharp_mode='OFF', turbo=True),
}


def _apply_preset(self, context):
    p = PRESETS.get(self.preset)
    if not p:
        return
    for k, v in p.items():
        setattr(self, k, v)


class RU_Settings(PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        items=[('FAST', "Fast", "Quick low-poly result"),
               ('BALANCED', "Balanced", "Good default for most models"),
               ('QUALITY', "Quality", "Best of 3 solutions, strong relax"),
               ('HARD', "Hard Surface", "Keeps sharp edges and corners"),
               ('ORGANIC', "Organic", "Sculpts, characters, creatures")],
        default='BALANCED', update=_apply_preset)
    detect_mode: EnumProperty(
        name="Mode",
        items=[('AUTO', "Automatic", "Decides by itself: recognises a body (head, arms, "
                                     "legs...) or treats it as a mechanical object"),
               ('ORGANIC', "Organic", "Detects head, torso, upper arms, forearms, legs and feet "
                                      "and separates each part (separating is the default)"),
               ('OBJECT', "Object", "Detects wheels, axles and mechanical parts and names each one")],
        default='AUTO')
    engine: EnumProperty(
        name="Engine",
        items=[('QUADWILD', "QuadWild", "Best edge flow: clean loops around eyes, mouth and "
                                        "creases, almost 100% quads. Slower"),
               ('QUADRIFLOW', "QuadriFlow", "Fastest: Blender's built-in solver")],
        default='QUADWILD')
    quad_size: EnumProperty(
        name="Quad Size",
        items=[('S', "Small", "Dense: lots of small quads (edge = 1/100 of the model size)"),
               ('SM', "Small-Medium", "Edge = 1/70 of the model size"),
               ('M', "Medium", "Balanced density (edge = 1/50 of the model size)"),
               ('ML', "Medium-Large", "Edge = 1/35 of the model size"),
               ('L', "Large", "Light: big quads (edge = 1/25 of the model size)"),
               ('CUSTOM', "Custom", "Type the number of quads yourself")],
        default='M')
    target_faces: IntProperty(name="Target Quads", default=2000, min=50, max=300000,
                              soft_min=200, soft_max=50000,
                              description="Approximate number of quads in the result")
    symmetry: EnumProperty(
        name="Symmetry",
        items=[('NONE', "Off", ""), ('AUTO', "Auto", "Detect mirror symmetry automatically"),
               ('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")],
        default='AUTO')
    sharp_mode: EnumProperty(
        name="Sharp Edges",
        items=[('AUTO', "Auto", "Detect hard-surface parts and lock their creases and corners"),
               ('ON', "Keep", "Always lock creases and corners"),
               ('OFF', "Soft", "Organic: let quads flow freely")],
        default='AUTO')
    sharp_angle: FloatProperty(name="Sharp Angle", default=math.radians(30.0),
                               min=math.radians(5), max=math.radians(120), subtype='ANGLE')
    preserve_boundary: BoolProperty(name="Keep Open Borders", default=True)
    clean_mode: EnumProperty(
        name="Parts",
        items=[('AUTO', "Smart Parts", "Remesh every separate part on its own, repair broken "
                                       "parts locally, mirror twin parts, never lose a part"),
               ('VOXEL', "Merge Parts", "Fuse everything into one watertight shell (voxel)"),
               ('NONE', "Single Mesh", "Treat the whole object as one surface")],
        default='AUTO')
    turbo: BoolProperty(name="Turbo Pre-Pass", default=True,
                        description="Simplify dense meshes before solving (much faster, "
                                    "accuracy is restored by projecting onto the original)")
    tries: IntProperty(name="Best of N", default=1, min=1, max=8,
                       description="Solve with N different seeds and keep the best scored result")
    relax_iterations: IntProperty(name="Relax", default=4, min=0, max=50,
                                  description="Surface-locked relax iterations (evens out quads)")
    relax_strength: FloatProperty(name="Relax Strength", default=0.5, min=0.0, max=1.0)
    project: BoolProperty(name="Project to Surface", default=True)
    add_shrinkwrap: BoolProperty(name="Add Shrinkwrap", default=False,
                                 description="Keep a live Shrinkwrap modifier to the original")
    hide_original: BoolProperty(name="Hide Original", default=True)
    seed: IntProperty(name="Seed", default=0, min=0, max=9999)
    method: EnumProperty(
        name="Method",
        items=[('AUTO', "Smart", "Per part: keep exact shape on clean low-poly / hard-surface "
                                 "parts, rebuild dense or organic parts"),
               ('REMESH', "Rebuild", "Always rebuild the topology from scratch"),
               ('QUADIFY', "Keep Shape", "Never rebuild: convert the existing mesh to quads")],
        default='AUTO')
    pure_quads: BoolProperty(name="100% Quads", default=False,
                             description="Kept-shape parts get one flat subdivision so not a single "
                                         "triangle remains (4x the faces there)")
    area_style: EnumProperty(
        name="Area Style",
        items=[('AUTO', "Auto", "Decide from the model: hard surface follows the creases, "
                                "a smooth organic model is divided by its form"),
               ('SHAPE', "Hard Surface", "Borders only where the shape really changes "
                                         "(creases and deep junctions). A smooth model stays whole"),
               ('ORGANIC', "Organic", "Always divide a smooth body into Max Areas regions, "
                                      "with the borders in the shallowest valleys")],
        default='AUTO')
    adaptive_density: FloatProperty(
        name="Adaptive Density", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
        description="Smaller quads where the model has detail and bigger ones where it is "
                    "smooth. 0 = every quad the same size")
    clean_flow: BoolProperty(
        name="Clean Edge Flow", default=True,
        description="Final pass that turns inner edges to cancel poles (vertices that do "
                    "not have 4 edges). No vertex moves, so the shape and the quad "
                    "percentage stay the same")
    area_count: IntProperty(name="Max Areas", default=24, min=2, max=400,
                            description="Upper limit for Detect Areas on the surfaces. Separate pieces "
                                        "are always their own area on top of this. Borders only go "
                                        "where the shape really changes, so a simple model gets fewer")
    use_guides: BoolProperty(name="Follow Areas & Lines", default=True,
                             description="Make the quad flow follow area borders and drawn lines")
    color_parts: BoolProperty(name="Color Parts", default=True,
                              description="Give every part its own coloured material, visible in "
                                          "Solid, Material Preview and Rendered")
    join_legs: BoolProperty(name="Legs with Torso", default=True,
                            description="Organic: torso and legs come out as one piece "
                                        "(overalls, jumpsuit, high trousers)")
    separate_parts: BoolProperty(name="Separate Parts", default=True,
                                 description="Optional: REMESH delivers one coloured object per area, "
                                             "inside a sub-collection (seams match exactly). "
                                             "Off = one continuous mesh, areas by material")
    mirror_tolerance: FloatProperty(
        name="Mirror Tolerance", default=3.0, min=0.2, max=20.0, subtype='PERCENTAGE',
        description="How different two mirrored pieces (separate objects) may be and still "
                    "count as a pair, in % of the piece size. Pieces that do not match within "
                    "this tolerance are never paired")
    isolated: BoolProperty(name="Safe Parallel Solver", default=True,
                           description="Solve in separate background processes on several CPU "
                                       "cores, with a time limit: a solver hang can never freeze Blender")
    last_report: StringProperty(default="")


# --------------------------------------------------------------------------
#  Helpers
# --------------------------------------------------------------------------
def _status(context, text):
    try:
        if text:
            context.workspace.status_text_set(text)
        else:
            context.workspace.status_text_set(None)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    except Exception:
        pass


def _temp_collection(context):
    coll = bpy.data.collections.get(TEMP_COLL)
    if coll is None:
        coll = bpy.data.collections.new(TEMP_COLL)
    if coll.name not in context.scene.collection.children:
        context.scene.collection.children.link(coll)
    return coll


def _cleanup_temp(context):
    coll = bpy.data.collections.get(TEMP_COLL)
    if coll is None:
        return
    for ob in list(coll.objects):
        me = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if me and me.users == 0:
            bpy.data.meshes.remove(me)
    bpy.data.collections.remove(coll)


def _new_temp_object(context, mesh, name="RU_tmp"):
    ob = bpy.data.objects.new(name, mesh)
    _temp_collection(context).objects.link(ob)
    return ob


def _eval_modifier(context, ob, mod_type, **kw):
    """Apply one modifier through the depsgraph (no operator context needed)."""
    mod = ob.modifiers.new("RU_tmp_mod", mod_type)
    for k, v in kw.items():
        setattr(mod, k, v)
    dg = context.evaluated_depsgraph_get()
    dg.update()
    ev = ob.evaluated_get(dg)
    new_me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=False, depsgraph=dg)
    ob.modifiers.remove(mod)
    old = ob.data
    ob.data = new_me
    if old.users == 0:
        bpy.data.meshes.remove(old)
    return new_me


def _work_matrix(ob):
    """World orientation and real proportions (as 1.6.3).  X / Y / Z in the
    Symmetry menu are the axes you see in the viewport, whatever the object's
    own rotation."""
    return ob.matrix_world.to_3x3()


_PLANE_HINT = {"plane": None}     # world mirror plane of the current selection


def _plane_in_object(src, me, tmp, hint):
    """Express the world plane `hint` (n, d) in one of this object's frames.
    Returns (axis, position, frame, local_mesh_or_None); axis -1 when the plane
    is not along an axis of the object or the object is not symmetric about it."""
    n, d = hint
    n = np.asarray(n, dtype=np.float64)
    t = np.array(src.matrix_world.translation)
    d_rel = float(d - n @ t)                    # plane relative to the object origin
    frames = [("WORLD", np.eye(3), tmp)]
    r = np.array(src.matrix_world.to_3x3().normalized())
    frames.append(("LOCAL", r, None))
    for name, R, mesh in frames:
        nl = R.T @ n                            # plane normal in that frame
        k = int(np.argmax(np.abs(nl)))
        if abs(abs(nl[k]) - 1.0) > 1e-3:
            continue
        sgn = 1.0 if nl[k] > 0 else -1.0
        c = sgn * d_rel
        made = None
        if mesh is None:
            made = me.copy()
            lw = _local_work_matrix(src)
            made.transform(lw.to_4x4())
            if lw.determinant() < 0.0:
                made.flip_normals()
            mesh = made
        co = _mesh_co(mesh)
        if len(co) >= 8:
            lo, hi = co[:, k].min(), co[:, k].max()
            diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
            if lo < c < hi:
                shifted = co.copy()
                shifted[:, k] -= c
                if _is_symmetric(shifted, _bvh_from_mesh_shift(mesh, k, c), diag, k):
                    return k, c, name, made
        if made is not None:
            bpy.data.meshes.remove(made)
    return -1, 0.0, "WORLD", None


def _selection_plane(context, sources):
    """World mirror plane of the selected models (from their own meshes)."""
    s = context.scene.remesh_ultimate
    if s.symmetry == 'NONE' or len(sources) < 1:
        return None
    dg = context.evaluated_depsgraph_get()
    pieces, temp = [], []
    for src in sources:
        try:
            me = bpy.data.meshes.new_from_object(src.evaluated_get(dg), depsgraph=dg)
        except Exception:
            continue
        temp.append(me)
        holder = type("H", (), {})()
        holder.data = me
        pieces.append(_world_piece(src, holder))
    plane = None
    if pieces:
        n, d, _share = _scene_mirror_plane(pieces, s.symmetry, context.active_object)
        if n is not None:
            plane = (n, d)
    for me in temp:
        bpy.data.meshes.remove(me)
    return plane


def _local_work_matrix(ob):
    """The object's own axes with real proportions (scale, no rotation)."""
    m = ob.matrix_world.to_3x3()
    try:
        r = m.to_quaternion().to_matrix()
        w = r.transposed() @ m
        if all(math.isfinite(v) for row in w for v in row) and abs(w.determinant()) > 1e-12:
            return w
    except Exception:
        pass
    return m


def _mesh_co(me):
    co = np.empty(len(me.vertices) * 3, dtype=np.float64)
    me.vertices.foreach_get("co", co)
    return co.reshape(-1, 3)


def _mesh_edges(me):
    ed = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ed)
    return ed.reshape(-1, 2)


def _bvh_from_mesh(me):
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    tree = BVHTree.FromBMesh(bm)
    bm.free()
    return tree


def _tri_count(me):
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    return int((lt - 2).clip(min=0).sum())


def _analyze_fast(me, merge_dist):
    """Pure numpy mesh diagnosis (fast on millions of faces)."""
    nv, ne, nl = len(me.vertices), len(me.edges), len(me.loops)
    le = np.empty(nl, dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lv = np.empty(nl, dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    efc = np.bincount(le, minlength=ne)
    area = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", area)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    nxt = np.arange(nl, dtype=np.int64) + 1
    nxt[ls + lt - 1] = ls
    # winding check in O(n): on a consistent 2-face edge, exactly one of its
    # two loops walks the edge "forward" (low -> high vertex index)
    fwd = (lv < lv[nxt]).astype(np.float64)
    fcount = np.bincount(le, weights=fwd, minlength=ne)
    inconsistent = int(((efc == 2) & (fcount != 1.0)).sum())
    used = np.bincount(lv, minlength=nv) > 0
    co = _mesh_co(me)
    q = np.round(co / max(merge_dist, 1e-12)).astype(np.int64)
    order = np.lexsort((q[:, 2], q[:, 1], q[:, 0]))
    qs = q[order]
    dups = int(np.all(qs[1:] == qs[:-1], axis=1).sum()) if len(qs) > 1 else 0
    return dict(nonmanifold_edges=int((efc > 2).sum()), boundary_edges=int((efc == 1).sum()),
                loose=int((efc == 0).sum() + (~used).sum()), inconsistent=inconsistent,
                duplicates=dups, area=float(area.sum()), faces=len(me.polygons))


def _analyze_and_clean(me, merge_dist):
    info = _analyze_fast(me, merge_dist)
    if not (info["loose"] or info["inconsistent"] or info["duplicates"] or info["nonmanifold_edges"]):
        info["cleaned"] = False
        return info
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=merge_dist)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=merge_dist)
    loose_v = [v for v in bm.verts if not v.link_faces]
    if loose_v:
        bmesh.ops.delete(bm, geom=loose_v, context='VERTS')
    loose_e = [e for e in bm.edges if not e.link_faces]
    if loose_e:
        bmesh.ops.delete(bm, geom=loose_e, context='EDGES')
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.update()
    info = _analyze_fast(me, merge_dist)
    info["cleaned"] = True
    return info


def _detect_symmetry(co, bvh, diag):
    """Return 'X', 'Y', 'Z' or 'NONE' - mirror plane through the local origin."""
    if len(co) < 8:
        return 'NONE'
    rng = np.random.default_rng(1)
    idx = rng.choice(len(co), size=min(1500, len(co)), replace=False)
    sample = co[idx]
    tol = diag * 0.006
    best, best_ratio = 'NONE', 0.0
    for axis_i, name in enumerate("XYZ"):
        hits = 0
        for p in sample:
            q = Vector(p)
            q[axis_i] = -q[axis_i]
            loc, _n, _i, d = bvh.find_nearest(q)
            if loc is not None and d <= tol:
                hits += 1
        ratio = hits / len(sample)
        if ratio > best_ratio:
            best, best_ratio = name, ratio
    return best if best_ratio >= 0.93 else 'NONE'


def _mesh_quality(me, bvh_target, target_co, diag, target_faces):
    nf = len(me.polygons)
    nv = len(me.vertices)
    if nf == 0 or nv == 0:
        return dict(score=0.0, faces=0, quads=0, quad_pct=0.0, poles=0,
                    deviation_pct=100.0, uniformity=0.0)
    lt = np.empty(nf, dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    quads = int((lt == 4).sum())
    ed = _mesh_edges(me)
    ne = len(ed)
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    efc = np.bincount(le, minlength=ne)
    bverts = np.zeros(nv, dtype=bool)
    bverts[ed[efc == 1].ravel()] = True
    val = np.bincount(ed.ravel(), minlength=nv)
    poles = int(((val != 4) & ~bverts).sum())
    co = _mesh_co(me)
    lens = np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1)
    cv = float(lens.std() / max(lens.mean(), 1e-12))

    rng = np.random.default_rng(7)
    # result -> original
    idx = rng.choice(nv, size=min(2500, nv), replace=False)
    d1 = []
    for p in co[idx]:
        r = bvh_target.find_nearest(Vector(p))
        if r[0] is not None:
            d1.append(r[3])
    # original -> result (catches lost details)
    bvh_res = _bvh_from_mesh(me)
    idx2 = rng.choice(len(target_co), size=min(2500, len(target_co)), replace=False)
    d2 = []
    for p in target_co[idx2]:
        r = bvh_res.find_nearest(Vector(p))
        if r[0] is not None:
            d2.append(r[3])
    dev = max(float(np.mean(d1)) if d1 else 0.0, float(np.mean(d2)) if d2 else 0.0)
    dev_pct = 100.0 * dev / max(diag, 1e-12)

    quad_ratio = quads / nf
    pole_ratio = poles / nv
    s_quad = quad_ratio
    s_pole = 1.0 - min(1.0, pole_ratio * 8.0)
    s_dev = 1.0 - min(1.0, dev_pct / 1.5)
    s_uni = 1.0 - min(1.0, cv)
    score = 100.0 * (0.35 * s_quad + 0.25 * s_pole + 0.25 * s_dev + 0.15 * s_uni)
    return dict(score=round(score, 1), faces=nf, quads=quads,
                quad_pct=round(100.0 * quad_ratio, 1), poles=poles,
                deviation_pct=round(dev_pct, 3), uniformity=round(100 * s_uni, 1))


def _run_quadriflow(context, ob, s, target, seed, sym_axis, sharp=False, boundary=None):
    if boundary is None:
        boundary = s.preserve_boundary
    me = ob.data
    me.use_mirror_x = sym_axis == 'X'
    me.use_mirror_y = sym_axis == 'Y'
    me.use_mirror_z = sym_axis == 'Z'
    vl = context.view_layer
    for o in context.selected_objects:
        o.select_set(False)
    ob.hide_set(False)
    ob.select_set(True)
    vl.objects.active = ob
    before = len(me.polygons)
    try:
        with context.temp_override(object=ob, active_object=ob,
                                   selected_objects=[ob], selected_editable_objects=[ob]):
            ret = bpy.ops.object.quadriflow_remesh(
                use_mesh_symmetry=(sym_axis != 'NONE'),
                use_preserve_sharp=bool(sharp),
                use_preserve_boundary=bool(boundary),
                preserve_attributes=False,
                smooth_normals=False,
                mode='FACES',
                target_faces=int(target),
                seed=int(seed))
    except Exception as ex:
        print("[Remesh Ultimate] QuadriFlow error:", ex)
        return False
    if 'FINISHED' not in ret:
        return False
    nf = len(ob.data.polygons)
    if nf == 0:
        return False
    lt = np.empty(nf, dtype=np.int64)
    ob.data.polygons.foreach_get("loop_total", lt)
    # QuadriFlow output is pure quads; anything else means it silently gave up
    if (lt == 4).mean() < 0.9 and nf == before:
        return False
    return True


def _symmetry_pairs(co, axis_i, tol):
    kd = KDTree(len(co))
    for i, p in enumerate(co):
        kd.insert(p, i)
    kd.balance()
    center = np.where(np.abs(co[:, axis_i]) < tol)[0]
    pairs = []
    for i in np.where(co[:, axis_i] >= tol)[0]:
        q = Vector(co[i])
        q[axis_i] = -q[axis_i]
        _c, j, d = kd.find(q)
        if j is not None and d < tol * 2.0 and j != i:
            pairs.append((i, j))
    return center, np.array(pairs, dtype=np.int64).reshape(-1, 2)


def _extend_pairs(co, axis_i, pairs, center, tol, plane=0.0):
    """1.11.0 (idea from PolyQuilt's mirror lookup): after the first projection
    QuadriFlow vertices sit closer to their mirror twin, so vertices that were left
    without a partner get a second chance with a wider tolerance.  Only MUTUAL
    nearest twins are accepted, so a wide tolerance never pairs the wrong vertex."""
    n = len(co)
    if n == 0:
        return pairs
    used = np.zeros(n, dtype=bool)
    if len(pairs):
        used[pairs.ravel()] = True
    if len(center):
        used[center] = True
    free = np.flatnonzero(~used)
    if len(free) < 2:
        return pairs
    kd = KDTree(len(free))
    for k, i in enumerate(free):
        kd.insert(co[i], k)
    kd.balance()

    def twin(i):
        q = Vector(co[i])
        q[axis_i] = 2.0 * plane - q[axis_i]
        _c, k, d = kd.find(q)
        if k is None or d > tol:
            return -1
        return int(free[k])

    new = []
    for i in free:
        if co[i, axis_i] <= plane + tol * 0.25:
            continue
        j = twin(i)
        if j < 0 or j == i or used[j] or co[j, axis_i] >= plane:
            continue
        if twin(j) != i:
            continue
        used[i] = used[j] = True
        new.append((i, j))
    if not new:
        return pairs
    new = np.array(new, dtype=np.int64).reshape(-1, 2)
    return np.vstack([pairs.reshape(-1, 2), new]) if len(pairs) else new


def _poly_topology(me):
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    nxt = np.arange(len(lv), dtype=np.int64) + 1
    if len(ls):
        nxt[ls + lt - 1] = ls
    poly_of_loop = np.repeat(np.arange(len(ls), dtype=np.int64), lt)
    return lv, ls, lt, nxt, poly_of_loop


def _vertex_normals_np(co, topo):
    """Area-weighted vertex normals (Newell), fully vectorised."""
    lv, ls, lt, nxt, pol = topo
    cr = np.cross(co[lv], co[lv[nxt]])
    fn = np.add.reduceat(cr, ls, axis=0) if len(ls) else np.zeros((0, 3))
    vn = np.zeros_like(co)
    np.add.at(vn, lv, fn[pol])
    ln = np.linalg.norm(vn, axis=1)
    ln[ln == 0] = 1.0
    return vn / ln[:, None]


# --------------------------------------------------------------------------
#  Feature lines of the ORIGINAL surface (creases, borders, corners)
# --------------------------------------------------------------------------
class _Features:
    def __init__(self):
        self.crease = None      # (A, B) arrays of segments
        self.border = None
        self.kd_crease = None
        self.kd_border = None
        self.seg_crease = None
        self.seg_border = None
        self.corners = np.zeros((0, 3))
        self.hard = False
        self.count = 0


def _segments_kd(A, B, step):
    """Sample segments every `step` so a KD-tree can find the nearest segment."""
    L = np.linalg.norm(B - A, axis=1)
    n = np.maximum(1, np.ceil(L / max(step, 1e-9)).astype(np.int64))
    total = int(n.sum() + len(A))
    kd = KDTree(total)
    seg_id = np.empty(total, dtype=np.int64)
    k = 0
    for i in range(len(A)):
        a, b, m = A[i], B[i], n[i]
        for j in range(m + 1):
            t = j / m
            kd.insert(a + (b - a) * t, k)
            seg_id[k] = i
            k += 1
    kd.balance()
    return kd, seg_id


def _extract_features(me, angle, want_border, step, mode='AUTO', extra=None):
    f = _Features()
    ne = len(me.edges)
    if ne == 0 or len(me.polygons) == 0:
        return f
    co = _mesh_co(me)
    ed = _mesh_edges(me)
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lv, ls, lt, nxt, pol = _poly_topology(me)
    fnorm = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fnorm)
    fnorm = fnorm.reshape(-1, 3)
    efc = np.bincount(le, minlength=ne)
    # the two faces of every 2-face edge
    order = np.argsort(le, kind='stable')
    le_s, pol_s = le[order], pol[order]
    starts = np.searchsorted(le_s, np.arange(ne))
    two = np.flatnonzero(efc == 2)
    f0 = pol_s[starts[two]]
    f1 = pol_s[starts[two] + 1]
    dots = np.einsum('ij,ij->i', fnorm[f0], fnorm[f1]).clip(-1.0, 1.0)
    crease_e = two[dots < math.cos(angle)]
    border_e = np.flatnonzero(efc == 1) if want_border else np.zeros(0, dtype=np.int64)

    f.count = len(crease_e)
    frac = len(crease_e) / max(ne, 1)
    # hard-surface = real crease lines, not sculpt noise
    if mode == 'ON':
        f.hard = 0 < len(crease_e) <= 60000
    elif mode == 'OFF':
        f.hard = False
    else:
        f.hard = len(crease_e) >= 8 and frac >= 0.003 and len(crease_e) <= 60000
    if not f.hard:
        crease_e = np.zeros(0, dtype=np.int64)

    feat_e = np.concatenate([crease_e, border_e])
    if len(feat_e):
        deg = np.bincount(ed[feat_e].ravel(), minlength=len(co))
        # corners: 3+ feature lines meet, or a feature line ends
        corner_v = np.flatnonzero((deg >= 3) | (deg == 1))
        f.corners = co[corner_v]
    cA = [co[ed[crease_e, 0]]] if len(crease_e) else []
    cB = [co[ed[crease_e, 1]]] if len(crease_e) else []
    if extra is not None and len(extra[0]):
        cA.append(extra[0])
        cB.append(extra[1])
        f.hard = True
        # junctions and ends of the guide network become corners
        ends = np.round(np.vstack([extra[0], extra[1]]) / max(step * 0.25, 1e-9)).astype(np.int64)
        u, inv, cnt = np.unique(ends, axis=0, return_inverse=True, return_counts=True)
        pts = np.vstack([extra[0], extra[1]])
        firsts = np.zeros(len(u), dtype=np.int64)
        firsts[inv[::-1]] = np.arange(len(inv))[::-1]
        jn = pts[firsts[(cnt >= 3) | (cnt == 1)]]
        if len(jn):
            f.corners = np.vstack([f.corners, jn]) if len(f.corners) else jn
    if cA:
        f.crease = (np.concatenate(cA), np.concatenate(cB))
        f.kd_crease, f.seg_crease = _segments_kd(*f.crease, step)
    if len(border_e):
        f.border = (co[ed[border_e, 0]], co[ed[border_e, 1]])
        f.kd_border, f.seg_border = _segments_kd(*f.border, step)
    return f


def _closest_on_segment(p, a, b):
    ab = b - a
    t = float(np.dot(p - a, ab) / max(np.dot(ab, ab), 1e-20))
    t = min(1.0, max(0.0, t))
    return a + ab * t, ab


# --------------------------------------------------------------------------
#  Fit: thin-safe projection + feature snapping + tangential relax
# --------------------------------------------------------------------------
def _fit_to_surface(me, bvh, feats, s, sym_axis, avg_edge):
    co = _mesh_co(me)
    n = len(co)
    if n == 0:
        return
    topo = _poly_topology(me)
    ed = _mesh_edges(me)
    deg = np.bincount(ed.ravel(), minlength=n).astype(np.float64)
    ae = max(avg_edge, 1e-9)

    # result borders
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    efc = np.bincount(le, minlength=len(ed))
    res_border = np.zeros(n, dtype=bool)
    res_border[ed[efc == 1].ravel()] = True

    axis_i = "XYZ".index(sym_axis) if sym_axis in ('X', 'Y', 'Z') else -1
    if axis_i >= 0:
        center, pairs = _symmetry_pairs(co, axis_i, ae * 0.25)
    else:
        center = pairs = None

    def symmetrize():
        if axis_i < 0:
            return
        if len(pairs):
            a, b = pairs[:, 0], pairs[:, 1]
            mb = co[b].copy()
            mb[:, axis_i] *= -1.0
            m = 0.5 * (co[a] + mb)
            co[a] = m
            m2 = m.copy()
            m2[:, axis_i] *= -1.0
            co[b] = m2
        if len(center):
            co[center, axis_i] = 0.0

    co_solver = co.copy()

    # orientation of the result vs the reference (QuadriFlow may flip it)
    vn = _vertex_normals_np(co, topo)
    agree = 0
    probe = range(0, n, max(1, n // 400))
    cnt = 0
    for i in probe:
        r = bvh.find_nearest(Vector(co[i]))
        if r[0] is not None:
            cnt += 1
            if r[1].dot(Vector(vn[i])) > 0.0:
                agree += 1
    sign = 1.0 if agree >= cnt * 0.5 else -1.0

    # ---- feature assignment (done once, on the solver output)
    kind = np.zeros(n, dtype=np.int8)     # 0 surface, 1 crease, 2 border, 3 corner
    seg = np.full(n, -1, dtype=np.int64)
    snap_tol = ae * 0.35
    if feats is not None:
        if feats.kd_border is not None:
            for i in np.flatnonzero(res_border):
                _c, k, d = feats.kd_border.find(co[i])
                if k is not None and d <= ae * 0.75:
                    kind[i] = 2
                    seg[i] = feats.seg_border[k]
        if feats.kd_crease is not None and s.project:
            for i in range(n):
                if kind[i]:
                    continue
                _c, k, d = feats.kd_crease.find(co[i])
                if k is not None and d <= snap_tol:
                    kind[i] = 1
                    seg[i] = feats.seg_crease[k]
        if len(feats.corners) and s.project:
            kdv = KDTree(n)
            for i in range(n):
                kdv.insert(co[i], i)
            kdv.balance()
            for c in feats.corners:
                _p, i, d = kdv.find(c)
                if i is not None and d <= ae * 0.75:
                    co[i] = c
                    kind[i] = 3
    elif s.preserve_boundary:
        kind[res_border] = 3        # no feature data: just keep borders still

    def seg_of(i):
        if kind[i] == 1:
            A, B = feats.crease
        else:
            A, B = feats.border
        return A[seg[i]], B[seg[i]]

    def project():
        nonlocal vn
        vn = _vertex_normals_np(co, topo) * sign
        if not s.project:
            return
        maxd = ae * 1.5
        for i in range(n):
            k = kind[i]
            if k == 3:
                continue
            if k in (1, 2):
                a, b = seg_of(i)
                # stay on the line; re-pick the neighbouring segment when we slide past an end
                p, _ab = _closest_on_segment(co[i], a, b)
                kd = feats.kd_crease if k == 1 else feats.kd_border
                ids = feats.seg_crease if k == 1 else feats.seg_border
                _c, kk, _d = kd.find(co[i])
                if kk is not None and ids[kk] != seg[i] and _d <= ae * 0.5:
                    A2, B2 = feats.crease if k == 1 else feats.border
                    p2, _ = _closest_on_segment(co[i], A2[ids[kk]], B2[ids[kk]])
                    if np.linalg.norm(p2 - co[i]) < np.linalg.norm(p - co[i]):
                        seg[i] = ids[kk]
                        p = p2
                co[i] = p
                continue
            pv = Vector(co[i])
            nv_ = Vector(vn[i])
            loc, no, _idx, _d = bvh.find_nearest(pv)
            if loc is not None and no.dot(nv_) > 0.1:
                co[i] = loc
                continue
            # the nearest point is on the other side of a thin wall: search along the normal
            best = None
            for dirn in (nv_, -nv_):
                h = bvh.ray_cast(pv, dirn, maxd)
                if h[0] is not None and h[1].dot(nv_) > 0.1:
                    if best is None or h[3] < best[1]:
                        best = (h[0], h[3])
            if best is not None:
                co[i] = best[0]

    project()
    if axis_i >= 0:
        pairs = _extend_pairs(co, axis_i, pairs, center, ae * 0.45)
    symmetrize()

    movable = kind != 3
    k_str = s.relax_strength
    half = s.relax_iterations // 2
    for _it in range(s.relax_iterations):
        if axis_i >= 0 and _it == half and _it > 0:
            pairs = _extend_pairs(co, axis_i, pairs, center, ae * 0.45)
        acc = np.zeros_like(co)
        np.add.at(acc, ed[:, 0], co[ed[:, 1]])
        np.add.at(acc, ed[:, 1], co[ed[:, 0]])
        avg = acc / np.maximum(deg, 1.0)[:, None]
        delta = avg - co
        # slide along the surface only, never shrink
        delta -= (delta * vn).sum(axis=1)[:, None] * vn
        # feature vertices slide only along their line
        fi = np.flatnonzero((kind == 1) | (kind == 2))
        for i in fi:
            a, b = seg_of(i)
            d = b - a
            dl = np.linalg.norm(d)
            if dl > 0:
                d = d / dl
                delta[i] = d * float(np.dot(delta[i], d))
        delta[~movable] = 0.0
        if axis_i >= 0 and len(center):
            delta[center, axis_i] = 0.0
        co += k_str * delta
        project()
        symmetrize()

    # safety net: any vertex that produced a stretched edge goes back to the
    # solver position, projected safely onto the surface
    for _pass in range(3):
        L = np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1)
        med = float(np.median(L)) if len(L) else 0.0
        badE = np.flatnonzero(L > max(med * 3.5, 1e-9))
        if len(badE) == 0:
            break
        bad_v = np.unique(ed[badE].ravel())
        for i in bad_v:
            loc, _no, _ix, _d = bvh.find_nearest(Vector(co_solver[i]))
            co[i] = loc if loc is not None else co_solver[i]
            kind[i] = 3

    me.vertices.foreach_set("co", co.ravel())
    me.update()


def _voxel_size_for(area, faces_wanted):
    return math.sqrt(max(area, 1e-12) / max(faces_wanted, 1))


def _voxelize(context, ob, area, faces_wanted):
    """OpenVDB rebuild + one light smoothing pass. The raw voxel grid has
    perfectly coplanar staircase faces that QuadriFlow's field solver often
    rejects; one smoothing step removes them without losing shape."""
    vs = _voxel_size_for(area, faces_wanted)
    _eval_modifier(context, ob, 'REMESH', mode='VOXEL', voxel_size=vs, adaptivity=0.0)
    _eval_modifier(context, ob, 'SMOOTH', factor=0.5, iterations=1)


# --------------------------------------------------------------------------
#  Mesh building blocks (numpy, fast)
# --------------------------------------------------------------------------
TMP_PREFIX = "RU__tmp"


def _tmp_copy(me):
    m = me.copy()
    m.name = TMP_PREFIX
    return m


def _mesh_arrays(me):
    co = _mesh_co(me)
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    return co, lv, ls, lt


def _build_mesh(co, lv, lt, name=TMP_PREFIX):
    me = bpy.data.meshes.new(name)
    if len(lt) == 0:
        return me
    ls = np.zeros(len(lt), dtype=np.int64)
    ls[1:] = np.cumsum(lt)[:-1]
    me.vertices.add(len(co))
    me.vertices.foreach_set("co", np.ascontiguousarray(co, dtype=np.float32).ravel())
    me.loops.add(len(lv))
    me.loops.foreach_set("vertex_index", lv.astype(np.int32))
    me.polygons.add(len(lt))
    me.polygons.foreach_set("loop_start", ls.astype(np.int32))
    me.update(calc_edges=True)
    me.validate(clean_customdata=False)
    return me


def _join_meshes(meshes, name=TMP_PREFIX):
    cos, lvs, lts, off = [], [], [], 0
    for m in meshes:
        co, lv, _ls, lt = _mesh_arrays(m)
        cos.append(co)
        lvs.append(lv + off)
        lts.append(lt)
        off += len(co)
    if not cos:
        return bpy.data.meshes.new(name)
    return _build_mesh(np.concatenate(cos), np.concatenate(lvs), np.concatenate(lts), name)


def _components(me):
    """Connected parts (by shared vertices). Numpy union-find with pointer jumping."""
    nv = len(me.vertices)
    ed = _mesh_edges(me)
    parent = np.arange(nv, dtype=np.int64)
    if len(ed) == 0:
        return parent
    a, b = ed[:, 0], ed[:, 1]
    for _round in range(64):
        pa, pb = parent[a], parent[b]
        if np.array_equal(pa, pb):
            break
        lo = np.minimum(pa, pb)
        hi = np.maximum(pa, pb)
        np.minimum.at(parent, hi, lo)
        while True:
            gp = parent[parent]
            if np.array_equal(gp, parent):
                break
            parent = gp
    _u, labels = np.unique(parent, return_inverse=True)
    return labels


def _split_parts(me, labels):
    co, lv, ls, lt = _mesh_arrays(me)
    face_lab = labels[lv[ls]]
    parts = []
    order = np.argsort(face_lab, kind='stable')
    bounds = np.flatnonzero(np.diff(face_lab[order])) + 1
    groups = np.split(order, bounds)
    for faces in groups:
        if len(faces) == 0:
            continue
        sel_lt = lt[faces]
        idx = _loop_ranges(ls[faces], sel_lt)
        verts = lv[idx]
        uniq, remap = np.unique(verts, return_inverse=True)
        parts.append(_build_mesh(co[uniq], remap.astype(np.int64), sel_lt))
    return parts


def _loop_ranges(starts, totals):
    total = int(totals.sum())
    rep = np.repeat(starts - np.concatenate([[0], np.cumsum(totals)[:-1]]), totals)
    return np.arange(total, dtype=np.int64) + rep


def _mirror_mesh(me, axis_i):
    m = _tmp_copy(me)
    co = _mesh_co(m)
    co[:, axis_i] *= -1.0
    m.vertices.foreach_set("co", co.ravel())
    bm = bmesh.new()
    bm.from_mesh(m)
    bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
    bm.to_mesh(m)
    bm.free()
    m.update()
    return m


def _weld_mirror_seam(me, axis_i, diag):
    """Snap open-border points lying next to the mirror plane onto it and weld
    the two halves together there.  Returns how many points were welded."""
    bm = bmesh.new()
    bm.from_mesh(me)
    edges = [e for e in bm.edges if e.is_boundary]
    if not edges:
        bm.free()
        return 0
    lens = sorted(e.calc_length() for e in bm.edges)
    ae = lens[len(lens) // 2] if lens else diag * 0.01
    tol = min(ae * 0.6, diag * 0.01)
    # only open edges that run ALONG the plane (both ends on it) form a seam; an
    # opening that merely crosses the plane (a hole in the middle) is left alone
    seam = {v for e in edges if all(abs(x.co[axis_i]) <= tol for x in e.verts)
            for v in e.verts}
    # ... and only points that really have a twin on the other side get welded
    if seam:
        from mathutils.kdtree import KDTree
        sl = list(seam)
        kd = KDTree(len(sl))
        for i, v in enumerate(sl):
            kd.insert(v.co, i)
        kd.balance()
        paired = set()
        for v in sl:
            q = v.co.copy()
            q[axis_i] = -q[axis_i]
            # 1.8.4: a point ON the plane is its own mirror - find() returned the
            # point itself and the seam was never welded (head split in two
            # after a symmetric QuadriFlow solve).  Look at the nearest others.
            for _co, j, dd in kd.find_n(q, 4):
                if j is not None and sl[j] is not v and dd <= tol * 0.5:
                    paired.add(v)
                    break
        seam = paired
    if not seam:
        bm.free()
        return 0
    for v in seam:
        v.co[axis_i] = 0.0
    before = len(bm.verts)
    bmesh.ops.remove_doubles(bm, verts=list(seam),
                             dist=max(diag * 1e-5, min(tol * 0.7, ae * 0.35)))
    welded = before - len(bm.verts)
    if welded:
        bm.to_mesh(me)
        me.update()
    bm.free()
    return welded


def _symmetrize_quads(me, axis_i, diag):
    """1.13.2: make a solved mesh exactly symmetric about the plane coordinate 0
    of `axis_i` without cutting quads: every face goes whole to the side its
    centre is on, the positive side is kept, the ragged centre border is moved
    onto the plane (along the axis only) and mirrored.  Returns False (mesh
    untouched) when the border is too far from the plane to move safely."""
    bm = bmesh.new()
    bm.from_mesh(me)
    if not bm.faces:
        bm.free()
        return False
    lens = sorted(e.calc_length() for e in bm.edges)
    ae = lens[len(lens) // 2] if lens else diag * 0.01
    keep = [f for f in bm.faces if f.calc_center_median()[axis_i] >= 0.0]
    drop = [f for f in bm.faces if f.calc_center_median()[axis_i] < 0.0]
    if not keep or not drop:
        bm.free()
        return False
    kept_v = {v for f in keep for v in f.verts}
    seam = {v for f in drop for v in f.verts if v in kept_v}
    if not seam:
        bm.free()
        return False
    if max(abs(v.co[axis_i]) for v in seam) > ae * 0.9:
        bm.free()
        return False
    bmesh.ops.delete(bm, geom=drop, context='FACES')
    for v in seam:
        v.co[axis_i] = 0.0
    # a kept face lying flat on the plane would be a sliver: give up
    eps = diag * 1e-6
    for f in bm.faces:
        if all(abs(v.co[axis_i]) <= eps for v in f.verts):
            bm.free()
            return False
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    direction = ("X", "Y", "Z")[axis_i]
    bmesh.ops.symmetrize(bm, input=bm.verts[:] + bm.edges[:] + bm.faces[:],
                         direction=direction, dist=max(diag * 1e-6, ae * 1e-3))
    bm.to_mesh(me)
    me.update()
    bm.free()
    return True


def _boundary_loops(me):
    """Lengths of the open border loops (holes, openings) of a mesh."""
    ne = len(me.edges)
    if ne == 0 or len(me.loops) == 0:
        return []
    ei = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", ei)
    use = np.bincount(ei, minlength=ne)
    b = np.flatnonzero(use == 1)
    if len(b) == 0:
        return []
    ev = np.empty(ne * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ev)
    ev = ev.reshape(-1, 2)[b]
    co = _mesh_co(me)
    elen = np.linalg.norm(co[ev[:, 0]] - co[ev[:, 1]], axis=1)
    parent = {}

    def find(x):
        while parent.get(x, x) != x:
            parent[x] = parent.get(parent[x], parent[x])
            x = parent[x]
        return x
    for a_, b_ in ev.tolist():
        ra, rb = find(a_), find(b_)
        if ra != rb:
            parent[ra] = rb
    tot = {}
    for (a_, _b), L in zip(ev.tolist(), elen.tolist()):
        r = find(a_)
        tot[r] = tot.get(r, 0.0) + L
    return sorted(tot.values(), reverse=True)


def _repair_part(me, merge_dist):
    """Local repair without voxels: weld, drop junk, split non-manifold fans,
    make normals consistent."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=merge_dist)
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=merge_dist)
    junk = [v for v in bm.verts if not v.link_faces]
    if junk:
        bmesh.ops.delete(bm, geom=junk, context='VERTS')
    nm = [e for e in bm.edges if len(e.link_faces) > 2]
    if nm:
        bmesh.ops.split_edges(bm, edges=nm)
    nmv = [v for v in bm.verts if not v.is_manifold and v.link_faces and not v.is_boundary]
    if nmv:
        bmesh.ops.split_edges(bm, edges=list({e for v in nmv for e in v.link_edges}))
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.update()


def _bvh_from_mesh_shift(me, axis_i, c):
    bm = bmesh.new()
    bm.from_mesh(me)
    for v in bm.verts:
        v.co[axis_i] -= c
    tree = BVHTree.FromBMesh(bm)
    bm.free()
    return tree


def _sample_points(me, limit=3000, seed=3):
    co = _mesh_co(me)
    cen = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("center", cen)
    pts = np.concatenate([co, cen.reshape(-1, 3)])
    if len(pts) > limit:
        rng = np.random.default_rng(seed)
        pts = pts[rng.choice(len(pts), size=limit, replace=False)]
    return pts


def _avg_edge(me):
    co = _mesh_co(me)
    ed = _mesh_edges(me)
    if len(ed) == 0:
        return 0.0
    return float(np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1).mean())


def _coverage(ref_pts, res_me, tol):
    """Fraction of the original surface that the result still covers."""
    if len(res_me.polygons) == 0:
        return 0.0
    bvh = _bvh_from_mesh(res_me)
    hit = 0
    for p in ref_pts:
        r = bvh.find_nearest(Vector(p))
        if r[0] is not None and r[3] <= tol:
            hit += 1
    return hit / max(len(ref_pts), 1)


def _is_symmetric(co, bvh, diag, axis_i):
    if len(co) < 8:
        return False
    rng = np.random.default_rng(1)
    sample = co[rng.choice(len(co), size=min(800, len(co)), replace=False)]
    tol = diag * 0.006
    hits = 0
    for p in sample:
        q = Vector(p)
        q[axis_i] = -q[axis_i]
        loc, _n, _i, d = bvh.find_nearest(q)
        if loc is not None and d <= tol:
            hits += 1
    return hits / len(sample) >= 0.85


# --------------------------------------------------------------------------
#  One part -> quads
# --------------------------------------------------------------------------
COVER_MIN = 0.95


# --------------------------------------------------------------------------
#  Isolated, parallel QuadriFlow
#  Each solve runs in a background Blender process with a time limit, so a
#  solver hang can never freeze the user's Blender, and parts are solved on
#  several CPU cores at once.
# --------------------------------------------------------------------------
import sys
import json
import tempfile
import subprocess

_WORKER_SRC = r'''
import sys, os, json
import numpy as np
import bpy

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
jobdir, listfile = argv[0], argv[1]
ids = json.load(open(listfile))

def build(co, lv, lt):
    me = bpy.data.meshes.new("ru_w")
    ls = np.zeros(len(lt), dtype=np.int64)
    if len(lt) > 1:
        ls[1:] = np.cumsum(lt)[:-1]
    me.vertices.add(len(co))
    me.vertices.foreach_set("co", co.astype(np.float32).ravel())
    me.loops.add(len(lv))
    me.loops.foreach_set("vertex_index", lv.astype(np.int32))
    me.polygons.add(len(lt))
    me.polygons.foreach_set("loop_start", ls.astype(np.int32))
    me.update(calc_edges=True)
    me.validate(clean_customdata=False)
    return me

for jid in ids:
    base = os.path.join(jobdir, jid)
    meta = json.load(open(base + ".json"))
    d = np.load(os.path.join(jobdir, meta["input"] + ".in.npz"))
    me = build(d["co"], d["lv"], d["lt"])
    sym = meta["sym"]
    me.use_mirror_x = sym == "X"
    me.use_mirror_y = sym == "Y"
    me.use_mirror_z = sym == "Z"
    ob = bpy.data.objects.new("ru_w", me)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    ok = False
    try:
        with bpy.context.temp_override(object=ob, active_object=ob,
                                       selected_objects=[ob], selected_editable_objects=[ob]):
            r = bpy.ops.object.quadriflow_remesh(
                use_mesh_symmetry=(sym != "NONE"),
                use_preserve_sharp=bool(meta["sharp"]),
                use_preserve_boundary=bool(meta["boundary"]),
                preserve_attributes=False, smooth_normals=False,
                mode='FACES', target_faces=int(meta["target"]), seed=int(meta["seed"]))
        ok = 'FINISHED' in r and len(ob.data.polygons) > 0
    except Exception as ex:
        ok = False
    if ok:
        m = ob.data
        co = np.empty(len(m.vertices) * 3, dtype=np.float64); m.vertices.foreach_get("co", co)
        lv = np.empty(len(m.loops), dtype=np.int64); m.loops.foreach_get("vertex_index", lv)
        lt = np.empty(len(m.polygons), dtype=np.int64); m.polygons.foreach_get("loop_total", lt)
        tmp = base + ".tmp.npz"
        np.savez(tmp, co=co.reshape(-1, 3), lv=lv, lt=lt)
        os.replace(tmp, base + ".out.npz")
    else:
        open(base + ".fail", "w").close()
    old = ob.data
    bpy.data.objects.remove(ob)
    if old.users == 0:
        bpy.data.meshes.remove(old)
    sys.stdout.flush()
'''


def _blender_cmd(worker, jobdir, listfile):
    exe = bpy.app.binary_path
    if exe and os.path.isfile(exe):
        return [exe, "--background", "--factory-startup", "--python", worker, "--", jobdir, listfile]
    # Blender running as a Python module (bpy from pip): plain python works
    return [sys.executable, worker, jobdir, listfile]


def _worker_count(n_jobs):
    try:
        cpus = os.cpu_count() or 2
    except Exception:
        cpus = 2
    return max(1, min(n_jobs, max(1, cpus // 2), 6))


def _qf_isolated(jobs, inputs, worker_path=None, limit_fn=None):
    """jobs: list of dict(id, input, target, seed, sym, sharp, boundary, faces)
       inputs: dict input_id -> (co, lv, lt)
       Returns dict id -> (co, lv, lt) | 'fail' | 'timeout', or None if the
       isolated runner is not available at all."""
    if not jobs:
        return {}
    tmp = tempfile.mkdtemp(prefix="ru_qf_")
    try:
        if worker_path:
            worker = worker_path
        else:
            worker = os.path.join(tmp, "ru_worker.py")
            with open(worker, "w", encoding="utf-8") as fh:
                fh.write(_WORKER_SRC)
        for iid, (co, lv, lt) in inputs.items():
            np.savez(os.path.join(tmp, iid + ".in.npz"), co=co, lv=lv, lt=lt)
        for j in jobs:
            with open(os.path.join(tmp, j["id"] + ".json"), "w") as fh:
                json.dump(j, fh)

        def limit(j):
            t = 10.0 + j["faces"] / 6000.0 + j["target"] / 1500.0
            return t * (2.0 if j["sharp"] else 1.0)
        if limit_fn is not None:
            limit = limit_fn

        results = {}
        busy = {}
        pending = [j for j in jobs]
        flags = 0x08000000 if sys.platform == "win32" else 0   # no console window
        attempts = 0
        while pending and attempts < 6:
            attempts += 1
            nw = _worker_count(len(pending))
            chunks = [pending[k::nw] for k in range(nw)]
            procs = []
            for k, chunk in enumerate(chunks):
                if not chunk:
                    continue
                lf = os.path.join(tmp, "list_%d_%d.json" % (attempts, k))
                with open(lf, "w") as fh:
                    json.dump([j["id"] for j in chunk], fh)
                try:
                    p = subprocess.Popen(_blender_cmd(worker, tmp, lf), stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL, creationflags=flags)
                except Exception as ex:
                    print("[Remesh Ultimate] isolated solver unavailable:", ex)
                    for q in procs:
                        q[0].kill()
                    return None
                procs.append([p, chunk, 0, time.time(), 15.0])   # +15 s start-up allowance
            requeue = []
            while procs:
                time.sleep(0.03)
                now = time.time()
                for st in list(procs):
                    p, chunk, idx, t_last, extra = st
                    while idx < len(chunk):
                        b = os.path.join(tmp, chunk[idx]["id"])
                        if os.path.exists(b + ".out.npz"):
                            # 1.8.4: no Windows o arquivo pode ficar preso por um
                            # instante (antivirus, indexador, o proprio worker
                            # fechando) - PermissionError abortava o REMESH
                            # inteiro.  Tenta de novo no proximo ciclo; depois
                            # de ~5 s conta so esse solve como falho.
                            try:
                                with np.load(b + ".out.npz") as d:
                                    results[chunk[idx]["id"]] = (np.array(d["co"]), np.array(d["lv"]),
                                                                 np.array(d["lt"]))
                            except Exception as ex:
                                k_ = chunk[idx]["id"]
                                busy[k_] = busy.get(k_, 0) + 1
                                if busy[k_] < 160:
                                    break
                                print("[Remesh Ultimate] result unreadable:", ex)
                                results[k_] = 'fail'
                        elif os.path.exists(b + ".fail"):
                            results[chunk[idx]["id"]] = 'fail'
                        else:
                            break
                        idx += 1
                        t_last, extra = now, 0.0
                    st[2], st[3], st[4] = idx, t_last, extra
                    if idx >= len(chunk):
                        if p.poll() is None:
                            try:
                                p.wait(timeout=5)
                            except Exception:
                                p.kill()
                        procs.remove(st)
                        continue
                    if p.poll() is not None:
                        # worker died on chunk[idx]: count it as failed, retry the rest
                        results[chunk[idx]["id"]] = 'fail'
                        requeue.extend(chunk[idx + 1:])
                        procs.remove(st)
                    elif now - t_last > limit(chunk[idx]) + extra:
                        p.kill()
                        try:
                            p.wait(timeout=5)
                        except Exception:
                            pass
                        results[chunk[idx]["id"]] = 'timeout'
                        requeue.extend(chunk[idx + 1:])
                        procs.remove(st)
            pending = [j for j in requeue if j["id"] not in results]
        for j in pending:
            results.setdefault(j["id"], 'fail')
        return results
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _qf_inprocess(context, jobs, inputs):
    """Fallback: same interface, solved inside this Blender (sharp disabled: it can hang)."""
    results = {}
    for j in jobs:
        co, lv, lt = inputs[j["input"]]
        me = _build_mesh(co, lv, lt)
        ob = _new_temp_object(context, me, "RU_qf")
        ok = _run_quadriflow(context, ob, None, j["target"], j["seed"], j["sym"], sharp=False,
                             boundary=j["boundary"])
        if ok:
            a = _mesh_arrays(ob.data)
            results[j["id"]] = (a[0], a[1], a[3])
        else:
            results[j["id"]] = 'fail'
        old = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if old.users == 0:
            bpy.data.meshes.remove(old)
    return results


# --------------------------------------------------------------------------
#  QuadWild engine (1.12.0).  Native libraries for Windows (.dll) and Linux
#  (.so) ship together in the qw/ folder; they are only ever loaded inside the
#  background worker processes, never inside Blender itself, so a crash or a
#  hang in the native code can not take Blender down and the files are never
#  locked (uninstall keeps working on Windows).
# --------------------------------------------------------------------------
QW_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qw")


def _qw_available():
    if sys.platform == "win32":
        names = ("lib_quadwild.dll", "lib_quadpatches.dll")
    elif sys.platform == "darwin":
        names = ("liblib_quadwild.dylib", "liblib_quadpatches.dylib")
    else:
        names = ("liblib_quadwild.so", "liblib_quadpatches.so")
    need = names + ("qw_worker.py",)
    return all(os.path.isfile(os.path.join(QW_DIR, n)) for n in need)


def _half_input(co, lv, lt, axis_i):
    """Keep the + side of the mirror plane (QuadWild has no mirror mode: one
    half is solved, mirrored and welded, so both sides are exactly equal)."""
    me = _build_mesh(co, lv, lt)
    bm = bmesh.new()
    bm.from_mesh(me)
    no = [0.0, 0.0, 0.0]
    no[axis_i] = 1.0
    bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], dist=1e-6,
                           plane_co=(0.0, 0.0, 0.0), plane_no=no,
                           clear_outer=False, clear_inner=True)
    bm.to_mesh(me)
    bm.free()
    me.update()
    a = _arrays_of(me)
    bpy.data.meshes.remove(me)
    return a


def _qw_mirror(arr, axis_i):
    co, lv, lt = arr
    me = _build_mesh(co, lv, lt)
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    # points of the open cut that the solver smoothed a hair off the plane go back on it
    bm = bmesh.new()
    bm.from_mesh(me)
    lens = sorted(e.calc_length() for e in bm.edges)
    ae = lens[len(lens) // 2] if lens else diag * 0.01
    for e in bm.edges:
        if e.is_boundary:
            for v in e.verts:
                if abs(v.co[axis_i]) <= ae * 0.5:
                    v.co[axis_i] = 0.0
    bm.to_mesh(me)
    bm.free()
    me.update()
    mi = _mirror_mesh(me, axis_i)
    full = _join_meshes([me, mi])
    _weld_mirror_seam(full, axis_i, diag)
    out = _arrays_of(full)
    for m in (me, mi, full):
        try:
            bpy.data.meshes.remove(m)
        except Exception:
            pass
    return out


def _qw_solve(s, jobs, inputs):
    """Solve with QuadWild.  One solve per input (QuadWild is deterministic, so
    extra Best-of-N seeds would only repeat it).  Returns dict like _qf_isolated
    or None when the engine can not run at all."""
    first = {}
    for j in jobs:
        first.setdefault(j["input"], j)
    qjobs, qinputs, half = [], {}, {}
    axis_of = {'X': 0, 'Y': 1, 'Z': 2}
    for iid, j in first.items():
        co, lv, lt = inputs[iid]
        target = int(j["target"])
        ax = axis_of.get(j["sym"])
        arr = (co, lv, lt)
        if ax is not None:
            h = _half_input(co, lv, lt, ax)
            if len(h[2]) >= 30:
                arr, target = h, max(20, target // 2)
                half[j["id"]] = ax
        qinputs[iid] = arr
        qj = dict(j)
        qj.update(target=target, libdir=QW_DIR, sharp_angle=math.degrees(s.sharp_angle),
                  faces=int(len(arr[2])), pre=True, smooth=True)
        qjobs.append(qj)

    def limit(j):
        return 30.0 + j["faces"] / 1000.0 + j["target"] / 200.0

    res = _qf_isolated(qjobs, qinputs, worker_path=os.path.join(QW_DIR, "qw_worker.py"),
                       limit_fn=limit)
    if res is None:
        return None
    out = {}
    for j in jobs:
        f = first[j["input"]]
        if j is not f:
            out[j["id"]] = 'fail'
            continue
        r = res.get(j["id"], 'fail')
        if isinstance(r, tuple) and j["id"] in half:
            try:
                r = _qw_mirror(r, half[j["id"]])
            except Exception as ex:
                print("[Remesh Ultimate] QuadWild mirror failed:", ex)
                r = 'fail'
        out[j["id"]] = r
    return out


def _solve_jobs(context, s, jobs, inputs):
    res = None
    if getattr(s, "engine", 'QUADRIFLOW') == 'QUADWILD' and _qw_available():
        try:
            res = _qw_solve(s, jobs, inputs)
        except Exception as ex:
            print("[Remesh Ultimate] QuadWild unavailable:", ex)
            res = None
        if res is not None:
            # parts QuadWild could not solve fall back to QuadriFlow, seed by seed
            left = [j for j in jobs if not isinstance(res.get(j["id"]), tuple)]
            solved_in = {j["input"] for j in jobs if isinstance(res.get(j["id"]), tuple)}
            left = [j for j in left if j["input"] not in solved_in]
            if left:
                print("[Remesh Ultimate] QuadWild fallback to QuadriFlow: %d solve(s)" % len(left))
                res.update(_solve_jobs_qf(context, s, left, inputs))
            return res
    return _solve_jobs_qf(context, s, jobs, inputs)


def _solve_jobs_qf(context, s, jobs, inputs):
    res = None
    if s.isolated:
        res = _qf_isolated(jobs, inputs)
    if res is None:
        for j in jobs:
            j["sharp"] = False
        res = _qf_inprocess(context, jobs, inputs)
    return res


# --------------------------------------------------------------------------
#  Per-part work, in two phases (prepare -> batch solve -> finish)
# --------------------------------------------------------------------------
class _PartWork:
    pass


def _arrays_of(me):
    co, lv, _ls, lt = _mesh_arrays(me)
    return co, lv, lt


def _prepare_part(context, key, part, s, target, sym, merge_dist, info=None, ref_bvh=None,
                  guides=None):
    w = _PartWork()
    w.key, w.target, w.sym = key, target, sym
    if info is None:
        info = _analyze_fast(part, merge_dist)
    w.border0 = _boundary_loops(part)        # real openings, before any repair
    if info["nonmanifold_edges"] or info["inconsistent"] or info["loose"] or info["duplicates"]:
        _repair_part(part, merge_dist)
        info = _analyze_fast(part, merge_dist)
        ref_bvh = None
    w.part = part
    w.info = info
    w.closed = info["boundary_edges"] == 0
    w.co = _mesh_co(part)
    w.diag = float(np.linalg.norm(w.co.max(axis=0) - w.co.min(axis=0))) or 1.0
    w.ref_bvh = ref_bvh if ref_bvh is not None else _bvh_from_mesh(part)
    w.ref_pts = _sample_points(part)
    est_edge = math.sqrt(max(info["area"], 1e-12) / max(target, 1))
    w.feats = None
    if len(part.polygons) <= 400000:
        w.feats = _extract_features(part, s.sharp_angle, s.preserve_boundary, est_edge / 3.0,
                                    mode=s.sharp_mode, extra=guides)
    w.hard = bool(w.feats is not None and w.feats.hard)

    # candidate solver inputs, best first (built lazily)
    tris = _tri_count(part)
    cap = max(target * 12, 30000)
    stages = []

    def mk_turbo():
        tmp = _new_temp_object(context, _tmp_copy(part), "RU_turbo")
        if w.closed:
            _voxelize(context, tmp, info["area"], target * 6)
        else:
            _eval_modifier(context, tmp, 'DECIMATE', decimate_type='COLLAPSE',
                           ratio=cap / tris, use_collapse_triangulate=True)
        return _arrays_of(tmp.data)

    def mk_direct():
        return _arrays_of(part)

    def mk_tri():
        tmp = _new_temp_object(context, _tmp_copy(part), "RU_tri")
        _eval_modifier(context, tmp, 'TRIANGULATE')
        return _arrays_of(tmp.data)

    def mk_vox(mult):
        def f():
            tmp = _new_temp_object(context, _tmp_copy(part), "RU_vox")
            _voxelize(context, tmp, info["area"], target * mult)
            return _arrays_of(tmp.data)
        return f

    if s.turbo and tris > cap * 1.3:
        stages.append(("turbo", mk_turbo))
    stages.append(("direct", mk_direct))
    if not w.closed:
        stages.append(("tri", mk_tri))
    if w.closed:
        stages.append(("voxel x3", mk_vox(3)))
        stages.append(("voxel x2", mk_vox(2)))
    w.stages = stages
    w.stage = 0
    w.no_sharp = set()
    w.result = None
    w.tag = None
    w.sym_dropped = False
    w.retry_same = False
    w.lumpy = False
    w.backup = None
    w.backup_bad = 1e9
    return w


# 1.6.4 wrinkle test (measured on real runs: clean solves 0 - 0.3 % flipped quads and
# no vertex off the surface; wrinkled solves 5 - 9 % flipped or vertices 1 - 21 quad
# edges away).  Distance percentiles are NOT used to reject: on a noisy sculpt with
# big quads they are naturally high and would throw away good results.
LUMP_MAX = 1.0    # no result vertex may float more than one quad edge off the surface
LUMP_FLIP = 3.0   # at most this % of quads may face against the surface below them
DENSE_KEEP = 4.0  # a part with more than this x its quad budget is never kept as-is


def _shape_check(ref_pts, ref_bvh, res_me, tol, edge):
    """Coverage of the original surface plus how far the two surfaces stray apart,
    both ways.  Lumps and dents: the original strays from the result.  Spikes and
    folds: the result strays from the original.  Measured in quad edges."""
    if len(res_me.polygons) == 0 or len(ref_pts) == 0:
        return 0.0, 1e9, 1e9, 1e9, 90.0, 1e9
    bvh = _bvh_from_mesh(res_me)
    d = np.full(len(ref_pts), 1e9)
    for i, p in enumerate(ref_pts.tolist()):
        r = bvh.find_nearest(p)
        if r[0] is not None:
            d[i] = r[3]
    cover = float((d <= tol).mean())
    e = max(edge, 1e-12)
    p90 = float(np.percentile(d, 90)) / e
    p99 = float(np.percentile(d, 99)) / e
    # every result vertex: a single spike is enough to spoil a part
    rp = _mesh_co(res_me)
    d2 = np.full(len(rp), 1e9)
    for i, p in enumerate(rp.tolist()):
        r = ref_bvh.find_nearest(p)
        if r[0] is not None:
            d2[i] = r[3]
    dmax = 0.0
    if len(d2):
        p90 = max(p90, float(np.percentile(d2, 90)) / e)
        p99 = max(p99, float(np.percentile(d2, 99)) / e)
        dmax = float(d2.max()) / e
    # crumpled quads (folds that stay on the surface): the quad faces another way
    # than the surface below it
    nf = len(res_me.polygons)
    fc = np.empty(nf * 3)
    res_me.polygons.foreach_get("center", fc)
    fn = np.empty(nf * 3)
    res_me.polygons.foreach_get("normal", fn)
    fc, fn = fc.reshape(-1, 3), fn.reshape(-1, 3)
    # quads stretched over a hole or a gap keep their corners on the surface, but
    # their middle floats over empty space
    dc = np.zeros(nf)
    for i, p in enumerate(fc.tolist()):
        r = ref_bvh.find_nearest(p)
        dc[i] = r[3] if r[0] is not None else 1e9
    span = float(np.percentile(dc, 99.5)) / e if nf else 0.0
    pick = np.arange(0, nf, max(1, nf // 4000))
    dots = np.ones(len(pick))
    for k, i in enumerate(pick.tolist()):
        r = ref_bvh.find_nearest(fc[i].tolist())
        if r[1] is not None:
            dots[k] = r[1].dot(Vector(fn[i]))
    if dots.mean() < 0.0:              # the result is wound the other way as a whole
        dots = -dots
    tilt = float((dots < -0.2).mean() * 100.0)     # % of quads flipped against the surface
    return cover, p90, p99, dmax, tilt, span


def _finish_candidates(w, s, cands, tag):
    best, best_q = None, None
    for (co, lv, lt) in cands:
        m = _build_mesh(co, lv, lt)
        q = _mesh_quality(m, w.ref_bvh, w.co, w.diag, w.target)
        if best is None or q["score"] > best_q["score"]:
            if best is not None:
                bpy.data.meshes.remove(best)
            best, best_q = m, q
        else:
            bpy.data.meshes.remove(m)
    if best is None:
        return None
    ae = _avg_edge(best) or w.diag * 0.01
    _fit_to_surface(best, w.ref_bvh, w.feats, s, w.sym, ae)
    tol = max(ae * 0.75, w.diag * 0.004)
    cover, p90, p99, dmax, tilt, span = _shape_check(w.ref_pts, w.ref_bvh, best, tol, ae)
    w.check = (round(cover, 3), round(p90, 2), round(p99, 2), round(dmax, 2), round(tilt, 1), round(span, 2))
    # 1.6.4: openings (air intakes, windows) must stay open - a solve that
    # stretches quads over them changes the model
    border_ok = True
    if getattr(w, "border0", None) and s.preserve_boundary:
        # every opening big enough for the quads (3 edges round) must still be there
        need = sorted((L for L in w.border0 if L >= ae * 3.0), reverse=True)
        have = sorted((L for L in _boundary_loops(best) if L >= ae * 1.5), reverse=True)
        # every opening needs its own border of a similar size in the result
        border_ok = len(have) >= len(need) and all(
            h >= n * 0.6 for n, h in zip(need, have))
    if not border_ok and getattr(w, "organic_cut", False):
        # 1.8.5: peca organica cortada: o solver fecha os furos onde as
        # vizinhas encaixam (orelha na cabeca, mao no pulso). Para partes
        # separadas isso e bom: a junta fica sem fresta.
        border_ok = True
    if not border_ok and getattr(w, "organic", False):
        # 1.8.4: num corpo organico as aberturas sao encaixes escondidos por
        # outra peca (tornozelo dentro do sapato, pescoco dentro da cabeca);
        # fecha-las nao muda o modelo - isso sozinho nao recusa a peca
        border_ok = True
    w.check = w.check + (border_ok,)
    flip_max = LUMP_FLIP * (2.0 if getattr(w, "organic_cut", False) else 1.0)
    if cover >= COVER_MIN and dmax <= LUMP_MAX and tilt <= flip_max and border_ok:
        w.tag = tag
        return best
    w.lumpy = cover >= COVER_MIN
    if w.lumpy:
        # keep the least wrinkled solve in reserve: a dense part (a sculpt) must
        # still come out light even if no solve passes the wrinkle test
        bad = tilt + 10.0 * max(0.0, dmax - LUMP_MAX)
        if w.backup is None or bad < w.backup_bad:
            if w.backup is not None:
                bpy.data.meshes.remove(w.backup)
            w.backup, w.backup_bad = best, bad
            return None
    bpy.data.meshes.remove(best)
    return None


def _finish_guarded(w, s, mine, res, tag):
    """Finish a part.  1.6.4 symmetry guard: QuadriFlow's own mirror mode can wrinkle
    a part (lumps / spikes on joined or repaired meshes).  If the mirrored solve
    fails the wrinkle test, the same input is solved again without the mirror."""
    cands = [res[j["id"]] for j in mine if isinstance(res.get(j["id"]), tuple)]
    m = _finish_candidates(w, s, cands, tag) if cands else None
    if m is None and w.sym != 'NONE' and not w.sym_dropped:
        w.sym_dropped = True
        w.sym = 'NONE'
        w.retry_same = True
    return m


def _solve_parts(context, s, works):
    """Batch-solve every part; each round tries the next input for parts still open."""
    rnd = 0
    while True:
        open_w = [w for w in works if w.result is None and w.stage < len(w.stages)]
        if not open_w:
            break
        rnd += 1
        jobs, inputs = [], {}
        for w in open_w:
            tag, builder = w.stages[w.stage]
            iid = "p%s_s%d" % (w.key, w.stage)
            arr = builder()
            inputs[iid] = arr
            sharp = w.hard and (w.stage not in w.no_sharp)
            for k in range(max(1, s.tries)):
                jobs.append(dict(id="%s_r%d_k%d" % (iid, rnd, k), input=iid, target=int(w.target),
                                 seed=int(s.seed + k * 7919), sym=w.sym, sharp=bool(sharp),
                                 boundary=bool(s.preserve_boundary), faces=int(len(arr[2])),
                                 part=w.key))
        res = _solve_jobs(context, s, jobs, inputs)
        for w in open_w:
            mine = [j for j in jobs if j["part"] == w.key]
            cands = [res[j["id"]] for j in mine if isinstance(res.get(j["id"]), tuple)]
            timed_out = any(res.get(j["id"]) == 'timeout' for j in mine)
            was_sharp = any(j["sharp"] for j in mine)
            m = _finish_guarded(w, s, mine, res, w.stages[w.stage][0])
            if m is not None:
                w.result = m
                continue
            if w.retry_same:
                w.retry_same = False            # same input again, without the mirror
                continue
            if timed_out and was_sharp and not cands:
                w.no_sharp.add(w.stage)        # same input again, without the slow sharp mode
                continue
            w.stage += 1
        _cleanup_temp(context)

    # last resort for solids: plain voxel quads (no solver involved)
    for w in works:
        if w.result is None and w.closed:
            tmp = _new_temp_object(context, _tmp_copy(w.part), "RU_fb")
            vs = _voxel_size_for(w.info["area"], w.target)
            _eval_modifier(context, tmp, 'REMESH', mode='VOXEL', voxel_size=vs, adaptivity=0.0)
            m = _finish_candidates(w, s, [_arrays_of(tmp.data)], "voxel quads")
            if m is not None:
                w.result = m
    _cleanup_temp(context)



# --------------------------------------------------------------------------
#  Quadify: exact-shape conversion for well-modelled low-poly / hard-surface
#  parts. A solver can never beat a clean hand-made mesh at the same density,
#  so the existing topology is turned into quads instead of being rebuilt.
# --------------------------------------------------------------------------
def _crease_info(me, angle):
    ne = len(me.edges)
    if ne == 0 or len(me.polygons) == 0:
        return 0, 0.0
    le = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("edge_index", le)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    pol = np.repeat(np.arange(len(lt), dtype=np.int64), lt)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    efc = np.bincount(le, minlength=ne)
    order = np.argsort(le, kind='stable')
    le_s, pol_s = le[order], pol[order]
    starts = np.searchsorted(le_s, np.arange(ne))
    two = np.flatnonzero(efc == 2)
    dots = np.einsum('ij,ij->i', fn[pol_s[starts[two]]], fn[pol_s[starts[two] + 1]])
    n = int((dots < math.cos(angle)).sum())
    return n, n / max(ne, 1)


def _quad_ratio(me):
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    return float((lt == 4).mean()) if len(lt) else 1.0


def _is_star_shaped(f):
    c = f.calc_center_median()
    n = f.normal
    vs = [v.co for v in f.verts]
    for i in range(len(vs)):
        a, b = vs[i] - c, vs[(i + 1) % len(vs)] - c
        if a.cross(b).dot(n) <= 0.0:
            return False
    return True


def _pair_fans(bm, fan):
    """Join the fan triangles of a poked n-gon two by two (exact, no search)."""
    centers = {}
    fs = set(fan)
    for f in fan:
        for v in f.verts:
            if all(x in fs for x in v.link_faces):
                centers.setdefault(v, []).append(f)
                break
    for cv, tris in centers.items():
        # order triangles around the centre
        ring = []
        start = tris[0]
        seen = {start}
        ring.append(start)
        cur = start
        while True:
            nxt = None
            for e in cur.edges:
                if cv in e.verts:
                    for lf in e.link_faces:
                        if lf is not cur and lf in fs and lf not in seen:
                            nxt = lf
                            break
                if nxt:
                    break
            if nxt is None:
                break
            ring.append(nxt)
            seen.add(nxt)
            cur = nxt
        if len(ring) != len(tris) or len(ring) % 2:
            continue
        for k in range(0, len(ring), 2):
            a, b = ring[k], ring[k + 1]
            shared = [e for e in a.edges if e in b.edges and cv in e.verts]
            if shared:
                bmesh.ops.dissolve_edges(bm, edges=shared, use_verts=False)


def _quadify(me, s):
    """Same shape, (almost) all quads: join triangle pairs, split n-gons cleanly."""
    m = _tmp_copy(me)
    bm = bmesh.new()
    bm.from_mesh(m)
    ang = math.radians(40.0)
    for _round in range(2):
        tri = [f for f in bm.faces if len(f.verts) == 3]
        if tri:
            bmesh.ops.join_triangles(bm, faces=tri, angle_face_threshold=ang,
                                     angle_shape_threshold=ang)
        ngons = [f for f in bm.faces if len(f.verts) > 4]
        if not ngons:
            break
        even = [f for f in ngons if len(f.verts) % 2 == 0 and _is_star_shaped(f)]
        other = [f for f in ngons if f not in set(even)]
        if even:
            # even n-gon -> centre point + n/2 radial quads (classic cap topology)
            res = bmesh.ops.poke(bm, faces=even)
            fan = [f for f in res["faces"] if f.is_valid]
            _pair_fans(bm, fan)
        if other:
            # odd / irregular n-gons -> beauty triangles -> paired into quads next round
            bmesh.ops.triangulate(bm, faces=other, quad_method='BEAUTY', ngon_method='BEAUTY')
    bm.to_mesh(m)
    bm.free()
    m.update()
    if s.pure_quads and _quad_ratio(m) < 1.0:
        # one flat (simple) subdivision: 100 % quads, shape unchanged
        tmp = bpy.data.objects.new("RU_pq", m)
        _temp_collection(bpy.context).objects.link(tmp)
        _eval_modifier(bpy.context, tmp, 'SUBSURF', subdivision_type='SIMPLE', levels=1,
                       render_levels=1)
        m = _tmp_copy(tmp.data)
    return m


def _purge_tmp_meshes():
    for m in list(bpy.data.meshes):
        if m.name.startswith(TMP_PREFIX) and m.users == 0:
            bpy.data.meshes.remove(m)


def _border_loops_bm(bm):
    """Contornos abertos de um bmesh: lista de listas de vertices (em ordem)."""
    edges = [e for e in bm.edges if e.is_boundary]
    adj = {}
    for e in edges:
        a, b = e.verts
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)
    seen, loops = set(), []
    for v0 in adj:
        if v0 in seen:
            continue
        loop, prev, cur = [v0], None, v0
        seen.add(v0)
        while True:
            nxt = [w for w in adj[cur] if w is not prev and w not in seen]
            if not nxt:
                break
            prev, cur = cur, nxt[0]
            seen.add(cur)
            loop.append(cur)
        loops.append(loop)
    return loops


def _snap_border(res_me, src_me):
    """1.8.12: cada contorno aberto de `res_me` e casado com o contorno do
    corte original (`src_me`) mais parecido e puxado inteiro para ele.  Pecas
    vizinhas cortadas da mesma malha vao para a mesma linha: a fresta fecha,
    e um contorno nunca e puxado para o contorno errado."""
    from mathutils.kdtree import KDTree
    sb = bmesh.new()
    sb.from_mesh(src_me)
    sloops = _border_loops_bm(sb)
    if not sloops:
        sb.free()
        return 0
    trees, cents = [], []
    for lp in sloops:
        pts = []
        for k in range(len(lp)):
            a, b = lp[k].co, lp[(k + 1) % len(lp)].co
            n = max(1, int((a - b).length / 0.004))
            for t in range(n):
                pts.append(a.lerp(b, t / n))
        kd = KDTree(len(pts))
        for q, c in enumerate(pts):
            kd.insert(c, q)
        kd.balance()
        trees.append(kd)
        cents.append(sum((v.co for v in lp), lp[0].co * 0) / len(lp))
    sb.free()
    rb = bmesh.new()
    rb.from_mesh(res_me)
    moved = 0
    for lp in _border_loops_bm(rb):
        # contorno do corte mais parecido: menor distancia media
        best, best_d = None, 1e18
        for k, kd in enumerate(trees):
            d = sum(kd.find(v.co)[2] for v in lp[::max(1, len(lp) // 12)])
            if d < best_d:
                best, best_d = k, d
        if best is None:
            continue
        el = [e.calc_length() for v in lp for e in v.link_edges]
        lim = (sorted(el)[len(el) // 2] if el else 0.0) * 2.0
        for v in lp:
            co, _i, d = trees[best].find(v.co)
            if d <= lim:            # 1.8.12: so ate 2 quads - mais que isso deforma
                v.co = co
                moved += 1
    if moved:
        rb.to_mesh(res_me)
        res_me.update()
    rb.free()
    return moved


def _part_fits(res_me, src_me):
    """1.8.12: a peca refeita encaixa no lugar?  (1) cada ponto do contorno
    do corte original tem a peca nova encostada, (2) nada dobrado (normais
    contra a superficie original)."""
    sb = bmesh.new()
    sb.from_mesh(src_me)
    pts = [v.co.copy() for v in sb.verts if v.is_boundary]
    el = sorted(e.calc_length() for e in sb.edges)
    sb.free()
    ae = el[len(el) // 2] if el else 0.0
    rbvh = _bvh_from_mesh(res_me)
    tol = max(ae * 0.6, 1e-6)
    far = sum(1 for q in pts if (rbvh.find_nearest(q)[3] or 0.0) > tol)
    if pts and far > max(2, 0.03 * len(pts)):
        return False
    sbvh = _bvh_from_mesh(src_me)
    nf = len(res_me.polygons)
    fc = np.empty(nf * 3)
    res_me.polygons.foreach_get("center", fc)
    fn = np.empty(nf * 3)
    res_me.polygons.foreach_get("normal", fn)
    fc, fn = fc.reshape(-1, 3), fn.reshape(-1, 3)
    flips = 0
    for i in range(nf):
        r = sbvh.find_nearest(fc[i].tolist())
        if r[1] is not None and r[1].dot(Vector(fn[i])) < -0.3:
            flips += 1
    return flips <= max(1, int(0.01 * nf))


def _clean_grid(me, max_poles=0.15):
    """1.8.12: True quando a malha ja e quase toda quad e com poucos polos
    (vertices internos com valencia != 4) - topologia boa, feita a mao."""
    if len(me.polygons) < 24:
        return False
    if _quad_ratio(me) < 0.98:
        return False
    ed = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ed)
    ed = ed.reshape(-1, 2)
    val = np.bincount(ed.ravel(), minlength=len(me.vertices))
    # arestas de borda: usadas por uma face so
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    me.polygons.foreach_get("loop_total", lt)
    nxt = np.arange(len(lv)) + 1
    ends = ls + lt
    wrap = np.isin(nxt, ends)
    nxt[wrap] = np.repeat(ls, lt)[wrap]
    a, b = np.minimum(lv, lv[nxt]), np.maximum(lv, lv[nxt])
    key, cnt = np.unique(a * len(me.vertices) + b, return_counts=True)
    bk = key[cnt == 1]
    border = np.zeros(len(me.vertices), dtype=bool)
    border[bk // len(me.vertices)] = True
    border[bk % len(me.vertices)] = True
    inner = ~border
    if inner.sum() < 12:
        return False
    return float((val[inner] != 4).mean()) < max_poles


ORGANIC_DENSE = {"Hand": 2.6, "Glove": 2.6, "Ear": 2.0, "Foot": 1.4,
                 "Head": 2.2, "Hat": 1.5, "Hair": 1.5}   # 1.8.5: quads extra nas pontas


def _split_by_areas(me, vlab):
    """1.8.5: pedacos (area detectada x peca solta) da malha de trabalho.
    Devolve (meshes, area de cada uma, se e uma peca solta inteira)."""
    co, lv, ls, lt = _mesh_arrays(me)
    nf = len(lt)
    flab = np.empty(nf, dtype=np.int32)
    me.attributes["ru_lab"].data.foreach_get("value", flab)
    fcomp = vlab[lv[ls]]
    # peca solta inteira = todas as faces dela na mesma area
    ncomp = int(fcomp.max()) + 1 if nf else 0
    lo_ = np.full(ncomp, 1 << 30)
    hi_ = np.full(ncomp, -1)
    np.minimum.at(lo_, fcomp, flab)
    np.maximum.at(hi_, fcomp, flab)
    key = flab.astype(np.int64) * max(ncomp, 1) + fcomp
    order = np.argsort(key, kind='stable')
    bounds = np.flatnonzero(np.diff(key[order])) + 1
    parts, labs, whole = [], [], []
    for faces in np.split(order, bounds):
        if len(faces) == 0:
            continue
        # um pedaco de area que se partiu em ilhas (vizinhos so pelo canto)
        # continua sendo um pedaco: o solver lida com isso
        sel_lt = lt[faces]
        idx = _loop_ranges(ls[faces], sel_lt)
        uniq, remap = np.unique(lv[idx], return_inverse=True)
        parts.append(_build_mesh(co[uniq], remap.astype(np.int64), sel_lt))
        labs.append(int(flab[faces[0]]))
        c = int(fcomp[faces[0]])
        whole.append(bool(lo_[c] == hi_[c]))
    return parts, labs, whole


# --------------------------------------------------------------------------
#  Limpeza de fluxo: rotacao de arestas para cancelar polos
#
#  Um polo e um vertice interno com valencia != 4. Quando um polo 5 e um
#  polo 3 ficam cruzados num par de quads, girar a aresta compartilhada
#  zera os dois: a aresta sai dos vertices a,b (que perdem 1 de valencia)
#  e entra nos vertices x,y (que ganham 1). Nenhum vertice se move, e dois
#  quads continuam dois quads -- logo a forma e a % de quads nao mudam.
# --------------------------------------------------------------------------
FLOW_PASSES = 6
FLOW_FOLD_DOT = 0.25


def _bm_poles(bm):
    n = 0
    for v in bm.verts:
        if not v.is_boundary and len(v.link_edges) != 4:
            n += 1
    return n


def _irr(v, d=0):
    """Quanto esse vertice foge do ideal (valencia 4). Borda nao conta."""
    if v.is_boundary:
        return 0
    return abs(len(v.link_edges) + d - 4)


def _quad_n(a, b, c, d):
    return (c.co - a.co).cross(d.co - b.co)


def _edge_between(x, y):
    for e in x.link_edges:
        if e.other_vert(x) is y:
            return True
    return False


def _rot_candidates(bm):
    """Arestas internas cuja rotacao reduz o total de irregularidade."""
    out = []
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        f1, f2 = e.link_faces
        if len(f1.verts) != 4 or len(f2.verts) != 4:
            continue
        a, b = e.verts
        if a.is_boundary or b.is_boundary:
            continue
        if len(a.link_edges) < 4 or len(b.link_edges) < 4:
            continue
        ends = []
        for f in (f1, f2):
            vs = list(f.verts)
            i = -1
            for k in range(4):
                pair = (vs[k], vs[(k + 1) % 4])
                if pair == (a, b) or pair == (b, a):
                    i = k
                    break
            if i < 0:
                ends = []
                break
            if vs[i] is a:                      # ordem a -> b
                ends.append((vs[(i - 1) % 4], vs[(i + 2) % 4]))
            else:                               # ordem b -> a
                ends.append((vs[(i + 2) % 4], vs[(i - 1) % 4]))
        if len(ends) != 2:
            continue
        (q1, p1), (q2, p2) = ends              # q = vizinho de a, p = vizinho de b
        base = _irr(a) + _irr(b)
        drop = _irr(a, -1) + _irr(b, -1)
        best = None
        for x, y in ((q1, p2), (p1, q2)):
            if x is y or x.is_boundary or y.is_boundary:
                continue
            if _edge_between(x, y):
                continue
            delta = (drop + _irr(x, 1) + _irr(y, 1)) - (base + _irr(x) + _irr(y))
            if delta >= 0:
                continue
            if best is None or delta < best[0]:
                best = (delta, x, y)
        if best is None:
            continue
        delta, x, y = best
        # dobra: as faces novas tem de olhar para o mesmo lado das antigas.
        # a referencia e a configuracao ATUAL medida com esta mesma travessia
        # do hexagono (q1,a,q2,p2,b,p1), para o sinal se cancelar
        n0 = _quad_n(a, q2, p2, b) + _quad_n(b, p1, q1, a)
        if n0.length < 1e-12:
            continue
        n0.normalize()
        if x is q1:                             # hexagono q1,a,q2,y,b,p1
            new = ((q1, a, q2, y), (q1, y, b, p1))
        else:                                   # diagonal p1-q2
            new = ((q2, p2, b, p1), (p1, q1, a, q2))
        ok = True
        for quad in new:
            nn = _quad_n(*quad)
            if nn.length < 1e-12 or nn.normalized().dot(n0) < FLOW_FOLD_DOT:
                ok = False
                break
        if ok:
            out.append((delta, e, x, y))
    out.sort(key=lambda t: t[0])
    return out


def _flow_pass(bm):
    """Um passe guloso. Devolve quantas arestas girou."""
    cands = _rot_candidates(bm)
    if not cands:
        return 0
    dirty = set()
    done = 0
    for delta, e, x, y in cands:
        if not e.is_valid or not x.is_valid or not y.is_valid:
            continue
        a, b = e.verts
        if (a.index in dirty or b.index in dirty
                or x.index in dirty or y.index in dirty):
            continue
        want = {x, y}
        try:
            r = bmesh.ops.rotate_edges(bm, edges=[e], use_ccw=False)
            ne = r.get("edges", [])
            if not ne:
                continue
            ne = ne[0]
            # as tres diagonais do hexagono se alternam a cada rotacao; se
            # caiu na outra, uma rotacao a mais chega na que queremos
            for _ in range(2):
                if set(ne.verts) == want:
                    break
                r = bmesh.ops.rotate_edges(bm, edges=[ne], use_ccw=False)
                nx = r.get("edges", [])
                if not nx:
                    break
                ne = nx[0]
            if set(ne.verts) != want:
                continue
        except Exception:
            continue
        done += 1
        for f in ne.link_faces:
            for v in f.verts:
                dirty.add(v.index)
    return done


def _reduce_poles(me, passes=FLOW_PASSES):
    """Gira arestas internas para cancelar polos. Nenhum vertice se move."""
    if len(me.polygons) < 8:
        return 0, 0, 0
    bm = bmesh.new()
    try:
        bm.from_mesh(me)
        bm.verts.index_update()
        bm.normal_update()
        before = _bm_poles(bm)
        total = 0
        for _ in range(max(1, int(passes))):
            n = _flow_pass(bm)
            if n == 0:
                break
            total += n
            bm.normal_update()
        after = _bm_poles(bm)
        if total:
            bm.to_mesh(me)
            me.update()
        return before, after, total
    except Exception as ex:
        print("[Remesh Ultimate] flow cleanup:", ex)
        return 0, 0, 0
    finally:
        bm.free()


def remesh_object(context, src, s):
    t0 = time.time()
    log = []

    # 1) evaluated copy (modifiers applied), scale baked in, origin kept
    dg = context.evaluated_depsgraph_get()
    ev = src.evaluated_get(dg)
    base_me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=False, depsgraph=dg)
    base_me.name = TMP_PREFIX
    # work in true world proportions (rotation + any scale, even negative),
    # then bring the result back so it keeps the original transform
    lin = _work_matrix(src)
    if abs(lin.determinant()) < 1e-12:
        raise RuntimeError("Object has zero scale")
    flipped = lin.determinant() < 0.0
    base_me.transform(lin.to_4x4())
    if flipped:
        base_me.flip_normals()
    result_matrix = src.matrix_world.copy()

    # 1.8.5: corpo organico -> cortar ANTES e retopologizar cada parte.
    # As areas detectadas vao para a malha de trabalho como atributo de face
    # (sobrevive a solda de pontos duplicados e a solda do plano de simetria).
    _ao_src = _areas_obj(src)
    organic_src = (getattr(s, "detect_mode", 'AUTO') == 'ORGANIC'
                   or (_ao_src is not None and _ao_src.get("ru_mode") == 'ORGANIC'))
    area_meta = None
    if (organic_src and _ao_src is not None and (s.separate_parts or s.color_parts)
            and "ru_area" in _ao_src.data.attributes
            and len(_ao_src.data.polygons) == len(base_me.polygons)):
        try:
            area_meta = _area_meta(_ao_src)
            at = base_me.attributes.new("ru_lab", 'INT', 'FACE')
            at.data.foreach_set("value", area_meta["lab"].astype(np.int32))
        except Exception as ex:
            print("[Remesh Ultimate] area labels:", ex)
            area_meta = None

    co0 = _mesh_co(base_me)
    if len(co0) == 0 or len(base_me.polygons) == 0:
        raise RuntimeError("Object has no faces")
    diag = float(np.linalg.norm(co0.max(axis=0) - co0.min(axis=0)))
    merge_dist = diag * 1e-5

    # 2) symmetry: the mirror plane may pass through the object origin OR through
    #    the middle of the model (meshes modelled away from their origin)
    sym_axis, offset = 'NONE', Vector((0.0, 0.0, 0.0))
    if s.symmetry != 'NONE':
        mid = (co0.min(axis=0) + co0.max(axis=0)) * 0.5
        probe_bvh = _bvh_from_mesh(base_me)
        axes = "XYZ" if s.symmetry == 'AUTO' else s.symmetry
        found = False
        for plane in ("origin", "middle"):
            for ax in axes:
                ai = "XYZ".index(ax)
                c = 0.0 if plane == "origin" else float(mid[ai])
                shifted = co0.copy()
                shifted[:, ai] -= c
                bvh_s = probe_bvh if c == 0.0 else _bvh_from_mesh_shift(base_me, ai, c)
                if _is_symmetric(shifted, bvh_s, diag, ai):
                    sym_axis = ax
                    offset[ai] = c
                    found = True
                    break
            if found:
                break
        if not found and s.symmetry != 'AUTO':
            sym_axis = s.symmetry          # forced by the user, plane at the origin
    if offset.length > 0.0:
        base_me.transform(Matrix.Translation(-offset))
        co0 = _mesh_co(base_me)
    axis_i = "XYZ".index(sym_axis) if sym_axis in ('X', 'Y', 'Z') else -1
    if axis_i >= 0:
        # 1.6.5: halves joined by a Mirror modifier often stay open at the centre
        # (points a hair off the plane are not merged).  The solver then sees a
        # crack down the middle (dented wing).  Close that seam first.
        welded = _weld_mirror_seam(base_me, axis_i, diag)
        if welded:
            log.append("%d centre seam points welded" % welded)
            co0 = _mesh_co(base_me)

    # 1.8.4: o modelo foi reconhecido como corpo (modo Orgânico ou detectado)?
    # areas / drawn lines become guides the quads must follow
    guides = _guide_segments(src, lin, offset) if s.use_guides else None
    if guides is not None:
        log.append("%d guide segments" % len(guides[0]))
        gmid = (guides[0] + guides[1]) * 0.5

    # drawn lines alone: the user asked for a quad flow there, so such a part is
    # always rebuilt.  Area borders alone never force a rebuild (1.6.5).
    line_guides = _guide_segments(src, lin, offset, areas=False) if s.use_guides else None

    def part_guides(pmesh, guides=guides):
        if guides is None:
            return None
        gmid = (guides[0] + guides[1]) * 0.5
        pc = _mesh_co(pmesh)
        pad = diag * 0.02
        lo_, hi_ = pc.min(axis=0) - pad, pc.max(axis=0) + pad
        m = np.all((gmid >= lo_) & (gmid <= hi_), axis=1)
        if not m.any():
            return None
        # keep only segments that really lie on this part
        pb = _bvh_from_mesh(pmesh)
        keep = np.zeros(len(m), dtype=bool)
        tol = diag * 0.01
        for i in np.flatnonzero(m):
            r = pb.find_nearest(Vector(gmid[i]))
            keep[i] = r[0] is not None and r[3] <= tol
        if not keep.any():
            return None
        return guides[0][keep], guides[1][keep]

    # density: quads sized relative to the model, or a typed count
    QUAD_EDGE = {'S': 1 / 100.0, 'SM': 1 / 70.0, 'M': 1 / 50.0, 'ML': 1 / 35.0, 'L': 1 / 25.0}
    if s.quad_size in QUAD_EDGE:
        _ar = np.empty(len(base_me.polygons))
        base_me.polygons.foreach_get("area", _ar)
        edge = diag * QUAD_EDGE[s.quad_size]
        target_total = int(min(300000, max(60, float(_ar.sum()) / (edge * edge))))
    else:
        target_total = int(s.target_faces)
    log.append("~%d quads (%s)" % (target_total, s.quad_size))

    # the untouched original surface: used to measure the final result
    orig_pts = _sample_points(base_me, limit=6000, seed=11)
    if s.symmetry != 'NONE' and offset.length == 0.0:
        orig_bvh = probe_bvh
    else:
        orig_bvh = _bvh_from_mesh(base_me)

    # 3) parts
    single_info = None
    part_labels = None          # 1.8.5: area of every part (organic, cut first)
    part_whole = None           # ... and whether the part is a whole loose piece
    if s.clean_mode == 'VOXEL':
        tmp = _new_temp_object(context, _tmp_copy(base_me), "RU_merge")
        area = float(sum(p.area for p in base_me.polygons))
        _voxelize(context, tmp, area, min(max(target_total * 8, 40000), 600000))
        parts = [_tmp_copy(tmp.data)]
        log.append("parts merged (voxel)")
    elif s.clean_mode == 'NONE':
        parts = [_tmp_copy(base_me)]
    else:
        base_info = _analyze_fast(base_me, merge_dist)
        if base_info["duplicates"]:
            _weld = bmesh.new()
            _weld.from_mesh(base_me)
            bmesh.ops.remove_doubles(_weld, verts=_weld.verts[:], dist=merge_dist)
            _weld.to_mesh(base_me)
            _weld.free()
            base_me.update()
            base_info = None
            orig_bvh = _bvh_from_mesh(base_me)
        labels = _components(base_me)
        lp = np.empty(len(base_me.loops), dtype=np.int64)
        base_me.loops.foreach_get("vertex_index", lp)
        n_parts = len(np.unique(labels[lp]))
        if area_meta is not None and "ru_lab" in base_me.attributes:
            parts, part_labels, part_whole = _split_by_areas(base_me, labels)
            log.append("organic: cut first, %d area pieces" % len(parts))
        elif n_parts > 1:
            parts = _split_parts(base_me, labels)
        else:
            parts = [base_me]
            single_info = base_info
    log.append("%d part%s" % (len(parts), "s" if len(parts) != 1 else ""))

    areas = []
    for p in parts:
        a = np.empty(len(p.polygons))
        p.polygons.foreach_get("area", a)
        areas.append(float(a.sum()))
    total_area = sum(areas) or 1.0

    # 1.9.0: densidade adaptativa - quads menores onde ha detalhe, maiores no liso
    shares, adapt_w = _adaptive_shares(parts, areas, total_area, target_total,
                                       s.adaptive_density)
    if s.adaptive_density > 0 and len(parts) > 1:
        log.append("adaptive x%.2f-%.2f" % (min(adapt_w), max(adapt_w)))

    # 4) mirrored twins: solve one side, mirror the other (exact symmetry, half the work)
    info_parts = []
    for p, a in zip(parts, areas):
        c = _mesh_co(p)
        info_parts.append(dict(center=c.mean(axis=0), area=a, faces=len(p.polygons), twin=None))
    if axis_i >= 0:
        for i, pi in enumerate(info_parts):
            if pi["twin"] is not None or pi["center"][axis_i] <= diag * 1e-3:
                continue
            mc = pi["center"].copy()
            mc[axis_i] *= -1.0
            for j, pj in enumerate(info_parts):
                if j == i or pj["twin"] is not None:
                    continue
                if part_labels is not None and (
                        int(area_meta["twin"][part_labels[j]]) != int(part_labels[i])):
                    continue
                if (pj["faces"] == pi["faces"] and abs(pj["area"] - pi["area"]) <= 0.01 * pi["area"]
                        and np.linalg.norm(pj["center"] - mc) <= diag * 0.003):
                    pi["twin"], pj["twin"] = j, -1   # -1: produced by mirroring i
                    break

    # 5) solve every part: batched, isolated, parallel
    plan, works = [], []
    kept, mirrored, solved, quadified, clean = 0, 0, 0, 0, 0
    for i, (p, pinfo) in enumerate(zip(parts, info_parts)):
        if pinfo["twin"] == -1:
            continue
        share = shares[i]
        if len(parts) == 1:
            share = target_total
        detail = False
        if part_labels is not None:
            # 1.8.5: peca solta pequena (bigode, olho, botao): forma exata - o
            # QuadriFlow nao resolve e a peca sumia do resultado
            detail = bool(part_whole[i]) and pinfo["area"] < 0.03 * total_area
            # extremidades finas (mao, orelha, pe) ganham quads menores
            nm_ = area_meta["names"][part_labels[i]] if area_meta["names"] else ""
            if nm_ in ORGANIC_DENSE:
                share *= ORGANIC_DENSE[nm_]
            share = max(share, 60.0)
        if part_labels is not None and not detail and _clean_grid(p):
            # 1.8.12: a malha original desta peca ja e uma grade limpa de quads
            # (poucos polos): refazer so piora - fica a topologia original
            plan.append(('mesh', _tmp_copy(p), pinfo))
            clean += 1
            continue
        if detail or pinfo["faces"] <= 60 or share < 12:
            # tiny detail: exact shape, converted to quads
            if _quad_ratio(p) >= 0.98 and not s.pure_quads:
                plan.append(('mesh', _tmp_copy(p), pinfo))
                clean += 1
            else:
                plan.append(('mesh', _quadify(p, s), pinfo))
                quadified += 1
            continue
        target = int(max(share, 40))
        pg = part_guides(p)
        plg = part_guides(p, line_guides) if line_guides is not None else None
        # --- never make a part worse than its source
        src_faces = pinfo["faces"]
        qr = _quad_ratio(p)
        n_cr, fr_cr = _crease_info(p, s.sharp_angle)
        is_hard = s.sharp_mode != 'OFF' and n_cr >= 8 and (fr_cr >= 0.003 or s.sharp_mode == 'ON')
        low_poly = src_faces <= target * 1.5
        # 1.8.4: num corpo organico os vincos (aba de bone, botoes, unhas) nao
        # fazem dele hard-surface: "ja e quad e tem vincos" mantinha a malha
        # original inteira e a retopologia nunca acontecia ("Original kept")
        # 1.8.5: cortado antes (organico) = sempre retopologia de verdade; manter
        # a malha original era exatamente o que nao se queria (1277 polos)
        if s.method == 'QUADIFY' or (s.method == 'AUTO' and plg is None and part_labels is None and
                                     (low_poly or (is_hard and not organic_src
                                                   and src_faces <= 4000))):
            if qr >= 0.98 and not s.pure_quads:
                plan.append(('mesh', _tmp_copy(p), pinfo))
                clean += 1
            else:
                plan.append(('mesh', _quadify(p, s), pinfo))
                quadified += 1
            continue
        part_sym = 'NONE'
        if axis_i >= 0 and len(parts) == 1:
            part_sym = sym_axis
        elif axis_i >= 0 and abs(pinfo["center"][axis_i]) <= diag * 0.01:
            pc = _mesh_co(p)
            pdiag = float(np.linalg.norm(pc.max(axis=0) - pc.min(axis=0))) or 1.0
            if _is_symmetric(pc, _bvh_from_mesh(p), pdiag, axis_i):
                part_sym = sym_axis
        if p is base_me:
            w = _prepare_part(context, i, _tmp_copy(p), s, target, part_sym, merge_dist,
                              info=single_info, ref_bvh=orig_bvh, guides=pg)
        else:
            w = _prepare_part(context, i, p, s, target, part_sym, merge_dist, guides=pg)
        works.append(w)
        plan.append(('work', w, pinfo))

    for w in works:
        # cortado antes: as bordas sao os cortes entre partes e TEM de ficar
        w.organic = organic_src and part_labels is None
        w.organic_cut = part_labels is not None
    _solve_parts(context, s, works)

    # 1.8.4: num corpo organico uma peca que nenhum solve aceitou (dedos finos,
    # bordas abertas no pescoco / tornozelo) era devolvida com a malha
    # original - a retopologia "pulava" o corpo.  Antes disso, tenta de novo
    # com quads menores so naquela peca.
    if organic_src:
        for mult in (1.8, 3.0):
            retry = [w for w in works if w.result is None
                     and getattr(w, "backup", None) is None
                     and len(w.part.polygons) > w.target * 1.2]
            if not retry:
                break
            for w in retry:
                w.target = int(w.target * mult)
                w.stage = 0
                w.sym_dropped = False
                w.retry_same = False
                w.no_sharp = set()
            _solve_parts(context, s, retry)
            n_ok = sum(1 for w in retry if w.result is not None)
            if n_ok:
                log.append("%d organic part%s solved denser" % (n_ok, "s" if n_ok != 1 else ""))

    out_meshes = []
    out_labels = []
    symmetrized = 0
    plan_index = {id(pi_): k_ for k_, pi_ in enumerate(info_parts)}
    hard_parts = sum(1 for w in works if w.hard)
    for kind_, obj_, pinfo in plan:
        if kind_ == 'mesh':
            res = obj_
        elif obj_.result is None:
            if obj_.backup is not None and len(obj_.part.polygons) > DENSE_KEEP * obj_.target:
                # dense part: the best solve, even if not perfect, beats keeping it dense
                res, obj_.backup = obj_.backup, None
                solved += 1
            else:
                res = _quadify(obj_.part, s)
                quadified += 1
        else:
            # shape guard: if the quads are too coarse for this piece, keep its exact
            # shape instead (converted to quads) - small/thin parts stay crisp
            qq = _mesh_quality(obj_.result, obj_.ref_bvh, obj_.co, obj_.diag, obj_.target)
            allowed = 100.0 * 0.3 * _avg_edge(obj_.result) / max(obj_.diag, 1e-9)
            # 1.8.4: num corpo organico dedos e orelhas finos sempre desviam um
            # pouco mais; recusar por 0.03% devolvia a malha original inteira
            if organic_src:
                allowed = max(allowed * 1.6, 1.0)
            if qq["deviation_pct"] > max(allowed, 0.5):
                bpy.data.meshes.remove(obj_.result)
                res = _quadify(obj_.part, s)
                quadified += 1
            else:
                res = obj_.result
                solved += 1
                # 1.13.2: a centre part whose mirrored solve was refused came out
                # different on each side (kart body: 1225 quads on one side,
                # 1071 on the other, so the .L / .R parts did not match).
                # Keep one side and mirror it: identical halves, still all quads.
                if getattr(obj_, "sym_dropped", False) and axis_i >= 0:
                    try:
                        if _symmetrize_quads(res, axis_i, diag):
                            symmetrized += 1
                    except Exception as ex:
                        print("[Remesh Ultimate] symmetrize:", ex)
        if part_labels is not None:
            src_p = parts[plan_index[id(pinfo)]]
            # 1.8.7: confere a peca contra o PROPRIO pedaco original; se faltar
            # forma (gomos de cabelo, dedos), fica a malha original (ja e quad)
            if kind_ == 'work' and res is not obj_.part:
                try:
                    nm_p = (area_meta["names"][part_labels[plan_index[id(pinfo)]]]
                            if area_meta["names"] else "")
                    fine = nm_p in ("Glove", "Hand", "Ear")
                    # 1.8.11: maos/luvas e orelhas: tolerancia fina - um dedo
                    # perdido e defeito, mesmo que o resto da peca esteja bom
                    tol_p = (max(_avg_edge(src_p) * 0.5, diag * 0.002) if fine else
                             max(_avg_edge(res) * 0.5, _avg_edge(src_p) * 0.6, diag * 0.004))
                    cov_p = _coverage(_sample_points(src_p, limit=1500, seed=5), res, tol_p)
                    if cov_p < (0.97 if fine else 0.95):
                        bpy.data.meshes.remove(res)
                        res = _quadify(src_p, s)
                        solved -= 1
                        quadified += 1
                        log.append("%s kept exact (cover %.0f%%)" % (
                            area_meta["names"][part_labels[plan_index[id(pinfo)]]]
                            if area_meta["names"] else "part", 100.0 * cov_p))
                except Exception as ex:
                    print("[Remesh Ultimate] cover check:", ex)
            # costura: a borda da peca volta para a linha do corte original,
            # entao as vizinhas se encontram (sem frestas)
            try:
                _snap_border(res, src_p)
            except Exception as ex:
                print("[Remesh Ultimate] border snap:", ex)
            # 1.8.12: so fica a retopologia que ENCAIXA: todo o corte original
            # encostado na borda nova, nenhuma face dobrada.  Senao, a malha
            # original (ja quad) - nunca fresta nem buraco entre pecas.
            if kind_ == 'work' and not _part_fits(res, src_p):
                bpy.data.meshes.remove(res)
                res = _quadify(src_p, s)
                solved -= 1
                quadified += 1
                log.append("%s kept exact (did not fit its neighbours)" % (
                    area_meta["names"][part_labels[plan_index[id(pinfo)]]]
                    if area_meta["names"] else "part"))
        if part_labels is not None and axis_i >= 0 and abs(pinfo["center"][axis_i]) <= diag * 0.01:
            try:
                _weld_mirror_seam(res, axis_i, diag)   # parte central resolvida espelhada
            except Exception as ex:
                print("[Remesh Ultimate] seam weld:", ex)
        out_meshes.append(res)
        out_labels.append(-1 if part_labels is None else int(part_labels[plan_index[id(pinfo)]]))
        if pinfo["twin"] is not None and pinfo["twin"] >= 0:
            out_meshes.append(_mirror_mesh(res, axis_i))
            out_labels.append(-1 if part_labels is None else int(part_labels[pinfo["twin"]]))
            mirrored += 1

    for w in works:
        if getattr(w, "backup", None) is not None:
            bpy.data.meshes.remove(w.backup)
            w.backup = None
    log.append("%d remeshed" % solved)
    if symmetrized:
        log.append("%d part%s made exactly symmetric" % (symmetrized, "s" if symmetrized != 1 else ""))
    if quadified:
        log.append("%d quadified (exact shape)" % quadified)
    if clean:
        log.append("%d already clean quads" % clean)
    if hard_parts:
        log.append("%d hard-surface" % hard_parts)
    if mirrored:
        log.append("%d mirrored twins" % mirrored)
    guarded = sum(1 for w in works if getattr(w, "sym_dropped", False))
    if guarded:
        log.append("%d part%s solved without mirror (cleaner shape)" % (guarded, "s" if guarded != 1 else ""))
    if kept:
        log.append("%d kept original" % kept)
    log.append("symmetry: %s" % ("none" if axis_i < 0 else sym_axis + (" (model centre)" if offset.length > 0 else "")))

    best = _join_meshes(out_meshes, src.name + RESULT_SUFFIX)
    if part_labels is not None and min(out_labels or [-1]) >= 0:
        fl = np.concatenate([np.full(len(m.polygons), L, dtype=np.int32)
                             for m, L in zip(out_meshes, out_labels)])
        if len(fl) == len(best.polygons):
            at = best.attributes.new("ru_area_res", 'INT', 'FACE')
            at.data.foreach_set("value", fl)
    if axis_i >= 0 and part_labels is None:
        # 1.8.4: halves of a symmetric solve (QuadriFlow mirror or a mirrored
        # twin) used to stay open down the middle - weld them
        try:
            nw = _weld_mirror_seam(best, axis_i, diag)
            if nw:
                log.append("%d centre seam points welded in the result" % nw)
        except Exception as ex:
            print("[Remesh Ultimate] seam weld:", ex)
    if offset.length > 0.0:
        best.transform(Matrix.Translation(offset))
        base_me.transform(Matrix.Translation(offset))
        orig_pts = orig_pts + np.array(offset)
        orig_bvh = _bvh_from_mesh(base_me)
    if getattr(s, "clean_flow", True):
        try:
            pb, pa, nrot = _reduce_poles(best)
            if nrot:
                log.append("flow cleanup: %d edges rotated, poles %d -> %d"
                           % (nrot, pb, pa))
        except Exception as ex:
            log.append("flow cleanup warning: %s" % ex)
    # quality is measured in world proportions, then the mesh goes back to local space
    final_q = _mesh_quality(best, orig_bvh, _mesh_co(base_me), diag, target_total)
    cover = _coverage(orig_pts, best, max(_avg_edge(best) * 0.75, diag * 0.004))

    # Preserve source material slots AND per-face assignments. QuadriFlow is
    # intentionally called with preserve_attributes=False, so transfer the
    # material index by nearest source surface polygon while both meshes are
    # still in the same working coordinate system.
    try:
        best.materials.clear()
        for mat in base_me.materials:
            best.materials.append(mat)
        if len(base_me.polygons) and len(best.polygons):
            src_bvh = BVHTree.FromPolygons(
                [v.co.copy() for v in base_me.vertices],
                [list(poly.vertices) for poly in base_me.polygons],
                all_triangles=False)
            src_midx = np.empty(len(base_me.polygons), dtype=np.int32)
            base_me.polygons.foreach_get("material_index", src_midx)
            dst_midx = np.zeros(len(best.polygons), dtype=np.int32)
            for poly in best.polygons:
                center = poly.center
                hit = src_bvh.find_nearest(center)
                if hit is not None and hit[2] is not None:
                    dst_midx[poly.index] = int(src_midx[hit[2]])
            best.polygons.foreach_set("material_index", dst_midx)
    except Exception as material_error:
        log.append("material transfer warning: %s" % material_error)

    best.transform(lin.inverted().to_4x4())
    if flipped:
        best.flip_normals()

    # 6) final object
    best.polygons.foreach_set("use_smooth", np.ones(len(best.polygons), dtype=bool))
    try:
        best.set_sharp_from_angle(angle=max(s.sharp_angle * 1.8, math.radians(55.0)))
    except Exception:
        pass
    best.update()
    res = bpy.data.objects.new(src.name + RESULT_SUFFIX, best)
    res.matrix_world = result_matrix
    for coll in src.users_collection:
        coll.objects.link(res)
    if not res.users_collection:
        context.scene.collection.objects.link(res)
    if s.add_shrinkwrap:
        sw = res.modifiers.new("RU Shrinkwrap", 'SHRINKWRAP')
        sw.target = src
        sw.wrap_method = 'NEAREST_SURFACEPOINT'

    dt = time.time() - t0
    eng = ("QuadWild" if getattr(s, "engine", '') == 'QUADWILD' and _qw_available()
           else "QuadriFlow")
    method = eng if solved else ("Quadify" if quadified else "Original kept")
    if solved and quadified:
        method = eng + " + Quadify"
    res["ru_source"] = src.name
    res["ru_score"] = round(final_q["score"] * min(1.0, cover / 0.98), 1)
    res["ru_cover"] = round(100.0 * cover, 1)
    res["ru_report"] = ("%d faces | %.0f%% quads | %d poles | cover %.1f%% | dev %.2f%% | %.1fs | %s" %
                        (final_q["faces"], final_q["quad_pct"], final_q["poles"], 100.0 * cover,
                         final_q["deviation_pct"], dt, method))
    res["ru_log"] = "; ".join(log)
    return res, final_q, dt


# --------------------------------------------------------------------------
#  Areas & Lines (Nitro-style patches, automatic + hand-drawn guides)
# --------------------------------------------------------------------------
AREAS_SUFFIX = "_RU_AREAS"
LINES_SUFFIX = "_RU_LINES"


def _uf_labels(n, a, b):
    """Connected labels for n items joined by pairs (a[i], b[i]) - numpy union-find."""
    parent = np.arange(n, dtype=np.int64)
    if len(a):
        for _round in range(64):
            pa, pb = parent[a], parent[b]
            if np.array_equal(pa, pb):
                break
            lo = np.minimum(pa, pb)
            hi = np.maximum(pa, pb)
            np.minimum.at(parent, hi, lo)
            while True:
                gp = parent[parent]
                if np.array_equal(gp, parent):
                    break
                parent = gp
    _u, labels = np.unique(parent, return_inverse=True)
    return labels


def _face_pairs(me):
    """Faces sharing an edge, found by POSITION (works on meshes whose seams are not
    welded). Returns face_a, face_b, edge end ids (welded) and the welded coordinates."""
    co = _mesh_co(me)
    lv, ls, lt, nxt, pol = _poly_topology(me)
    if len(co) == 0 or len(lv) == 0:
        z = np.zeros(0, dtype=np.int64)
        return z, z, z, z, co
    span = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    q = np.round(co / (span * 1e-6)).astype(np.int64)
    # weld by position with ONE int64 key per vertex (same grouping and order as
    # np.unique(q, axis=0), a fraction of its memory): every axis spans <= ~1e6
    # steps, so x*R*R + y*R + z stays far below 2**63
    q -= q.min(axis=0)
    R = int(q.max()) + 1
    if R ** 3 < 2 ** 62:
        key1 = (q[:, 0] * R + q[:, 1]) * R + q[:, 2]
        del q
        nw_keys, uid = np.unique(key1, return_inverse=True)
        del key1
        n_w = len(nw_keys)
    else:
        wco_keys, uid = np.unique(q, axis=0, return_inverse=True)
        n_w = len(wco_keys)
    uid = uid.ravel()
    wco = np.zeros((n_w, 3))
    np.add.at(wco, uid, co)
    wco /= np.maximum(np.bincount(uid, minlength=n_w), 1)[:, None]
    # per-loop arrays are the big ones: drop each as soon as it is used
    a, b = uid[lv], uid[lv[nxt]]
    del lv, nxt, ls, lt, uid
    lo, hi = np.minimum(a, b), np.maximum(a, b)
    del a, b
    keep = np.flatnonzero(lo != hi)
    lo, hi, pk = lo[keep], hi[keep], pol[keep]
    del keep, pol
    key = lo * n_w + hi
    order = np.argsort(key, kind='stable')
    key, pk = key[order], pk[order]
    lo_k, hi_k = lo[order], hi[order]
    del lo, hi, order
    start = np.ones(len(key), dtype=bool)
    start[1:] = key[1:] != key[:-1]
    sidx = np.flatnonzero(start)
    cnt = np.diff(np.append(sidx, len(key)))
    two = sidx[cnt == 2]
    return pk[two], pk[two + 1], lo_k[two], hi_k[two], wco


AREA_JUNCTION = 9.0    # concave curvature (x model size) that counts as a real junction
AREA_CONVEX = 0.12     # convex bends weigh this much: rounded shells are NOT cut
AREA_CREASE = 18.0     # a sharp crease (above Sharp Angle) is always a strong border
AREA_TINY = 0.0015     # regions below this fraction of the surface are merged first
AREA_COMPACT = 0.7      # preference for compact areas (0 = none)
AREA_REFINE = 12       # passes that pull borders into the valleys
AREA_SMOOTH = 8        # passes that even out soft borders


AREA_ORGANIC_CREASE = 0.02      # below this share of crease length: organic model


ADAPT_MIN, ADAPT_MAX = 0.40, 2.80   # quanto a densidade pode cair / subir por area


def _detail_weight(me):
    """Quanto detalhe esta area tem, em curvatura por unidade de comprimento.

    Area lisa (um capo, uma coxa) devolve um valor baixo; area cheia de relevo
    (mao, grade, dobra) devolve um valor alto.  A medida e a curvatura media
    discreta: soma do angulo entre faces vizinhas vezes o comprimento da aresta,
    dividida pela area.  Nao depende de quao denso o original foi modelado.
    """
    nf = len(me.polygons)
    if nf < 4:
        return 0.0
    try:
        f0, f1, ea, eb, wco = _face_pairs(me)
    except Exception:
        return 0.0
    if len(f0) == 0:
        return 0.0
    fn_ = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fn_)
    fn_ = fn_.reshape(-1, 3)
    fa = np.empty(nf)
    me.polygons.foreach_get("area", fa)
    total = float(fa.sum())
    if total <= 1e-12:
        return 0.0
    dots = np.einsum('ij,ij->i', fn_[f0], fn_[f1]).clip(-1.0, 1.0)
    ang = np.arccos(dots)
    elen = np.linalg.norm(wco[ea] - wco[eb], axis=1)
    return float((ang * elen).sum() / total)      # 1/comprimento


def _adaptive_shares(parts, areas, total_area, target_total, strength):
    """Reparte os quads entre as areas segundo area E detalhe.

    O numero de quads que uma regiao precisa cresce com a area e com o quadrado
    da curvatura (aresta ideal ~ 1/curvatura).  Com strength=0 o resultado e
    exatamente o de antes: so a area manda.
    """
    n = len(parts)
    base = [target_total * a / total_area for a in areas]
    if strength <= 0.0 or n < 2:
        return base, [1.0] * n
    curv = np.array([_detail_weight(p) for p in parts], dtype=np.float64)
    ok = curv[curv > 0]
    if len(ok) < 2:
        return base, [1.0] * n
    ref = float(np.median(ok))
    if ref <= 1e-12:
        return base, [1.0] * n
    w = (np.maximum(curv, ref * 1e-3) / ref) ** (2.0 * float(strength))
    w = np.clip(w, ADAPT_MIN, ADAPT_MAX)
    wa = np.array(areas, dtype=np.float64) * w
    tot = float(wa.sum()) or 1.0
    return [target_total * float(x) / tot for x in wa], [float(x) for x in w]


def _segment_areas(me, angle, n_areas, style='AUTO'):
    """Split a surface into areas the way a modeller would (1.6.3).

    Borders go where the shape really changes: sharp creases and concave
    junctions (where a fender meets the body, a post meets the wing...).
    Smooth or convex surfaces are never cut just to reach a count, so a round
    nose stays one area.  `n_areas` is the maximum: a simple model gets fewer.
    Separate pieces always stay separate areas.

    1. curvature of every edge from scale-aware smoothed normals
       (concave = strong border, convex = weak, crease = always a border)
    2. small compact patches ("superfaces") grown on the surface
    3. patches merged, weakest shared border first (average strength along
       the border, so one noisy edge never decides)
    4. borders pulled into the valleys, crumbs merged into their neighbour
    """
    nf = len(me.polygons)
    if nf == 0:
        return np.zeros(0, dtype=np.int64)
    # 1.6.5: separate pieces are always their own area, so they do not use up the
    # budget - Max Areas is what the surfaces themselves may be divided into
    try:
        _vc = _components(me)
        _fv = np.empty(len(me.loops), dtype=np.int64)
        me.loops.foreach_get("vertex_index", _fv)
        _ls = np.empty(nf, dtype=np.int64)
        me.polygons.foreach_get("loop_start", _ls)
        # 1.13.2: only pieces that count (>= 3% of the surface) raise the budget;
        # 270 tread blocks used to let a tyre be cut into ~290 areas
        _fc = _vc[_fv[_ls]]
        _fa0 = np.empty(nf)
        me.polygons.foreach_get("area", _fa0)
        _ca = np.bincount(_fc, weights=_fa0)
        n_pieces = max(1, int((_ca >= SMALL_PIECE_SHARE * (_ca.sum() or 1.0)).sum()))
    except Exception:
        n_pieces = 1
    n_areas = int(n_areas) + max(0, n_pieces - 1)
    # 1.8.2: an organic model has no creases and no deep junctions, so the
    # "never cut a smooth surface" rule used to merge the whole body into one
    # area.  In ORGANIC the count itself is the target: borders land in the
    # shallowest valleys the shape has.  AUTO decides from the model.
    organic = style == 'ORGANIC'
    fn = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    fc = np.empty(nf * 3)
    me.polygons.foreach_get("center", fc)
    fc = fc.reshape(-1, 3)
    fa = np.empty(nf)
    me.polygons.foreach_get("area", fa)
    f0, f1, ea, eb, wco = _face_pairs(me)
    if len(f0) == 0:
        return np.arange(nf, dtype=np.int64)
    diag = float(np.linalg.norm(fc.max(axis=0) - fc.min(axis=0))) or 1.0
    total = float(fa.sum()) or 1.0
    elen = np.linalg.norm(wco[ea] - wco[eb], axis=1)

    # ---- 1. edge strength -------------------------------------------------
    crease = np.einsum('ij,ij->i', fn[f0], fn[f1]) < math.cos(angle)
    if style == 'AUTO':
        # hardly any creases and barely any sharp relief -> treat it as organic
        organic = float(np.average(crease, weights=elen)) < AREA_ORGANIC_CREASE
    sm = ~crease
    a0, a1 = f0[sm], f1[sm]
    fns = fn.copy()
    iters = int(np.clip(round(math.sqrt(nf) / 25.0), 4, 24))   # denser mesh -> wider smoothing
    for _it in range(iters):
        acc = fns.copy()
        for k in range(3):
            acc[:, k] += (np.bincount(a0, weights=fns[a1, k], minlength=nf)
                          + np.bincount(a1, weights=fns[a0, k], minlength=nf))
        ln = np.linalg.norm(acc, axis=1)
        ln[ln == 0] = 1.0
        fns = acc / ln[:, None]
    d = fc[f1] - fc[f0]
    dist = np.maximum(np.linalg.norm(d, axis=1), diag * 1e-7)
    th = np.arccos(np.einsum('ij,ij->i', fns[f0], fns[f1]).clip(-1.0, 1.0))
    concave = np.einsum('ij,ij->i', fns[f1] - fns[f0], d) < 0.0
    w = th / dist * diag * np.where(concave, 1.0, AREA_CONVEX)
    w[crease] = np.maximum(w[crease], AREA_CREASE)
    del fns, d, dist, th, concave

    # ---- 2. superfaces: compact patches grown from random seeds -------------
    rng = np.random.default_rng(0)
    m = int(min(nf, np.clip(nf // 40, 300, 5000)))
    sup = np.full(nf, -1, dtype=np.int64)
    sup[rng.choice(nf, size=m, replace=False)] = np.arange(m)
    nxt_id = m
    A = np.concatenate([a0, a1])          # grow across smooth edges only:
    B = np.concatenate([a1, a0])          # a patch never straddles a crease
    for _guard in range(10000):
        grow = (sup[A] < 0) & (sup[B] >= 0)
        if grow.any():
            sup[A[grow]] = sup[B[grow]]
            continue
        rest = np.flatnonzero(sup < 0)
        if len(rest) == 0:
            break
        k = max(1, len(rest) // 40)
        pick = rest[rng.choice(len(rest), size=k, replace=False)]
        sup[pick] = np.arange(nxt_id, nxt_id + k)
        nxt_id += k
    sup[sup < 0] = np.arange(nxt_id, nxt_id + int((sup < 0).sum()))
    _u, sup = np.unique(sup, return_inverse=True)
    sup = sup.ravel()
    m = int(sup.max()) + 1

    # ---- 3. merge patches, weakest border first -----------------------------
    sa, sb = sup[f0], sup[f1]
    cross = sa != sb
    lo = np.minimum(sa[cross], sb[cross])
    hi = np.maximum(sa[cross], sb[cross])
    key, inv = np.unique(lo * m + hi, return_inverse=True)
    inv = inv.ravel()
    wl = np.bincount(inv, weights=(w * elen)[cross])
    ll = np.bincount(inv, weights=elen[cross])
    area = np.bincount(sup, weights=fa, minlength=m).tolist()
    perim = (np.bincount(sa[cross], weights=elen[cross], minlength=m)
             + np.bincount(sb[cross], weights=elen[cross], minlength=m)).tolist()
    nb = [dict() for _ in range(m)]
    for x, y, s1, s2 in zip((key // m).tolist(), (key % m).tolist(), wl.tolist(), ll.tolist()):
        nb[x][y] = (s1, s2)
        nb[y][x] = (s1, s2)
    tiny = total * AREA_TINY
    ver = [0] * m
    parent = list(range(m))
    heap = []

    def push(x, y):
        s1, s2 = nb[x][y]
        avg = s1 / max(s2, 1e-12)
        # compact shapes: a patch that is mostly wrapped by its neighbour joins it first
        wrap = s2 / max(min(perim[x], perim[y]), 1e-12)
        # 1.6.5: not across a real crease - a lip / bumper wrapped all round by a
        # sharp edge is a separate part of the design, not a crumb to absorb
        compact = AREA_COMPACT if avg < AREA_CREASE * 0.75 else 0.0
        eff = avg * (1.0 - compact * min(wrap, 1.0))
        if min(area[x], area[y]) < tiny:
            eff *= 0.001
        heapq.heappush(heap, (eff, avg, x, y, ver[x], ver[y]))

    for x in range(m):
        for y in nb[x]:
            if x < y:
                push(x, y)
    count = m
    while heap:
        eff, avg, x, y, vx, vy = heapq.heappop(heap)
        if ver[x] != vx or ver[y] != vy or nb[x] is None or nb[y] is None:
            continue
        small = min(area[x], area[y]) < tiny
        if count <= n_areas and not small and (organic or avg >= AREA_JUNCTION):
            break
        if len(nb[x]) < len(nb[y]):
            x, y = y, x
        for z, (s1, s2) in nb[y].items():
            if z == x:
                continue
            del nb[z][y]
            if z in nb[x]:
                t1, t2 = nb[x][z]
                nb[x][z] = (t1 + s1, t2 + s2)
            else:
                nb[x][z] = (s1, s2)
            nb[z][x] = nb[x][z]
        shared = nb[x][y][1]
        del nb[x][y]
        nb[y] = None
        area[x] += area[y]
        perim[x] += perim[y] - 2.0 * shared
        parent[y] = x
        ver[x] += 1
        count -= 1
        for z in nb[x]:
            push(x, z)
    par = np.array(parent, dtype=np.int64)
    for _r in range(64):
        pp = par[par]
        if np.array_equal(pp, par):
            break
        par = pp
    _u, lab = np.unique(par[sup], return_inverse=True)
    lab = lab.ravel()

    # ---- 4a. pull borders into the valleys -----------------------------------
    aff = np.exp(-w / (AREA_JUNCTION * 0.5))
    F = np.concatenate([f0, f1])
    Nb = np.concatenate([f1, f0])
    Af = np.concatenate([aff, aff])
    for _it in range(AREA_REFINE):
        nl = int(lab.max()) + 1
        uk, inv = np.unique(F * nl + lab[Nb], return_inverse=True)
        sc = np.bincount(inv.ravel(), weights=Af)
        kf, kl = uk // nl, uk % nl
        own = np.zeros(nf)
        mine = kl == lab[kf]
        own[kf[mine]] = sc[mine]
        order = np.lexsort((-sc, kf))
        kf, kl, sc = kf[order], kl[order], sc[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bs = kf[first], kl[first], sc[first]
        flip = (bl != lab[bf]) & (bs > own[bf] * 1.05 + 1e-12)
        if not flip.any():
            break
        lab = lab.copy()
        lab[bf[flip]] = bl[flip]

    # ---- 4b. crumbs: fragments cut off by 4a join the neighbour they touch most
    for _pass in range(3):
        same = lab[f0] == lab[f1]
        frag = _uf_labels(nf, f0[same], f1[same])
        nfr = int(frag.max()) + 1
        fr_area = np.bincount(frag, weights=fa, minlength=nfr)
        fr_lab = np.zeros(nfr, dtype=np.int64)
        fr_lab[frag] = lab
        big = np.zeros(int(lab.max()) + 1)
        np.maximum.at(big, fr_lab, fr_area)
        crumb = (fr_area < big[fr_lab] * 0.5) | (fr_area < tiny)
        if not crumb.any():
            break
        x, y = frag[f0[~same]], frag[f1[~same]]
        L2 = elen[~same]
        xs = np.concatenate([x, y]); ys = np.concatenate([y, x]); ws = np.concatenate([L2, L2])
        keep = crumb[xs]
        if not keep.any():
            break
        uk, inv = np.unique(xs[keep] * nfr + ys[keep], return_inverse=True)
        sl = np.bincount(inv.ravel(), weights=ws[keep])
        kx, ky = uk // nfr, uk % nfr
        order = np.lexsort((-sl, kx))
        kx, ky = kx[order], ky[order]
        first = np.ones(len(kx), dtype=bool)
        first[1:] = kx[1:] != kx[:-1]
        new_lab = fr_lab.copy()
        new_lab[kx[first]] = fr_lab[ky[first]]
        if np.array_equal(new_lab, fr_lab):
            break
        lab = new_lab[frag]
    # ---- 4c. even out the borders that are not creases (majority of neighbours)
    Fs = np.concatenate([a0, a1])
    Ns = np.concatenate([a1, a0])
    deg = np.bincount(Fs, minlength=nf)
    for _it in range(AREA_SMOOTH):
        nl = int(lab.max()) + 1
        uk, cnt = np.unique(Fs * nl + lab[Ns], return_counts=True)
        kf, kl = uk // nl, uk % nl
        order = np.lexsort((-cnt, kf))
        kf, kl, cnt = kf[order], kl[order], cnt[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bc = kf[first], kl[first], cnt[first]
        flip = (bl != lab[bf]) & ((bc * 2 > deg[bf]) | ((bc * 2 == deg[bf]) & (_it == 0)))
        if not flip.any():
            break
        lab = lab.copy()
        lab[bf[flip]] = bl[flip]
    _u, lab = np.unique(lab, return_inverse=True)
    return lab.ravel()


# ==========================================================================
#  1.8.0  Deteccao semantica (modos Automático / Orgânico / Objeto)
#  Nomeia as partes pelo que elas SAO: cabeça, torso, braços, antebraços,
#  pernas e pés num corpo; rodas, eixos e partes mecânicas num objeto.
#  Puro numpy (centros, áreas, normais e adjacência de faces): funciona igual
#  no Windows e no Linux e pode ser testado fora do Blender.
# === RU SEMANTIC CORE (inicio) ===
# ==========================================================================
def _uf2(n, a, b):
    """Rotulos de componentes para n itens ligados pelos pares (a, b)."""
    parent = np.arange(n, dtype=np.int64)
    if len(a):
        for _round in range(64):
            pa, pb = parent[a], parent[b]
            if np.array_equal(pa, pb):
                break
            lo = np.minimum(pa, pb)
            hi = np.maximum(pa, pb)
            np.minimum.at(parent, hi, lo)
            while True:
                gp = parent[parent]
                if np.array_equal(gp, parent):
                    break
                parent = gp
    _u, lab = np.unique(parent, return_inverse=True)
    return lab.ravel()


def _sem_profile_cut(tpar, X, w, axis_dir, lo_frac=0.45, hi_frac=0.92, nseg=24, N=None):
    """Onde comeca a extremidade de um membro (mao, pe) - 1.8.4.

    Mede o RAIO da secao ao longo do membro (distancia media das faces ao
    centro de cada fatia, sem a componente do eixo): nao depende do tamanho
    das faces, ao contrario da area por fatia.  A extremidade comeca onde o
    raio passa a ser claramente maior que o do antebraco/canela (luva, mao
    aberta, sapato); sem esse salto, no ponto mais fino (pulso).
    Devolve (corte, achou)."""
    t0, t1 = float(tpar.min()), float(tpar.max())
    L = t1 - t0
    if L <= 1e-12 or len(tpar) < 24:
        return t0 + 0.8 * L, False
    sb = np.clip(((tpar - t0) / L * nseg).astype(np.int64), 0, nseg - 1)
    ax = np.asarray(axis_dir, dtype=float)
    ax = ax / (np.linalg.norm(ax) or 1.0)
    rad = np.zeros(nseg)
    has = np.zeros(nseg, dtype=bool)
    for k in range(nseg):
        m = sb == k
        if not m.any():
            continue
        wk = w[m]
        c = (X[m] * wk[:, None]).sum(axis=0) / max(float(wk.sum()), 1e-18)
        d = X[m] - c
        d = d - (d @ ax)[:, None] * ax[None, :]
        rad[k] = float(np.average(np.linalg.norm(d, axis=1), weights=np.maximum(wk, 1e-18)))
        has[k] = True
    # buracos (fatias sem faces) herdam o vizinho
    for k in range(nseg):
        if not has[k]:
            nb = [rad[j] for j in (k - 1, k + 1) if 0 <= j < nseg and has[j]]
            rad[k] = float(np.mean(nb)) if nb else 0.0
    sm = rad.copy()
    sm[1:-1] = (rad[:-2] + 2.0 * rad[1:-1] + rad[2:]) / 4.0
    r0, r1 = int(0.25 * nseg), max(int(0.50 * nseg), int(0.25 * nseg) + 2)
    ref = float(np.median(sm[r0:r1]))
    a, b = int(lo_frac * nseg), int(hi_frac * nseg)
    # 1.8.5: faces viradas ao longo do membro = degrau/anel (borda do punho
    # de uma luva, cano de uma bota).  A extremidade comeca NA borda.
    axial = np.zeros(nseg)
    if N is not None and len(N) == len(tpar):
        aa = np.abs(np.asarray(N) @ ax)
        axial = np.bincount(sb, weights=aa * w, minlength=nseg) / np.maximum(
            np.bincount(sb, weights=w, minlength=nseg), 1e-18)
    if ref > 0:
        for k in range(a, b):
            if sm[k] > 1.12 * ref and sm[min(k + 1, nseg - 1)] > 1.08 * ref:
                back = max(int(0.30 * nseg), k - max(2, int(0.18 * nseg)))
                win_ax = axial[back:k + 1]
                med = float(np.median(axial[r0:r1])) if r1 > r0 else 0.0
                if len(win_ax) and float(win_ax.max()) >= max(0.45, 1.6 * med):
                    kr = back + int(np.argmax(win_ax))       # o anel da borda
                    return t0 + kr / float(nseg) * L, True
                # sem anel: comeca no ponto mais fino antes da subida
                while k - 1 >= back and sm[k - 1] <= sm[k]:
                    k -= 1
                return t0 + k / float(nseg) * L, True
    win = sm[a:b]
    if len(win):
        k = int(np.argmin(win)) + a
        if float(sm[k + 1:].max() if k + 1 < nseg else 0.0) >= 1.2 * float(sm[k]):
            return t0 + (k + 0.5) / nseg * L, True
    return t0 + 0.8 * L, False


def _semantic_humanoid(cen, fa, f0, f1, axis_lr, mid_lr=None, n_bins=64, fcomp=None, fn=None):
    """Reconhece as partes de um corpo humanoide so pela geometria (1.8.4).

    Fatia o modelo da cabeca aos pes; em cada fatia os "blobs" (pedacos
    ligados dentro da fatia) separam tronco, bracos e pernas.  Um blob e do
    tronco quando ATRAVESSA o plano de simetria (antes bastava encostar nele:
    pernas juntas de personagens cartunescos viravam tronco e a deteccao
    inteira falhava).  Em pose T os bracos ficam na mesma fatia que o tronco,
    entao a largura do peito (medida abaixo das axilas) separa os dois.
    Maos e pes saem na constricao do pulso/tornozelo; pecas soltas (sapato,
    luva) que encostam no membro entram nele.

    fcomp: componente (peca solta) de cada face, opcional.
    Devolve dict(ok, lab, names, twin, side, up, fwd) ou ok=False."""
    fail = dict(ok=False)
    nf = len(cen)
    if nf < 120 or len(f0) == 0:
        return fail
    axes = [a for a in range(3) if a != axis_lr]
    ext = cen.max(axis=0) - cen.min(axis=0)
    up = axes[0] if ext[axes[0]] >= ext[axes[1]] else axes[1]
    fwd = axes[1] if up == axes[0] else axes[0]
    span = float(ext[up])
    if span <= 1e-12 or float(ext[axis_lr]) <= 1e-12:
        return fail
    if mid_lr is None:
        mid_lr = 0.5 * float(cen[:, axis_lr].min() + cen[:, axis_lr].max())
    if fcomp is None:
        fcomp = np.zeros(nf, dtype=np.int64)
    fcomp = np.asarray(fcomp, dtype=np.int64)
    LR = cen[:, axis_lr] - mid_lr
    # 1.8.4: a fatia precisa ser mais alta que uma face, senao o anel do tronco
    # se quebra em pedacos (faces vizinhas caem em fatias alternadas) e o
    # tronco vira "braco".  Malha grossa -> menos fatias.
    edge = math.sqrt(max(float(np.median(fa)), 1e-18))
    n_bins = int(np.clip(span / (1.8 * edge), 20, n_bins))
    h0 = cen[:, up]
    tbin = np.clip(((h0 - h0.min()) / span * n_bins).astype(np.int64), 0, n_bins - 1)
    total_area = float(fa.sum()) or 1.0
    tol = float(ext[axis_lr]) * 0.002

    def slabs(tb):
        same = tb[f0] == tb[f1]
        blob = _uf2(nf, f0[same], f1[same])
        nbl = int(blob.max()) + 1
        bb = np.zeros(nbl, dtype=np.int64)
        bb[blob] = tb
        ba = np.bincount(blob, weights=fa, minlength=nbl)
        blr = np.bincount(blob, weights=fa * LR, minlength=nbl) / np.maximum(ba, 1e-18)
        lrmin = np.full(nbl, 1e18)
        lrmax = np.full(nbl, -1e18)
        np.minimum.at(lrmin, blob, LR)
        np.maximum.at(lrmax, blob, LR)
        central = (lrmin <= -tol) & (lrmax >= tol)
        return blob, bb, ba, blr, central, lrmin, lrmax

    blob, bb, ba, blr, central, lrmin, lrmax = slabs(tbin)

    def pair_at(bins):
        sel = np.flatnonzero(np.isin(bb, bins) & (ba > 0))
        if len(sel) == 0:
            return False
        sel = sel[ba[sel] >= 0.10 * float(ba[sel].max())]
        off = ~central[sel]
        return bool((off & (blr[sel] > 0)).any() and (off & (blr[sel] < 0)).any())

    tenth = max(2, n_bins // 10)
    flipped = False
    if pair_at(np.arange(n_bins - tenth, n_bins)) and not pair_at(np.arange(tenth)):
        flipped = True
        tbin = n_bins - 1 - tbin
        blob, bb, ba, blr, central, lrmin, lrmax = slabs(tbin)
    hh = -h0 if flipped else h0

    # ---- virilha: de baixo para cima, a primeira fatia em que um blob central
    #      grande junta as duas colunas
    slab_total = np.bincount(bb, weights=ba, minlength=n_bins)
    eps = float(ext[axis_lr]) * 0.01
    split_bin = np.zeros(n_bins, dtype=bool)
    for b in range(n_bins):
        sel = np.flatnonzero(bb == b)
        if len(sel) == 0:
            continue
        bigc = (central[sel] & (ba[sel] >= 0.25 * slab_total[b])).any()
        off = ~central[sel]
        hasL = (off & (blr[sel] > eps)).any()
        hasR = (off & (blr[sel] < -eps)).any()
        split_bin[b] = (not bigc) and hasL and hasR
    b = 0
    while b < n_bins and (split_bin[b] or slab_total[b] <= 0):
        b += 1
    crotch = b
    if crotch < int(0.10 * n_bins) or crotch > int(0.72 * n_bins):
        return fail

    # ---- pernas: abaixo da virilha, as colunas que chegam ao chao, mais toda
    #      peca daquele lado que fica dentro da largura da coluna (sapato solto)
    legface = tbin < crotch
    jj = legface[f0] & legface[f1]
    comp = _uf2(nf, f0[jj], f1[jj])
    ncp = int(comp.max()) + 1
    lsel = np.flatnonzero(legface)
    cmin = np.full(ncp, n_bins, dtype=np.int64)
    np.minimum.at(cmin, comp[lsel], tbin[lsel])
    carea = np.bincount(comp[lsel], weights=fa[lsel], minlength=ncp)
    clr = np.bincount(comp[lsel], weights=fa[lsel] * LR[lsel], minlength=ncp) / np.maximum(carea, 1e-18)
    cl0 = np.full(ncp, 1e18)
    cl1 = np.full(ncp, -1e18)
    np.minimum.at(cl0, comp[lsel], LR[lsel])
    np.maximum.at(cl1, comp[lsel], LR[lsel])
    floor_bin = max(1, crotch // 5)
    grounded = np.flatnonzero((cmin <= floor_bin) & (carea > 0))
    gl = [int(cx) for cx in grounded if clr[cx] > 0]
    gr = [int(cx) for cx in grounded if clr[cx] <= 0]
    if not gl or not gr:
        return fail
    leg_mask = {}
    for side_s, gsel in ((1, gl), (-1, gr)):
        lo_ = min(cl0[g] for g in gsel)
        hi_ = max(cl1[g] for g in gsel)
        pad = 0.25 * (hi_ - lo_)
        cs = [cx for cx in range(ncp) if carea[cx] > 0 and side_s * clr[cx] > 0
              and lo_ - pad <= clr[cx] <= hi_ + pad]
        leg_mask[side_s] = legface & np.isin(comp, cs)
    inL, inR = leg_mask[1], leg_mask[-1]
    if min(float(fa[inL].sum()), float(fa[inR].sum())) < 0.02 * total_area:
        return fail

    pos = LR > 0
    fcentral = central[blob]
    upper = ~legface & ~inL & ~inR
    nonempty = np.flatnonzero(slab_total > 0)
    topb = int(nonempty.max())

    # ---- largura do tronco por fatia (blob central).  Onde ela pula - pose T,
    #      bracos na mesma fatia que o tronco - vale a largura do peito medida
    #      logo abaixo das axilas.  Medido ANTES do pescoco: com os bracos
    #      abertos a "constricao" acima deles era confundida com o pescoco e a
    #      cabeca engolia ombros e bracos (1.8.4)
    halfw = np.zeros(n_bins)
    for b2 in range(crotch, topb + 1):
        sel = np.flatnonzero((bb == b2) & central)
        if len(sel):
            k = sel[np.argmax(ba[sel])]
            halfw[b2] = max(-lrmin[k], lrmax[k])
    lo_t = crotch
    ref_rng = halfw[lo_t: lo_t + max(2, (topb - lo_t) // 4)]
    ref = float(np.median(ref_rng[ref_rng > 0])) if (ref_rng > 0).any() else 0.0
    torso_half = np.full(n_bins, 1e18)
    armpit = armtop = -1
    if ref > 0:
        for b2 in range(lo_t, topb + 1):
            if halfw[b2] > 1.6 * ref:
                armpit = b2
                break
        if armpit >= 0:
            armtop = armpit
            while armtop + 1 <= topb and halfw[armtop + 1] > 1.6 * ref:
                armtop += 1
            below = halfw[lo_t:armpit]
            chest = float(below[below > 0].max()) if (below > 0).any() else ref
            torso_half[armpit:] = chest * 1.06

    # ---- pescoco: a constricao central mais estreita no alto do corpo, medida
    #      so dentro da largura do tronco (sem os bracos)
    narrow = fcentral & (np.abs(LR) <= torso_half[tbin])
    slab_central = np.bincount(tbin[narrow], weights=fa[narrow], minlength=n_bins)
    w0 = max(int(0.55 * n_bins), crotch + 2, armtop + 1 if armtop >= 0 else 0)
    neck, best_a = -1, None
    for b2 in range(w0, topb):
        above = slab_central[b2 + 1: topb + 1]
        if len(above) == 0 or float(above.max()) <= 0:
            continue
        if slab_central[b2] < 0.72 * float(above.max()):
            if best_a is None or slab_central[b2] <= best_a:
                best_a = slab_central[b2]
                neck = b2
    if neck < 0:
        neck = max(topb - max(2, n_bins // 10), crotch + 1)

    # cabeca solta (peca separada no alto do corpo): o pescoco e onde ela comeca
    ncomp = int(fcomp.max()) + 1
    comp_area = np.bincount(fcomp, weights=fa, minlength=ncomp)
    comp_lo = np.full(ncomp, n_bins, dtype=np.int64)
    np.minimum.at(comp_lo, fcomp, tbin)
    c0 = np.full(ncomp, 1e18)
    c1 = np.full(ncomp, -1e18)
    np.minimum.at(c0, fcomp, LR)
    np.maximum.at(c1, fcomp, LR)
    comp_cross = (c0 <= -tol) & (c1 >= tol)
    head_comp = -1
    cand = [k for k in range(ncomp) if comp_cross[k] and comp_lo[k] > crotch + 2
            and comp_lo[k] >= int(0.45 * n_bins)
            and 0.12 * total_area <= comp_area[k] <= 0.6 * total_area]   # 1.8.11: gorro solto nao e cabeca
    if cand:
        head_comp = max(cand, key=lambda k: comp_area[k])
        neck = int(comp_lo[head_comp]) - 1

    # acima do pescoco so ha cabeca: uma cabeca mais larga que o peito
    # (personagem cartunesco) nao pode perder as laterais para os bracos
    torso_half[max(neck, armtop) + 1:] = 1e18

    # ---- classes: 0 Tronco 1 Cabeca 2/3 Braco 4/5 Antebraco 6/7 Perna
    #      8/9 Pe 10/11 Mao  (.L = lado positivo do eixo)
    slot = np.zeros(nf, dtype=np.int64)
    slot[inL] = 6
    slot[inR] = 7
    other = legface & ~inL & ~inR          # maos penduradas abaixo da virilha
    slot[other & pos] = 2
    slot[other & ~pos] = 3
    headf = upper & (tbin > neck) & fcentral & (np.abs(LR) <= np.maximum(torso_half[tbin], 0))
    if head_comp >= 0:
        # cabeca e uma peca propria: o corpo inteiro fica fora dela
        headf = fcomp == head_comp
        # pecas pequenas soltas presas na cabeca (bigode, olhos, nariz)
        small = (comp_area < 0.05 * total_area) & (comp_lo > neck)
        headf |= upper & small[fcomp] & (np.abs(LR) <= torso_half[tbin])
    slot[headf] = 1
    body = upper & ~headf
    out_t = np.abs(LR) > torso_half[tbin]
    # um blob fora do centro so e braco se estiver FORA da largura do tronco
    # naquela fatia: a lateral do tronco de uma malha grossa pode se partir
    # dentro da fatia e nao deve virar braco (1.8.4)
    side_lim = np.maximum(halfw, ref) * 0.92
    if armpit >= 0:
        side_lim[:armpit] = np.maximum(side_lim[:armpit], chest)
    off_t = ~fcentral & (np.abs(LR) > side_lim[tbin])
    armf = body & (off_t | out_t)
    slot[armf & pos] = 2
    slot[armf & ~pos] = 3
    if float(fa[slot == 1].sum()) > 0.45 * total_area:
        return fail
    if float(fa[slot == 1].sum()) < 0.005 * total_area:
        return fail

    # ---- braco: ombro -> cotovelo -> pulso -> mao (luva: punho incluido)
    gloved = set()
    for aslot, fslot, hslot in ((2, 4, 10), (3, 5, 11)):
        sel2 = np.flatnonzero(slot == aslot)
        if len(sel2) < 24:
            continue
        X = cen[sel2]
        w = fa[sel2]
        tw_ = float(w.sum()) or 1.0
        C = (X * w[:, None]).sum(axis=0) / tw_
        Y = X - C
        cov = (Y * w[:, None]).T @ Y / tw_
        try:
            _ev, evec = np.linalg.eigh(cov)
        except Exception:
            continue
        tpar = Y @ evec[:, -1]
        k = max(1, len(sel2) // 10)
        o = np.argsort(tpar)
        loi, hii = o[:k], o[-k:]
        hlo = float(np.median(hh[sel2][loi]))
        hhi = float(np.median(hh[sel2][hii]))
        armlen = float(tpar.max() - tpar.min()) or 1.0
        if abs(hhi - hlo) > 0.3 * armlen:
            root_hi = hhi > hlo
        else:
            dlo = abs(float(np.median(LR[sel2][loi])))
            dhi = abs(float(np.median(LR[sel2][hii])))
            root_hi = dhi < dlo
        if root_hi:
            tpar = -tpar
        t0 = float(tpar.min())
        wrist, found = _sem_profile_cut(tpar, X, w, evec[:, -1], nseg=40,
                                        N=None if fn is None else fn[sel2])
        if found:
            gloved.add(hslot)
        if not found:
            wrist = t0 + 0.80 * (float(tpar.max()) - t0)
        elbow = t0 + 0.5 * (wrist - t0)
        slot[sel2[(tpar > elbow) & (tpar <= wrist)]] = fslot
        slot[sel2[tpar > wrist]] = hslot

    # ---- pe: peca solta no fim da perna (sapato) ou, numa perna inteirica,
    #      o trecho que se estica para a frente / abaixo do tornozelo
    for lslot, fslot in ((6, 8), (7, 9)):
        sel2 = np.flatnonzero(slot == lslot)
        if len(sel2) < 24:
            continue
        hl = hh[sel2]
        lo2 = float(hl.min())
        spn = float(hl.max()) - lo2
        if spn <= 0:
            continue
        pc = fcomp[sel2]
        ucomp = np.unique(pc)
        if len(ucomp) > 1:
            pa = {int(u): float(fa[sel2][pc == u].sum()) for u in ucomp}
            plo = {int(u): float(hl[pc == u].min()) for u in ucomp}
            low = min(pa, key=lambda u: plo[u])
            legsum = sum(pa.values())
            if pa[low] <= 0.65 * legsum and plo[low] <= lo2 + 0.05 * spn:
                slot[sel2[pc == low]] = fslot
                continue
        nsub = 24
        sb = np.clip(((hl - lo2) / spn * nsub).astype(np.int64), 0, nsub - 1)
        fe = cen[sel2, fwd]
        emin = np.full(nsub, 1e18)
        emax = np.full(nsub, -1e18)
        np.minimum.at(emin, sb, fe)
        np.maximum.at(emax, sb, fe)
        extf = np.where(emax >= emin, emax - emin, 0.0)
        midsel = extf[int(0.4 * nsub):int(0.7 * nsub)]
        refx = float(np.median(midsel[midsel > 0])) if (midsel > 0).any() else 0.0
        cutf = lo2 + 0.10 * spn
        if refx > 0:
            cnd = [sbb for sbb in range(int(0.35 * nsub)) if extf[sbb] >= 1.6 * refx]
            if cnd:
                cutf = lo2 + (max(cnd) + 1) / float(nsub) * spn
        slot[sel2[hl < cutf]] = fslot

    names_all = ["Torso", "Head", "UpperArm", "UpperArm", "Forearm", "Forearm",
                 "Leg", "Leg", "Foot", "Foot", "Hand", "Hand"]
    side_all = [0, 0, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1]
    twin_all = [0, 1, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10]
    for g_ in gloved:
        names_all[g_] = "Glove"
    used, lab = np.unique(slot, return_inverse=True)
    remap = -np.ones(len(names_all), dtype=np.int64)
    remap[used] = np.arange(len(used))
    names = [names_all[u] for u in used]
    side = np.array([side_all[u] for u in used], dtype=np.int64)
    twin = np.array([remap[twin_all[u]] if remap[twin_all[u]] >= 0 else i
                     for i, u in enumerate(used)], dtype=np.int64)
    return dict(ok=True, lab=lab.ravel().astype(np.int64), names=names,
                twin=twin, side=side, up=int(up), fwd=int(fwd), mid_lr=float(mid_lr))


def _compress_sem(lab, names, twin, side):
    """Depois da suavizacao alguns rotulos podem sumir: renumera e refaz as tabelas."""
    lab = np.asarray(lab, dtype=np.int64)
    used, lab2 = np.unique(lab, return_inverse=True)
    hi = (int(used.max()) if len(used) else 0) + 1
    remap = -np.ones(max(hi, len(names), len(twin)) + 1, dtype=np.int64)
    remap[used] = np.arange(len(used))
    nm = [str(names[u]) if u < len(names) else "Part" for u in used]
    sd = np.array([int(side[u]) if u < len(side) else 0 for u in used], dtype=np.int64)
    tw = np.arange(len(used), dtype=np.int64)
    for i, u in enumerate(used):
        t = int(twin[u]) if u < len(twin) else int(u)
        if 0 <= t < len(remap) and remap[t] >= 0:
            tw[i] = remap[t]
    return lab2.ravel(), nm, tw, sd


def _classify_one_part(X, w, N, dots):
    """Nome de uma peca mecanica: 'Wheel' (spins around a short axis),
    'Axle' (spins around a long axis), 'Mechanical' (sharp creases)
    or 'Part'.  X centros, w areas, N normais, dots = produto das normais
    dos pares de faces internos da peca."""
    if len(X) < 24:
        return "Part"
    tot = float(w.sum()) or 1.0
    C = (X * w[:, None]).sum(axis=0) / tot
    Y = X - C
    cov = (Y * w[:, None]).T @ Y / tot
    try:
        _ev, evec = np.linalg.eigh(cov)
    except Exception:
        return "Part"
    for k in (0, 2):                      # eixo curto (disco) e eixo comprido
        a = evec[:, k]
        r = np.linalg.norm(Y - (Y @ a)[:, None] * a[None, :], axis=1)
        rm = float(r.mean())
        if rm <= 1e-12:
            continue
        axial = Y @ a
        aspect = float(axial.max() - axial.min()) / max(2.0 * rm, 1e-12)
        bvec = evec[:, (k + 1) % 3]
        cvec = evec[:, (k + 2) % 3]
        angle = np.arctan2(Y @ cvec, Y @ bvec)
        sec = ((angle + math.pi) / (2.0 * math.pi) * 16).astype(np.int64) % 16
        if int((np.bincount(sec, minlength=16) > 0).sum()) < 15:
            continue                      # nao da a volta completa: nao gira
        rmax = np.zeros(16)
        np.maximum.at(rmax, sec, r)
        cvr = float(rmax.std()) / max(float(rmax.mean()), 1e-12)
        Np = N - (N @ a)[:, None] * a[None, :]
        ln = np.linalg.norm(Np, axis=1)
        ring = ln > 0.5
        bal = 1.0
        if int(ring.sum()) >= 8:
            bal = float(np.linalg.norm((Np[ring] / ln[ring, None]).mean(axis=0)))
        if cvr <= 0.08 and bal <= 0.35:
            return "Wheel" if aspect <= 1.2 else "Axle"
    frac = float((dots < math.cos(math.radians(30.0))).mean()) if len(dots) else 0.0
    return "Mechanical" if frac >= 0.02 else "Part"


def _semantic_object_parts(cen, fa, fn, f0, f1, lab):
    """Nome de cada area de um modelo mecanico (modo Objeto)."""
    lab = np.asarray(lab, dtype=np.int64)
    n = int(lab.max()) + 1 if len(lab) else 0
    dots = (np.einsum('ij,ij->i', fn[f0], fn[f1])
            if len(f0) else np.zeros(0))
    names = []
    for L in range(n):
        sel = np.flatnonzero(lab == L)
        dd = dots[(lab[f0] == L) & (lab[f1] == L)] if len(f0) else np.zeros(0)
        names.append(_classify_one_part(cen[sel], fa[sel], fn[sel], dd))
    return names
# === RU SEMANTIC CORE (fim) ===


def _semantic_from_mesh(me, axis_i, c):
    """Tenta reconhecer um corpo na malha.  O eixo esquerda/direita vem do
    plano de simetria; sem plano, os tres eixos sao tentados por ordem.
    1.8.4: pecas soltas (sapato, cabeca, luva) entram no membro certo e a
    cabeca e dividida em cabeca, cabelo/chapeu e orelhas."""
    nf = len(me.polygons)
    if nf == 0:
        return None
    cen, fa = _face_centers_areas(me)
    f0, f1 = _face_pairs(me)[:2]
    fn_ = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fn_)
    fn_ = fn_.reshape(-1, 3)
    try:
        vc = _components(me)
        fv = np.empty(len(me.loops), dtype=np.int64)
        me.loops.foreach_get("vertex_index", fv)
        ls = np.empty(nf, dtype=np.int64)
        me.polygons.foreach_get("loop_start", ls)
        fcomp = vc[fv[ls]]
    except Exception:
        fcomp = None
    if axis_i >= 0:
        cands = [(int(axis_i), float(c))]
        cands += [(a, None) for a in range(3) if a != axis_i]
    else:
        order = np.argsort(-(cen.max(axis=0) - cen.min(axis=0)))
        cands = [(int(order[1]), None), (int(order[0]), None), (int(order[2]), None)]
    for ax, cc in cands:
        sem = _semantic_humanoid(cen, fa, f0, f1, ax, mid_lr=cc, fcomp=fcomp, fn=fn_)
        if sem.get("ok"):
            sem["axis_lr"] = ax
            try:
                sem = _refine_head(me, sem, ax, sem.get("mid_lr", 0.0 if cc is None else cc))
            except Exception as ex:
                print("[Remesh Ultimate] cabeca:", ex)
            return sem
    return None


def _sem_submesh(me, faces):
    """Malha so com as faces pedidas (mesma ordem)."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    keep = np.zeros(len(bm.faces), dtype=bool)
    keep[np.asarray(faces, dtype=np.int64)] = True
    bmesh.ops.delete(bm, geom=[f for f in bm.faces if not keep[f.index]], context='FACES')
    sub = bpy.data.meshes.new(TMP_PREFIX + "_sem")
    bm.to_mesh(sub)
    bm.free()
    return sub


def _hat_by_sky(sub, cen, fn, up, sgn):
    """1.8.7: faces de um chapeu/bone na malha da cabeca (`sub`, mesma ordem).
    A = sem nada acima; B = viradas para baixo que, atravessando a propria
    casca, chegam ao ceu aberto (parte de baixo da aba/beirada).  Fica so o
    pedaco ligado a face mais alta."""
    from mathutils import Vector
    bvh = _bvh_from_mesh(sub)
    u = Vector((0.0, 0.0, 0.0))
    u[up] = float(sgn)
    n = len(cen)
    span = float(np.linalg.norm(cen.max(axis=0) - cen.min(axis=0))) or 1.0
    eps = span * 0.002
    shell = span * 0.12
    hat = np.zeros(n, dtype=bool)
    for i in range(n):
        c = Vector(cen[i])
        nn = Vector(fn[i])
        if float(nn.dot(u)) >= -0.2:
            if bvh.ray_cast(c + nn * eps, u)[0] is None:
                hat[i] = True
        else:
            r = bvh.ray_cast(c + u * eps, u)
            if r[0] is not None and r[3] < shell:
                if bvh.ray_cast(r[0] + u * eps, u)[0] is None:
                    hat[i] = True
    if not hat.any():
        return hat
    f0, f1 = _face_pairs(sub)[:2]
    h = np.asarray(cen)[:, up] * sgn
    seed = int(np.flatnonzero(hat)[np.argmax(h[hat])])
    ok = hat[f0] & hat[f1]
    A = np.concatenate([f0[ok], f1[ok]])
    B = np.concatenate([f1[ok], f0[ok]])
    vis = np.zeros(n, dtype=bool)
    vis[seed] = True
    for _r in range(2000):
        g = vis[A] & ~vis[B]
        if not g.any():
            break
        vis[B[g]] = True
    return vis


def _refine_head(me, sem, axis_lr, mid_lr):
    """Divide a cabeca em Cabeca, Cabelo/Chapeu e Orelhas (1.8.4).

    Orelhas: saliencias laterais (bordas em vales concavos) a meia altura.
    Cabelo/chapeu: tudo acima de uma aba (faixa virada para baixo no alto da
    cabeca - aba de bone, franja, borda do cabelo).  Sem aba clara a cabeca
    fica inteira.  Detalhes pequenos do rosto (nariz, bigode, olhos) ficam
    na cabeca."""
    names = list(sem["names"])
    if "Head" not in names:
        return sem
    lab = np.asarray(sem["lab"], dtype=np.int64).copy()
    hid = names.index("Head")
    head = np.flatnonzero(lab == hid)
    if len(head) < 60:
        return sem
    up = int(sem["up"])
    fwd = int(sem["fwd"])
    cen, fa = _face_centers_areas(me)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    # 1.8.9b: faces que tocam um polo (vertice com valencia != 4): marcam
    # malha irregular (cabelo) x grade regular (chapeu)
    _ed = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", _ed)
    _val = np.bincount(_ed, minlength=len(me.vertices))
    _lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", _lv)
    _lp = np.repeat(np.arange(len(me.polygons)), np.diff(np.append(
        np.array([p.loop_start for p in me.polygons], dtype=np.int64), len(me.loops))))
    pole_face = np.zeros(len(me.polygons), dtype=bool)
    np.logical_or.at(pole_face, _lp, _val[_lv] != 4)
    # sentido de "cima": a cabeca fica acima do resto do corpo
    body = np.flatnonzero(lab != hid)
    sgn = 1.0
    if len(body) and float(cen[head, up].mean()) < float(cen[body, up].mean()):
        sgn = -1.0
    H = cen[:, up] * sgn
    LRh = cen[:, axis_lr] - mid_lr
    hlo, hhi = float(H[head].min()), float(H[head].max())
    hspan = (hhi - hlo) or 1.0
    hhalf = float(np.abs(LRh[head]).max()) or 1.0
    harea = float(fa[head].sum()) or 1.0
    sub = _sem_submesh(me, head)
    try:
        sl = _segment_areas(sub, math.radians(30.0), 8, 'SHAPE')
        if len(sl) != len(head):
            return sem
        nl = int(sl.max()) + 1
        ar = np.bincount(sl, weights=fa[head], minlength=nl)
        main = int(np.argmax(ar))
        ear = np.zeros(len(head), dtype=np.int64)       # +1 / -1 = lado da orelha
        for k in range(nl):
            if k == main:
                continue
            m = sl == k
            w = fa[head][m]
            cl = float(np.average(LRh[head][m], weights=w))
            ch = (float(np.average(H[head][m], weights=w)) - hlo) / hspan
            mx = float(np.abs(LRh[head][m]).max())
            if (abs(cl) > 0.25 * hhalf and mx > 0.5 * hhalf and 0.08 < ch < 0.75
                    and 0.003 * harea < ar[k] < 0.15 * harea):
                ear[m] = 1 if cl > 0 else -1
        # orelha so vale em par (simetria): um lado sozinho e outra coisa
        if not ((ear > 0).any() and (ear < 0).any()):
            ear[:] = 0
        # aba: faixa da regiao principal virada para baixo na metade de cima
        hair = np.zeros(len(head), dtype=bool)
        brim_fwd = None
        mi = np.flatnonzero(sl == main)
        if len(mi) >= 40:
            sub2 = _sem_submesh(sub, mi)
            try:
                s2 = _segment_areas(sub2, math.radians(30.0), 2, 'ORGANIC')
            finally:
                bpy.data.meshes.remove(sub2)
            if len(s2) == len(mi) and int(s2.max()) >= 1:
                for k in range(int(s2.max()) + 1):
                    m = s2 == k
                    gi = head[mi[m]]
                    w = fa[gi]
                    if float(w.sum()) > 0.25 * harea:
                        continue
                    nup = float(np.average(fn[gi, up] * sgn, weights=w))
                    ch = (float(np.average(H[gi], weights=w)) - hlo) / hspan
                    if nup < -0.6 and ch > 0.45:
                        # 1.8.5: tudo acima da borda de baixo da aba, em volta
                        # da cabeca inteira (antes as laterais do bone na
                        # altura da aba ficavam como "cabeca")
                        brim_lo = float(H[gi].min())
                        brim_fwd = float(np.average(cen[gi, fwd], weights=w))
                        hair = H[head] >= brim_lo
                        hair[mi[m]] = True
                        break
        hair &= ear == 0
        if float(fa[head][hair].sum()) > 0.85 * harea or float(fa[head][hair].sum()) < 0.03 * harea:
            hair[:] = False
        hat = hair                      # 1.8.6: o que fica acima da aba e chapeu/bone
        # 1.8.7: chapeu = o que nao tem nada da cabeca por cima (ceu aberto)
        # mais a parte de baixo da aba/beirada (logo acima dela so a propria
        # casca do chapeu).  A testa embaixo da viseira e o cabelo embaixo da
        # beirada tem o chapeu por cima: ficam fora.  Cabeca careca nao tem
        # parte de baixo com ceu aberto -> nada de chapeu.
        try:
            hat2 = _hat_by_sky(sub, cen[head], fn[head], up, sgn)
            ha2 = float(fa[head][hat2].sum())
            if 0.08 * harea < ha2 < 0.85 * harea:
                hat = hat2 & (ear == 0)
                # 1.8.11: sem aba de verdade nao se adivinha a frente pelo chapeu
                # (gorro redondo inventava "cabelo" numa cabeca careca)
        except Exception as ex:
            print("[Remesh Ultimate] chapeu:", ex)
        # 1.8.6: frente do rosto = lado da aba (ou das pecas soltas do rosto)
        ff = cen[head, fwd]
        hc = float(np.average(ff, weights=fa[head]))
        front = 0.0
        if hat.any() and brim_fwd is not None:
            front = 1.0 if brim_fwd > hc else -1.0
        # pecas soltas pequenas da cabeca (bigode, olhos, nariz solto)
        vc = _components(sub)
        sfv = np.empty(len(sub.loops), dtype=np.int64)
        sub.loops.foreach_get("vertex_index", sfv)
        sls = np.empty(len(sub.polygons), dtype=np.int64)
        sub.polygons.foreach_get("loop_start", sls)
        fcomp = vc[sfv[sls]]
        nc = int(fcomp.max()) + 1
        carea = np.bincount(fcomp, weights=fa[head], minlength=nc)
        mainc = int(np.argmax(carea))
        if front == 0.0:
            loose = [k for k in range(nc) if k != mainc and carea[k] < 0.08 * harea]
            if loose:
                lm = np.isin(fcomp, loose)
                lf = float(np.average(ff[lm], weights=fa[head][lm]))
                front = 1.0 if lf > hc else -1.0
        must = np.zeros(len(head), dtype=bool)
        for k in range(nc):
            if k == mainc or carea[k] >= 0.08 * harea or carea[k] < 0.002 * harea:
                continue
            m = fcomp == k
            w = fa[head][m]
            cl = float(np.average(LRh[head][m], weights=w))
            ch = (float(np.average(H[head][m], weights=w)) - hlo) / hspan
            cf = (float(np.average(ff[m], weights=w)) - hc) * front
            wid = float(LRh[head][m].max() - LRh[head][m].min())
            if abs(cl) < 0.2 * hhalf and ch < 0.6 and cf > 0 and wid > 0.25 * hhalf:
                must |= m
        must &= (ear == 0) & ~hat
        # cabelo: embaixo do chapeu, na metade de tras da cabeca
        hair2 = np.zeros(len(head), dtype=bool)
        if hat.any() and front != 0.0:
            back_ref = hc
            if (ear != 0).any():
                back_ref = float(np.average(ff[ear != 0], weights=fa[head][ear != 0]))
            # gomos de cabelo da nuca que a segmentacao juntou com a orelha:
            # o que da "orelha" fica atras dela e mais para dentro e cabelo
            lobe = (ear != 0) & ((ff - back_ref) * front < 0) & (np.abs(LRh[head]) < 0.75 * hhalf)
            ear = np.where(lobe, 0, ear)
            hair2 = ((ff - back_ref) * front < 0) & ~hat & (ear == 0) & ~must
            hair2 &= (H[head] - hlo) / hspan > 0.12
            if hair2.any():
                # 1.8.9: o cabelo leva tambem a parte de baixo dos gomos (viradas
                # para baixo) e o que, atras da cabeca, fica abaixo do topo do
                # cabelo - antes isso ia para a cabeca/chapeu e parecia buraco
                Hh = H[head]
                behind = (ff - back_ref) * front < 0
                htop = float(Hh[hair2].max())
                hbot = float(Hh[hair2].min())
                nzu = fn[head, up] * sgn
                under = behind & (ear == 0) & ~must & ~hat & (nzu < -0.3) & (
                    Hh >= hbot - 0.04 * hspan) & (Hh <= htop)
                # 1.8.9b: so passa do chapeu para o cabelo o que toca a malha
                # IRREGULAR do cabelo (vertices com valencia != 4).  A grade
                # regular da parte de baixo da beirada continua no chapeu.
                low_hat = behind & hat & (Hh < htop) & pole_face[head]
                under &= ~hat
                hair2 |= under | low_hat
                hat = hat & ~low_hat
                # 1.8.13: costura cabelo/chapeu = a fileira mais alta de faces
                # com polo (malha irregular do cabelo).  O que fica acima dela,
                # em grade regular, e o chapeu (beirada enrolada para dentro).
                pf = pole_face[head]
                if (hair2 & pf).any():
                    ptop = float(Hh[hair2 & pf].max())
                    up_reg = hair2 & ~pf & (Hh > ptop + 0.005 * hspan)
                    hair2 &= ~up_reg
                    hat |= up_reg
            ha = float(fa[head][hair2].sum())
            if ha < 0.03 * harea or ha > 0.45 * harea:
                hair2[:] = False
        # 1.8.14: a grade REGULAR do chapeu (quads grandes, no maximo um
        # vertice irregular) que ficou na cabeca/cabelo volta para o chapeu.
        # A pele e o cabelo sao malha miuda e irregular: a costura passa a
        # seguir a troca de topologia, sem degraus.
        if hat.any():
            _np = np.zeros(len(me.polygons), dtype=np.int64)
            np.add.at(_np, _lp, (_val[_lv] != 4).astype(np.int64))
            _nv = np.diff(np.append(np.array([p.loop_start for p in me.polygons],
                                             dtype=np.int64), len(me.loops)))
            ah = float(np.median(fa[head][hat]))
            cand = (~hat & (ear == 0) & ~must & (_nv[head] == 4)
                    & (fa[head] > 0.45 * ah) & (_np[head] <= 1))
            g0, g1 = _face_pairs(sub)[:2]
            grown = hat.copy()
            for _it in range(50):
                a = grown[g0] & cand[g1] & ~grown[g1]
                b = grown[g1] & cand[g0] & ~grown[g0]
                new = np.concatenate([g1[a], g0[b]])
                if len(new) == 0:
                    break
                grown[new] = True
            add = grown & ~hat
            if float(fa[head][add].sum()) < 0.10 * harea:
                hat = grown
                hair2 &= ~add
            # dente do cabelo entrando no chapeu (no polo da nuca do chapeu):
            # face de cabelo com 2+ lados encostados no chapeu e acima da
            # fileira mais baixa do chapeu e da beirada -> chapeu
            if hair2.any():
                hb = hat[g0] & hair2[g1]
                hb2 = hat[g1] & hair2[g0]
                touch = np.zeros(len(head), dtype=bool)
                touch[g1[hb]] = True
                touch[g0[hb2]] = True
                if touch.any():
                    Hh = H[head]
                    hat_low = float(np.median(Hh[np.unique(np.concatenate([g0[hb], g1[hb2]]))]))
                    tol = 0.05 * hspan
                    for _it in range(3):
                        cnt = np.zeros(len(head), dtype=np.int64)
                        a = hat[g0] & hair2[g1]
                        b = hat[g1] & hair2[g0]
                        np.add.at(cnt, g1[a], 1)
                        np.add.at(cnt, g0[b], 1)
                        mv = hair2 & (cnt >= 2) & (Hh > hat_low - tol)
                        if not mv.any():
                            break
                        hat |= mv
                        hair2 &= ~mv
    finally:
        bpy.data.meshes.remove(sub)
    if not (hat.any() or ear.any() or must.any() or hair2.any()):
        return sem
    twin = list(int(t) for t in sem["twin"])
    side = list(int(v) for v in sem["side"])

    def add_part(mask, name):
        k = len(names)
        lab[head[mask]] = k
        names.append(name)
        twin.append(k)
        side.append(0)

    if hat.any():
        add_part(hat, "Hat")
    if hair2.any():
        add_part(hair2, "Hair")
    if must.any():
        add_part(must, "Mustache")
    # 1.8.15: a orelha faz parte da cabeca (como o nariz).  Ela continua
    # sendo achada so para nao ir para o cabelo/chapeu.
    if ear.any() and False:
        eL, eR = len(names), len(names) + 1
        lab[head[ear > 0]] = eL
        lab[head[ear < 0]] = eR
        names += ["Ear", "Ear"]
        twin += [eR, eL]
        side += [1, -1]
    out = dict(sem)
    out.update(lab=lab, names=names, twin=np.array(twin, dtype=np.int64),
               side=np.array(side, dtype=np.int64))
    return out


def _object_names_from_mesh(me, lab):
    cen, fa = _face_centers_areas(me)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    f0, f1 = _face_pairs(me)[:2]
    return _semantic_object_parts(cen, fa, fn.reshape(-1, 3), f0, f1, lab)


# 1.7.6 palette.  The colours are designed in sRGB (what the screen shows) and
# converted to scene-linear before they are stored: Blender treats object and
# material colours as LINEAR, so the old HSV values were displayed brighter
# and paler than intended (the washed-out, greyish look).
# 36 colours chosen by farthest-point sampling in CIELAB (each one as far as
# possible from all the ones before it), lightness L* 51-88, chroma >= 45:
# never greyish, never too dark, never white.  Smallest difference between any
# two of the first 12: dE 41; first 24: dE 27; all 36: dE 20.
PALETTE_HEX = ("EDA6A6", "94FF94", "9494FF", "94F7FF", "FFEA94", "FF94E2", "D2D1FF", "B4EDB9",
               "EDB98A", "FFE0D1", "DCFF94", "DEB2FF", "8AA7ED", "8ACAED", "FFC2E7", "ED8AAF",
               "FAFFD1", "DF94FF", "D1F0FF", "D1FFEA", "94FFE4", "94FFB9", "DFF5AB", "AFED98",
               "FF9494", "EDC2CB", "FFAC94", "FFB2F2", "EDD498", "F5C0AB", "B198ED", "FFFF94",
               "A3C8FF", "CAB4ED", "8AEDBE", "FF94FA", "EDA6BD", "BAD6F5", "A3E8FF", "B4B2FF",
               "B4EDEC", "8A96ED", "B9FF94", "BC94FF", "E798ED", "F4D1FF", "D1EDC2", "FFA3D3",
               "A6EDD8", "8AED96", "ED8A9B", "ED8AC5", "B2FFD7", "F3C2FF", "D8A3FF", "CDFFB2",
               "EFFFA3", "ABF5B1", "B4BAED", "FFD1E8", "8EF5EB", "FFA3AF", "ED968A", "E3EDB4",
               "FFC5C2", "FFCF94", "D9FFC2", "C9ED98", "C1A6ED", "ED98DC", "B2FFF5", "FBFFB2",
               )


def _srgb_to_linear(c):
    c = max(0.0, min(1.0, float(c)))
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _palette_srgb(i):
    """Colour number i of the palette, in display sRGB (deterministic)."""
    i = int(i)
    if i < len(PALETTE_HEX):
        h = PALETTE_HEX[i]
        return tuple(int(h[k:k + 2], 16) / 255.0 for k in (0, 2, 4))
    j = i - len(PALETTE_HEX)            # past the table: more pastels, golden angle
    sat, val = ((0.30, 1.0), (0.42, 0.95), (0.20, 0.97))[j % 3]
    return colorsys.hsv_to_rgb((j * 0.61803398875 + 0.07) % 1.0, sat, val)


WIRE_LIGHTEN = 0.15     # wires: palette colour mixed this much toward white (sRGB)


def _wire_colour(i):
    """Object colour for part i - what Wireframe draws.  A thin line in a dark,
    fully saturated colour reads dim on the grey background, so wires get a light
    tint of the same colour (bright like 1.6.8, but from the distinct palette).
    Mirrored parts share the colour index, so their wires are identical too."""
    r, g, b = _palette_srgb(i)
    k = WIRE_LIGHTEN
    return (_srgb_to_linear(r + (1.0 - r) * k), _srgb_to_linear(g + (1.0 - g) * k),
            _srgb_to_linear(b + (1.0 - b) * k), 1.0)


def _area_palette(n):
    """First n palette colours, scene-linear RGBA, ready for object / material colour."""
    cols = np.empty((max(int(n), 1), 4), dtype=np.float32)
    for i in range(len(cols)):
        r, g, b = _palette_srgb(i)
        cols[i] = (_srgb_to_linear(r), _srgb_to_linear(g), _srgb_to_linear(b), 1.0)
    return cols


# --------------------------------------------------------------------------
#  1.6.4  Mirror-aware areas
#  Areas are worked out on one half of a symmetric model and mirrored onto the
#  other half, so left and right are identical.  An area that crosses the mirror
#  plane (hood, wing) stays one area; an area on one side gets a twin on the
#  other side.  Twins share one colour and one material and are named .L / .R.
# --------------------------------------------------------------------------
SIDE_NAMES = {0: (".L", ".R"), 1: (".Back", ".Front"), 2: (".Top", ".Bottom")}


def _find_mirror_plane(me, mode):
    """(axis index, plane position) of the mirror plane of `me`, or (-1, 0.0).
    Check both the object origin and the model midpoint; tolerate modest
    asymmetric accessories while requiring a strong geometric match."""
    if mode == 'NONE' or len(me.polygons) == 0:
        return -1, 0.0
    co = _mesh_co(me)
    if len(co) < 8:
        return -1, 0.0
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    mid = (co.min(axis=0) + co.max(axis=0)) * 0.5
    probe = _bvh_from_mesh(me)
    axes = "XYZ" if mode == 'AUTO' else mode
    for plane in ("origin", "middle"):
        for ax in axes:
            ai = "XYZ".index(ax)
            c = 0.0 if plane == "origin" else float(mid[ai])
            shifted = co.copy()
            shifted[:, ai] -= c
            bvh_s = probe if c == 0.0 else _bvh_from_mesh_shift(me, ai, c)
            if _is_symmetric(shifted, bvh_s, diag, ai):
                return ai, c
    if mode != 'AUTO':
        return "XYZ".index(mode), 0.0
    return -1, 0.0


def _face_centers_areas(me, lin=None):
    nf = len(me.polygons)
    cen = np.empty(nf * 3)
    me.polygons.foreach_get("center", cen)
    cen = cen.reshape(-1, 3)
    fa = np.empty(nf)
    me.polygons.foreach_get("area", fa)
    if lin is not None:
        cen = cen @ np.array(lin).T
    return cen, fa


def _mirror_lookup(me, lin, axis_i, c):
    """For every face on the negative side of the plane: the face on the positive
    side it mirrors onto.  Returns (positive mask, negative face ids, their partner)."""
    co, lv, ls, lt = _mesh_arrays(me)
    if lin is not None:
        co = co @ np.array(lin).T
    cen, _fa = _face_centers_areas(me, lin)
    x = cen[:, axis_i] - c
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    pos = x >= -diag * 1e-5
    pos_ids = np.flatnonzero(pos)
    neg_ids = np.flatnonzero(~pos)
    if len(pos_ids) == 0 or len(neg_ids) == 0:
        return pos, neg_ids, np.zeros(0, dtype=np.int64)
    idx = _loop_ranges(ls[pos_ids], lt[pos_ids])
    half = _build_mesh(co, lv[idx], lt[pos_ids])
    bvh = _bvh_from_mesh(half)
    bpy.data.meshes.remove(half)
    q = cen[neg_ids].copy()
    q[:, axis_i] = 2.0 * c - q[:, axis_i]
    # Compatibility with the original 1.6.8 mirror pairing: always map the
    # reflected face centre to its nearest face on the opposite half.  The
    # restrictive 1.2%-of-diagonal cutoff introduced in 1.7.3 rejected valid
    # kart pairs because face centres do not necessarily lie on the surface.
    partner = np.full(len(neg_ids), -1, dtype=np.int64)
    fn = bvh.find_nearest
    for k, p in enumerate(q.tolist()):
        r = fn(p)
        if r[0] is not None and r[2] is not None:
            partner[k] = pos_ids[r[2]]
    return pos, neg_ids, partner


def _mirror_area_labels(me, lab, axis_i, c):
    """Make segmentation labels mirror-symmetric (mesh already in world proportions).
    Returns labels, twin[label], side[label] (0 centre, +1 / -1)."""
    lab = np.asarray(lab, dtype=np.int64)
    pos, neg_ids, partner = _mirror_lookup(me, None, axis_i, c)
    n0 = int(lab.max()) + 1 if len(lab) else 0
    if len(neg_ids) == 0 or n0 == 0:
        return lab, np.arange(n0), np.zeros(n0, dtype=np.int64)
    _cen, fa = _face_centers_areas(me)
    co, lv, ls, lt = _mesh_arrays(me)
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    # a face touches the plane when one of its corners lies on it (or it crosses it)
    vx = co[lv, axis_i] - c
    touch = np.minimum.reduceat(np.abs(vx), ls) <= diag * 1e-4
    touch |= (np.minimum.reduceat(vx, ls) < 0.0) & (np.maximum.reduceat(vx, ls) > 0.0)
    tot = np.bincount(lab[pos], weights=fa[pos], minlength=n0)
    near = pos & touch
    inb = np.bincount(lab[near], weights=fa[near], minlength=n0)
    # an area that runs along the plane (hood, wing, chin) is one centre area
    centre = (tot > 0) & (inb >= 0.01 * tot)
    twin_id = np.arange(n0) + n0                 # provisional id of each label's twin
    new = lab.copy()
    ok = partner >= 0
    src_lab = lab[partner[ok]]
    new[neg_ids[ok]] = np.where(centre[src_lab], src_lab, twin_id[src_lab])
    # Keep the original 1.6.8 fallback for rare BVH misses.  This prevents
    # one half from becoming a separately-coloured orphan area.
    bad = neg_ids[~ok]
    if len(bad):
        new[bad] = lab[pos][0]
    u, comp = np.unique(new, return_inverse=True)
    comp = comp.ravel()
    remap = -np.ones(2 * n0, dtype=np.int64)
    remap[u] = np.arange(len(u))
    n = len(u)
    twin = np.arange(n)
    side = np.zeros(n, dtype=np.int64)
    for L in range(n0):
        a, b = remap[L], remap[twin_id[L]]
        if a < 0:
            continue
        if centre[L] or b < 0:
            continue
        twin[a], twin[b] = b, a
        side[a], side[b] = 1, -1
    for L in range(n0, 2 * n0):              # a twin whose source vanished: plain area
        b = remap[L]
        if b >= 0 and twin[b] == b:
            side[b] = 0
    return comp, twin, side


def _area_groups(lab, fa, twin):
    """Colour group of every label: mirrored twins MUST share one colour group.

    This is the invariant used by both continuous-mesh material assignment and
    separate-part object colouring.  The palette is indexed by this group,
    never by the individual left/right label.
    """
    n = len(twin)
    size = np.bincount(lab, weights=fa, minlength=n)
    gsize = size + np.where(twin != np.arange(n), size[twin], 0.0)
    group = -np.ones(n, dtype=np.int64)
    g = 0
    for L in np.argsort(-gsize, kind='stable'):
        if group[L] >= 0:
            continue
        T = int(twin[L])
        group[L] = g
        if 0 <= T < n:
            group[T] = g
        g += 1
    return group


def _palette_hue(i):
    r, g, b = _palette_srgb(i)
    h, _sv, _vv = colorsys.rgb_to_hsv(r, g, b)
    return h * 360.0


def _colour_adjacency(pieces, ncolors):
    """Which colour groups touch each other, across every piece."""
    adj = [set() for _ in range(ncolors)]
    for p in pieces:
        me = p["ao"].data
        try:
            f0, f1, _ea, _eb, _w = _face_pairs(me)
        except Exception:
            continue
        if len(f0) == 0:
            continue
        lab = p["meta"]["lab"]
        gc = p["gcolor"]
        a, b = gc[lab[f0]], gc[lab[f1]]
        d = a != b
        for x, y in zip(a[d].tolist(), b[d].tolist()):
            if 0 <= x < ncolors and 0 <= y < ncolors:
                adj[x].add(y)
                adj[y].add(x)
    return adj


def _spread_colours(pieces, ncolors):
    """Give touching areas colours that look nothing alike.

    The palette is vivid and well spread, but neighbours still have to be far
    apart *from each other*, or two areas that share a border can end up as two
    reds.  Groups are taken busiest first and each one takes the free palette
    slot whose hue is furthest from the slots its neighbours already hold.
    """
    if ncolors <= 1:
        return np.arange(max(ncolors, 1), dtype=np.int64)
    adj = _colour_adjacency(pieces, ncolors)
    hues = [_palette_hue(i) for i in range(ncolors)]
    order = sorted(range(ncolors), key=lambda g: (-len(adj[g]), g))
    perm = np.full(ncolors, -1, dtype=np.int64)
    free = set(range(ncolors))

    def hdist(a, b):
        d = abs(a - b) % 360.0
        return min(d, 360.0 - d)

    for g in order:
        taken = [hues[perm[n]] for n in adj[g] if perm[n] >= 0]
        if not taken:
            slot = min(free)
        else:
            slot = max(free, key=lambda c: (min(hdist(hues[c], t) for t in taken), -c))
        perm[g] = slot
        free.discard(slot)
    return perm


def _area_meta(ao):
    """twin, side, group arrays, axis, plane of an areas object (defaults for old files)."""
    me = ao.data
    lab = np.empty(len(me.polygons), dtype=np.int32)
    me.attributes["ru_area"].data.foreach_get("value", lab)
    n = int(lab.max()) + 1 if len(lab) else 1
    twin = np.array(ao.get("ru_twin", []), dtype=np.int64)
    side = np.array(ao.get("ru_side", []), dtype=np.int64)
    group = np.array(ao.get("ru_group", []), dtype=np.int64)
    # 1.13.2: a mirrored follower carries its leader's tables; a leader area that
    # did not land on the follower leaves the table longer than its labels
    if len(twin) > n and len(side) == len(twin) == len(group):
        n = len(twin)
    if len(twin) != n or len(side) != n or len(group) != n:
        twin = np.arange(n)
        side = np.zeros(n, dtype=np.int64)
        group = np.arange(n)
    # 1.7.6: colour of every label.  "ru_gcolor" is written by the scene-wide
    # colour pass (shared groups across mirrored objects); without it the local
    # group is the colour.  Mirrored twins always carry the same value.
    color = np.array(ao.get("ru_gcolor", []), dtype=np.int64)
    if len(color) != n:
        color = group.copy()
    names = [str(x) for x in ao.get("ru_names", [])]
    if len(names) != n:
        names = []
    return dict(lab=lab, twin=twin, side=side, group=group, n=n, color=color, names=names,
                ncolors=int(color.max()) + 1 if len(color) else 1,
                axis=int(ao.get("ru_sym_axis", -1)), c=float(ao.get("ru_sym_c", 0.0)),
                frame=str(ao.get("ru_sym_frame", "WORLD")),
                ngroups=int(group.max()) + 1 if len(group) else 1)


# --------------------------------------------------------------------------
#  1.7.6  Scene-wide colour groups
#  Several selected objects are coloured together.  Mirrored pieces that are
#  separate Blender objects (left / right wheel, two side pods) are found in
#  world space and share colour groups area by area.  Pieces only pair when
#  their shapes really match after mirroring - never on similar size alone.
# --------------------------------------------------------------------------
SCENE_PLANE_MATCH = 0.80   # share of the scene that must mirror onto itself


def _world_piece(src, ao, seed=11):
    """World-space data of one model: sample points, face BVH, size, centre."""
    me = ao.data
    co, lv, ls, lt = _mesh_arrays(me)
    M = np.array(src.matrix_world)
    wco = co @ M[:3, :3].T + M[:3, 3]
    polys = [lv[a:a + b].tolist() for a, b in zip(ls.tolist(), lt.tolist())]
    bvh = BVHTree.FromPolygons(wco.tolist(), polys) if polys else None
    pts = _sample_points(me, limit=600, seed=seed)
    wpts = pts @ M[:3, :3].T + M[:3, 3] if len(pts) else wco
    cen = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("center", cen)
    wcen = cen.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]
    fa = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", fa)
    sc = abs(np.linalg.det(M[:3, :3])) ** (2.0 / 3.0)
    lo, hi = wco.min(axis=0), wco.max(axis=0)
    return dict(src=src, ao=ao, pts=wpts, bvh=bvh, fcen=wcen, farea=fa * sc, wco=wco, polys=polys,
                area=float((fa * sc).sum()), lo=lo, hi=hi,
                diag=float(np.linalg.norm(hi - lo)) or 1e-9,
                centre=(lo + hi) * 0.5)


def _reflect(P, n, d):
    """Mirror points P across the plane n.x = d (n unit length)."""
    P = np.asarray(P, dtype=np.float64)
    return P - 2.0 * ((P @ n) - d)[:, None] * n[None, :]


def _scene_mirror_plane(pieces, mode, active=None):
    """Mirror plane of all pieces together, in world space: (normal, offset, share)
    or (None, 0, share).  The plane may sit anywhere and need not follow the
    world axes: candidates are the world axes and the active object's own axes
    (a whole model turned in the scene), through the middle of the model, the
    world origin or the active object's origin."""
    if mode == 'NONE' or not pieces:
        return None, 0.0, 0.0
    P = np.vstack([p["pts"] for p in pieces])
    lo, hi = P.min(axis=0), P.max(axis=0)
    diag = float(np.linalg.norm(hi - lo)) or 1.0
    # distance to the SURFACE of all pieces together (not to other sample
    # points, which would miss on a big, sparsely sampled piece)
    allco, allpoly, off = [], [], 0
    for p in pieces:
        allco.append(p["wco"])
        allpoly.extend([[v + off for v in poly] for poly in p["polys"]])
        off += len(p["wco"])
    union = BVHTree.FromPolygons(np.vstack(allco).tolist(), allpoly)
    tol = diag * 0.01
    mid = (lo + hi) * 0.5
    normals = []
    axes = "XYZ" if mode == 'AUTO' else mode
    for ax in axes:
        ai = "XYZ".index(ax)
        e = np.zeros(3)
        e[ai] = 1.0
        normals.append(e)
        if active is not None:
            r = np.array(active.matrix_world.to_3x3().normalized())
            v = r[:, ai] / (np.linalg.norm(r[:, ai]) or 1.0)
            if abs(abs(float(v @ e)) - 1.0) > 1e-4:
                normals.append(v)
    # every piece weighs by its surface area: one odd small piece (an accessory
    # on one side only) must not hide the symmetry of the whole model
    wts = np.array([p["area"] for p in pieces], dtype=np.float64)
    wts = wts / (wts.sum() or 1.0)
    subs = [p["pts"][::max(1, len(p["pts"]) // 250)] for p in pieces]
    best = (None, 0.0, 0.0)
    for n in normals:
        cands = [float(mid @ n), 0.0]
        if active is not None:
            cands.append(float(np.array(active.matrix_world.translation) @ n))
        for d in cands:
            share = 0.0
            for w_, sub in zip(wts, subs):
                Q = _reflect(sub, n, d)
                hit = 0
                for q in Q.tolist():
                    r = union.find_nearest(q, tol)
                    hit += r[0] is not None
                share += w_ * hit / float(len(Q))
            if share > best[2] + 1e-9:
                best = (n, d, share)
    if best[2] >= SCENE_PLANE_MATCH:
        # 1.13.2: the candidates above are coarse (bbox middle, world 0, active
        # origin).  A kart whose origin sits 1.8 cm off its true middle mirrored
        # the left wheels 3.6 cm away from the right ones and no pair was found.
        # Slide the plane along its normal to where the model really mirrors.
        try:
            d_fine = _refine_plane_offset(union, subs, wts, best[0], best[1], diag)
            best = (best[0], d_fine, best[2])
        except Exception as ex:
            print("[Remesh Ultimate] plane refine:", ex)
        return best
    return None, 0.0, best[2]


def _refine_plane_offset(union, subs, wts, n, d0, diag, span=0.04, budget=3000):
    """Best plane offset near d0: minimises the robust mean distance between the
    mirrored sample points and the surface of all pieces together."""
    n = np.asarray(n, dtype=np.float64)
    tot = sum(len(s_) for s_ in subs) or 1
    keep = max(1, int(math.ceil(tot / float(budget))))
    pts, w = [], []
    for w_, sub in zip(wts, subs):
        sub = sub[::keep]
        if len(sub) == 0:
            continue
        pts.append(sub)
        w.append(np.full(len(sub), w_ / len(sub)))
    if not pts:
        return d0
    P = np.vstack(pts)
    W = np.concatenate(w)
    cap = diag * 0.02            # far misses (one-sided accessories) count only this much
    fn = union.find_nearest

    def cost(d):
        Q = _reflect(P, n, d)
        dist = np.empty(len(Q))
        for i, q in enumerate(Q.tolist()):
            r = fn(q, cap)
            dist[i] = r[3] if r[0] is not None else cap
        return float((dist * W).sum())

    lo, hi = d0 - span * diag, d0 + span * diag
    grid = np.linspace(lo, hi, 17)
    vals = [cost(g) for g in grid]
    k = int(np.argmin(vals))
    a = grid[max(k - 1, 0)]
    b = grid[min(k + 1, len(grid) - 1)]
    g = (math.sqrt(5.0) - 1.0) * 0.5          # golden-section on the best bracket
    c_, e_ = b - g * (b - a), a + g * (b - a)
    fc, fe = cost(c_), cost(e_)
    for _ in range(14):
        if fc < fe:
            b, e_, fe = e_, c_, fc
            c_ = b - g * (b - a)
            fc = cost(c_)
        else:
            a, c_, fc = c_, e_, fe
            e_ = a + g * (b - a)
            fe = cost(e_)
    d_best = 0.5 * (a + b)
    # never worse than where we started
    return d_best if cost(d_best) <= cost(d0) else d0


def _mirror_mismatch(a, b, n, d):
    """How far piece a, mirrored, lies from piece b (and back), in % of their size.
    Uses the 90th percentile of the surface distances, so a small local
    difference is tolerated but a different shape is not."""
    if a["bvh"] is None or b["bvh"] is None:
        return 1e9
    dist = []
    for src_, dst in ((a, b), (b, a)):
        for p in _reflect(src_["pts"], n, d).tolist():
            r = dst["bvh"].find_nearest(p)
            dist.append(r[3] if r[0] is not None else 1e9)
    size = min(a["diag"], b["diag"])
    return 100.0 * float(np.percentile(dist, 90)) / size


def _pair_mirrored_pieces(pieces, n, d, tol_pct):
    """One-to-one mirrored pairs (i, j, mismatch) and the pieces that mirror
    onto themselves (centre pieces, e.g. a hood across the plane)."""
    cnt = len(pieces)
    centre = set()
    for i, p in enumerate(pieces):
        side = p["pts"] @ n - d
        if side.min() < 0.0 < side.max() and _mirror_mismatch(p, p, n, d) <= tol_pct:
            centre.add(i)
    cand = []
    for i in range(cnt):
        a = pieces[i]
        if i in centre:
            continue
        mc = _reflect(a["centre"][None, :], n, d)[0]
        for j in range(i + 1, cnt):
            b = pieces[j]
            if j in centre:
                continue
            ratio = a["diag"] / b["diag"]
            if not (0.75 <= ratio <= 1.333):
                continue
            if not (0.6 <= a["area"] / max(b["area"], 1e-12) <= 1.667):
                continue
            if np.linalg.norm(mc - b["centre"]) > 0.25 * max(a["diag"], b["diag"]):
                continue
            m, dp = _pair_mismatch(a, b, n, d)
            if m <= tol_pct:
                cand.append((m, i, j, dp))
    cand.sort(key=lambda t: t[0])
    used, pairs = set(), []
    for m, i, j, dp in cand:
        if i in used or j in used:
            continue
        used.update((i, j))
        pairs.append((i, j, m, dp))
    return pairs, centre


def _pair_mismatch(a, b, n, d):
    """1.13.2: (mismatch %, plane offset) of two separate pieces.  A modelled pair
    is rarely placed exactly: the kart's left wheels sit 1.8 cm off the mirror of
    the right ones (3.6 cm once mirrored), more than the tolerance on a small hub,
    so the pair was never found and the twins got different colours.  The plane
    may slide for this pair only - never further than 5% of the pieces' size -
    to where the two really mirror each other."""
    m0 = _mirror_mismatch(a, b, n, d)
    best = (m0, d)
    size = max(a["diag"], b["diag"])
    d_mid = float(0.5 * (a["centre"] + b["centre"]) @ n)     # plane halfway between them
    if abs(d_mid - d) > 0.05 * size:
        d_mid = d + math.copysign(0.05 * size, d_mid - d)
    for t in (0.0, 0.25, 0.5, 0.75, 1.0):
        dd = d + (d_mid - d) * t
        if t == 0.0:
            continue
        m = _mirror_mismatch(a, b, n, dd)
        if m < best[0]:
            best = (m, dd)
    # small polish around the best offset
    step = 0.005 * size
    for dd in (best[1] - step, best[1] + step):
        m = _mirror_mismatch(a, b, n, dd)
        if m < best[0]:
            best = (m, dd)
    return best


def _assign_scene_colors(context, sources):
    """Give every area of every source a palette colour.  Rules:
    - twins inside one object share a colour (already one local group);
    - a piece that mirrors another selected object takes, area by area, the
      colour of the area it mirrors onto;
    - everything else gets its own colour, in a fixed order (by object name
      and area size), so running it again gives the same colours."""
    s = context.scene.remesh_ultimate
    pieces = []
    for src in sorted(sources, key=lambda o: o.name):
        ao = _areas_obj(src)
        if ao is None or "ru_area" not in ao.data.attributes or len(ao.data.polygons) == 0:
            continue
        pieces.append(_world_piece(src, ao))
    if not pieces:
        return []
    for p in pieces:
        p["meta"] = _area_meta(p["ao"])
    pairs, pn, pd = [], None, 0.0
    if len(pieces) > 1:
        pn, pd, _share = _scene_mirror_plane(pieces, s.symmetry, context.active_object)
        if pn is not None:
            pairs, _centre = _pair_mirrored_pieces(pieces, pn, pd, s.mirror_tolerance)
    follower = {}
    for i, j, m, dp in pairs:
        a, b = pieces[i], pieces[j]
        # the piece on the positive side of the plane leads, the other follows
        lead, fol = (i, j) if float(a["centre"] @ pn) >= float(b["centre"] @ pn) else (j, i)
        follower[fol] = (lead, m, dp)
    nxt = 0
    for k, p in enumerate(pieces):
        if k in follower:
            continue
        g = p["meta"]["group"]
        p["gcolor"] = g + nxt
        nxt += int(g.max()) + 1 if len(g) else 1
    report = []
    for k, (lead, m, dp) in sorted(follower.items()):
        # 1.13.2: the follower takes the leader's areas themselves, mirrored face
        # by face (not just its colours): both wheels are cut at the same places,
        # so the separated parts match one to one and share colour and name.
        p, L = pieces[k], pieces[lead]
        q = _reflect(p["fcen"], pn, dp)
        llab = L["meta"]["lab"]
        new = np.zeros(len(q), dtype=np.int64)
        fnear = L["bvh"].find_nearest
        for f, pt in enumerate(q.tolist()):
            r = fnear(pt)
            if r[2] is not None:
                new[f] = llab[r[2]]
        ao, lao = p["ao"], L["ao"]
        at = ao.data.attributes.get("ru_area")
        at.data.foreach_set("value", new.astype(np.int32))
        for key in ("ru_twin", "ru_side", "ru_group", "ru_names"):
            ao[key] = list(lao.get(key, []))
        ao["ru_mode"] = lao.get("ru_mode", ao.get("ru_mode", "AREAS"))
        p["meta"] = _area_meta(ao)
        gl = np.asarray(L["gcolor"], dtype=np.int64)
        p["gcolor"] = gl[:p["meta"]["n"]] if len(gl) >= p["meta"]["n"] else np.resize(gl, p["meta"]["n"])
        report.append((p["src"].name, L["src"].name, m))
    perm = _spread_colours(pieces, max(nxt, 1))
    for p in pieces:
        p["gcolor"] = perm[np.asarray(p["gcolor"], dtype=np.int64)]
    pal = _area_palette(max(nxt, 1))
    for k, p in enumerate(pieces):
        ao = p["ao"]
        ao["ru_gcolor"] = [int(v) for v in p["gcolor"]]
        pair = follower.get(k)
        lead_of = [pieces[f]["src"].name for f, (ld, _m, _d) in follower.items() if ld == k]
        ao["ru_mirror_partner"] = (pieces[pair[0]]["src"].name if pair
                                   else (lead_of[0] if lead_of else ""))
        # 1.13.2: a follower is not remeshed on its own - REMESH mirrors its
        # leader's result through this world plane (identical twins)
        if pair:
            ao["ru_mirror_lead"] = pieces[pair[0]]["src"].name
            ao["ru_mirror_plane"] = [float(v) for v in pn] + [float(pair[2])]
        else:
            for key in ("ru_mirror_lead", "ru_mirror_plane"):
                if key in ao:
                    del ao[key]
        _paint_area_preview(ao, pal)
    return report


def _mirror_lead(src):
    """(leader name, (n, d)) when `src` is the mirrored twin of another object."""
    ao = _areas_obj(src)
    if ao is None:
        return None, None
    lead = str(ao.get("ru_mirror_lead", ""))
    pl = list(ao.get("ru_mirror_plane", []))
    if not lead or len(pl) != 4:
        return None, None
    return lead, (np.array(pl[:3], dtype=np.float64), float(pl[3]))


def _mirror_parts_from(context, src, lead_parts, plane, s):
    """1.13.2: build `src`'s parts as the exact mirror of its leader's parts."""
    n, d = plane
    R = np.eye(4)
    R[:3, :3] -= 2.0 * np.outer(n, n)
    R[:3, 3] = 2.0 * d * n
    W = Matrix(R.tolist())
    Mf_inv = src.matrix_world.inverted()
    cname = src.name + "_QUAD_AREAS"
    coll = bpy.data.collections.get(cname)
    if coll is None:
        coll = bpy.data.collections.new(cname)
        context.scene.collection.children.link(coll)
    for o in list(coll.objects):
        m = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if m is not None and m.users == 0:
            bpy.data.meshes.remove(m)
    lead_name = str(lead_parts[0].get("ru_source", "")) if lead_parts else ""
    made = []
    for lp in lead_parts:
        m = lp.data.copy()
        m.transform(Mf_inv @ W @ lp.matrix_world)
        m.flip_normals()
        nm = lp.name
        if lead_name and nm.startswith(lead_name):
            nm = src.name + nm[len(lead_name):]
        else:
            nm = src.name + "_" + nm
        m.name = nm
        ob = bpy.data.objects.new(nm, m)
        ob.matrix_world = src.matrix_world
        ob.color = lp.color
        for key in ("ru_color", "ru_report", "ru_score"):
            if key in lp:
                ob[key] = lp[key]
        ob["ru_area_of"] = src.name
        ob["ru_source"] = src.name
        ob["ru_mirror_of"] = lp.name
        coll.objects.link(ob)
        made.append(ob)
    return coll, made


def _paint_area_preview(ao, pal=None):
    """Repaint the Detect Areas preview with the final colours."""
    meta = _area_meta(ao)
    me = ao.data
    if pal is None or len(pal) < meta["ncolors"]:
        pal = _area_palette(meta["ncolors"])
    col = me.color_attributes.get("RU_Areas")
    if col is None:
        col = me.color_attributes.new("RU_Areas", 'BYTE_COLOR', 'CORNER')
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    if len(meta["lab"]):
        col.data.foreach_set("color", np.repeat(pal[meta["color"][meta["lab"]]], lt, axis=0).ravel())
    me.color_attributes.active_color = col
    me.update()


def _areas_stamp(s, n_sel):
    """1.13.2: the settings an areas object was detected with.  A stale areas
    object (other mode, quad size, selection...) is detected again."""
    return "|".join(str(x) for x in (
        VERSION_STR, getattr(s, "detect_mode", ""), s.area_count, s.area_style,
        s.quad_size, s.symmetry, round(float(s.sharp_angle), 4), s.join_legs,
        "ASSEMBLY" if n_sel >= 2 else "SINGLE"))


_SELECTION = {"n": 1}      # how many objects the current detection runs on


def _ensure_areas(context, sources):
    """Areas object for every source (detected on the fly when missing or stale)."""
    s = context.scene.remesh_ultimate
    out = []
    stamp = _areas_stamp(s, len(sources))
    missing = []
    for src in sources:
        ao = _areas_obj(src)
        if ao is not None and str(ao.get("ru_stamp", "")) != stamp:
            m = ao.data
            bpy.data.objects.remove(ao, do_unlink=True)
            if m is not None and m.users == 0:
                bpy.data.meshes.remove(m)
            ao = None
        if ao is None:
            missing.append(src)
    _PLANE_HINT["plane"] = _selection_plane(context, sources) if missing else None
    _SELECTION["n"] = len(sources)
    try:
        for src in sources:
            ao = _areas_obj(src)
            if ao is None:
                ao, _n = _make_areas(context, src, s)
                ao["ru_stamp"] = stamp
            out.append(ao)
    finally:
        _PLANE_HINT["plane"] = None
        _SELECTION["n"] = 1
    return out


def _mirror_result_labels(src, me, lab, meta):
    """Copy the labels of the positive half of a result onto its negative half
    (through the twin table), so twin parts match quad for quad."""
    if meta["axis"] < 0 or len(lab) == 0:
        return lab
    lin = _local_work_matrix(src) if meta.get("frame") == "LOCAL" else _work_matrix(src)
    pos, neg_ids, partner = _mirror_lookup(me, lin, meta["axis"], meta["c"])
    ok = partner >= 0
    lab = np.asarray(lab, dtype=np.int64).copy()
    lab[neg_ids[ok]] = meta["twin"][lab[partner[ok]]]
    return lab


def _side_suffix(meta, L):
    sd = int(meta["side"][L])
    if sd == 0 or meta["axis"] < 0:
        return ""
    names = SIDE_NAMES.get(meta["axis"], (".A", ".B"))
    return names[0] if sd > 0 else names[1]


def _corner_normals(me):
    """Per-corner shading normals of the whole mesh (None if unavailable)."""
    try:
        cn = np.empty(len(me.loops) * 3)
        me.corner_normals.foreach_get("vector", cn)
        return cn.reshape(-1, 3)
    except Exception:
        return None


def _apply_corner_normals(m, cn_part):
    """Give a split-off part the shading of the whole model: no seams between parts."""
    if cn_part is None:
        return False
    try:
        m.polygons.foreach_set("use_smooth", np.ones(len(m.polygons), dtype=bool))
        m.normals_split_custom_set(cn_part.astype(np.float32))
        return True
    except Exception as ex:
        print("[Remesh Ultimate] custom normals:", ex)
        return False


def _areas_obj(src):
    return bpy.data.objects.get(src.name + AREAS_SUFFIX)


def _lines_obj(src):
    return bpy.data.objects.get(src.name + LINES_SUFFIX)


def _selected_sources(context):
    """1.6.8: every selected model (active first), never a result or a helper twice."""
    out = []
    obs = list(context.selected_objects)
    if context.active_object is not None:
        obs.insert(0, context.active_object)
    for o in obs:
        o = _source_of(o)
        if (o is not None and o.type == 'MESH' and "ru_source" not in o
                and o not in out):
            out.append(o)
    return out


def _source_of(ob):
    if ob is None:
        return None
    s = ob.get("ru_helper_of") or ob.get("ru_area_of")
    if s:
        return bpy.data.objects.get(s)
    return ob


def _guide_segments(src, lin, offset, areas=True):
    """Area borders + drawn lines of `src`, in the remesh working space."""
    A, B = [], []
    M = lin.to_4x4()
    ao = _areas_obj(src) if areas else None
    if ao is not None and "ru_area" in ao.data.attributes:
        me = ao.data
        lab = np.empty(len(me.polygons), dtype=np.int32)
        me.attributes["ru_area"].data.foreach_get("value", lab)
        f0, f1, ea, eb, co = _face_pairs(me)
        diffm = lab[f0] != lab[f1]
        # relax the soft (curvature) borders so the guides are smooth curves;
        # real creases and junctions stay exactly where they are
        fn = np.empty(len(me.polygons) * 3)
        me.polygons.foreach_get("normal", fn)
        fn = fn.reshape(-1, 3)
        dots = np.einsum('ij,ij->i', fn[f0[diffm]], fn[f1[diffm]])
        hardcut = dots < math.cos(math.radians(30.0))
        ce = np.stack([ea[diffm], eb[diffm]], axis=1)
        nv = len(co)
        dg_ = np.bincount(ce.ravel(), minlength=nv)
        pinned = np.zeros(nv, dtype=bool)
        pinned[ce[hardcut].ravel()] = True
        movable = (dg_ == 2) & ~pinned
        if movable.any():
            bvh_a = _bvh_from_mesh(me)
            pos = co.copy()
            for _it in range(25):
                acc = np.zeros_like(pos)
                np.add.at(acc, ce[:, 0], pos[ce[:, 1]])
                np.add.at(acc, ce[:, 1], pos[ce[:, 0]])
                avg = acc / np.maximum(dg_, 1)[:, None]
                mv = np.flatnonzero(movable)
                pos[mv] = pos[mv] * 0.5 + avg[mv] * 0.5
                if _it % 5 == 4:
                    for i in mv:
                        r = bvh_a.find_nearest(Vector(pos[i]))
                        if r[0] is not None:
                            pos[i] = r[0]
            co = pos
        # only real creases between areas guide the quads; soft (curvature) borders are
        # for organisation - forcing loops onto them would ripple smooth surfaces
        if hardcut.any():
            A.append(co[ce[hardcut, 0]])
            B.append(co[ce[hardcut, 1]])
    lo = _lines_obj(src)
    if lo is not None and len(lo.data.edges):
        co = _mesh_co(lo.data)
        ed = _mesh_edges(lo.data)
        A.append(co[ed[:, 0]])
        B.append(co[ed[:, 1]])
    if not A:
        return None
    A = np.concatenate(A)
    if len(A) == 0:
        return None
    B = np.concatenate(B)
    R = np.array(lin)
    A = A @ R.T - np.array(offset)
    B = B @ R.T - np.array(offset)
    return A, B


def _glove_cuff_by_topology(me, lab, names):
    """1.8.14: a manga e grade regular (quads grandes); a luva e malha miuda e
    irregular.  As faces irregulares da manga encostadas na luva sao o punho
    da luva: passam para a luva, e a costura segue a troca de topologia."""
    gl = [k for k, n in enumerate(names) if n in ("Glove", "Hand")]
    sl = [k for k, n in enumerate(names) if n in ("Shirt", "UpperArm", "Forearm")]
    if not gl or not sl:
        return lab
    lab = np.asarray(lab, dtype=np.int64).copy()
    _cen, fa = _face_centers_areas(me)
    ed = np.empty(len(me.edges) * 2, dtype=np.int64)
    me.edges.foreach_get("vertices", ed)
    val = np.bincount(ed, minlength=len(me.vertices))
    lv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", lv)
    ls = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    lp = np.repeat(np.arange(len(me.polygons)), lt)
    npole = np.zeros(len(me.polygons), dtype=np.int64)
    np.add.at(npole, lp, (val[lv] != 4).astype(np.int64))
    sleeve = np.isin(lab, sl)
    reg = sleeve & (npole <= 1) & (lt == 4)
    if reg.sum() < 20:
        return lab
    areg = float(np.median(fa[reg]))
    cand = sleeve & ((npole >= 2) | (lt != 4)) & (fa < 0.6 * areg)
    f0, f1 = _face_pairs(me)[:2]
    for k in gl:
        g = lab == k
        if not g.any():
            continue
        garea = float(fa[g].sum())
        grown = g.copy()
        for _it in range(40):
            a = grown[f0] & cand[f1] & ~grown[f1]
            b = grown[f1] & cand[f0] & ~grown[f0]
            new = np.concatenate([f1[a], f0[b]])
            if len(new) == 0:
                break
            grown[new] = True
        add = grown & ~g
        if add.any() and float(fa[add].sum()) < 0.5 * garea:
            lab[add] = k
    return lab


def _shirt_by_topology(me, lab, names):
    """1.8.7: dentro do macacao/tronco, a camisa (ombros, alto das costas) tem
    faces bem menores que o macacao.  Limiar de Otsu no log da area; so vale
    se as duas familias forem bem diferentes, e fica so o que encosta nos
    bracos.  Devolve a mascara (faces) ou None."""
    tid = None
    for nm in ("Overalls", "Torso"):
        if nm in names:
            tid = names.index(nm)
            break
    arms = [k for k, n in enumerate(names) if n == "UpperArm"]
    if tid is None or not arms:
        return None
    cen, fa = _face_centers_areas(me)
    f0, f1 = _face_pairs(me)[:2]
    T = np.flatnonzero(lab == tid)
    if len(T) < 60:
        return None
    la = np.log(np.maximum(fa[T], 1e-18))
    vs = np.sort(la)
    best_t, best_v = None, -1.0
    for t in np.linspace(vs[len(vs) // 20], vs[-len(vs) // 20 - 1], 80):
        lo_, hi_ = la[la < t], la[la >= t]
        if len(lo_) < 0.05 * len(la) or len(hi_) < 0.05 * len(la):
            continue
        v = len(lo_) * len(hi_) * (lo_.mean() - hi_.mean()) ** 2
        if v > best_v:
            best_t, best_v = t, v
    if best_t is None:
        return None
    if float(np.exp(la[la >= best_t].mean() - la[la < best_t].mean())) < 2.2:
        return None                     # uma topologia so: nada de camisa
    inT = np.zeros(len(fa), dtype=bool)
    inT[T] = True
    small = inT & (np.log(np.maximum(fa, 1e-18)) < best_t)
    ok = inT[f0] & inT[f1]
    A = np.concatenate([f0[ok], f1[ok]])
    B = np.concatenate([f1[ok], f0[ok]])
    deg = np.bincount(A, minlength=len(fa))
    for _it in range(6):
        cnt = np.bincount(A, weights=small[B].astype(float), minlength=len(fa))
        new = small.copy()
        new[inT & (cnt * 2 > deg)] = True
        new[inT & (cnt * 2 < deg)] = False
        small = new
    isarm = np.isin(lab, arms)
    vis = np.zeros(len(fa), dtype=bool)
    vis[f1[isarm[f0] & small[f1]]] = True
    vis[f0[isarm[f1] & small[f0]]] = True
    ok2 = small[f0] & small[f1]
    A2 = np.concatenate([f0[ok2], f1[ok2]])
    B2 = np.concatenate([f1[ok2], f0[ok2]])
    for _r in range(2000):
        g = vis[A2] & ~vis[B2]
        if not g.any():
            break
        vis[B2[g]] = True
    if not vis.any() or float(fa[vis].sum()) > 0.6 * float(fa[T].sum()):
        return None
    # 1.8.11: camisa de verdade cobre parte do tronco (ombros, peito), nao so
    # uma faixa no pescoco - membros finos tambem tem faces menores
    if float(fa[vis].sum()) < 0.08 * float(fa[T].sum()):
        return None
    return vis


SMALL_PIECE_SHARE = 0.03   # a loose piece under 3% of the object's surface is a detail


def _merge_small_pieces(me, lab, share=SMALL_PIECE_SHARE):
    """1.13.2: loose details join the area of the nearest big piece.

    "Separate pieces are always their own area" turned a tyre with 270 loose
    tread blocks into ~80 objects.  A loose piece that is small next to the
    object (tread block, bolt, rivet) now takes the area of the closest face of
    a big piece; big loose pieces still stay separate."""
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(me.polygons)
    if nf == 0 or len(lab) != nf:
        return lab
    vc = _components(me)
    fv = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", fv)
    ls = np.empty(nf, dtype=np.int64)
    me.polygons.foreach_get("loop_start", ls)
    fcomp = vc[fv[ls]]
    ncomp = int(fcomp.max()) + 1
    if ncomp < 2:
        return lab
    cen, fa = _face_centers_areas(me)
    carea = np.bincount(fcomp, weights=fa, minlength=ncomp)
    total = float(carea.sum()) or 1.0
    big = carea >= share * total
    if not big.any():
        # all pieces are small: the biggest ones (together half the surface) lead
        order = np.argsort(-carea)
        acc = np.cumsum(carea[order])
        big[order[:int(np.searchsorted(acc, 0.5 * total)) + 1]] = True
    if big.all():
        return lab
    anchor = np.flatnonzero(big[fcomp])
    kd = KDTree(len(anchor))
    for i, f in enumerate(anchor.tolist()):
        kd.insert(cen[f].tolist(), i)
    kd.balance()
    for comp in np.flatnonzero(~big).tolist():
        faces = np.flatnonzero(fcomp == comp)
        if len(faces) == 0:
            continue
        # the whole piece goes to the area its centre is nearest to
        pc = (cen[faces] * fa[faces, None]).sum(axis=0) / max(float(fa[faces].sum()), 1e-18)
        _co, idx, _dist = kd.find(pc.tolist())
        if idx is None:
            continue
        lab[faces] = lab[anchor[idx]]
    _u, lab = np.unique(lab, return_inverse=True)
    return lab.ravel().astype(np.int64)


# --------------------------------------------------------------------------
#  1.13.3  Creature detection (big-headed figures: chibi, toys, AI meshes)
#  Regions come from a watershed on the grooves of the surface (the fur of a
#  generated mesh hides creases).  Eyes = the most convex mirrored pair on the
#  front, refined by a sphere fit; helmet / hat = the smooth dome reaching the
#  top, refined by a sphere fit, with what bulges from its sides (headphones);
#  muzzle = the front of the face between the eyes and the chin; the neck is
#  the narrowest point of the central column; arms go with the body.
# --------------------------------------------------------------------------
CREATURE_FACES = 120000      # analysed on a copy reduced to this many faces
CREATURE_HEAD_WITH_BODY = True   # 1.13.4: head + body one piece, helmet one piece


def _cr_groove_signal(co, vn, edges, diag, iters=25):
    a, b = edges[:, 0], edges[:, 1]
    nv = len(co)
    deg = np.bincount(np.r_[a, b], minlength=nv).astype(float).clip(1)
    p = co.copy()
    for _ in range(iters):
        acc = np.zeros_like(p)
        np.add.at(acc, a, p[b])
        np.add.at(acc, b, p[a])
        p = 0.5 * p + 0.5 * acc / deg[:, None]
    return np.einsum('ij,ij->i', (p - co), vn) / diag      # > 0 concave, < 0 convex


def _cr_watershed(g, f0, f1, fa, thr=0.002, small=0.002):
    nf = len(g)
    A_ = np.r_[f0, f1]; B_ = np.r_[f1, f0]
    order = np.argsort(A_, kind='stable'); A = A_[order]; B = B_[order]
    start = np.searchsorted(A, np.arange(nf)); end = np.searchsorted(A, np.arange(nf), side='right')
    nbmin = np.full(nf, np.inf)
    np.minimum.at(nbmin, f0, g[f1]); np.minimum.at(nbmin, f1, g[f0])
    seeds = np.flatnonzero(g < nbmin)
    lab = np.full(nf, -1, dtype=np.int64)
    lab[seeds] = np.arange(len(seeds))
    h = [(float(g[f]), int(f)) for f in seeds]
    heapq.heapify(h)
    gl = g.tolist(); Bl = B.tolist(); st = start.tolist(); en = end.tolist(); labl = lab.tolist()
    saddle = {}
    while h:
        val, f = heapq.heappop(h)
        L = labl[f]
        for k in range(st[f], en[f]):
            n = Bl[k]; Ln = labl[n]
            if Ln < 0:
                labl[n] = L
                heapq.heappush(h, (max(gl[n], val), n))
            elif Ln != L:
                key = (L, Ln) if L < Ln else (Ln, L)
                sv = max(gl[f], gl[n])
                if key not in saddle or sv < saddle[key]:
                    saddle[key] = sv
    lab = np.array(labl)
    nreg = int(lab.max()) + 1 if len(seeds) else 0
    un = np.flatnonzero(lab < 0)
    lab[un] = nreg + np.arange(len(un)); nreg += len(un)
    rmin = np.full(nreg, np.inf); np.minimum.at(rmin, lab, g)
    rarea = np.bincount(lab, weights=fa, minlength=nreg)
    tot = float(fa.sum()) or 1.0
    parent = list(range(nreg))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    rm = rmin.tolist(); ra = rarea.tolist()
    edges = [(sv - max(rm[a], rm[b]), sv, a, b) for (a, b), sv in saddle.items()]
    heapq.heapify(edges)
    while edges:
        d_, sv, a, b = heapq.heappop(edges)
        x, y = find(a), find(b)
        if x == y:
            continue
        dd = sv - max(rm[x], rm[y])
        if dd > d_ + 1e-12:
            heapq.heappush(edges, (dd, sv, x, y)); continue
        if dd > thr and min(ra[x], ra[y]) > small * tot:
            continue
        parent[y] = x; rm[x] = min(rm[x], rm[y]); ra[x] += ra[y]
    roots = np.array([find(i) for i in range(nreg)])
    return np.unique(roots[lab], return_inverse=True)[1].ravel()


def _cr_roughness(fn, f0, f1, iters=2):
    sm = fn.copy()
    for _ in range(iters):
        acc = sm.copy()
        np.add.at(acc, f0, sm[f1]); np.add.at(acc, f1, sm[f0])
        sm = acc / np.linalg.norm(acc, axis=1, keepdims=True).clip(1e-12)
    return 1.0 - np.einsum('ij,ij->i', fn, sm)


def _cr_adjacency(lab, f0, f1, n):
    d = lab[f0] != lab[f1]
    a, b = lab[f0][d], lab[f1][d]
    key = np.minimum(a, b) * n + np.maximum(a, b)
    u, c = np.unique(key, return_counts=True)
    adj = [dict() for _ in range(n)]
    for k, cnt in zip(u.tolist(), c.tolist()):
        x, y = divmod(k, n)
        adj[x][y] = cnt; adj[y][x] = cnt
    return adj


def _cr_segment_creature(cen, fn, fa, g_face, f0, f1, lr_axis, lr_mid, log=None):
    """Returns (labels per face, names) with names among
    Body, Head, Helmet, Eye(L/R share name), Muzzle.  None when no face found."""
    log = log if log is not None else []
    nf = len(cen)
    tot = float(fa.sum())
    lo, hi = cen.min(0), cen.max(0); ext = hi - lo
    others = [a for a in range(3) if a != lr_axis]
    up = others[0] if ext[others[0]] >= ext[others[1]] else others[1]
    fwd = others[1] if up == others[0] else others[0]
    H = (cen[:, up] - lo[up]) / ext[up]               # 0 feet .. 1 top
    X = (cen[:, lr_axis] - lr_mid) / ext[lr_axis]     # signed, centred
    # ---- regions
    reg = _cr_watershed(g_face, f0, f1, fa)
    n = int(reg.max()) + 1
    rough = _cr_roughness(fn, f0, f1)
    RA = np.bincount(reg, weights=fa, minlength=n).clip(1e-18)

    def rm(x):
        return np.bincount(reg, weights=fa * x, minlength=n) / RA
    rH, rX = rm(H), rm(X)
    rF = rm(cen[:, fwd]); rNf = rm(fn[:, fwd]); rR = rm(rough); rG = rm(g_face)
    rN = np.stack([rm(fn[:, i]) for i in range(3)], 1)
    rNlen = np.linalg.norm(rN, axis=1)        # 1 = flat-ish cap, small = wraps around
    # ---- neck: depth (fwd extent) profile of the central column, ignoring arms
    nb = 40
    hb = np.clip((H * nb).astype(int), 0, nb - 1)
    central = np.abs(X) < 0.18
    depth = np.zeros(nb)
    for b in range(nb):
        s = central & (hb == b)
        if s.sum() > 10:
            v = cen[s, fwd]; depth[b] = np.percentile(v, 98) - np.percentile(v, 2)
    lo_b, hi_b = int(0.25 * nb), int(0.75 * nb)
    neck_b = lo_b + int(np.argmin(depth[lo_b:hi_b] + (depth[lo_b:hi_b] == 0) * 1e9))
    neck = (neck_b + 0.5) / nb
    log.append("neck at %.2f" % neck)
    # ---- front: the face side of the head is the rough (fur, features) one;
    #      the back of a helmet / hair is smooth
    headf = H > neck + 0.05
    fside = cen[:, fwd] - 0.5 * (lo[fwd] + hi[fwd])
    r_pos = float((rough * fa)[headf & (fside > 0)].sum() / max(fa[headf & (fside > 0)].sum(), 1e-18))
    r_neg = float((rough * fa)[headf & (fside < 0)].sum() / max(fa[headf & (fside < 0)].sum(), 1e-18))
    front = 1.0 if r_pos > r_neg else -1.0
    log.append("front %+d (rough %.4f / %.4f)" % (front, r_pos, r_neg))
    # neighbour roughness of every region (fur around an eye)
    adj = _cr_adjacency(reg, f0, f1, n)
    nbr_rough = np.array([sum(rR[y] * c for y, c in adj[x].items()) / max(sum(adj[x].values()), 1)
                          for x in range(n)])
    # ---- eyes: best mirrored pair of smooth, round, convex regions set in fur
    best = None
    # eyes are the most convex front-facing pair of the face (on a generated
    # mesh they are not smoother than the fur around them)
    g_conv = np.percentile(g_face, 10)
    cand = np.flatnonzero((rH > neck + 0.05) & (rNf * front > 0.5) & (np.abs(rX) > 0.04)
                          & (rG < g_conv * 0.6) & (RA > 0.002 * tot) & (RA < 0.06 * tot))
    for i in cand.tolist():
        for j in cand.tolist():
            if j <= i or rX[i] * rX[j] >= 0:
                continue
            if abs(abs(rX[i]) - abs(rX[j])) > 0.05 or abs(rH[i] - rH[j]) > 0.05:
                continue
            ar = RA[i] / RA[j]
            if not (0.6 < ar < 1.67):
                continue
            score = ((RA[i] + RA[j]) / tot * (1.0 - abs(rH[i] - rH[j]) * 5)
                     * (-(rG[i] + rG[j])) * abs(rNf[i] + rNf[j]))
            if best is None or score > best[0]:
                best = (score, i, j)
    log.append("eye candidates %d" % len(cand))
    if best is None:
        log.append("no eye pair")
        return None
    _s, ei, ej = best
    log.append("eyes %d %d front %+d" % (ei, ej, front))
    eye_x = 0.5 * (abs(rX[ei]) + abs(rX[ej]))
    eye_h = 0.5 * (rH[ei] + rH[ej])
    names = ["Body", "Head", "Helmet", "Eye", "Muzzle"]
    lab = np.where(H < neck, 0, 1).astype(np.int64)
    # ---- helmet: smooth head regions, the connected cluster touching the top
    smooth_thr = np.percentile(rough, 45)
    head_r = (rH > neck + 0.02)
    smooth = head_r & (rR < smooth_thr)
    smooth[[ei, ej]] = False
    # face opening: front-facing regions inside the eye/muzzle box are never helmet
    face_box = (np.abs(rX) < eye_x * 1.9) & (rH < eye_h + 0.12) & (rNf * front > 0.3)
    smooth &= ~face_box
    # clusters of touching smooth regions; the helmet is the biggest one that
    # reaches the top of the head
    seen = np.zeros(n, dtype=bool)
    helm = np.zeros(n, dtype=bool)
    best_c = (0.0, None)
    top_h = np.percentile(H[H > neck], 95)
    for s0 in np.flatnonzero(smooth).tolist():
        if seen[s0]:
            continue
        comp = [s0]; seen[s0] = True; k = 0
        while k < len(comp):
            x = comp[k]; k += 1
            for y in adj[x]:
                if not seen[y] and smooth[y]:
                    seen[y] = True; comp.append(y)
        area_c = float(RA[comp].sum())
        reach = max(float(np.percentile(H[np.isin(reg, comp)], 99)), 0.0) if area_c > 0 else 0.0
        if reach >= top_h and area_c > best_c[0]:
            best_c = (area_c, comp)
    if best_c[1] is not None:
        helm[best_c[1]] = True
    # tiny rough islands fully enclosed by helmet regions join it
    for x in range(n):
        if not helm[x] and head_r[x] and adj[x] and RA[x] < 0.004 * tot and x not in (ei, ej):
            nb_area = sum(c for y, c in adj[x].items() if helm[y])
            if nb_area >= 0.8 * sum(adj[x].values()):
                helm[x] = True
    log.append("helmet regions %d, %.1f%%" % (int(helm.sum()), 100 * RA[helm].sum() / tot))
    lab[helm[reg]] = 2
    # the helmet is a dome: fit a sphere to the smooth cluster and take the
    # whole shell on it (rim, sides), plus what bulges a little out of it on the
    # sides (headphones).  The face is recessed inside, the ears stick out on top.
    if helm.any():
        hm = helm[reg]
        P = cen[hm]
        Am = np.c_[2 * P, np.ones(len(P))]
        sol, *_ = np.linalg.lstsq(Am, (P ** 2).sum(1), rcond=None)
        hc = sol[:3]; hr = math.sqrt(max(sol[3] + hc @ hc, 1e-18))
        dv = cen - hc; dist = np.linalg.norm(dv, axis=1)
        radial = np.einsum('ij,ij->i', dv / dist[:, None].clip(1e-18), fn)
        upc = (cen[:, up] - hc[up]) / hr          # -1 bottom .. +1 top of the dome
        side = np.abs(cen[:, lr_axis] - hc[lr_axis]) / hr
        frontc = (cen[:, fwd] - hc[fwd]) * front / hr
        opening = (frontc > 0.55) & (upc < 0.15) & (side < 0.6)    # the face hole
        # 1.13.4: the shell hugs the dome; the cheeks sit deeper inside it
        # (on the front a tighter band, so the rim stays and the fur goes)
        inner = np.where(frontc > 0.2, 0.97, 0.92)
        shell = ((lab == 1) & (dist > inner * hr) & (dist < 1.10 * hr) & (radial > 0.3)
                 & ~opening)
        # headphones: on the sides, bulging out up to ~30% of the radius
        phones = (lab == 1) & (side > 0.6) & (dist > 0.92 * hr) & (dist < 1.35 * hr) \
            & (np.abs(upc) < 0.6) & (rough < smooth_thr * 1.5)
        # ears: every region that stands out above the dome stays with the
        # head as a whole (tip and base), never a speckle of helmet on it
        rmaxd = np.zeros(n); np.maximum.at(rmaxd, reg, dist / hr)
        rup = np.bincount(reg, weights=fa * upc, minlength=n) / RA
        ear_r = (rmaxd > 1.12) & (rup > 0.15)
        ears = ((dist > 1.10 * hr) & (upc > 0.3)) | ear_r[reg]
        add = (shell | phones) & ~ears
        lab[add] = 2
        lab[ears & (lab == 2)] = 1
        log.append("helmet sphere r=%.3f, +%.1f%%" % (hr, 100 * fa[add].sum() / tot))
        # 1.13.4: headphones are their own parts - what bulges clearly out of
        # the dome on each side (cups), whole regions so the border follows
        # the groove where the cup meets the shell
        cup = ((lab == 2) & (side > 0.55) & (dist > 1.03 * hr) & (np.abs(upc) < 0.65))
        if cup.any():
            for sgn in (1.0, -1.0):
                side_m = cup & ((cen[:, lr_axis] - hc[lr_axis]) * sgn > 0)
                if not side_m.any():
                    continue
                # only the biggest connected bulge of this side (the cup and
                # the guard joined to it); stray bulges of an uneven dome stay
                ok_e = side_m[f0] & side_m[f1]
                comp = _uf_labels(nf, f0[ok_e], f1[ok_e])
                ca = np.bincount(comp[side_m], weights=fa[side_m], minlength=nf)
                big_c = int(np.argmax(ca))
                cc = np.zeros((nf, 3))
                np.add.at(cc, comp[side_m], cen[side_m] * fa[side_m, None])
                cc = cc / ca[:, None].clip(1e-18)
                # the biggest bulge and the bulges close to it (the round cup
                # and the cheek guard are two pieces); far ones are an uneven dome
                near_c = ((ca >= 0.15 * ca[big_c])
                          & (np.linalg.norm(cc - cc[big_c], axis=1) <= 0.65 * hr))
                main = side_m & near_c[comp]
                # whole regions mostly covered by it, so the border follows
                # the groove around the cup
                share_r = np.bincount(reg[main], weights=fa[main], minlength=n) / RA
                sel = (((share_r > 0.6)[reg] & (lab == 2)) | main) \
                    & ((cen[:, lr_axis] - hc[lr_axis]) * sgn > 0)
                if fa[sel].sum() > 0.002 * tot:
                    lab[sel] = 6
            log.append("headphones %.1f%%" % (100 * fa[lab == 6].sum() / tot))
    # eyes: fit a sphere to each eye region and take the whole cap on it
    eye_mask = np.zeros(nf, dtype=bool)
    for e in (ei, ej):
        P = cen[reg == e]
        if len(P) < 8:
            eye_mask |= reg == e
            continue
        Am = np.c_[2 * P, np.ones(len(P))]
        bm = (P ** 2).sum(1)
        sol, *_ = np.linalg.lstsq(Am, bm, rcond=None)
        cs = sol[:3]; rs = math.sqrt(max(sol[3] + cs @ cs, 1e-18))
        dv = cen - cs; dist = np.linalg.norm(dv, axis=1)
        radial = np.einsum('ij,ij->i', dv / dist[:, None].clip(1e-18), fn)
        on = (np.abs(dist - rs) < 0.08 * rs) & (radial > 0.6) & (H > neck)
        # 1.13.4: an eye is smooth - the fur around it never joins
        on &= rough <= np.percentile(rough[reg == e], 90) * 1.2
        on &= (cen - cs) @ np.eye(3)[fwd] * front > -0.2 * rs     # front cap only
        on |= reg == e
        # keep the big pieces of the cap (the eye), drop cheek crumbs
        ok_e = on[f0] & on[f1]
        a_, b_ = f0[ok_e], f1[ok_e]
        parent = np.arange(nf)
        for _r in range(64):
            pa, pb = parent[a_], parent[b_]
            if np.array_equal(pa, pb):
                break
            lo_ = np.minimum(pa, pb); hi_ = np.maximum(pa, pb)
            np.minimum.at(parent, hi_, lo_)
            while True:
                gp = parent[parent]
                if np.array_equal(gp, parent):
                    break
                parent = gp
        comp_area = np.bincount(parent[on], weights=fa[on], minlength=nf)
        big = comp_area >= 0.2 * comp_area.max()
        keep = on & big[parent]
        eye_mask |= keep
        log.append("eye sphere r=%.3f" % rs)
    lab[eye_mask] = 3
    # ---- muzzle + mouth: front of the face between the eyes and the chin
    eye_bottom = min(np.percentile(H[reg == ei], 5), np.percentile(H[reg == ej], 5))
    mz = ((np.abs(X) < eye_x * 0.85) & (H < eye_bottom + 0.01) & (H > neck)
          & (fn[:, fwd] * front > 0.0) & (lab == 1))
    # only the front-most layer of the face
    fpos = cen[:, fwd] * front
    if mz.any():
        cut = np.percentile(fpos[mz], 35)
        mz &= fpos >= cut
        # 1.13.4: follow the relief, not a box: whole surface regions that lie
        # mostly inside the muzzle zone, so the border runs along the grooves
        mz_share = np.bincount(reg[mz], weights=fa[mz], minlength=n) / RA
        mz_r = mz_share > 0.5
        # 1.13.4: the mouth is the inside of the opening (tongue, palate):
        # recessed regions.  Nose and upper lip stand out and stay with the face.
        inside = mz_r & (rG > 0.0)
        if RA[inside].sum() > 0.001 * tot:
            # the recessed gap under the upper teeth marks the top of the
            # opening: the mouth is what lies at or below it (tongue, lower
            # teeth); what lies above (nose, upper lip) stays with the face
            gap_top = float(np.percentile(H[inside[reg]], 95))
            mz_r = mz_r & (rH <= gap_top)
        mz = mz_r[reg] & (lab == 1) & (H > neck)
    lab[mz] = 4
    log.append("muzzle %.1f%%" % (100 * fa[mz].sum() / tot))
    lab = _cr_clean_islands(lab, f0, f1, fa)
    return lab, names, reg, dict(up=up, fwd=fwd, front=front, neck=neck)


def _cr_clean_islands(lab, f0, f1, fa, keep_frac=0.15, rounds=4):
    """Every island of a part smaller than keep_frac of that part's biggest island
    goes to the part it touches most (speckles, stray bits)."""
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(lab)
    for _ in range(rounds):
        same = lab[f0] == lab[f1]
        a, b = f0[same], f1[same]
        parent = np.arange(nf)
        for _r in range(64):
            pa, pb = parent[a], parent[b]
            if np.array_equal(pa, pb):
                break
            lo = np.minimum(pa, pb); hi = np.maximum(pa, pb)
            np.minimum.at(parent, hi, lo)
            while True:
                gp = parent[parent]
                if np.array_equal(gp, parent):
                    break
                parent = gp
        isl = np.unique(parent, return_inverse=True)[1].ravel()
        ni = int(isl.max()) + 1
        iarea = np.bincount(isl, weights=fa, minlength=ni)
        ilab = np.zeros(ni, dtype=np.int64); ilab[isl] = lab
        best = np.zeros(int(lab.max()) + 1); np.maximum.at(best, ilab, iarea)
        # only real crumbs move: a limb is an island too, but never a crumb
        weak = (iarea < keep_frac * best[ilab]) & (iarea < 0.01 * float(fa.sum()))
        if not weak.any():
            break
        d = ~same
        ia, ib = isl[f0[d]], isl[f1[d]]
        la, lb = lab[f0[d]], lab[f1[d]]
        # votes: island -> neighbour label (count of shared edges)
        src = np.r_[ia, ib]; nb = np.r_[lb, la]
        m = weak[src]
        src, nb = src[m], nb[m]
        if len(src) == 0:
            break
        key = src * (int(lab.max()) + 1) + nb
        u, c = np.unique(key, return_counts=True)
        ks, kl = u // (int(lab.max()) + 1), u % (int(lab.max()) + 1)
        order = np.lexsort((-c, ks))
        ks, kl = ks[order], kl[order]
        first = np.r_[True, ks[1:] != ks[:-1]]
        new_ilab = ilab.copy()
        new_ilab[ks[first]] = kl[first]
        if np.array_equal(new_ilab, ilab):
            break
        lab = new_ilab[isl]
    return lab


def _mirror_creature_labels(me, lab, twin, axis_i, c):
    """Copy the labels of the cleaner half onto the other half (through the
    twin table: Eye.L <-> Eye.R, Headphone.L <-> Headphone.R)."""
    lab = np.asarray(lab, dtype=np.int64).copy()
    cen, fa = _face_centers_areas(me)
    x = cen[:, axis_i] - c
    f0, f1 = _face_pairs(me)[:2]

    # the cleaner half has the shorter borders between parts
    cross = lab[f0] != lab[f1]
    pos_e = (x[f0] >= 0) & (x[f1] >= 0)
    neg_e = (x[f0] < 0) & (x[f1] < 0)
    src_pos = int((cross & pos_e).sum()) <= int((cross & neg_e).sum())
    # mirror lookup works positive -> negative: flip the axis when the
    # negative half is the cleaner one
    if src_pos:
        _p, dst_ids, partner = _mirror_lookup(me, None, axis_i, c)
    else:
        m2 = me.copy()
        co = _mesh_co(m2)
        co[:, axis_i] = 2.0 * c - co[:, axis_i]
        m2.vertices.foreach_set("co", co.ravel())
        m2.update()
        try:
            _p, dst_ids, partner = _mirror_lookup(m2, None, axis_i, c)
        finally:
            bpy.data.meshes.remove(m2)
    ok = partner >= 0
    lab[dst_ids[ok]] = twin[lab[partner[ok]]]
    return lab


def _creature_from_mesh(context, tmp, axis_i, c):
    """Labels of `tmp` (work frame) as a creature, or None when it is not one."""
    nf_full = len(tmp.polygons)
    if nf_full < 2000:
        return None
    # reduced copy for the analysis
    lo_me = tmp.copy()
    if nf_full > CREATURE_FACES * 1.2:
        ob = bpy.data.objects.new(TMP_PREFIX + "cr", lo_me)
        context.scene.collection.objects.link(ob)
        try:
            md = ob.modifiers.new("dec", 'DECIMATE')
            md.ratio = CREATURE_FACES / float(nf_full)
            dg = context.evaluated_depsgraph_get()
            red = bpy.data.meshes.new_from_object(ob.evaluated_get(dg), depsgraph=dg)
        finally:
            bpy.data.objects.remove(ob, do_unlink=True)
            bpy.data.meshes.remove(lo_me)
        lo_me = red
    try:
        nf = len(lo_me.polygons); nv = len(lo_me.vertices)
        co = _mesh_co(lo_me)
        vn = np.empty(nv * 3); lo_me.vertices.foreach_get("normal", vn); vn = vn.reshape(-1, 3)
        ed = _mesh_edges(lo_me)
        diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
        gv = _cr_groove_signal(co, vn, ed, diag)
        lv = np.empty(len(lo_me.loops), dtype=np.int64); lo_me.loops.foreach_get("vertex_index", lv)
        ls = np.empty(nf, dtype=np.int64); lo_me.polygons.foreach_get("loop_start", ls)
        lt = np.empty(nf, dtype=np.int64); lo_me.polygons.foreach_get("loop_total", lt)
        gf = np.add.reduceat(gv[lv], ls) / lt
        f0, f1 = _face_pairs(lo_me)[:2]
        deg = np.bincount(np.r_[f0, f1], minlength=nf) + 1
        for _i in range(3):
            acc = gf.copy(); np.add.at(acc, f0, gf[f1]); np.add.at(acc, f1, gf[f0]); gf = acc / deg
        cen, fa = _face_centers_areas(lo_me)
        fn = np.empty(nf * 3); lo_me.polygons.foreach_get("normal", fn); fn = fn.reshape(-1, 3)
        if axis_i >= 0:
            lr_axis, lr_mid = int(axis_i), float(c)
        else:
            ext = cen.max(axis=0) - cen.min(axis=0)
            hor = sorted(range(3), key=lambda a: -ext[a])[1:]   # not the tallest axis
            lr_axis = hor[0]
            lr_mid = 0.5 * float(cen[:, lr_axis].min() + cen[:, lr_axis].max())
        log = []
        out = _cr_segment_creature(cen, fn, fa, gf, f0, f1, lr_axis, lr_mid, log)
        print("[Remesh Ultimate] creature:", "; ".join(log))
        if out is None:
            return None
        lab_lo, _names, _reg, info = out
        if info["neck"] > 0.6:
            return None            # a normal body: the humanoid detector does it better
        tot = float(fa.sum())
        share = np.bincount(lab_lo, weights=fa, minlength=5) / tot
        if share[0] < 0.05 or share[3] <= 0.0:
            return None
        # eyes: left / right
        X = cen[:, lr_axis] - lr_mid
        lab_lo = lab_lo.copy()
        lab_lo[(lab_lo == 3) & (X < 0)] = 5
        lab_lo[(lab_lo == 6) & (X < 0)] = 7
        if CREATURE_HEAD_WITH_BODY:
            # 1.13.4: the head (with its ears) is the body's own skin - one
            # piece; the helmet is one piece with its headphones and guards
            lab_lo[lab_lo == 1] = 0
            lab_lo[(lab_lo == 6) | (lab_lo == 7)] = 2
            lab_lo = _cr_clean_islands(lab_lo, f0, f1, fa, keep_frac=0.3)
        # carry the labels to the full mesh (nearest analysed face)
        if len(tmp.polygons) != nf:
            kd = KDTree(nf)
            for i, p in enumerate(cen.tolist()):
                kd.insert(p, i)
            kd.balance()
            fc, _fa_full = _face_centers_areas(tmp)
            lab = np.empty(len(fc), dtype=np.int64)
            find = kd.find
            for i, p in enumerate(fc.tolist()):
                lab[i] = lab_lo[find(p)[1]]
        else:
            lab = lab_lo
    finally:
        if lo_me.users == 0:
            bpy.data.meshes.remove(lo_me)
    base = ["Body", "Head", "Helmet", "Eye", "Mouth", "Eye", "Headphone", "Headphone"]
    used = [k for k in range(8) if (lab == k).any()]
    remap = -np.ones(8, dtype=np.int64)
    remap[used] = np.arange(len(used))
    lab = remap[lab]
    names = [base[k] for k in used]
    side = np.array([1 if k in (3, 6) else (-1 if k in (5, 7) else 0) for k in used],
                    dtype=np.int64)
    twin = np.arange(len(used))
    for a_, b_ in ((3, 5), (6, 7)):
        if a_ in used and b_ in used:
            twin[used.index(a_)] = used.index(b_)
            twin[used.index(b_)] = used.index(a_)
    return dict(lab=lab, names=names, twin=twin, side=side)


MIN_AREA_QUADS = 24        # an area must hold at least this many result quads
MIN_AREA_SHARE = 0.025     # ... and 2.5% of the object's surface


def _merge_tiny_areas(me, lab, s):
    """1.13.2: an area too small for the chosen quad size cannot survive the
    remesh - a tyre's tread strips became speckles and islands on the new
    quads.  Such an area joins the neighbour it shares the longest border with.
    Areas with no neighbour (separate pieces) are left alone."""
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(me.polygons)
    if nf == 0 or len(lab) != nf:
        return lab
    co = _mesh_co(me)
    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    edge_frac = {'S': 1 / 100.0, 'SM': 1 / 70.0, 'M': 1 / 50.0,
                 'ML': 1 / 35.0, 'L': 1 / 25.0}.get(getattr(s, "quad_size", 'M'), 1 / 50.0)
    _cen, fa = _face_centers_areas(me)
    total = float(fa.sum()) or 1.0
    min_area = max(MIN_AREA_QUADS * (diag * edge_frac) ** 2, MIN_AREA_SHARE * total)
    f0, f1 = _face_pairs(me)[:2]
    if len(f0) == 0:
        return lab
    for _it in range(400):
        nl = int(lab.max()) + 1
        area = np.bincount(lab, weights=fa, minlength=nl)
        a, b = lab[f0], lab[f1]
        cross = a != b
        if not cross.any():
            break
        ca, cb = a[cross], b[cross]
        has_nb = np.zeros(nl, dtype=bool)
        has_nb[ca] = True
        has_nb[cb] = True
        small = np.flatnonzero((area > 0) & (area < min_area) & has_nb)
        if len(small) == 0:
            break
        L = int(small[np.argmin(area[small])])
        nb = np.concatenate([cb[ca == L], ca[cb == L]])
        if len(nb) == 0:
            break
        tgt = int(np.bincount(nb).argmax())
        lab[lab == L] = tgt
    _u, lab = np.unique(lab, return_inverse=True)
    return lab.ravel().astype(np.int64)


def _clean_label_islands(me, lab, pairs=None, keep_frac=0.5):
    """1.13.2: after the labels are carried onto the new quads, an area can come
    out in several islands (speckles of tread colour on a tyre, a strip of floor
    up an axle arm).  Every island except the biggest of its area goes to the
    neighbour it touches most, when it is under `keep_frac` of the biggest."""
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(lab)
    if nf == 0:
        return lab
    f0, f1 = (pairs if pairs is not None else _face_pairs(me))[:2]
    if len(f0) == 0:
        return lab
    for _round in range(3):
        same = lab[f0] == lab[f1]
        isl = _uf_labels(nf, f0[same], f1[same])
        ni = int(isl.max()) + 1
        isize = np.bincount(isl, minlength=ni)
        ilab = np.zeros(ni, dtype=np.int64)
        ilab[isl] = lab
        best = np.zeros(int(lab.max()) + 1, dtype=np.int64)
        np.maximum.at(best, ilab, isize)
        weak = (isize < keep_frac * best[ilab]) & (isize < best[ilab])
        if not weak.any():
            break
        d = ~same
        ia, ib = isl[f0[d]], isl[f1[d]]
        changed = False
        new_ilab = ilab.copy()
        for i in np.flatnonzero(weak).tolist():
            nb = np.concatenate([lab[f1[d][ia == i]], lab[f0[d][ib == i]]])
            if len(nb) == 0:
                continue
            new_ilab[i] = int(np.bincount(nb).argmax())
            changed = True
        if not changed:
            break
        lab = new_ilab[isl]
    return lab


def _make_areas(context, src, s):
    """Create (or replace) the coloured area preview object of `src`."""
    old = _areas_obj(src)
    if old is not None:
        m = old.data
        bpy.data.objects.remove(old, do_unlink=True)
        if m.users == 0:
            bpy.data.meshes.remove(m)
    dg = context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(src.evaluated_get(dg), preserve_all_data_layers=False,
                                         depsgraph=dg)
    me.name = src.name + AREAS_SUFFIX
    tmp = me.copy()
    _wm = _work_matrix(src)
    tmp.transform(_wm.to_4x4())
    if _wm.determinant() < 0.0:
        # 1.6.5: a mirrored object (negative scale) turns its faces inside out
        # once transformed - concave and convex would swap and the borders go to
        # the wrong places (a bumper melted into the hood)
        tmp.flip_normals()
    nfaces = len(tmp.polygons)
    axis_i, c, frame = -1, 0.0, "WORLD"
    hint = _PLANE_HINT.get("plane")
    # 1.13.2: when the whole selection has a mirror plane, that plane is the only
    # one a piece may use.  A wheel lying entirely on one side used to fall back
    # to its own symmetry and was cut in half into a ".L" and a ".R" - its real
    # twin is the wheel on the other side (paired by _assign_scene_colors).
    hinted = hint is not None and s.symmetry != 'NONE' and nfaces > 0
    if hinted:
        # 1.7.6: the mirror plane of the whole selection comes first - a piece
        # that sits across it (hood, wing) mirrors left/right like the model,
        # never top/bottom by accident
        axis_i, c, frame, loc = _plane_in_object(src, me, tmp, hint)
        if frame == "LOCAL" and loc is not None:
            bpy.data.meshes.remove(tmp)
            tmp = loc
        if axis_i < 0:
            # 1.13.2: a piece across the plane that is not exactly centred on it
            # (rear lights 1 cm off) may mirror about its own middle - but only
            # along the same left/right axis, never another one
            try:
                hn = np.asarray(hint[0], dtype=np.float64)
                k = int(np.argmax(np.abs(hn)))
                if abs(abs(hn[k]) - 1.0) <= 1e-3:
                    co_t = _mesh_co(tmp)
                    c_rel = float(np.sign(hn[k]) * (hint[1] - hn @ np.array(src.matrix_world.translation)))
                    lo_, hi_ = float(co_t[:, k].min()), float(co_t[:, k].max())
                    if lo_ < c_rel < hi_ and len(co_t) >= 8:
                        cm = 0.5 * (lo_ + hi_)
                        diag_t = float(np.linalg.norm(co_t.max(axis=0) - co_t.min(axis=0))) or 1.0
                        if abs(cm - c_rel) <= 0.05 * diag_t:
                            sh = co_t.copy()
                            sh[:, k] -= cm
                            if _is_symmetric(sh, _bvh_from_mesh_shift(tmp, k, cm), diag_t, k):
                                axis_i, c, frame = k, cm, "WORLD"
            except Exception as ex:
                print("[Remesh Ultimate] plano proprio no mesmo eixo:", ex)
    if axis_i < 0 and nfaces and not hinted:
        axis_i, c = _find_mirror_plane(tmp, s.symmetry)
        frame = "WORLD"
    if axis_i < 0 and s.symmetry == 'AUTO' and nfaces and not hinted:
        # 1.7.6: a model turned in the scene is still symmetric along its OWN
        # axes (labels do not depend on orientation, so they carry over)
        loc = me.copy()
        loc.transform(_local_work_matrix(src).to_4x4())
        if _local_work_matrix(src).determinant() < 0.0:
            loc.flip_normals()
        axis_i, c = _find_mirror_plane(loc, 'AUTO')
        if axis_i >= 0:
            frame = "LOCAL"
            bpy.data.meshes.remove(tmp)
            tmp = loc
        else:
            bpy.data.meshes.remove(loc)
    # 1.8.0: modos.  Automático tenta reconhecer um corpo e, se nao for um,
    # trata como objeto; Orgânico exige corpo (sem corpo, areas normais);
    # Objeto usa as areas normais e nomeia rodas, eixos e partes mecânicas.
    mode = getattr(s, "detect_mode", 'AUTO')
    names, sem, used_mode = [], None, 'AREAS'
    creature = None
    if nfaces and (mode == 'ORGANIC' or (mode == 'AUTO' and _SELECTION.get("n", 1) < 2)):
        # 1.13.3: big-headed creatures (chibi, toys, AI-generated figures) first:
        # helmet / hat, eyes, muzzle, head, body
        try:
            creature = _creature_from_mesh(context, tmp, axis_i, c)
        except Exception as ex:
            import traceback
            traceback.print_exc()
            creature = None
        if creature is None:
            try:
                sem = _semantic_from_mesh(tmp, axis_i, c)
            except Exception as ex:
                print("[Remesh Ultimate] deteccao organica:", ex)
                sem = None
    if creature is not None:
        lab = creature["lab"]
        names, twin, side = creature["names"], creature["twin"], creature["side"]
        used_mode = 'ORGANIC'
        if axis_i >= 0:
            # 1.13.4: a symmetric creature is cut the same on both sides - the
            # cleaner half (fewer stray islands) is mirrored onto the other
            try:
                lab = _mirror_creature_labels(tmp, lab, np.asarray(twin), axis_i, c)
            except Exception as ex:
                print("[Remesh Ultimate] espelho da criatura:", ex)
    elif sem is not None:
        lab = np.asarray(sem["lab"], dtype=np.int64)
        if getattr(s, "join_legs", True) and "Torso" in sem["names"]:
            # 1.8.6: roupa inteirica (macacao, calca alta): tronco + pernas
            # numa peca so; bracos, luvas, pes e cabeca continuam separados
            nm_ = list(sem["names"])
            t_ = nm_.index("Torso")
            legs_ = [k for k, n in enumerate(nm_) if n == "Leg"]
            if legs_:
                lab[np.isin(lab, legs_)] = t_
                nm_[t_] = "Overalls"
                sem = dict(sem)
                sem["names"] = nm_
        try:
            shirt = _shirt_by_topology(tmp, lab, list(sem["names"]))
        except Exception as ex:
            print("[Remesh Ultimate] camisa:", ex)
            shirt = None
        if shirt is not None:
            sem = dict(sem)
            nm_ = list(sem["names"])
            k_ = len(nm_)
            lab[shirt] = k_
            # 1.8.11: a manga e da camisa: braco e antebraco entram na camisa
            # (uma peca de roupa so, sem costuras em escadinha no braco)
            sleeves = [j for j, n in enumerate(nm_) if n in ("UpperArm", "Forearm")]
            if sleeves:
                lab[np.isin(lab, sleeves)] = k_
            nm_.append("Shirt")
            sem["names"] = nm_
            sem["twin"] = np.append(np.asarray(sem["twin"], dtype=np.int64), k_)
            sem["side"] = np.append(np.asarray(sem["side"], dtype=np.int64), 0)
        try:
            lab = _glove_cuff_by_topology(tmp, lab, list(sem["names"]))
        except Exception as ex:
            print("[Remesh Ultimate] punho da luva:", ex)
        if axis_i >= 0:
            # 1.8.5: corpo simetrico -> o lado .R e o espelho exato do .L (antes
            # cada lado achava o seu pulso e as luvas saiam de tamanhos diferentes)
            try:
                tw_ = np.asarray(sem["twin"], dtype=np.int64)
                _pos, neg_ids, partner = _mirror_lookup(tmp, None, axis_i, c)
                ok_ = partner >= 0
                lab[neg_ids[ok_]] = tw_[lab[partner[ok_]]]
            except Exception as ex:
                print("[Remesh Ultimate] espelho das partes:", ex)
        pairs = _face_pairs(tmp)
        lab = _smooth_labels(tmp, lab, pairs=pairs, crease=_crease_mask(tmp, pairs))
        del pairs
        lab, names, twin, side = _compress_sem(lab, sem["names"], sem["twin"], sem["side"])
        used_mode = 'ORGANIC'
    else:
        if _SELECTION.get("n", 1) >= 2:
            # 1.13.2: several objects selected = an assembly that is already
            # split into its parts (chassis with its axle, each tyre, each rim).
            # Every object is ONE part: never cut it into strips or halves.
            lab = np.zeros(nfaces, dtype=np.int64)
        else:
            lab = _segment_areas(tmp, s.sharp_angle, s.area_count, s.area_style)
        try:
            lab = _merge_small_pieces(tmp, lab)
        except Exception as ex:
            print("[Remesh Ultimate] pedacos soltos:", ex)
        try:
            lab = _merge_tiny_areas(tmp, lab, s)
        except Exception as ex:
            print("[Remesh Ultimate] areas pequenas:", ex)
        if _SELECTION.get("n", 1) >= 2:
            # one whole part, never a .L / .R pair of halves (its twin, if any,
            # is another object)
            lab = np.zeros(nfaces, dtype=np.int64)
            twin, side = np.arange(1), np.zeros(1, dtype=np.int64)
        elif axis_i >= 0:
            lab, twin, side = _mirror_area_labels(tmp, lab, axis_i, c)
        else:
            n0 = int(lab.max()) + 1 if len(lab) else 0
            twin, side = np.arange(n0), np.zeros(n0, dtype=np.int64)
        if nfaces and len(lab) and mode in ('AUTO', 'OBJECT'):
            used_mode = 'OBJECT'
            try:
                names = _object_names_from_mesh(tmp, lab)
            except Exception as ex:
                print("[Remesh Ultimate] nomes de pecas:", ex)
                names = []
    _cen, fa = _face_centers_areas(tmp)
    bpy.data.meshes.remove(tmp)
    group = _area_groups(lab, fa, twin) if len(lab) else np.zeros(0, dtype=np.int64)
    n = int(lab.max()) + 1 if len(lab) else 0
    at = me.attributes.new("ru_area", 'INT', 'FACE')
    at.data.foreach_set("value", lab.astype(np.int32))
    col = me.color_attributes.new("RU_Areas", 'BYTE_COLOR', 'CORNER')
    lt = np.empty(len(me.polygons), dtype=np.int64)
    me.polygons.foreach_get("loop_total", lt)
    pal = _area_palette(max(int(group.max()) + 1 if len(group) else 1, 1))
    if len(lab):
        col.data.foreach_set("color", np.repeat(pal[group[lab]], lt, axis=0).ravel())
    me.color_attributes.active_color = col
    ob = bpy.data.objects.new(src.name + AREAS_SUFFIX, me)
    ob.matrix_world = src.matrix_world
    ob["ru_helper_of"] = src.name
    ob["ru_twin"] = [int(v) for v in twin]
    ob["ru_side"] = [int(v) for v in side]
    ob["ru_group"] = [int(v) for v in group]
    ob["ru_sym_axis"] = int(axis_i)
    ob["ru_sym_c"] = float(c)
    ob["ru_sym_frame"] = frame
    ob["ru_names"] = [str(x) for x in (names or [])]
    ob["ru_mode"] = used_mode
    for cl in src.users_collection:
        cl.objects.link(ob)
    return ob, n


def _face_areas(me):
    fa = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", fa)
    return fa


def _crease_mask(me, pairs, angle=math.radians(40.0)):
    """Edge pairs (from _face_pairs) that sit on a real crease of the result."""
    f0, f1 = pairs[:2]
    if len(f0) == 0:
        return np.zeros(0, dtype=bool)
    fn = np.empty(len(me.polygons) * 3)
    me.polygons.foreach_get("normal", fn)
    fn = fn.reshape(-1, 3)
    return np.abs(np.einsum('ij,ij->i', fn[f0], fn[f1])) < math.cos(angle)


def _classify_faces(me, abvh, alab, pairs=None):
    """Which source area each new quad belongs to.

    The centre alone misreads thin plates and the seams where two areas meet,
    so a face votes with its centre (weight 3) plus its corners pulled in towards
    that centre (weight 1 each), and the label with most votes wins (the centre
    wins ties).

    Sparse version (1.6.2): memory is O(faces), never O(faces x areas).  Every
    face casts its centre; only faces near a border (a neighbour got another
    label, or the centre missed) and their neighbours cast the extra corner
    votes - inside an area all votes would agree anyway.
    """
    nf = len(me.polygons)
    if nf == 0:
        return np.zeros(0, dtype=np.int64)
    co = _mesh_co(me)
    lv, ls, lt, _nxt, _pol = _poly_topology(me)
    cen = np.empty(nf * 3)
    me.polygons.foreach_get("center", cen)
    cen = cen.reshape(-1, 3)
    alab = np.asarray(alab, dtype=np.int32)
    fno = np.empty(nf * 3)
    me.polygons.foreach_get("normal", fno)
    fno = fno.reshape(-1, 3)
    span = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) if len(co) else 1.0
    reach = max(math.sqrt(max(float(np.median(_face_areas(me))), 1e-18)) * 1.5, span * 1e-4)

    # 1.6.4 thin plates (a wing, a fin): the nearest original face can be the one on
    # the far side.  Pick the nearest face that looks the same way as the quad.
    # The quads may be wound the other way round as a whole: measure that first.
    probe = np.arange(0, nf, max(1, nf // 500))
    agree = 0
    for i in probe.tolist():
        r = abvh.find_nearest(cen[i].tolist())
        if r[1] is not None and r[1].dot(Vector(fno[i])) > 0.0:
            agree += 1
    sign = 1.0 if agree >= len(probe) * 0.5 else -1.0

    def cast(points, normals):
        out = np.full(len(points), -1, dtype=np.int32)
        fn = abvh.find_nearest
        fr = abvh.find_nearest_range
        for i, pt in enumerate(points.tolist()):
            r = fn(pt)
            if r[2] is None:
                continue
            hit = r[2]
            nrm = Vector(normals[i]) * sign
            if r[1].dot(nrm) < -0.5:
                best = None
                for loc_, n_, ix_, d_ in fr(pt, max(r[3] * 1.01, reach)):
                    if ix_ is not None and n_.dot(nrm) > 0.5 and (best is None or d_ < best[1]):
                        best = (ix_, d_)
                if best is not None:
                    hit = best[0]
            out[i] = alab[hit]
        return out

    lab_c = cast(cen, fno)

    # faces whose label is uncertain: centre missed or a neighbour disagrees,
    # grown by one ring so both sides of every border are re-checked
    f0, f1 = (pairs if pairs is not None else _face_pairs(me))[:2]
    cand = lab_c < 0
    if len(f0):
        diff = lab_c[f0] != lab_c[f1]
        cand[f0[diff]] = True
        cand[f1[diff]] = True
        ring = cand.copy()
        ring[f0[cand[f1]]] = True
        ring[f1[cand[f0]]] = True
        cand = ring
    idx_c = np.flatnonzero(cand)
    lab = lab_c.astype(np.int64)
    if len(idx_c) == 0:
        lab[lab < 0] = 0
        return lab

    # votes of the candidate faces only: (k, 5) labels + (5,) weights
    n_cols = 1 + min(int(lt.max()), 4)
    L = np.full((len(idx_c), n_cols), -1, dtype=np.int32)
    L[:, 0] = lab_c[idx_c]
    W = np.array([3] + [1] * (n_cols - 1), dtype=np.int32)
    s_ls, s_lt, s_cen = ls[idx_c], lt[idx_c], cen[idx_c]
    for c in range(n_cols - 1):
        vi = lv[np.minimum(s_ls + c, s_ls + s_lt - 1)]
        L[:, c + 1] = cast(co[vi] * 0.35 + s_cen * 0.65, fno[idx_c])

    # weighted mode per row: score of column j = total weight of columns with the same label
    valid = L >= 0
    score = np.zeros(L.shape, dtype=np.int32)
    for j in range(n_cols):
        same = (L == L[:, j:j + 1]) & valid
        score[:, j] = (same * W).sum(axis=1)
    score[~valid] = -1
    best = L[np.arange(len(idx_c)), score.argmax(axis=1)]   # argmax: first column (centre) wins ties
    lab[idx_c] = best
    lab[lab < 0] = 0
    return lab


def _result_labels(src, res, ao, meta):
    # 1.8.5: organico cortado antes - cada quad ja sabe a sua parte
    at = res.data.attributes.get("ru_area_res")
    if at is not None and len(at.data) == len(res.data.polygons):
        lab = np.empty(len(res.data.polygons), dtype=np.int32)
        at.data.foreach_get("value", lab)
        if len(lab) and int(lab.max()) < int(meta["n"]):
            return lab.astype(np.int64)
    am = ao.data
    abvh = _bvh_from_mesh(am)
    rm = res.data
    pairs = _face_pairs(rm)
    lab = _smooth_labels(rm, _classify_faces(rm, abvh, meta["lab"], pairs), pairs=pairs,
                         crease=_crease_mask(rm, pairs))
    try:
        lab = _clean_label_islands(rm, lab, pairs)
    except Exception as ex:
        print("[Remesh Ultimate] ilhas:", ex)
    del pairs
    return _mirror_result_labels(src, rm, lab, meta)


def _colour_single_mesh(context, src, res, ao):
    """One continuous mesh, every area painted with its own material (twins share one)."""
    meta = _area_meta(ao)
    rm = res.data
    lab = _result_labels(src, res, ao, meta)
    grp = meta["color"][lab]
    used = np.unique(grp)
    pal = _area_palette(max(meta["ncolors"], 1))
    rm.materials.clear()
    slot = {}
    for i, g in enumerate(used):
        rm.materials.append(_part_material(int(g), pal[g]))
        slot[int(g)] = i
    midx = np.array([slot[int(g)] for g in grp], dtype=np.int32)
    rm.polygons.foreach_set("material_index", midx)
    rm.update()
    return len(np.unique(lab))


def _split_result_by_areas(context, src, res, ao):
    """Give every quad of `res` the area it lies on and deliver one object per area."""
    meta = _area_meta(ao)
    rm = res.data
    lab = _result_labels(src, res, ao, meta)
    coll, made = _split_into_collection(context, src, rm, lab, src.name + "_QUAD_AREAS",
                                        "Quad", meta)
    for o in made:
        o["ru_source"] = src.name
        o["ru_report"] = res.get("ru_report", "")
        o["ru_score"] = res.get("ru_score", 0.0)
    bpy.data.objects.remove(res, do_unlink=True)
    if rm.users == 0:
        bpy.data.meshes.remove(rm)
    return coll, made


def _screen_areas(context):
    """3D View areas of the current screen, or of every open window when the
    call has no screen of its own (scripts, MCP).  Empty in background mode, so
    no operator fails just because of the UI."""
    screen = getattr(context, "screen", None)
    if screen is not None:
        return list(screen.areas)
    out = []
    try:
        for win in bpy.context.window_manager.windows:
            out.extend(win.screen.areas)
    except Exception:
        pass
    return out


# 1.7.6 viewport set-up.  Only the 3D View's own display settings are touched
# (never the Preferences, never the scene's colour management); what was there
# before is kept once per file and can be put back with "Restore View".
VIEW_SHADING_KEYS = ("color_type", "wireframe_color_type", "show_specular_highlight", "light")
VIEW_OVERLAY_KEYS = ("wireframe_opacity",)


def _view3d_spaces(context):
    seen, out = set(), []
    for area in _screen_areas(context):
        if area.type == 'VIEW_3D':
            sp = area.spaces.active
            if sp.as_pointer() not in seen:
                seen.add(sp.as_pointer())
                out.append(sp)
    return out


def _backup_view(context):
    sc = context.scene
    if sc.get("ru_view_backup"):
        return                                    # keep the user's original state
    data = []
    for k, sp in enumerate(_view3d_spaces(context)):
        sh, ov = sp.shading, sp.overlay
        d = {"sh": {}, "ov": {}}
        for key in VIEW_SHADING_KEYS:
            if hasattr(sh, key):
                v = getattr(sh, key)
                d["sh"][key] = v if isinstance(v, (bool, int, float, str)) else str(v)
        for key in VIEW_OVERLAY_KEYS:
            if hasattr(ov, key):
                d["ov"][key] = float(getattr(ov, key))
        data.append(d)
    if data:
        sc["ru_view_backup"] = _json.dumps(data)


def _restore_view(context):
    sc = context.scene
    raw = sc.get("ru_view_backup")
    if not raw:
        return False
    try:
        data = _json.loads(raw)
    except Exception:
        data = []
    for sp, d in zip(_view3d_spaces(context), data):
        for key, v in d.get("sh", {}).items():
            try:
                setattr(sp.shading, key, v)
            except Exception:
                pass
        for key, v in d.get("ov", {}).items():
            try:
                setattr(sp.overlay, key, v)
            except Exception:
                pass
    del sc["ru_view_backup"]
    return True


def _show_material_colours(context):
    """Coloured parts in every 3D View:
    - Wireframe: each part draws its wires in its own object colour - a light
      tint of its palette colour, so thin lines stay bright and distinct;
    - Solid: material colour with the specular highlight off - a matte finish
      (the material's viewport roughness is 1.0 as well).
    Set whatever mode the view is in now, so switching later still shows it."""
    _backup_view(context)
    for sp in _view3d_spaces(context):
        sh, ov = sp.shading, sp.overlay
        for key, val in (("wireframe_color_type", 'OBJECT'), ("color_type", 'MATERIAL'),
                         ("show_specular_highlight", False), ("light", 'STUDIO')):
            try:
                setattr(sh, key, val)
            except Exception:
                pass
        try:
            ov.wireframe_opacity = 1.0          # overlay wires (Solid) fully drawn
        except Exception:
            pass


def _show_object_colours(context):
    _show_material_colours(context)


class RU_OT_restore_view(Operator):
    bl_idname = "remesh_ultimate.restore_view"
    bl_label = "Restore View"
    bl_description = ("Put the 3D View display settings back as they were before Remesh Ultimate "
                      "coloured the parts (Solid colour, specular, wire colour and opacity)")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return bool(context.scene.get("ru_view_backup"))

    def execute(self, context):
        _restore_view(context)
        for area in _screen_areas(context):
            area.tag_redraw()
        return {'FINISHED'}


class RU_OT_detect_areas(Operator):
    bl_idname = "remesh_ultimate.detect_areas"
    bl_label = "Detect Areas"
    bl_description = ("Split the model into coloured areas (along creases and curvature changes). "
                      "REMESH will make the quad flow follow every area border")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        s = context.scene.remesh_ultimate
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        made, n, fails, done = [], 0, [], []
        sources = _selected_sources(context)
        _PLANE_HINT["plane"] = _selection_plane(context, sources)
        for src in sources:
            try:
                ob, k = _make_areas(context, src, s)
            except Exception as ex:
                fails.append("%s (%s)" % (src.name, ex))
                continue
            src.hide_set(True)
            made.append(ob)
            done.append(src)
            n += k
        _PLANE_HINT["plane"] = None
        pairs = _assign_scene_colors(context, done)
        for o in context.selected_objects:
            o.select_set(False)
        for ob in made:
            ob.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        if fails:
            self.report({'WARNING'}, "No areas for: " + ", ".join(fails))
        _backup_view(context)
        for sp in _view3d_spaces(context):
            sh = sp.shading
            try:
                sh.color_type = 'VERTEX'          # "Attribute" colours
            except TypeError:
                sh.color_type = 'ATTRIBUTE'
            try:
                sh.show_specular_highlight = False
            except Exception:
                pass
        msg = "%d areas on %d object%s" % (n, len(made), "s" if len(made) != 1 else "")
        if pairs:
            msg += " | mirrored objects: " + ", ".join("%s = %s" % (a, b) for a, b, _m in pairs)
        named = []
        for ob in made:
            nm = [str(x) for x in ob.get("ru_names", [])]
            if not nm:
                continue
            sd = list(ob.get("ru_side", []))
            vis = []
            for i, nn in enumerate(nm):
                si = int(sd[i]) if i < len(sd) else 0
                vis.append(nn + (".L" if si > 0 else ".R" if si < 0 else ""))
            tag = "Organic" if str(ob.get("ru_mode", "")) == 'ORGANIC' else "Object"
            named.append("%s [%s]: %s" % (ob.name, tag, ", ".join(vis)))
        if named:
            msg += " | " + " || ".join(named)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class RU_OT_areas_to_collection(Operator):
    bl_idname = "remesh_ultimate.areas_to_collection"
    bl_label = "Areas to Collection"
    bl_description = ("Put every detected area in its own object, inside a sub-collection "
                      "named after the model (largest area first)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        s = context.scene.remesh_ultimate
        made, names = [], []
        sources = _selected_sources(context)
        _ensure_areas(context, sources)             # 1.6.8: detect on the fly
        _assign_scene_colors(context, sources)      # 1.7.6: shared mirrored colours
        for src in sources:
            ao = _areas_obj(src)
            meta = _area_meta(ao)
            cname = src.name + "_AREAS"
            parent = src.users_collection[0] if src.users_collection else context.scene.collection
            coll, part = _split_into_collection(context, src, ao.data, meta["lab"], cname,
                                                "Area", meta, parent=parent, materials=True)
            ao.hide_set(True)
            src.hide_set(True)
            made.extend(part)
            names.append(cname)
        _show_material_colours(context)
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        self.report({'INFO'}, "%d areas in %s" % (len(made), ", ".join(names)))
        return {'FINISHED'}


SMOOTH_ITERS = 6          # was 14 in 1.6.1; converges in a few passes, borders no longer creep
SMOOTH_KEEP = 0.75        # an area may lose at most 25% of its faces to smoothing
SMOOTH_FREEZE = 12        # areas this small (in faces) are never touched


def _smooth_labels(me, lab, iters=SMOOTH_ITERS, pairs=None, crease=None):
    """Majority vote of edge neighbours: removes staircase borders between labels.

    Protected (1.6.2): smoothing cleans stray specks and jagged borders but can
    never erase an area or eat into it - every label keeps at least
    SMOOTH_KEEP of its faces, and tiny areas (<= SMOOTH_FREEZE faces) are frozen.
    Specks of a big area can still be cleaned, because the budget is per area,
    not per speck.
    """
    lab = np.asarray(lab, dtype=np.int64).copy()
    nf = len(me.polygons)
    if nf == 0 or len(lab) == 0:
        return lab
    f0, f1 = (pairs if pairs is not None else _face_pairs(me))[:2]
    if len(f0) == 0:
        return lab
    if crease is not None and len(crease) == len(f0) and crease.any():
        # 1.6.4: a border that sits on a real crease is geometry, not noise -
        # faces never take a label from across a crease
        f0, f1 = f0[~crease], f1[~crease]
        if len(f0) == 0:
            return lab
    F = np.concatenate([f0, f1])
    Nb = np.concatenate([f1, f0])
    deg = np.bincount(F, minlength=nf)
    nl = int(lab.max()) + 1
    orig = np.bincount(lab, minlength=nl)
    floor = np.where(orig <= SMOOTH_FREEZE, orig,
                     np.ceil(orig * SMOOTH_KEEP).astype(np.int64))
    for it in range(iters):
        key = F * nl + lab[Nb]
        uk, cnt = np.unique(key, return_counts=True)
        kf, kl = uk // nl, uk % nl
        order = np.lexsort((-cnt, kf))
        kf, kl, cnt = kf[order], kl[order], cnt[order]
        first = np.ones(len(kf), dtype=bool)
        first[1:] = kf[1:] != kf[:-1]
        bf, bl, bc = kf[first], kl[first], cnt[first]
        # same-label neighbours of every face: 0 = an isolated speck
        same_n = np.bincount(F[lab[F] == lab[Nb]], minlength=nf)
        speck = (same_n[bf] == 0) & (deg[bf] > 0)
        # strict majority always; a 50/50 tie only on the first pass (straightens
        # staircases once - repeating it makes borders creep); specks always go
        flip = (bl != lab[bf]) & ((bc * 2 > deg[bf]) | ((bc * 2 == deg[bf]) & (it == 0)) | speck)
        if not flip.any():
            break
        # budget: no label may drop below its floor
        cur = np.bincount(lab, minlength=nl)
        lose = lab[bf[flip]]
        loss = np.bincount(lose, minlength=nl)
        over = loss > (cur - floor)
        if over.any():
            flip_idx = np.flatnonzero(flip)
            ok = ~over[lose]
            # over-budget labels: allow only as many flips as the budget leaves
            for l in np.flatnonzero(over):
                room = int(cur[l] - floor[l])
                mine = np.flatnonzero(lose == l)
                if room > 0:
                    ok[mine[:room]] = True
            flip = np.zeros_like(flip)
            flip[flip_idx[ok]] = True
            if not flip.any():
                break
        lab[bf[flip]] = bl[flip]
    return lab


def _part_material(idx, col, owner="Color"):
    """1.7.6: one material per palette colour, shared by every object that uses
    that colour (mirrored objects end up with the very same material)."""
    base = re.sub(r"[^0-9A-Za-z_.+-]", "_", str(owner))[:40] or "Color"
    name = "RU_%s_%02d" % (base, idx + 1)
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    rgba = (float(col[0]), float(col[1]), float(col[2]), 1.0)
    mat.diffuse_color = rgba                      # Solid view (Material colour)
    # Solid view takes its gloss from the material's Viewport Display values,
    # not from the shader nodes: Blender's default roughness 0.4 is what made the
    # parts look varnished.  Matte, non-metal.
    try:
        mat.roughness = 1.0
        mat.metallic = 0.0
    except Exception:
        pass
    try:
        mat.specular_intensity = 0.0
    except Exception:
        pass
    try:
        if not mat.use_nodes:
            mat.use_nodes = True
    except Exception:
        pass
    nt = getattr(mat, "node_tree", None)
    if nt is not None:
        bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if bsdf is None:
            bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
            if out is None:
                out = nt.nodes.new('ShaderNodeOutputMaterial')
            nt.links.new(bsdf.outputs[0], out.inputs[0])
        bsdf.inputs["Base Color"].default_value = rgba
        try:
            bsdf.inputs["Roughness"].default_value = 0.88
        except Exception:
            pass
        # Matte finish: reduce strong plastic-like highlights in rendered previews.
        for socket_name in ("Specular IOR Level", "Specular"):
            socket = bsdf.inputs.get(socket_name)
            if socket is not None:
                try:
                    socket.default_value = 0.12
                except Exception:
                    pass
                break
    return mat


def _split_into_collection(context, src, me, lab, cname, prefix, meta, parent=None,
                           materials=True):
    """One object per area inside a sub-collection.  Twins (.L / .R) share colour and
    material, and every part keeps the shading of the whole model, so the parts
    look exactly like the unsplit mesh (no shading seams)."""
    co, lv, ls, lt = _mesh_arrays(me)
    lab = np.asarray(lab, dtype=np.int64)
    cn = _corner_normals(me)
    fa = np.empty(len(me.polygons))
    me.polygons.foreach_get("area", fa)
    group = meta["group"]
    coll = bpy.data.collections.get(cname)
    if coll is None:
        coll = bpy.data.collections.new(cname)
        if (parent is None or parent == context.scene.collection
                or parent.name not in bpy.data.collections):
            context.scene.collection.children.link(coll)
        else:
            parent.children.link(coll)
    for o in list(coll.objects):
        m = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        if m is not None and m.users == 0:
            bpy.data.meshes.remove(m)
    pal = _area_palette(max(meta["ncolors"], 1))
    colour = meta["color"]
    # order: biggest colour group first; inside a pair the positive side first
    gsize = np.bincount(group[lab], weights=fa, minlength=meta["ngroups"])
    grank = np.empty(meta["ngroups"], dtype=np.int64)
    grank[np.argsort(-gsize, kind='stable')] = np.arange(meta["ngroups"])
    labels = [int(l) for l in np.unique(lab)]
    labels.sort(key=lambda l: (grank[group[l]], -int(meta["side"][l])))
    s = context.scene.remesh_ultimate
    made = []
    # 1.8.0: partes com nome proprio (Cabeça, Braço, Roda...); so numera
    # quando o mesmo nome aparece mais de uma vez no mesmo lado
    nm_meta = meta.get("names") or []
    ntotal, nseq = {}, {}
    if nm_meta:
        for l in labels:
            sd = int(meta["side"][l])
            k = (nm_meta[l], (sd > 0) - (sd < 0))
            ntotal[k] = ntotal.get(k, 0) + 1
    for l in labels:
        faces = np.flatnonzero(lab == l)
        if len(faces) == 0:
            continue
        g = int(group[l])
        idx = _loop_ranges(ls[faces], lt[faces])
        uniq, remap = np.unique(lv[idx], return_inverse=True)
        if nm_meta:
            sd = int(meta["side"][l])
            suf = ".L" if sd > 0 else (".R" if sd < 0 else "")
            k = (nm_meta[l], (sd > 0) - (sd < 0))
            nseq[k] = nseq.get(k, 0) + 1
            base = (nm_meta[l] if ntotal.get(k, 1) <= 1
                    else "%s_%02d" % (nm_meta[l], nseq[k]))
            name = "%s_%s%s" % (src.name, base, suf)
        else:
            name = "%s_%s_%02d%s" % (src.name, prefix, grank[g] + 1, _side_suffix(meta, l))
        m = _build_mesh(co[uniq], remap.astype(np.int64), lt[faces], name)
        if not _apply_corner_normals(m, cn[idx] if cn is not None else None):
            m.polygons.foreach_set("use_smooth", np.ones(len(m.polygons), dtype=bool))
            try:
                m.set_sharp_from_angle(angle=max(s.sharp_angle * 1.8, math.radians(55.0)))
            except Exception:
                pass
        ob = bpy.data.objects.new(name, m)
        ob.matrix_world = src.matrix_world
        cg = int(colour[l])
        ob.color = _wire_colour(cg)
        ob["ru_area_of"] = src.name
        ob["ru_color"] = cg
        if materials and s.color_parts:
            m.materials.append(_part_material(cg, pal[cg]))
        elif materials:
            for slot in src.material_slots:
                if slot.material:
                    m.materials.append(slot.material)
        coll.objects.link(ob)
        made.append(ob)
    return coll, made


class RU_OT_remesh_areas(Operator):
    bl_idname = "remesh_ultimate.remesh_areas"
    bl_label = "Remesh Areas"
    bl_description = ("Remesh the model (following Method: Smart keeps clean hard-surface parts "
                      "exact) and deliver one object per area in a sub-collection. Mirrored areas "
                      "share colour and are named .L / .R")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_sources(context))

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        s = context.scene.remesh_ultimate
        made, lines, fails = [], [], []
        sources = _selected_sources(context)
        _status(context, "Remesh Ultimate  -  Please wait... Processing...")
        try:
            _ensure_areas(context, sources)         # 1.6.8: detect on the fly
            _assign_scene_colors(context, sources)  # 1.7.6: shared mirrored colours
            for src in sources:
                try:
                    ao = _areas_obj(src)
                    # 1.6.4: follows the Method setting.  Smart (default) keeps the
                    # exact shape of clean low-poly / hard-surface parts and rebuilds
                    # dense or organic ones.
                    try:
                        res, q, dt = remesh_object(context, src, s)
                    finally:
                        _cleanup_temp(context)
                        _purge_tmp_meshes()
                    coll, part = _split_result_by_areas(context, src, res, ao)
                except Exception as ex:
                    import traceback
                    traceback.print_exc()
                    fails.append("%s (%s)" % (src.name, ex))
                    continue
                for o in (src, ao, _lines_obj(src)):
                    if o is not None:
                        o.hide_set(True)
                dense = bpy.data.collections.get(src.name + "_AREAS")
                if dense is not None:
                    for o in dense.objects:
                        o.hide_set(True)
                made.extend(part)
                lines.append("%s: %d areas, %d quads" % (
                    src.name, len(part), sum(len(o.data.polygons) for o in part)))
        finally:
            _status(context, None)
        _show_material_colours(context)
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[0]
        if lines:
            s.last_report = " || ".join(lines)
        if fails:
            self.report({'WARNING'}, "Failed: " + ", ".join(fails))
        self.report({'INFO'}, " | ".join(lines) if lines else "Nothing done")
        return {'FINISHED'} if made else {'CANCELLED'}


class RU_OT_clear_areas(Operator):
    bl_idname = "remesh_ultimate.clear_areas"
    bl_label = "Clear Areas"
    bl_description = "Remove the coloured areas and the drawn lines of this object"
    bl_options = {'REGISTER', 'UNDO'}
    lines_only: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        return _source_of(context.active_object) is not None

    def execute(self, context):
        src = _source_of(context.active_object)
        targets = [_lines_obj(src)] if self.lines_only else [_areas_obj(src), _lines_obj(src)]
        for o in targets:
            if o is None:
                continue
            m = o.data
            bpy.data.objects.remove(o, do_unlink=True)
            if m.users == 0:
                bpy.data.meshes.remove(m)
        if not self.lines_only:
            src.hide_set(False)
            for o in context.selected_objects:
                o.select_set(False)
            src.select_set(True)
            context.view_layer.objects.active = src
            for area in _screen_areas(context):
                if area.type == 'VIEW_3D':
                    area.spaces.active.shading.color_type = 'MATERIAL'
        return {'FINISHED'}


# ---- Draw Lines (modal) ----------------------------------------------------
_draw_state = {"handle": None}


def _draw_lines_cb(op):
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.line_width_set(3.0)
    segs = []
    for line in op.done + [op.current]:
        for i in range(len(line) - 1):
            segs.append(line[i])
            segs.append(line[i + 1])
    if segs:
        b = batch_for_shader(sh, 'LINES', {"pos": segs})
        sh.bind()
        sh.uniform_float("color", (1.0, 0.25, 0.85, 1.0))
        b.draw(sh)
    pts = list(op.clicks)
    if pts:
        gpu.state.point_size_set(9.0)
        b = batch_for_shader(sh, 'POINTS', {"pos": pts})
        sh.bind()
        sh.uniform_float("color", (1.0, 1.0, 0.2, 1.0))
        b.draw(sh)
    gpu.state.depth_test_set('NONE')
    gpu.state.line_width_set(1.0)
    gpu.state.point_size_set(1.0)
    gpu.state.blend_set('NONE')


class RU_OT_draw_lines(Operator):
    bl_idname = "remesh_ultimate.draw_lines"
    bl_label = "Draw Lines"
    bl_description = ("Click points on the model to draw guide lines on its surface. "
                      "Enter: new line | C: close loop | Backspace: undo point | "
                      "Right-click / Esc: finish")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _source_of(context.active_object)
        return (ob is not None and ob.type == 'MESH' and context.area is not None
                and context.area.type == 'VIEW_3D')

    def invoke(self, context, event):
        self.src = _source_of(context.active_object)
        target = _areas_obj(self.src) or self.src
        dg = context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(target.evaluated_get(dg), depsgraph=dg)
        me.transform(target.matrix_world)
        self.bvh = _bvh_from_mesh(me)
        co = _mesh_co(me)
        self.diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
        bpy.data.meshes.remove(me)
        self.clicks, self.current, self.done = [], [], []
        _draw_state["handle"] = bpy.types.SpaceView3D.draw_handler_add(
            _draw_lines_cb, (self,), 'WINDOW', 'POST_VIEW')
        context.workspace.status_text_set(
            "Draw Lines:  Click = point   Enter = new line   C = close loop   "
            "Backspace = undo   Right-click / Esc = finish   (middle mouse navigates)")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _hit(self, context, event):
        from bpy_extras import view3d_utils
        reg, rv3d = context.region, context.region_data
        mxy = (event.mouse_region_x, event.mouse_region_y)
        o = view3d_utils.region_2d_to_origin_3d(reg, rv3d, mxy)
        d = view3d_utils.region_2d_to_vector_3d(reg, rv3d, mxy)
        loc, no, _i, _d = self.bvh.ray_cast(o, d)
        return (loc, no) if loc is not None else (None, None)

    def _surface_path(self, a, b):
        """Straight between two clicks, glued to the surface."""
        L = (b - a).length
        n = max(2, int(L / (self.diag / 250.0)))
        pts = []
        for i in range(1, n + 1):
            p = a.lerp(b, i / n)
            loc, no, _i, _d = self.bvh.find_nearest(p)
            if loc is not None:
                pts.append(loc + no * self.diag * 0.0015)
        return pts

    def _add_point(self, loc, no):
        p = loc + no * self.diag * 0.0015
        if self.clicks:
            self.current.extend(self._surface_path(self.clicks[-1], p))
        else:
            self.current.append(p)
        self.clicks.append(p)

    def _end_line(self, close=False):
        if close and len(self.clicks) >= 3:
            self.current.extend(self._surface_path(self.clicks[-1], self.clicks[0]))
        if len(self.current) >= 2:
            self.done.append(list(self.current))
        self.current, self.clicks = [], []

    def _finish(self, context):
        self._end_line()
        if _draw_state["handle"] is not None:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_state["handle"], 'WINDOW')
            _draw_state["handle"] = None
        context.workspace.status_text_set(None)
        if not self.done:
            context.area.tag_redraw()
            return
        lo = _lines_obj(self.src)
        inv = self.src.matrix_world.inverted()
        verts, edges = [], []
        if lo is not None:
            verts = [v.co.copy() for v in lo.data.vertices]
            edges = [tuple(e.vertices) for e in lo.data.edges]
        for line in self.done:
            base = len(verts)
            verts.extend(inv @ p for p in line)
            edges.extend((base + i, base + i + 1) for i in range(len(line) - 1))
        me = bpy.data.meshes.new(self.src.name + LINES_SUFFIX)
        me.from_pydata(verts, edges, [])
        if lo is None:
            lo = bpy.data.objects.new(self.src.name + LINES_SUFFIX, me)
            lo["ru_helper_of"] = self.src.name
            for c in self.src.users_collection:
                c.objects.link(lo)
        else:
            old = lo.data
            lo.data = me
            if old.users == 0:
                bpy.data.meshes.remove(old)
        lo.matrix_world = self.src.matrix_world
        lo.display_type = 'WIRE'
        lo.show_in_front = True
        lo.color = (1.0, 0.25, 0.85, 1.0)
        context.area.tag_redraw()

    def modal(self, context, event):
        if context.area:
            context.area.tag_redraw()
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN',
                          'TRACKPADZOOM', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            return {'PASS_THROUGH'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if event.alt:
                return {'PASS_THROUGH'}
            loc, no = self._hit(context, event)
            if loc is not None:
                self._add_point(loc, no)
            return {'RUNNING_MODAL'}
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        if event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'}:
            self._end_line()
            return {'RUNNING_MODAL'}
        if event.type == 'C':
            self._end_line(close=True)
            return {'RUNNING_MODAL'}
        if event.type == 'BACK_SPACE':
            if self.clicks:
                self.clicks.pop()
                # rebuild the current path from the remaining clicks
                cl, self.clicks, self.current = self.clicks, [], []
                for p in cl:
                    if self.clicks:
                        self.current.extend(self._surface_path(self.clicks[-1], p))
                    else:
                        self.current.append(p)
                    self.clicks.append(p)
            elif self.done:
                self.done.pop()
            return {'RUNNING_MODAL'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._finish(context)
            return {'FINISHED'}
        if event.type.startswith('NUMPAD') or event.type in {'F', 'HOME'}:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}


# --------------------------------------------------------------------------
#  Operators
# --------------------------------------------------------------------------


class RU_OT_analyze_model(Operator):
    """Geometry-only inspection; does not modify the source mesh."""
    bl_idname = "remesh_ultimate.analyze_model"
    bl_label = "Analyze Model"
    bl_description = "Inspect topology, connected parts, borders, creases and materials without changing geometry"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH'

    def execute(self, context):
        ob = context.active_object
        me = ob.data
        if not me.vertices or not me.polygons:
            self.report({'WARNING'}, "The active mesh is empty")
            return {'CANCELLED'}
        labels = _components(me)
        parts = int(len(np.unique(labels))) if len(labels) else 0
        dims = ob.dimensions
        safe_dims = [max(float(v), 1e-9) for v in dims]
        aspect = max(safe_dims) / min(safe_dims)
        bm = bmesh.new(); bm.from_mesh(me)
        boundary = sum(1 for e in bm.edges if len(e.link_faces) == 1)
        wire = sum(1 for e in bm.edges if len(e.link_faces) == 0)
        sharp = 0
        for e in bm.edges:
            if len(e.link_faces) == 2:
                try:
                    sharp += int(e.calc_face_angle(0.0) >= math.radians(35.0))
                except Exception:
                    pass
        bm.free()
        smooth = sum(1 for f in me.polygons if f.use_smooth)
        mats = [m.name for m in me.materials if m is not None]
        indices = sorted(set(int(f.material_index) for f in me.polygons))
        quads = sum(1 for f in me.polygons if len(f.vertices) == 4)
        tris = sum(1 for f in me.polygons if len(f.vertices) == 3)
        nf = len(me.polygons)
        if parts > 1:
            profile, advice = "MULTI-PART", "Inspect detached details; process connected components independently."
        elif boundary > max(8, int(len(me.edges) * 0.02)):
            profile, advice = "OPEN / THIN SURFACE", "Protect open borders and thin structures; avoid automatic shell fusion."
        elif sharp > max(12, int(len(me.edges) * 0.08)):
            profile, advice = "HARD-SURFACE CANDIDATE", "Preserve creases and corners; test Sharp Edges Auto or Keep."
        else:
            profile, advice = "ORGANIC / GENERAL CANDIDATE", "Start with Organic or Quality; inspect high-curvature details."
        lines = ["RU INTELLIGENCE ANALYSIS", "Object: %s" % ob.name,
                 "Geometric profile heuristic: %s" % profile,
                 "Geometry: %d verts | %d edges | %d faces" % (len(me.vertices), len(me.edges), nf),
                 "Bounds: %.4g x %.4g x %.4g | aspect %.3f" % (dims.x, dims.y, dims.z, aspect),
                 "Connected components: %d" % parts,
                 "Quads: %.1f%% | triangles: %d" % (100.0 * quads / max(1,nf), tris),
                 "Smooth faces: %.1f%%" % (100.0 * smooth / max(1,nf)),
                 "Boundary: %d | wire: %d | sharp-angle edges: %d" % (boundary, wire, sharp),
                 "Material slots: %d | face indices: %s" % (len(mats), indices),
                 "Recommendation: %s" % advice,
                 "Limitation: heuristic geometry analysis, not semantic recognition of human anatomy."]
        ob["ru_intelligence_profile"] = profile
        ob["ru_intelligence_report"] = "\n".join(lines)
        self.report({'INFO'}, "Analysis complete: %s | %d components" % (profile, parts))
        return {'FINISHED'}


class RU_OT_remesh(Operator):
    bl_idname = "remesh_ultimate.remesh"
    bl_label = "REMESH"
    bl_description = "Build a clean quad mesh from the selected objects (original is kept)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        s = context.scene.remesh_ultimate
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        sources = []
        for o in context.selected_objects:
            o = _source_of(o)
            if (o is not None and o.type == 'MESH' and "ru_source" not in o
                    and "ru_helper_of" not in o and o not in sources):
                sources.append(o)
        if not sources:
            self.report({'WARNING'}, "Select a mesh that is not already a Remesh Ultimate result")
            return {'CANCELLED'}
        try:
            context.window.cursor_set('WAIT')
        except Exception:
            pass
        _status(context, "Remesh Ultimate  -  Please wait... Processing...")
        results, lines, warn = [], [], []
        if s.color_parts or s.separate_parts:
            try:
                _ensure_areas(context, sources)
                _assign_scene_colors(context, sources)   # 1.7.6: shared mirrored colours
            except Exception as ex:
                import traceback
                traceback.print_exc()
                warn.append("colour groups: %s" % ex)
        # 1.13.2: leaders first, so every mirrored twin can copy its leader
        if s.separate_parts:
            sources.sort(key=lambda o: 1 if _mirror_lead(o)[0] else 0)
        done_parts = {}
        try:
            for src in sources:
                lead, plane = _mirror_lead(src) if s.separate_parts else (None, None)
                if lead and done_parts.get(lead):
                    try:
                        coll, made = _mirror_parts_from(context, src, done_parts[lead], plane, s)
                        results.extend(made)
                        done_parts[src.name] = made
                        lines.append("%s: %d parts in '%s' | exact mirror of %s"
                                     % (src.name, len(made), coll.name, lead))
                        if s.hide_original:
                            src.hide_set(True)
                        for h in (_areas_obj(src), _lines_obj(src)):
                            if h is not None:
                                h.hide_set(True)
                        continue
                    except Exception as ex:
                        import traceback
                        traceback.print_exc()
                        warn.append("%s: mirror of %s failed (%s), remeshed instead"
                                    % (src.name, lead, ex))
                try:
                    res, q, dt = remesh_object(context, src, s)
                except Exception as ex:
                    import traceback
                    traceback.print_exc()
                    lines.append("%s: failed (%s)" % (src.name, ex))
                    continue
                finally:
                    _cleanup_temp(context)
                cover = float(res.get("ru_cover", 100.0))
                if s.color_parts and not s.separate_parts:
                    try:
                        ao = _areas_obj(src)
                        if ao is None:
                            ao, _n = _make_areas(context, src, s)
                        n_col = _colour_single_mesh(context, src, res, ao)
                        ao.hide_set(True)
                        _show_material_colours(context)
                        res["ru_report"] = res.get("ru_report", "") + " | %d areas" % n_col
                    except Exception as ex:
                        import traceback
                        traceback.print_exc()
                        warn.append("%s: could not colour areas (%s)" % (src.name, ex))
                if s.separate_parts:
                    try:
                        ao = _areas_obj(src)
                        if ao is None:
                            ao, _n = _make_areas(context, src, s)
                        rep_line = res.get("ru_report", "")
                        coll, made = _split_result_by_areas(context, src, res, ao)
                        ao.hide_set(True)
                        _show_object_colours(context)
                        results.extend(made)
                        done_parts[src.name] = made
                        lines.append("%s: %d parts in '%s' | %s" % (src.name, len(made),
                                                                     coll.name, rep_line))
                        if cover >= 90.0 and s.hide_original:
                            src.hide_set(True)
                        h = _lines_obj(src)
                        if h is not None:
                            h.hide_set(True)
                        continue
                    except Exception as ex:
                        import traceback
                        traceback.print_exc()
                        warn.append("%s: could not separate parts (%s)" % (src.name, ex))
                results.append(res)
                if cover < 90.0:
                    warn.append("%s: only %.0f%% of the surface covered - original left visible"
                                % (src.name, cover))
                elif s.hide_original:
                    src.hide_set(True)
                for h in (_areas_obj(src), _lines_obj(src)):
                    if h is not None:
                        h.hide_set(True)
                lines.append("%s: %s" % (src.name, res["ru_report"]))
        finally:
            _cleanup_temp(context)
            _purge_tmp_meshes()
            _status(context, None)
            try:
                context.window.cursor_set('DEFAULT')
            except Exception:
                pass

        for o in context.selected_objects:
            o.select_set(False)
        for r in results:
            r.select_set(True)
        if results:
            context.view_layer.objects.active = results[-1]
        s.last_report = " || ".join(lines)
        if not results:
            self.report({'ERROR'}, "Remesh failed: " + s.last_report)
            return {'CANCELLED'}
        if warn:
            self.report({'WARNING'}, " | ".join(warn))
        else:
            self.report({'INFO'}, "Remesh Ultimate: " + lines[-1])
        return {'FINISHED'}


def _pair(context):
    ob = context.active_object
    if ob is None:
        return None, None
    if "ru_source" in ob:
        return bpy.data.objects.get(ob["ru_source"]), ob
    for o in bpy.data.objects:
        if o.get("ru_source") == ob.name:
            return ob, o
    return ob, None


class RU_OT_compare(Operator):
    bl_idname = "remesh_ultimate.compare"
    bl_label = "Compare"
    bl_description = "Toggle between the original and the remeshed result"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return src is not None and res is not None

    def execute(self, context):
        src, res = _pair(context)
        show_src = not src.visible_get()
        src.hide_set(not show_src)
        res.hide_set(show_src)
        target = src if show_src else res
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        return {'FINISHED'}


class RU_OT_revert(Operator):
    bl_idname = "remesh_ultimate.revert"
    bl_label = "Revert"
    bl_description = "Delete the remeshed result and show the original again"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        src, res = _pair(context)
        return res is not None

    def execute(self, context):
        src, res = _pair(context)
        me = res.data
        bpy.data.objects.remove(res, do_unlink=True)
        if me.users == 0:
            bpy.data.meshes.remove(me)
        if src:
            src.hide_set(False)
            src.select_set(True)
            context.view_layer.objects.active = src
        return {'FINISHED'}


class RU_OT_scale_target(Operator):
    bl_idname = "remesh_ultimate.scale_target"
    bl_label = "Scale Target"
    bl_options = {'INTERNAL'}
    factor: FloatProperty(default=2.0)

    def execute(self, context):
        s = context.scene.remesh_ultimate
        s.target_faces = int(max(50, min(300000, s.target_faces * self.factor)))
        return {'FINISHED'}


class RU_OT_uninstall(Operator):
    bl_idname = "remesh_ultimate.uninstall"
    bl_label = "Uninstall Remesh Ultimate"
    bl_description = "Disable and completely remove Remesh Ultimate from Blender"

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_confirm(
                self, event, title="Uninstall Remesh Ultimate?",
                message="The add-on will be disabled and its files deleted.",
                confirm_text="Uninstall", icon='WARNING')
        except TypeError:
            return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        mod = ADDON_ID
        path = os.path.dirname(os.path.abspath(__file__))

        def _do():
            try:
                bpy.ops.preferences.addon_disable(module=mod)
            except Exception as ex:
                print("[Remesh Ultimate] disable:", ex)
            if mod.startswith("bl_ext."):
                try:
                    _b, repo_mod, pkg = mod.split(".", 2)
                    for i, r in enumerate(bpy.context.preferences.extensions.repos):
                        if r.module == repo_mod:
                            bpy.ops.extensions.package_uninstall(repo_index=i, pkg_id=pkg)
                            break
                except Exception as ex:
                    print("[Remesh Ultimate] extension uninstall:", ex)
            else:
                try:
                    bpy.ops.preferences.addon_remove(module=mod)
                except Exception as ex:
                    print("[Remesh Ultimate] addon_remove:", ex)
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            try:
                if not bpy.context.preferences.use_preferences_save:
                    bpy.ops.wm.save_userpref()
            except Exception:
                pass
            print("[Remesh Ultimate] uninstalled")
            return None

        bpy.app.timers.register(_do, first_interval=0.2)
        self.report({'INFO'}, "Remesh Ultimate uninstalled")
        return {'FINISHED'}


# --------------------------------------------------------------------------
#  UI
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
#  1.11.0  Polish - one-click version of PolyQuilt's relax brush
# --------------------------------------------------------------------------
def _polish_mirror(co, movable, s):
    """Find the mirror plane of the result in its own local space (through the
    origin or through the middle of the bounding box) and return the pairs."""
    if s.symmetry == 'NONE' or len(co) < 8:
        return -1, 0.0, None, None
    axes = [ "XYZ".index(s.symmetry) ] if s.symmetry in ('X', 'Y', 'Z') else [0, 1, 2]
    lo, hi = co.min(axis=0), co.max(axis=0)
    diag = float(np.linalg.norm(hi - lo)) or 1.0
    best = (-1, 0.0, None, None, 0.0)
    for a in axes:
        for plane in (0.0, 0.5 * float(lo[a] + hi[a])):
            sh = co.copy()
            sh[:, a] -= plane
            tol = diag * 0.004
            center, pairs = _symmetry_pairs(sh, a, tol)
            pairs = _extend_pairs(sh, a, pairs, center, tol * 3.0)
            cover = (2 * len(pairs) + len(center)) / float(len(co))
            if cover > best[4]:
                best = (a, plane, center, pairs, cover)
    if best[4] < 0.6:
        return -1, 0.0, None, None
    return best[:4]


def _polish_partner(ob):
    m = re.match(r"^(.*)\.(L|R)$", ob.name)
    if not m:
        return None
    p = bpy.data.objects.get(m.group(1) + (".R" if m.group(2) == "L" else ".L"))
    if (p is None or p.type != 'MESH' or p.mode == 'EDIT'
            or len(p.data.vertices) != len(ob.data.vertices)):
        return None
    return p


def _partner_map(ob, partner, src, co_ob, ae, s):
    """Vertex i of ob -> vertex j of its .L/.R twin, through the mirror plane of
    the source (in the source's local space).  Only an exact one-to-one match
    is accepted, otherwise the twin is left alone."""
    n = len(co_ob)
    to_src = src.matrix_world.inverted() @ ob.matrix_world
    p_to_src = src.matrix_world.inverted() @ partner.matrix_world
    A = np.array([(to_src @ Vector(c))[:] for c in co_ob])
    B = np.array([(p_to_src @ v.co)[:] for v in partner.data.vertices])
    kd = KDTree(n)
    for i, q in enumerate(B):
        kd.insert(q, i)
    kd.balance()
    axes = ["XYZ".index(s.symmetry)] if s.symmetry in ('X', 'Y', 'Z') else [0, 1, 2]
    lo = np.minimum(A.min(axis=0), B.min(axis=0))
    hi = np.maximum(A.max(axis=0), B.max(axis=0))
    tol = max(ae * 0.1, 1e-6)
    for a in axes:
        for plane in (0.0, 0.5 * float(lo[a] + hi[a])):
            idx = np.empty(n, dtype=np.int64)
            ok = True
            for i in range(n):
                q = Vector(A[i])
                q[a] = 2.0 * plane - q[a]
                _c, j, d = kd.find(q)
                if j is None or d > tol:
                    ok = False
                    break
                idx[i] = j
            if ok and len(np.unique(idx)) == n:
                return a, plane, idx, to_src, p_to_src
    return None


class RU_OT_polish(Operator):
    bl_idname = "remesh_ultimate.polish"
    bl_label = "Polish"
    bl_description = ("Relax the quads and glue them back onto the original surface, "
                      "keeping symmetry and open borders.  In Edit Mode only the "
                      "selected vertices move")
    bl_options = {'REGISTER', 'UNDO'}

    iterations: IntProperty(name="Iterations", default=6, min=1, max=50)
    strength: FloatProperty(name="Strength", default=0.5, min=0.05, max=1.0)

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob is not None and ob.type == 'MESH' and "ru_source" in ob
                and bpy.data.objects.get(ob["ru_source"]) is not None)

    def execute(self, context):
        ob = context.active_object
        src = bpy.data.objects.get(ob["ru_source"])
        s = context.scene.remesh_ultimate
        edit = ob.mode == 'EDIT'

        dg = context.evaluated_depsgraph_get()
        src_bvh = BVHTree.FromObject(src, dg, epsilon=0.0)
        to_src = src.matrix_world.inverted() @ ob.matrix_world
        to_res = to_src.inverted()
        rot_src = to_src.to_3x3()
        rot_res = to_res.to_3x3()

        if edit:
            bm = bmesh.from_edit_mesh(ob.data)
        else:
            bm = bmesh.new()
            bm.from_mesh(ob.data)
        bm.verts.ensure_lookup_table()
        n = len(bm.verts)
        if n == 0:
            if not edit:
                bm.free()
            return {'CANCELLED'}

        co = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
        movable = np.array([(v.select if edit else True) and not v.is_boundary
                            and len(v.link_edges) > 0 for v in bm.verts])
        if edit and not movable.any():
            self.report({'WARNING'}, "Select the vertices to polish")
            return {'CANCELLED'}
        ed = np.array([(e.verts[0].index, e.verts[1].index) for e in bm.edges],
                      dtype=np.int64).reshape(-1, 2)
        deg = np.bincount(ed.ravel(), minlength=n).astype(np.float64)
        ae = float(np.median(np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1))) if len(ed) else 0.0
        maxd = max(ae * 1.5, 1e-6)

        axis_i, plane, center, pairs = _polish_mirror(co, movable, s)

        # 1.11.0: a .L/.R piece and its twin must stay mirror copies
        partner = _polish_partner(ob)
        pmap = _partner_map(ob, partner, src, co, ae, s) if partner is not None else None

        def symmetrize():
            if axis_i < 0:
                return
            for a, b in pairs:
                ma, mb = movable[a], movable[b]
                if not (ma or mb):
                    continue
                pa = co[a].copy()
                pb = co[b].copy()
                pb[axis_i] = 2.0 * plane - pb[axis_i]
                m = 0.5 * (pa + pb) if (ma and mb) else (pa if not ma else pb)
                mm = m.copy()
                mm[axis_i] = 2.0 * plane - mm[axis_i]
                if ma:
                    co[a] = m
                if mb:
                    co[b] = mm
            if len(center):
                c = center[movable[center]]
                co[c, axis_i] = plane

        def normals():
            nv = np.zeros_like(co)
            for f in bm.faces:
                fn = np.array(f.normal[:])
                for v in f.verts:
                    nv[v.index] += fn
            ln = np.linalg.norm(nv, axis=1)
            ln[ln == 0] = 1.0
            return nv / ln[:, None]

        def project(nv):
            for i in np.flatnonzero(movable):
                p = to_src @ Vector(co[i])
                nn = (rot_src @ Vector(nv[i])).normalized()
                loc, no, _ix, _d = src_bvh.find_nearest(p)
                if loc is not None and no.dot(nn) > 0.1:
                    co[i] = (to_res @ loc)[:]
                    continue
                # thin wall: look along the normal on both sides (PolyQuilt raycast_double)
                best = None
                for dirn in (nn, -nn):
                    h = src_bvh.ray_cast(p, dirn, maxd)
                    if h[0] is not None and h[1].dot(nn) > 0.1:
                        if best is None or h[3] < best[1]:
                            best = (h[0], h[3])
                if best is not None:
                    co[i] = (to_res @ best[0])[:]

        def push():
            for v, p in zip(bm.verts, co):
                v.co = p
            bm.normal_update()

        orig = co.copy()
        for _it in range(self.iterations):
            nv = normals()
            acc = np.zeros_like(co)
            np.add.at(acc, ed[:, 0], co[ed[:, 1]])
            np.add.at(acc, ed[:, 1], co[ed[:, 0]])
            avg = acc / np.maximum(deg, 1.0)[:, None]
            delta = avg - co
            delta -= (delta * nv).sum(axis=1)[:, None] * nv   # slide, never shrink
            delta[~movable] = 0.0
            co += self.strength * delta
            project(nv)
            symmetrize()
            push()

        # safety net: undo any vertex that ended up stretching an edge
        L = np.linalg.norm(co[ed[:, 0]] - co[ed[:, 1]], axis=1) if len(ed) else np.zeros(0)
        bad = np.flatnonzero(L > max(ae * 3.5, 1e-9))
        if len(bad):
            bv = np.unique(ed[bad].ravel())
            co[bv] = orig[bv]
            push()

        if edit:
            bmesh.update_edit_mesh(ob.data)
        else:
            bm.to_mesh(ob.data)
            bm.free()
            ob.data.update()
        twin_txt = ""
        if pmap is not None:
            a, pl, idx, o_to_src, p_to_src = pmap
            p_from_src = p_to_src.inverted()
            pv = partner.data.vertices
            for i in range(n):
                q = o_to_src @ Vector(co[i])
                q[a] = 2.0 * pl - q[a]
                pv[int(idx[i])].co = p_from_src @ q
            partner.data.update()
            twin_txt = ", mirrored to %s" % partner.name
        moved = int(movable.sum())
        self.report({'INFO'}, "Polished %d vertices%s%s" %
                    (moved, " (mirror %s)" % "XYZ"[axis_i] if axis_i >= 0 else "", twin_txt))
        return {'FINISHED'}


def _use_card(context):
    try:
        return bool(context.preferences.addons[ADDON_ID].preferences.use_card)
    except Exception:
        return True


class RU_PT_main(Panel):
    """The sidebar tab. With the viewport card on (the default) it draws
    nothing: the card is drawn over this space by overlay.py. With the card
    switched off in Preferences, the classic panel is drawn here instead."""
    bl_label = "Remesh Ultimate " + VERSION_STR
    bl_idname = "RU_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Remesh Ultimate"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        if _use_card(context):
            return
        s = context.scene.remesh_ultimate
        lay = self.layout
        lay.label(text="Remesh Ultimate " + VERSION_STR, icon='MOD_REMESH')

        mb = lay.box()
        mb.label(text="Detection Mode", icon='AUTO')
        row = mb.row(align=True)
        row.prop(s, "detect_mode", expand=True)

        col = lay.column(align=True)
        col.label(text="Preset")
        grid = col.grid_flow(columns=3, align=True, even_columns=True)
        grid.prop_enum(s, "preset", 'FAST')
        grid.prop_enum(s, "preset", 'BALANCED')
        grid.prop_enum(s, "preset", 'QUALITY')
        row = col.row(align=True)
        row.prop_enum(s, "preset", 'HARD')
        row.prop_enum(s, "preset", 'ORGANIC')

        box = lay.box()
        box.label(text="Engine", icon='MOD_REMESH')
        row = box.row(align=True)
        row.prop(s, "engine", expand=True)
        if s.engine == 'QUADWILD' and not _qw_available():
            box.label(text="QuadWild files missing - using QuadriFlow", icon='ERROR')
        box.prop(s, "quad_size")
        box.prop(s, "adaptive_density", slider=True)
        box.prop(s, "clean_flow")
        if s.quad_size == 'CUSTOM':
            row = box.row(align=True)
            row.prop(s, "target_faces")
            op = row.operator(RU_OT_scale_target.bl_idname, text="", icon='REMOVE')
            op.factor = 0.5
            op = row.operator(RU_OT_scale_target.bl_idname, text="", icon='ADD')
            op.factor = 2.0
        box.label(text="Symmetry")
        row = box.row(align=True)
        row.prop(s, "symmetry", expand=True)
        box.label(text="Sharp Edges")
        row = box.row(align=True)
        row.prop(s, "sharp_mode", expand=True)
        if s.sharp_mode != 'OFF':
            box.prop(s, "sharp_angle")
        box.prop(s, "preserve_boundary")

        box.label(text="Method")
        row = box.row(align=True)
        row.prop(s, "method", expand=True)
        box.prop(s, "pure_quads")

        ab2 = lay.box()
        ab2.label(text="Result")
        row = ab2.row(align=True)
        row.prop(s, "color_parts", toggle=False)
        row.prop(s, "separate_parts", toggle=False)
        ab2.prop(s, "join_legs")
        if s.color_parts:
            ab2.label(text="One object per area" if s.separate_parts
                      else "One mesh, areas by material", icon='INFO')
        if context.scene.get("ru_view_backup"):
            ab2.operator("remesh_ultimate.restore_view", icon='LOOP_BACK')
        r = lay.row()
        r.scale_y = 2.2
        r.operator(RU_OT_remesh.bl_idname, text="REMESH", icon='MOD_REMESH')

        row = lay.row(align=True)
        row.operator(RU_OT_compare.bl_idname, icon='HIDE_OFF')
        row.operator(RU_OT_polish.bl_idname, icon='MOD_SMOOTH')
        row.operator(RU_OT_revert.bl_idname, icon='LOOP_BACK')

        ob = context.active_object
        if ob is not None and "ru_report" in ob:
            b = lay.box()
            sc = float(ob.get("ru_score", 0))
            b.label(text="Quality Score: %.0f / 100" % sc,
                    icon='CHECKMARK' if sc >= 75 else 'INFO')
            for part in str(ob["ru_report"]).split(" | "):
                b.label(text=part)


class RU_PT_advanced(Panel):
    bl_label = "Advanced"
    bl_idname = "RU_PT_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Remesh Ultimate"
    bl_parent_id = "RU_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return not _use_card(context)

    def draw(self, context):
        s = context.scene.remesh_ultimate
        lay = self.layout
        lay.prop(s, "clean_mode")
        lay.prop(s, "turbo")
        lay.prop(s, "tries")
        lay.prop(s, "relax_iterations")
        lay.prop(s, "relax_strength", slider=True)
        lay.prop(s, "project")
        lay.prop(s, "add_shrinkwrap")
        lay.prop(s, "hide_original")
        lay.prop(s, "seed")
        lay.prop(s, "isolated")
        lay.prop(s, "mirror_tolerance")


def _card_toggled(self, context):
    try:
        from . import overlay
        overlay.redraw_all()
    except Exception:
        pass


class RU_Preferences(AddonPreferences):
    bl_idname = ADDON_ID

    use_card: BoolProperty(
        name="Viewport Card", default=True, update=_card_toggled,
        description="Draw the controls as a card over the 3D View (rounded capsule "
                    "buttons, animated tips). Off = classic sidebar panel")

    def draw(self, context):
        lay = self.layout
        lay.label(text="Remesh Ultimate %s  -  Windows / Linux / macOS (pure Python)" % VERSION_STR)
        lay.label(text="Panel: 3D View > Sidebar (N) > Remesh Ultimate")
        lay.prop(self, "use_card")
        row = lay.row()
        row.alert = True
        row.scale_y = 1.4
        row.operator(RU_OT_uninstall.bl_idname, text="Uninstall Remesh Ultimate", icon='TRASH')


# 1.8.6: Analyze Model e Areas & Lines sairam da interface (deteccao automatica no REMESH)
classes = (RU_Settings, RU_OT_restore_view, RU_OT_remesh, RU_OT_compare, RU_OT_polish, RU_OT_revert, RU_OT_scale_target, RU_OT_uninstall, RU_PT_main, RU_PT_advanced, RU_Preferences)


DEFAULTS_STAMP = "ru_defaults_176"


def _apply_result_defaults(scenes=None):
    """Color Parts and Separate Parts are ON by default (1.7.6).  Scene settings
    are saved inside the .blend, so a file made with an older version would keep
    its old OFF value: switch both on once per scene, then leave the user's
    later choices alone."""
    try:
        scenes = scenes if scenes is not None else bpy.data.scenes
        for sc in scenes:
            if sc.get(DEFAULTS_STAMP):
                continue
            st = getattr(sc, "remesh_ultimate", None)
            if st is None:
                continue
            st.color_parts = True
            st.separate_parts = True
            sc[DEFAULTS_STAMP] = 1
    except Exception:
        pass
    return None


@bpy.app.handlers.persistent
def _ru_load_post(_dummy=None):
    _apply_result_defaults()


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.remesh_ultimate = PointerProperty(type=RU_Settings)
    try:
        from . import overlay
        overlay.register()
    except Exception:
        import traceback
        traceback.print_exc()
    if _ru_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_ru_load_post)
    try:
        bpy.app.timers.register(_apply_result_defaults, first_interval=0.5)
    except Exception:
        pass


def unregister():
    try:
        from . import overlay
        overlay.unregister()
    except Exception:
        pass
    try:
        bpy.app.handlers.load_post.remove(_ru_load_post)
    except ValueError:
        pass
    if _draw_state.get("handle") is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_state["handle"], 'WINDOW')
        except Exception:
            pass
        _draw_state["handle"] = None
    if hasattr(bpy.types.Scene, "remesh_ultimate"):
        del bpy.types.Scene.remesh_ultimate
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
