import sys, os, json, time, ctypes
from ctypes import (Structure, POINTER, byref, c_bool, c_float, c_double, c_int,
                    c_char_p)
import numpy as np


class _P(Structure):
    _fields_ = [('remesh', c_bool), ('sharpAngle', c_float), ('alpha', c_float),
                ('scaleFact', c_float), ('hasFeature', c_bool), ('hasField', c_bool)]


class _QP(Structure):
    _fields_ = [
        ("useFlowSolver", c_bool), ("flow_config_filename", c_char_p),
        ("satsuma_config_filename", c_char_p), ("initialRemeshing", c_bool),
        ("initialRemeshingEdgeFactor", c_double), ("reproject", c_bool),
        ("splitConcaves", c_bool), ("finalSmoothing", c_bool),
        ("ilpMethod", c_int), ("alpha", c_double), ("isometry", c_bool),
        ("regularityQuadrilaterals", c_bool), ("regularityNonQuadrilaterals", c_bool),
        ("regularityNonQuadrilateralsWeight", c_double), ("alignSingularities", c_bool),
        ("alignSingularitiesWeight", c_double), ("repeatLosingConstraintsIterations", c_bool),
        ("repeatLosingConstraintsQuads", c_bool), ("repeatLosingConstraintsNonQuads", c_bool),
        ("repeatLosingConstraintsAlign", c_bool), ("feasibilityFix", c_bool),
        ("hardParityConstraint", c_bool), ("timeLimit", c_double), ("gapLimit", c_double),
        ("minimumGap", c_double), ("callbackTimeLimit", POINTER(c_float)),
        ("callbackGapLimit", POINTER(c_float)), ("chartSmoothingIterations", c_int),
        ("quadrangulationFixedSmoothingIterations", c_int),
        ("quadrangulationNonFixedSmoothingIterations", c_int), ("doubletRemoval", c_bool),
        ("resultSmoothingIterations", c_int), ("resultSmoothingNRing", c_double),
        ("resultSmoothingLaplacianIterations", c_int), ("resultSmoothingLaplacianNRing", c_double),
    ]


_LIBS = {}


def _libs(libdir):
    if libdir in _LIBS:
        return _LIBS[libdir]
    if sys.platform == "win32":
        try:
            os.add_dll_directory(libdir)
        except Exception:
            pass
        names = ("lib_quadwild.dll", "lib_quadpatches.dll")
    elif sys.platform == "darwin":
        names = ("liblib_quadwild.dylib", "liblib_quadpatches.dylib")
    else:
        names = ("liblib_quadwild.so", "liblib_quadpatches.so")
    qw = ctypes.CDLL(os.path.join(libdir, names[0]))
    qp = ctypes.CDLL(os.path.join(libdir, names[1]))
    qw.remeshAndField2.argtypes = [POINTER(_P), c_char_p, c_char_p, c_char_p]
    qw.remeshAndField2.restype = None
    qw.trace2.argtypes = [c_char_p]
    qw.trace2.restype = c_bool
    qp.quadPatches.argtypes = [c_char_p, POINTER(_QP), c_float, c_int, c_bool]
    qp.quadPatches.restype = c_int
    _LIBS[libdir] = (qw, qp)
    return qw, qp


def _qparams(libdir, keep):
    p = _QP()
    tl = [3.0, 5.0, 10.0, 20.0, 30.0, 60.0, 90.0, 120.0]
    gl = [0.005, 0.02, 0.05, 0.10, 0.15, 0.20, 0.25, 0.3]
    keep.append((c_float * 8)(*tl))
    keep.append((c_float * 8)(*gl))
    p.initialRemeshing = True; p.initialRemeshingEdgeFactor = 1; p.reproject = True
    p.splitConcaves = False; p.finalSmoothing = True; p.doubletRemoval = True
    p.resultSmoothingIterations = 5; p.resultSmoothingNRing = 3
    p.resultSmoothingLaplacianIterations = 2; p.resultSmoothingLaplacianNRing = 3
    p.alpha = 0.005; p.ilpMethod = 1; p.timeLimit = 200; p.gapLimit = 0.0
    p.callbackTimeLimit = keep[-2]; p.callbackGapLimit = keep[-1]
    p.minimumGap = 0.4; p.isometry = 1; p.regularityQuadrilaterals = 1
    p.regularityNonQuadrilaterals = 1; p.regularityNonQuadrilateralsWeight = 0.9
    p.alignSingularities = 1; p.alignSingularitiesWeight = 0.1
    p.repeatLosingConstraintsIterations = 1; p.repeatLosingConstraintsQuads = 0
    p.repeatLosingConstraintsNonQuads = 0; p.repeatLosingConstraintsAlign = 1
    p.hardParityConstraint = 1; p.useFlowSolver = 1
    keep.append(os.path.join(libdir, "config", "main_config", "flow_virtual_simple.json").encode("utf-8"))
    keep.append(os.path.join(libdir, "config", "satsuma", "default.json").encode("utf-8"))
    p.flow_config_filename = keep[-2]
    p.satsuma_config_filename = keep[-1]
    p.chartSmoothingIterations = 0; p.quadrangulationFixedSmoothingIterations = 0
    p.quadrangulationNonFixedSmoothingIterations = 0; p.feasibilityFix = False
    return p


def _triangulate(lv, lt):
    ls = np.zeros(len(lt), dtype=np.int64)
    if len(lt) > 1:
        ls[1:] = np.cumsum(lt)[:-1]
    out = []
    for n in np.unique(lt):
        if n < 3:
            continue
        sel = ls[lt == n]
        for k in range(1, n - 1):
            out.append(np.stack([lv[sel], lv[sel + k], lv[sel + k + 1]], axis=1))
    return np.concatenate(out) if out else np.zeros((0, 3), dtype=np.int64)


def _write_obj(path, co, tri):
    with open(path, "w") as fh:
        fh.write("".join("v %.7f %.7f %.7f\n" % tuple(v) for v in co))
        fh.write("".join("f %d %d %d\n" % (a + 1, b + 1, c + 1) for a, b, c in tri))


def _write_sharp(path, co, tri, angle_deg, guides):
    """QuadWild feature file: 'convexity,face,edge_in_face' per sharp edge."""
    nf = len(tri)
    a, b, c = co[tri[:, 0]], co[tri[:, 1]], co[tri[:, 2]]
    fn = np.cross(b - a, c - a)
    fn /= np.maximum(np.linalg.norm(fn, axis=1), 1e-30)[:, None]
    ea = np.concatenate([tri[:, 0], tri[:, 1], tri[:, 2]])
    eb = np.concatenate([tri[:, 1], tri[:, 2], tri[:, 0]])
    ef = np.tile(np.arange(nf), 3)
    ei = np.repeat(np.arange(3), nf)
    key = np.minimum(ea, eb) * (len(co) + 1) + np.maximum(ea, eb)
    order = np.argsort(key, kind="stable")
    ks = key[order]
    starts = np.flatnonzero(np.r_[True, ks[1:] != ks[:-1]])
    counts = np.diff(np.r_[starts, len(ks)])
    gset = set(guides) if guides else set()
    cos_lim = np.cos(np.radians(angle_deg)) if angle_deg >= 0 else 2.0
    lines = []
    for st, cnt in zip(starts, counts):
        i0 = order[st]
        f0, e0 = int(ef[i0]), int(ei[i0])
        if cnt == 1:
            lines.append("0,%d,%d" % (f0, e0))
            continue
        if cnt != 2:
            continue
        i1 = order[st + 1]
        f1 = int(ef[i1])
        n0, n1 = fn[f0], fn[f1]
        g = int(ks[st]) in gset
        if g or float(n0 @ n1) < cos_lim:
            d = co[eb[i0]] - co[ea[i0]]
            convex = 1 if float(np.cross(n0, n1) @ d) > 0 else 0
            lines.append("%d,%d,%d" % (convex, f0, e0))
    with open(path, "w") as fh:
        fh.write("%d\n" % len(lines))
        fh.write("".join(l + "\n" for l in lines))
    return len(lines)


def _read_obj(path):
    vs, fs = [], []
    with open(path) as fh:
        for line in fh:
            if line.startswith("v "):
                vs.append([float(x) for x in line.split()[1:4]])
            elif line.startswith("f "):
                fs.append([int(t.split("/")[0]) - 1 for t in line.split()[1:]])
    co = np.array(vs, dtype=np.float64).reshape(-1, 3)
    lt = np.array([len(f) for f in fs], dtype=np.int64)
    lv = np.array([i for f in fs for i in f], dtype=np.int64)
    return co, lv, lt


def solve(meta, co, lv, lt, work):
    libdir = meta["libdir"]
    qw, qp = _libs(libdir)
    os.makedirs(work, exist_ok=True)
    tri = _triangulate(lv, lt)
    # QuadWild works in absolute units: normalise so the field step is stable
    c0 = (co.max(axis=0) + co.min(axis=0)) * 0.5
    sc = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0))) or 1.0
    nco = (co - c0) / sc * 10.0
    mesh = os.path.join(work, "m.obj")
    _write_obj(mesh, nco, tri)
    base = os.path.join(work, "m")
    sharp_on = bool(meta.get("sharp"))
    ang = float(meta.get("sharp_angle", 35.0))
    guides = meta.get("guides")
    nsh = _write_sharp(base + "_rem.sharp", nco, tri, ang if sharp_on else -1.0, guides)
    pr = _P(remesh=bool(meta.get("pre", True)), sharpAngle=(ang if sharp_on else -1.0),
            alpha=0.01, scaleFact=1.0, hasFeature=True, hasField=False)
    qw.remeshAndField2(byref(pr), mesh.encode("utf-8"), (base + "_rem.sharp").encode("utf-8"),
                       (base + "_rem.rosy").encode("utf-8"))
    if not qw.trace2((base + "_rem").encode("utf-8")):
        return None
    traced = (base + "_rem_p0.obj").encode("utf-8")
    smooth = bool(meta.get("smooth", True))
    outp = base + ("_rem_p0_0_quadrangulation_smooth.obj" if smooth else "_rem_p0_0_quadrangulation.obj")
    target = max(20, int(meta["target"]))
    sf = float(meta.get("scale0", 1.0))
    best = None
    prev_n = None
    for it in range(int(meta.get("calib", 3))):
        keep = []
        p = _qparams(libdir, keep)
        qp.quadPatches(traced, byref(p), c_float(sf), 0, smooth)
        if not os.path.exists(outp):
            break
        r = _read_obj(outp)
        os.remove(outp)
        n = len(r[2])
        if n == 0:
            break
        err = abs(np.log(n / target))
        if best is None or err < best[0]:
            best = (err, r, sf, n)
        if err < np.log(1.25):
            break
        if prev_n is not None and abs(n - prev_n) < 0.08 * prev_n:
            break          # density floor/ceiling of this patch layout: no point retrying
        prev_n = n
        sf = sf * float(np.clip(np.sqrt(n / target), 0.35, 3.0))
    if best is None:
        return None
    rco, rlv, rlt = best[1]
    rco = rco / 10.0 * sc + c0
    return rco, rlv, rlt, best[2], best[3], nsh


if __name__ == "__main__":
    jobdir, listfile = sys.argv[-2], sys.argv[-1]
    ids = json.load(open(listfile))
    for jid in ids:
        base = os.path.join(jobdir, jid)
        meta = json.load(open(base + ".json"))
        ok = False
        try:
            d = np.load(os.path.join(jobdir, meta["input"] + ".in.npz"))
            r = solve(meta, d["co"], d["lv"], d["lt"], base + "_qw")
            if r is not None:
                tmp = base + ".tmp.npz"
                np.savez(tmp, co=r[0], lv=r[1], lt=r[2])
                os.replace(tmp, base + ".out.npz")
                ok = True
                print("[QW] %s quads=%d scale=%.3f sharp=%d" % (jid, r[4], r[3], r[5]))
        except Exception as ex:
            print("[QW] fail", jid, ex)
        if not ok:
            open(base + ".fail", "w").close()
        sys.stdout.flush()
