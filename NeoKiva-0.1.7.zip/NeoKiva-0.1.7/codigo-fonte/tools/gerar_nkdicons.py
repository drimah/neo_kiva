import re,os,base64,sys
src,icons=sys.argv[1],sys.argv[2]
s=open(src+'/nkpalette.js').read()
cls=sorted(set(re.findall(r"\['(T[A-Za-z0-9]+)'",s)))
alias={'tdrawgrid':'tcustomdrawgrid','datagrid':'tdbgrid','navigationbar':'tdbnavigator','groupbox':'tgroupbox','data':'tdbnavigator','frames':'tframe' }
want={c.lower():c.lower() for c in cls}; want.update(alias)
def b(sz,n):
    p=f'{icons}/{sz}/{n}.png'
    return base64.b64encode(open(p,'rb').read()).decode() if os.path.exists(p) else ''
lines=[]; n=0
for k,v in sorted(want.items()):
    t=[b(16,v),b(24,v),b(32,v)]
    if not any(t): continue
    # garante pelo menos um tamanho em cada posição
    best=t[2] or t[1] or t[0]
    t=[x or best for x in t]
    lines.append(f"'{k}':['{t[0]}','{t[1]}','{t[2]}']"); n+=1
js=f"""// Neo Kiva 0.1.7 — ícones da Tool Palette do Delphi 13 (extraídos dos pacotes dcl*370.bpl do RAD Studio 37.0)
// chave: classe em minúsculas -> [PNG 16px, 24px, 32px] em base64
const NK_DICONS = {{
{(','+chr(10)).join(lines)}
}};
function nkDIcon(cls, size) {{
  const k = String(cls || '').toLowerCase(); const t = NK_DICONS[k]; if (!t) return '';
  const u = i => 'data:image/png;base64,' + t[i];
  const s = size || 24;
  const src = s <= 16 ? u(0) : u(1);
  const set = s <= 16 ? `${{u(0)}} 1x, ${{u(1)}} 1.5x, ${{u(2)}} 2x` : `${{u(1)}} 1x, ${{u(2)}} 1.33x`;
  return `<img class="i nkdi" alt="" draggable="false" width="${{s}}" height="${{s}}" src="${{src}}" srcset="${{set}}">`;
}}
"""
open(src+'/nkdicons.js','w').write(js); print(n,len(js))
