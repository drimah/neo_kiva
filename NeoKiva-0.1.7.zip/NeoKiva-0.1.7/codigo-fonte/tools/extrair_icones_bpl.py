import pefile,sys,os,struct,io,json
from PIL import Image
out=sys.argv[1]; files=sys.argv[2:]
idx={}
def tobmp(b):
    hs,w,h,pl,bpp,comp=struct.unpack('<IiiHHI',b[:20]); ah=abs(h)
    if bpp==32:
        px=b[hs+(12 if comp==3 and hs==40 else 0):]
        im=Image.frombytes('RGBA',(w,ah),px[:w*ah*4],'raw','BGRA')
        if h>0: im=im.transpose(Image.FLIP_TOP_BOTTOM)
        if im.getchannel('A').getextrema()[1]>0 and im.getchannel('A').getextrema()!=(255,255): return im
    else:
        clr=struct.unpack('<I',b[32:36])[0]
        if bpp<=8 and clr==0: clr=1<<bpp
        fh=b'BM'+struct.pack('<IHHI',14+len(b),0,0,14+hs+clr*4)
        im=Image.open(io.BytesIO(fh+b)); im.load()
    im=im.convert('RGBA'); p=im.load(); key=p[0,ah-1][:3]
    for y in range(ah):
        for x in range(w):
            p[x,y]=(0,0,0,0) if p[x,y][:3]==key else p[x,y][:3]+(255,)
    return im
for f in files:
    pkg=os.path.basename(f).replace('370.bpl','')
    pe=pefile.PE(f)
    for t in pe.DIRECTORY_ENTRY_RESOURCE.entries:
        tn=pefile.RESOURCE_TYPE.get(t.id)
        for e in t.directory.entries:
            n=str(e.name) if e.name else ''
            if not n.startswith('T'): continue
            d=e.directory.entries[0].data.struct; b=pe.get_data(d.OffsetToData,d.Size)
            if tn=='RT_BITMAP':
                if n[-2:] in('16','32') and n[:-2] in [str(x.name) for x in t.directory.entries]: base,sz=n[:-2],n[-2:]
                else: base,sz=n,'24'
                if base=='TSTACKPANEL6': continue
                im=tobmp(b); fn=f'{sz}/{base.lower()}.png'
            elif tn=='RT_RCDATA' and n.endswith('128_PNG'):
                base=n[:-7]; fn=f'128/{base.lower()}.png'; im=None
            else: continue
            os.makedirs(f'{out}/{os.path.dirname(fn)}',exist_ok=True)
            if im: im.save(f'{out}/{fn}')
            else: open(f'{out}/{fn}','wb').write(b)
            idx.setdefault(base.lower(),{'class':base[0]+base[1:].lower(),'package':pkg})
json.dump(dict(sorted(idx.items())),open(f'{out}/index.json','w'),indent=1)
print(len(idx))
