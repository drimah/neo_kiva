// ===== Neo Kiva 0.1 — Tool Palette (paleta de componentes no estilo Delphi, aba da esquerda) =====
'use strict';

// ---------- ícones (traço 24x24, mesma linguagem dos ícones da IDE) ----------
const NKG = {
  monitor: '<rect x="3" y="4" width="18" height="13" rx="1.5"/><path d="M6 13l3-3 3 2 4-5M9 21h6M12 17v4"/>',
  xml: '<path d="M6 2h9l4 4v16H6z"/><path d="M15 2v4h4M10 12l-2 2.5 2 2.5M14 12l2 2.5-2 2.5"/>',
  bind: '<path d="M9 15l6-6"/><path d="M10.5 6.5l1.8-1.8a4 4 0 0 1 5.7 5.7l-1.8 1.8M13.5 17.5l-1.8 1.8a4 4 0 0 1-5.7-5.7l1.8-1.8"/>',
  gesture: '<path d="M9 11V5a1.5 1.5 0 0 1 3 0v5M12 10V4a1.5 1.5 0 0 1 3 0v6M15 10V6a1.5 1.5 0 0 1 3 0v8a7 7 0 0 1-7 7h-.5A6.5 6.5 0 0 1 5 16l-1.5-3a1.5 1.5 0 0 1 2.6-1.5L9 15"/>',
  tether: '<rect x="2" y="5" width="8" height="12" rx="1.5"/><rect x="14" y="5" width="8" height="12" rx="1.5"/><path d="M10 11h4M11.5 9.5L10 11l1.5 1.5M12.5 9.5L14 11l-1.5 1.5"/>',
  sensor: '<circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8"/>',
  frame: '<rect x="3" y="4" width="18" height="16" rx="1.5" stroke-dasharray="3 2"/><path d="M7 9h10M7 13h6"/>',
  mainmenu: '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 8h18M6 6h3M11 6h3"/><rect x="10" y="8" width="8" height="8" fill="currentColor" fill-opacity=".15"/>',
  popup: '<rect x="5" y="3" width="14" height="18" rx="1.5"/><path d="M8 7h8M8 11h8M8 15h5"/><path d="M3 3l3 3"/>',
  label: '<path d="M5 19L11 5h2l6 14M8 14.5h8"/>',
  edit: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M6 9.5v5M5 9.5h2M5 14.5h2"/>',
  memo: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M6 7h12M6 11h12M6 15h8"/>',
  button: '<rect x="2.5" y="7" width="19" height="10" rx="1"/><path d="M8.5 12h7"/>',
  check: '<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M8 12.2l2.8 2.8L16 9.5"/>',
  radio: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"/>',
  listbox: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M6 7h9M6 11h9M6 15h9"/><path d="M17.5 4v16"/>',
  combo: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M16 7v10M17.5 11l1.2 1.4 1.3-1.4"/>',
  scrollbar: '<rect x="2" y="9" width="20" height="6" rx="1"/><path d="M6 9v6M18 9v6"/><rect x="9" y="10.5" width="5" height="3" fill="currentColor" stroke="none"/>',
  groupbox: '<path d="M9 6h11a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h1"/><path d="M5.5 6h2"/>',
  radiogroup: '<path d="M9 4h11v16H4V4h1"/><circle cx="8" cy="10" r="2"/><circle cx="8" cy="16" r="2"/><path d="M12 10h5M12 16h5"/><circle cx="8" cy="10" r=".6" fill="currentColor"/>',
  panel: '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M4.5 17.5V6.5h15" opacity=".5"/>',
  actionlist: '<rect x="3" y="3" width="18" height="18" rx="1.5"/><path d="M13 6l-4 7h4l-2 5 5-8h-4l2-4z"/>',
  bitbtn: '<rect x="2.5" y="7" width="19" height="10" rx="1"/><path d="M6 12l2 2 3-4M13 12h5"/>',
  speedbutton: '<rect x="5" y="5" width="14" height="14" rx="1"/><path d="M9 9h6v6H9z" fill="currentColor" fill-opacity=".2"/>',
  maskedit: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 12h1.5M8.5 12H10M12.5 12H14M16.5 12H18" stroke-width="2.4"/>',
  grid: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 8h18M3 13h18M3 18h18M8 3v18M14 3v18"/><path d="M3 3h5v5H3z" fill="currentColor" fill-opacity=".2"/>',
  drawgrid: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/><path d="M11 21l7-7 2 2-7 7"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M3 17l5-5 4 4 2-2 4 4"/><circle cx="8.5" cy="9" r="1.5"/>',
  shape: '<rect x="3" y="3" width="9" height="9"/><circle cx="15.5" cy="15.5" r="5.5"/>',
  bevel: '<rect x="3" y="5" width="18" height="14"/><rect x="4.5" y="6.5" width="15" height="11" opacity=".45"/>',
  scrollbox: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M17 3v18M17 7h4M17 17h4"/><rect x="18" y="9" width="2" height="5" fill="currentColor" stroke="none"/>',
  checklist: '<rect x="3" y="3" width="18" height="18" rx="1"/><rect x="6" y="6" width="3" height="3"/><rect x="6" y="11" width="3" height="3"/><rect x="6" y="16" width="3" height="3"/><path d="M11 7.5h6M11 12.5h6M11 17.5h6"/>',
  splitter: '<rect x="3" y="4" width="7" height="16" rx="1"/><rect x="14" y="4" width="7" height="16" rx="1"/><path d="M12 7v10" stroke-dasharray="1.5 1.5"/>',
  statictext: '<rect x="3" y="7" width="18" height="10"/><path d="M8 15l3-6h2l3 6M9 13h6"/>',
  controlbar: '<rect x="2" y="5" width="20" height="14" rx="1"/><path d="M2 12h20M5 7v3M5 14v3M8 8h9M8 15h6"/>',
  appevents: '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 8h18"/><path d="M13 10l-3 5h3l-1 3"/>',
  valuelist: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 8h18M3 13h18M3 18h18M10 3v18"/><path d="M5 5.5h3M12 5.5h5"/>',
  labelededit: '<path d="M4 8l2-5h1l2 5M4.8 6.5h3.4"/><rect x="2" y="11" width="20" height="9" rx="1"/><path d="M6 13.5v4"/>',
  colorbox: '<rect x="2" y="7" width="20" height="10" rx="1"/><rect x="4.5" y="9.5" width="7" height="5" fill="currentColor" fill-opacity=".45"/><path d="M16 7v10M17.5 11l1.2 1.4 1.3-1.4"/>',
  colorlist: '<rect x="3" y="3" width="18" height="18" rx="1"/><rect x="5.5" y="5.5" width="5" height="3" fill="currentColor" fill-opacity=".7"/><rect x="5.5" y="10.5" width="5" height="3" fill="currentColor" fill-opacity=".4"/><rect x="5.5" y="15.5" width="5" height="3" fill="currentColor" fill-opacity=".2"/><path d="M13 7h5M13 12h5M13 17h5"/>',
  catbuttons: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 7.5h18"/><rect x="6" y="10" width="12" height="3.5" rx=".5"/><rect x="6" y="15.5" width="12" height="3.5" rx=".5"/>',
  btngroup: '<rect x="3" y="3" width="18" height="18" rx="1"/><rect x="6" y="6" width="5" height="5"/><rect x="13" y="6" width="5" height="5"/><rect x="6" y="13" width="5" height="5"/><rect x="13" y="13" width="5" height="5"/>',
  docktabset: '<path d="M3 5h18v10H3z"/><path d="M4 15v4h6l1-4M11 15l1 4h6l1-4"/>',
  trayicon: '<rect x="2" y="15" width="20" height="6" rx="1"/><rect x="15" y="16.5" width="3" height="3" fill="currentColor"/><path d="M8 4h8v7H8zM12 11v3"/>',
  flowpanel: '<rect x="3" y="4" width="18" height="16" rx="1"/><rect x="5.5" y="7" width="4" height="4"/><rect x="11" y="7" width="4" height="4"/><path d="M16.5 9h2.5M5.5 15h8l-2-2"/>',
  gridpanel: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M3 12h18M12 4v16"/>',
  catpanel: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 8h18M3 14h18M17 5.5l1 1 1-1M17 11.5l1-1 1 1"/>',
  actionmanager: '<rect x="3" y="3" width="18" height="18" rx="1.5"/><path d="M3 8h18M12 10l-3 5h3l-1 3 4-6h-3l1-2z"/>',
  actmenubar: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 12h3M10 12h3M15 12h3"/>',
  acttoolbar: '<rect x="2" y="7" width="20" height="10" rx="1"/><rect x="4" y="9" width="4" height="6"/><rect x="10" y="9" width="4" height="6"/><rect x="16" y="9" width="4" height="6"/>',
  customize: '<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 8h18"/><circle cx="12" cy="14" r="2.5"/><path d="M12 10v1.5M12 16.5V18M8 14h1.5M14.5 14H16"/>',
  stackpanel: '<rect x="4" y="3" width="16" height="18" rx="1"/><rect x="6.5" y="5.5" width="11" height="3.5"/><rect x="6.5" y="10.3" width="11" height="3.5"/><rect x="6.5" y="15.1" width="11" height="3.5"/>',
  cardpanel: '<rect x="6" y="3" width="15" height="13" rx="1"/><path d="M3 7v13h14"/>',
  numberbox: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M6 10.5l1.5-1v5M11 10a1.5 1.5 0 1 1 2.2 1.3L11 14.5h3"/>',
  relativepanel: '<rect x="3" y="4" width="18" height="16" rx="1"/><rect x="6" y="7" width="5" height="4"/><rect x="13" y="13" width="5" height="4"/><path d="M11 9h4v4" stroke-dasharray="1.5 1.5"/>',
  tabcontrol: '<path d="M3 9h18v11H3z"/><path d="M3 9V5h6v4M9 7h5v2"/>',
  pagecontrol: '<path d="M3 9h18v11H3z"/><path d="M3 9V5h6v4M9 7h5v2"/><path d="M6 13h12M6 16h8" opacity=".6"/>',
  imagelist: '<rect x="2" y="7" width="7" height="7"/><rect x="8.5" y="7" width="7" height="7"/><rect x="15" y="7" width="7" height="7"/><path d="M3 18h18" stroke-dasharray="2 2"/>',
  richedit: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M7 7h10M7 11h6M7 15h10"/><path d="M15 9.5l2 3.5h-4z" fill="currentColor"/>',
  trackbar: '<path d="M3 11h18"/><path d="M11 6h4v7l-2 2-2-2z"/><path d="M4 16v2M8 16v2M12 16v2M16 16v2M20 16v2"/>',
  progress: '<rect x="2" y="8" width="20" height="8" rx="1"/><path d="M4 10h3v4H4zM8 10h3v4H8zM12 10h3v4h-3z" fill="currentColor" stroke="none"/>',
  updown: '<rect x="7" y="3" width="10" height="18" rx="1"/><path d="M7 12h10M10 8.5l2-2 2 2M10 15.5l2 2 2-2"/>',
  hotkey: '<rect x="2" y="6" width="20" height="12" rx="1"/><path d="M5 10h2M9 10h2M13 10h2M17 10h2M7 14h10"/>',
  animate: '<rect x="2" y="5" width="20" height="14" rx="1"/><path d="M2 8h20M2 16h20M6 5v3M10 5v3M14 5v3M18 5v3M6 16v3M10 16v3M14 16v3M18 16v3"/><path d="M10.5 10v4l3.5-2z" fill="currentColor"/>',
  datetime: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 12h7"/><rect x="15" y="9.5" width="5" height="5"/><path d="M15 11h5"/>',
  calendar: '<rect x="3" y="4" width="18" height="17" rx="1"/><path d="M3 9h18M7 2v4M17 2v4M7 13h2M11 13h2M15 13h2M7 17h2M11 17h2"/>',
  tree: '<path d="M6 4v14M6 8h5m-5 5h5m-5 5h5"/><rect x="3" y="2" width="6" height="3"/><rect x="12" y="6.5" width="8" height="3"/><rect x="12" y="11.5" width="8" height="3"/><rect x="12" y="16.5" width="8" height="3"/>',
  listview: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 7.5h18M10 3v18"/><rect x="5" y="10" width="3" height="2.5"/><rect x="5" y="15" width="3" height="2.5"/><path d="M12 11.3h6M12 16.3h6"/>',
  header: '<rect x="2" y="8" width="20" height="8" rx="1"/><path d="M8 8v8M15 8v8"/>',
  statusbar: '<rect x="2" y="4" width="20" height="16" rx="1"/><path d="M2 16h20M9 16v4M15 16v4"/>',
  toolbar: '<rect x="2" y="4" width="20" height="16" rx="1"/><path d="M2 9h20"/><rect x="4" y="5.5" width="2.5" height="2"/><rect x="8" y="5.5" width="2.5" height="2"/><rect x="12" y="5.5" width="2.5" height="2"/>',
  coolbar: '<rect x="2" y="4" width="20" height="16" rx="1"/><path d="M2 10h20M5 5.5v3M5 11.5v3M7 7h8M7 13h11"/>',
  pagescroller: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M6 10l-2 2 2 2M18 10l2 2-2 2M8 12h8"/>',
  comboex: '<rect x="2" y="7" width="20" height="10" rx="1"/><rect x="4" y="9.5" width="4" height="5"/><path d="M10 12h4M16 7v10M17.5 11l1.2 1.4 1.3-1.4"/>',
  timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M10 2h4"/>',
  paintbox: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M7 17c3-1 4-6 10-9"/><circle cx="16.5" cy="8" r="1.5" fill="currentColor"/>',
  media: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 10v4l3-2zM11 10v4M13 10v4M16 10h3v4h-3z" fill="currentColor"/>',
  ole: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M8 9a3 3 0 1 0 0 6 3 3 0 1 0 0-6M13 9v6h4"/>',
  tabset: '<path d="M3 4h18v10H3z"/><path d="M4 14l1 5h6l1-5M12 14l1 4h5l1-4" />',
  outline: '<path d="M5 5h3M5 5v14M5 10h3M5 15h3"/><path d="M10 5h9M10 10h9M10 15h9M7 19h12" opacity=".7"/>',
  notebook: '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 3v18M11 8h6M11 12h6"/>',
  filelist: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 15h6M9 18h4"/>',
  dirlist: '<path d="M3 7.5A1.5 1.5 0 0 1 4.5 6H9l2 2h8.5A1.5 1.5 0 0 1 21 9.5v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z"/>',
  drivecombo: '<rect x="2" y="7" width="20" height="10" rx="1"/><rect x="4" y="9.5" width="7" height="5" rx="1"/><circle cx="9" cy="12" r=".7" fill="currentColor"/><path d="M16 7v10M17.5 11l1.2 1.4 1.3-1.4"/>',
  filtercombo: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M4.5 9.5h7l-2.7 3v2l-1.6.8v-2.8z"/><path d="M16 7v10M17.5 11l1.2 1.4 1.3-1.4"/>',
  dlgopen: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M6 11h4l1 1.5h7v5H6z"/>',
  dlgsave: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M7 10h8l2 2v6H7z"/><path d="M9 10v3h5v-3M9 18v-3h6v3"/>',
  dlgopenpic: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><rect x="6" y="10" width="12" height="8"/><path d="M6 16l3-3 3 3 2-2 4 4"/>',
  dlgfont: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M8 18l3.5-8h1l3.5 8M9.5 15h5"/>',
  dlgcolor: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><circle cx="9" cy="12" r="2" fill="currentColor" fill-opacity=".7"/><circle cx="15" cy="12" r="2" fill="currentColor" fill-opacity=".45"/><circle cx="12" cy="16.5" r="2" fill="currentColor" fill-opacity=".2"/>',
  dlgprint: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M8 13V9.5h8V13M6 13h12v4H6zM8 15.5h8V19H8z"/>',
  dlgprintsetup: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M6 12h9v5H6zM8 12V9.5h5V12"/><circle cx="18" cy="16" r="2"/>',
  dlgfind: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><circle cx="11" cy="13" r="3"/><path d="M13.2 15.2L17 19"/>',
  dlgreplace: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><path d="M6 11h7l-2-2M18 16h-7l2 2"/>',
  dlgpage: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><rect x="8" y="9" width="8" height="10"/><path d="M10 12h4M10 15h4" opacity=".6"/>',
  dlgtask: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20"/><circle cx="8" cy="13" r="2.5"/><path d="M8 12.2v1.8M12.5 12h5.5M12.5 15h4"/>',
  dlgtext: '<rect x="2" y="3" width="20" height="18" rx="1.5"/><path d="M2 7h20M6 11h12M6 14h12M6 17h7"/>',
  db: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/>',
  datasource: '<ellipse cx="9" cy="6" rx="6" ry="2.4"/><path d="M3 6v10c0 1.3 2.7 2.4 6 2.4M15 6v4"/><path d="M14 15h7M18 12l3 3-3 3"/>',
  clientds: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/><rect x="9" y="11" width="6" height="5"/>',
  provider: '<ellipse cx="7" cy="6" rx="4.5" ry="2"/><path d="M2.5 6v9c0 1.1 2 2 4.5 2s4.5-.9 4.5-2V6"/><path d="M13 12h8M18 9l3 3-3 3"/>',
  dbgrid: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 8h18M3 13h18M9 3v18M15 3v18"/>',
  navigator: '<rect x="2" y="8" width="20" height="8" rx="1"/><path d="M5 10v4M8 10l-1.5 2L8 14M16 10l1.5 2L16 14M19 10v4M11 12h2"/>',
  dbctrlgrid: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 9h18M3 15h18"/><rect x="5" y="4.5" width="6" height="3"/><rect x="5" y="10.5" width="6" height="3"/>',
  ado: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/><path d="M9 17l2.5-6h1L15 17M9.8 15h4.4"/>',
  firedac: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/><path d="M12 17c-2 0-3-1.3-3-2.8 0-2 2-2.5 2.5-4.4 1 1 1.5 1.8 1.5 2.7.7-.4 1-1 1-1.5.5.8 1 1.5 1 2.6 0 2-1.4 3.4-3 3.4z"/>',
  conn: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v8M19 6v8"/><path d="M12 14v4M8 21h8M9 18h6"/>',
  query: '<ellipse cx="10" cy="6" rx="6" ry="2.4"/><path d="M4 6v11c0 1.3 2.7 2.4 6 2.4M16 6v4"/><circle cx="16.5" cy="15.5" r="3"/><path d="M18.7 17.7L21 20"/>',
  table: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M3 9h18M3 14h18M9 4v16M15 4v16"/>',
  storedproc: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/><path d="M10 11v6l5-3z"/>',
  command: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M6 9l3 3-3 3M11 15h6"/>',
  transaction: '<ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6"/><path d="M9 13h6l-2-2M15 16H9l2 2"/>',
  driverlink: '<ellipse cx="7" cy="7" rx="4" ry="1.8"/><path d="M3 7v7c0 1 1.8 1.8 4 1.8s4-.8 4-1.8V7"/><path d="M11 11h3a3 3 0 0 1 0 6h-1M17 14h4"/>',
  waitcursor: '<path d="M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9"/>',
  splitview: '<rect x="2" y="4" width="20" height="16" rx="1"/><path d="M8 4v16" /><path d="M4 8h2M4 11h2M4 14h2"/><rect x="2" y="4" width="6" height="16" fill="currentColor" fill-opacity=".15"/>',
  toggle: '<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16" cy="12" r="3" fill="currentColor"/>',
  activity: '<circle cx="12" cy="4.5" r="1.6"/><circle cx="17.3" cy="6.7" r="1.4"/><circle cx="19.5" cy="12" r="1.2"/><circle cx="17.3" cy="17.3" r="1"/><circle cx="12" cy="19.5" r=".9"/><circle cx="6.7" cy="17.3" r=".8"/><circle cx="4.5" cy="12" r=".7"/><circle cx="6.7" cy="6.7" r=".6"/>',
  calview: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 8h18"/><path d="M6 11h2M11 11h2M16 11h2M6 14.5h2M11 14.5h2M16 14.5h2M6 18h2M11 18h2"/>',
  calpicker: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 12h8"/><rect x="15" y="9" width="5" height="6"/><path d="M15 10.8h5M16.5 8v2M18.5 8v2"/>',
  timepicker: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M5 12h7"/><circle cx="17.5" cy="12" r="3"/><path d="M17.5 10.5V12l1 .8"/>',
  searchbox: '<rect x="2" y="7" width="20" height="10" rx="1"/><circle cx="16.5" cy="11.5" r="2.3"/><path d="M18.2 13.2l1.8 1.8"/>',
  gauge: '<path d="M3 17a9 9 0 1 1 18 0"/><path d="M12 17l4-6"/><circle cx="12" cy="17" r="1" fill="currentColor"/>',
  colorgrid: '<rect x="3" y="3" width="18" height="18"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/><path d="M3 3h6v6H3z" fill="currentColor" fill-opacity=".6"/><path d="M15 9h6v6h-6z" fill="currentColor" fill-opacity=".35"/>',
  spinbutton: '<rect x="8" y="3" width="8" height="18" rx="1"/><path d="M8 12h8M10.5 8.5L12 7l1.5 1.5M10.5 15.5L12 17l1.5-1.5"/>',
  spinedit: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M16 7v10M16 12h6M17.6 10.2l1.4-1.2 1.4 1.2M17.6 13.8l1.4 1.2 1.4-1.2M5 12h6"/>',
  web: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18M12 3c-5 5-5 13 0 18"/>',
  edge: '<circle cx="12" cy="12" r="9"/><path d="M5 14c1-6 13-7 14 0-1 3-5 4-8 2 3 0 5-2 4-4"/>',
  chart: '<path d="M3 3v18h18"/><path d="M7 17v-5M11 17V8M15 17v-7M19 17V5" stroke-width="2.2"/>',
  dbchart: '<path d="M3 3v18h18"/><path d="M7 17v-5M11 17V8M15 17v-7" stroke-width="2.2"/>',
  report: '<path d="M6 2h9l4 4v16H6z"/><path d="M15 2v5h4M9 11h7M9 15h7M9 19h5"/>',
  line: '<path d="M5 19L19 5"/>',
  data: '<rect x="2" y="7" width="20" height="10" rx="1"/><path d="M8 10l-2 2 2 2M16 10l2 2-2 2"/>',
  component: '<rect x="4" y="4" width="16" height="16" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M12 4v5M12 15v5M4 12h5M15 12h5"/>',
  frameold: '<path d="M10 6h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h1"/><path d="M6.5 4.5h2"/>',
};
const NKG_BADGE_DB = '<g transform="translate(13 13) scale(.45)" stroke-width="3"><ellipse cx="12" cy="6" rx="8" ry="3" fill="var(--nk-badge-bg,#fff)"/><path d="M4 6v12c0 1.6 3.6 3 8 3s8-1.4 8-3V6" fill="var(--nk-badge-bg,#fff)"/></g>';
const NKG_COLOR = { label: '#2f7de1', edit: '#5b6b7f', memo: '#e8890c', button: '#2f7de1', check: '#2e9d57', radio: '#2e9d57', listbox: '#2f7de1', combo: '#5b6b7f', scrollbar: '#d64545', groupbox: '#d64545', radiogroup: '#5b6b7f', panel: '#5b6b7f', actionlist: '#e8890c', mainmenu: '#2f7de1', popup: '#e8890c', frame: '#2f7de1',
  bitbtn: '#2e9d57', speedbutton: '#2f7de1', maskedit: '#8a5cd6', grid: '#2f7de1', drawgrid: '#8a5cd6', image: '#2e9d57', shape: '#e8890c', bevel: '#5b6b7f', scrollbox: '#d64545', checklist: '#2e9d57', splitter: '#5b6b7f', statictext: '#2f7de1', colorbox: '#d64545', colorlist: '#d64545', colorgrid: '#d64545', toggle: '#2f7de1', activity: '#2f7de1', gauge: '#e8890c', chart: '#2e9d57', dbchart: '#2e9d57',
  tabcontrol: '#2f7de1', pagecontrol: '#2f7de1', imagelist: '#2e9d57', richedit: '#e8890c', trackbar: '#2f7de1', progress: '#2e9d57', updown: '#5b6b7f', calendar: '#d64545', calview: '#d64545', calpicker: '#d64545', datetime: '#d64545', timepicker: '#8a5cd6', tree: '#e8890c', listview: '#2f7de1', statusbar: '#5b6b7f', toolbar: '#2f7de1', timer: '#8a5cd6', media: '#d64545', web: '#2f7de1', edge: '#14a39a',
  db: '#c8961c', datasource: '#c8961c', clientds: '#c8961c', provider: '#c8961c', ado: '#c8961c', firedac: '#e05a1c', conn: '#c8961c', query: '#c8961c', table: '#c8961c', storedproc: '#c8961c', transaction: '#c8961c', driverlink: '#e05a1c', dbgrid: '#c8961c', navigator: '#c8961c', dbctrlgrid: '#c8961c', xml: '#e8890c', bind: '#14a39a', gesture: '#8a5cd6', tether: '#14a39a', sensor: '#d64545', monitor: '#2f7de1', report: '#d64545' };
function nkIconSvg(glyph, badge) { const c = NKG_COLOR[glyph] || (/^dlg/.test(glyph || '') ? '#2f7de1' : '#5b6b7f'); return `<svg class="i nkc" viewBox="0 0 24 24" style="color:${c}">${NKG[glyph] || NKG.component}${badge ? NKG_BADGE_DB : ''}</svg>`; }

// ---------- catálogo: categorias e componentes, como na Tool Palette do Delphi ----------
// [classe Delphi, tipo do Neo Kiva, ícone, padrões, largura px, altura px]
const NK_PALETTE = [
  ['Standard', [
    ['Frames', 'NB.Panel', 'frame', { BorderStyle: 0, Caption: '' }, 185, 125],
    ['TMainMenu', '#menu', 'mainmenu'],
    ['TPopupMenu', 'NK.Component', 'popup'],
    ['TLabel', 'VB.Label', 'label', { BackStyle: 0, AutoSize: true }, 31, 15],
    ['TEdit', 'VB.TextBox', 'edit', {}, 121, 23],
    ['TMemo', 'VB.TextBox', 'memo', { MultiLine: true, ScrollBars: 2 }, 185, 89],
    ['TButton', 'VB.CommandButton', 'button', {}, 75, 25],
    ['TCheckBox', 'VB.CheckBox', 'check', {}, 97, 17],
    ['TRadioButton', 'VB.OptionButton', 'radio', {}, 113, 17],
    ['TListBox', 'VB.ListBox', 'listbox', {}, 121, 97],
    ['TComboBox', 'VB.ComboBox', 'combo', {}, 145, 23],
    ['TScrollBar', 'VB.HScrollBar', 'scrollbar', { Max: 100 }, 121, 17],
    ['TGroupBox', 'VB.Frame', 'groupbox', {}, 185, 105],
    ['TRadioGroup', 'NK.RadioGroup', 'radiogroup', {}, 185, 105],
    ['TPanel', 'NB.Panel', 'panel', {}, 185, 41],
    ['TActionList', 'NK.Component', 'actionlist'],
  ]],
  ['Additional', [
    ['TBitBtn', 'VB.CommandButton', 'bitbtn', { Style: 1 }, 75, 25],
    ['TSpeedButton', 'NK.SpeedButton', 'speedbutton', { Flat: true }, 23, 22],
    ['TMaskEdit', 'VB.TextBox', 'maskedit', { Mask: '##/##/####' }, 121, 23],
    ['TStringGrid', 'NK.StringGrid', 'grid', { Editing: true }, 320, 120],
    ['TDrawGrid', 'NK.StringGrid', 'drawgrid', {}, 320, 120],
    ['TImage', 'VB.Image', 'image', { Stretch: true }, 105, 105],
    ['TShape', 'VB.Shape', 'shape', { BackStyle: 1 }, 65, 65],
    ['TBevel', 'NK.Bevel', 'bevel', {}, 50, 50],
    ['TScrollBox', 'NK.ScrollBox', 'scrollbox', {}, 185, 185],
    ['TCheckListBox', 'VB.ListBox', 'checklist', { Style: 1 }, 121, 97],
    ['TSplitter', 'NK.Splitter', 'splitter', {}, 3, 100],
    ['TStaticText', 'VB.Label', 'statictext', { BorderStyle: 1, AutoSize: true }, 59, 17],
    ['TControlBar', 'NB.Panel', 'controlbar', { Caption: '' }, 250, 50],
    ['TApplicationEvents', 'NK.Component', 'appevents'],
    ['TValueListEditor', 'NK.StringGrid', 'valuelist', { ColCount: 2, RowCount: 2, FixedCols: 0, DefaultColWidth: 150, Cells: 'Key;Value', Editing: true }, 306, 300],
    ['TLabeledEdit', 'NK.LabeledEdit', 'labelededit', {}, 121, 23],
    ['TColorBox', 'NK.ColorBox', 'colorbox', {}, 145, 22],
    ['TColorListBox', 'NK.ColorListBox', 'colorlist', {}, 121, 97],
    ['TCategoryButtons', 'NK.ButtonGroup', 'catbuttons', { Items: '#Category|Button 1|Button 2' }, 133, 160],
    ['TButtonGroup', 'NK.ButtonGroup', 'btngroup', {}, 133, 160],
    ['TDockTabSet', 'NK.TabSet', 'docktabset', {}, 200, 21],
    ['TTrayIcon', 'NK.Component', 'trayicon'],
    ['TFlowPanel', 'NB.Panel', 'flowpanel', {}, 185, 41],
    ['TGridPanel', 'NB.Panel', 'gridpanel', {}, 185, 41],
    ['TCategoryPanelGroup', 'NB.Panel', 'catpanel', { Caption: '' }, 200, 250],
    ['TActionManager', 'NK.Component', 'actionmanager'],
    ['TActionMainMenuBar', 'NK.ToolBar', 'actmenubar', { Buttons: 'File|Edit|View|Help', Align: 1 }, 320, 25],
    ['TActionToolBar', 'NK.ToolBar', 'acttoolbar', { Align: 1 }, 320, 26],
    ['TCustomizeDlg', 'NK.Dialog', 'customize'],
    ['TStackPanel', 'NB.Panel', 'stackpanel', {}, 185, 200],
    ['TCardPanel', 'NB.Panel', 'cardpanel', {}, 300, 200],
    ['TNumberBox', 'NK.SpinEdit', 'numberbox', {}, 121, 23],
    ['TRelativePanel', 'NB.Panel', 'relativepanel', {}, 185, 41],
  ]],
  ['Win32', [
    ['TTabControl', 'NB.TabControl', 'tabcontrol', {}, 289, 193],
    ['TPageControl', 'NB.TabControl', 'pagecontrol', {}, 289, 193],
    ['TImageList', 'NB.ImageList', 'imagelist'],
    ['TRichEdit', 'NB.RichTextBox', 'richedit', {}, 185, 89],
    ['TTrackBar', 'NB.Slider', 'trackbar', {}, 150, 45],
    ['TProgressBar', 'NB.ProgressBar', 'progress', { Value: 0 }, 150, 17],
    ['TUpDown', 'NK.UpDown', 'updown', {}, 17, 25],
    ['THotKey', 'NK.HotKey', 'hotkey', {}, 121, 19],
    ['TAnimate', 'NK.Animate', 'animate', {}, 100, 80],
    ['TDateTimePicker', 'NB.DatePicker', 'datetime', {}, 186, 23],
    ['TMonthCalendar', 'NK.MonthCalendar', 'calendar', {}, 225, 160],
    ['TTreeView', 'NB.TreeView', 'tree', {}, 121, 97],
    ['TListView', 'NK.ListView', 'listview', {}, 250, 150],
    ['THeaderControl', 'NK.HeaderControl', 'header', {}, 320, 17],
    ['TStatusBar', 'NK.StatusBar', 'statusbar', {}, 320, 19],
    ['TToolBar', 'NK.ToolBar', 'toolbar', {}, 320, 29],
    ['TCoolBar', 'NB.Panel', 'coolbar', { Caption: '' }, 320, 75],
    ['TPageScroller', 'NB.Panel', 'pagescroller', { Caption: '' }, 150, 45],
    ['TComboBoxEx', 'VB.ComboBox', 'comboex', {}, 145, 22],
  ]],
  ['System', [
    ['TTimer', 'VB.Timer', 'timer', { Interval: 1000 }],
    ['TPaintBox', 'VB.PictureBox', 'paintbox', { BorderStyle: 0 }, 105, 105],
    ['TMediaPlayer', 'NK.MediaPlayer', 'media', {}, 253, 30],
    ['TOleContainer', 'NK.Component', 'ole'],
  ]],
  ['Win 3.1', [
    ['TTabSet', 'NK.TabSet', 'tabset', {}, 185, 21],
    ['TOutline', 'NB.TreeView', 'outline', {}, 121, 97],
    ['TTabbedNotebook', 'NB.TabControl', 'tabcontrol', {}, 300, 250],
    ['TNotebook', 'NB.Panel', 'notebook', { Caption: '' }, 150, 150],
    ['THeader', 'NK.HeaderControl', 'header', {}, 250, 25],
    ['TFileListBox', 'VB.FileListBox', 'filelist', {}, 145, 97],
    ['TDirectoryListBox', 'VB.DirListBox', 'dirlist', {}, 145, 97],
    ['TDriveComboBox', 'VB.DriveListBox', 'drivecombo', {}, 145, 22],
    ['TFilterComboBox', 'VB.ComboBox', 'filtercombo', { Text: 'All files (*.*)', Style: 2 }, 145, 22],
  ]],
  ['Dialogs', [
    ['TOpenDialog', 'NK.Dialog', 'dlgopen'], ['TSaveDialog', 'NK.Dialog', 'dlgsave'], ['TOpenPictureDialog', 'NK.Dialog', 'dlgopenpic'], ['TSavePictureDialog', 'NK.Dialog', 'dlgopenpic'],
    ['TFontDialog', 'NK.Dialog', 'dlgfont'], ['TColorDialog', 'NK.Dialog', 'dlgcolor'], ['TPrintDialog', 'NK.Dialog', 'dlgprint'], ['TPrinterSetupDialog', 'NK.Dialog', 'dlgprintsetup'],
    ['TFindDialog', 'NK.Dialog', 'dlgfind'], ['TReplaceDialog', 'NK.Dialog', 'dlgreplace'], ['TPageSetupDialog', 'NK.Dialog', 'dlgpage'], ['TFileOpenDialog', 'NK.Dialog', 'dlgopen'],
    ['TFileSaveDialog', 'NK.Dialog', 'dlgsave'], ['TTaskDialog', 'NK.Dialog', 'dlgtask'], ['TOpenTextFileDialog', 'NK.Dialog', 'dlgtext'], ['TSaveTextFileDialog', 'NK.Dialog', 'dlgtext'],
  ]],
  ['Data Access', [
    ['TDataSource', 'NK.Component', 'datasource'], ['TClientDataSet', 'NK.Component', 'clientds'], ['TDataSetProvider', 'NK.Component', 'provider'],
  ]],
  ['Data Controls', [
    ['TDBGrid', 'NB.DataGrid', 'dbgrid', {}, 320, 120, 1],
    ['TDBNavigator', 'NB.NavigationBar', 'navigator', { Align: 0 }, 240, 25, 1],
    ['TDBText', 'VB.Label', 'label', { BackStyle: 0 }, 65, 17, 1],
    ['TDBEdit', 'VB.TextBox', 'edit', {}, 121, 23, 1],
    ['TDBMemo', 'VB.TextBox', 'memo', { MultiLine: true, ScrollBars: 2 }, 185, 89, 1],
    ['TDBImage', 'VB.Image', 'image', { Stretch: true, BorderStyle: 1 }, 105, 105, 1],
    ['TDBListBox', 'VB.ListBox', 'listbox', {}, 121, 97, 1],
    ['TDBComboBox', 'VB.ComboBox', 'combo', {}, 145, 23, 1],
    ['TDBCheckBox', 'VB.CheckBox', 'check', {}, 97, 17, 1],
    ['TDBRadioGroup', 'NK.RadioGroup', 'radiogroup', {}, 185, 105, 1],
    ['TDBLookupListBox', 'VB.ListBox', 'listbox', {}, 121, 95, 1],
    ['TDBLookupComboBox', 'VB.ComboBox', 'combo', { Style: 2 }, 145, 23, 1],
    ['TDBRichEdit', 'NB.RichTextBox', 'richedit', {}, 185, 89, 1],
    ['TDBCtrlGrid', 'NB.Panel', 'dbctrlgrid', { Caption: '' }, 200, 220, 1],
    ['TDBChart', 'NK.Chart', 'dbchart', {}, 400, 250, 1],
  ]],
  ['dbGo', [
    ['TADOConnection', 'NK.Component', 'ado'], ['TADOCommand', 'NK.Component', 'command'], ['TADODataSet', 'NK.Component', 'ado'], ['TADOTable', 'NK.Component', 'table'],
    ['TADOQuery', 'NK.Component', 'query'], ['TADOStoredProc', 'NK.Component', 'storedproc'], ['TRDSConnection', 'NK.Component', 'conn'],
  ]],
  ['FireDAC', [
    ['TFDConnection', 'NK.Component', 'firedac'], ['TFDQuery', 'NK.Component', 'query'], ['TFDTable', 'NK.Component', 'table'], ['TFDStoredProc', 'NK.Component', 'storedproc'],
    ['TFDMemTable', 'NK.Component', 'clientds'], ['TFDCommand', 'NK.Component', 'command'], ['TFDTransaction', 'NK.Component', 'transaction'],
    ['TFDPhysMySQLDriverLink', 'NK.Component', 'driverlink'], ['TFDPhysSQLiteDriverLink', 'NK.Component', 'driverlink'], ['TFDGUIxWaitCursor', 'NK.Component', 'waitcursor'],
  ]],
  ['Windows 10', [
    ['TSplitView', 'NK.SplitView', 'splitview', {}, 200, 300],
    ['TToggleSwitch', 'NK.ToggleSwitch', 'toggle', {}, 73, 20],
    ['TActivityIndicator', 'NK.ActivityIndicator', 'activity', {}, 32, 32],
    ['TCalendarView', 'NK.MonthCalendar', 'calview', {}, 250, 220],
    ['TCalendarPicker', 'NB.DatePicker', 'calpicker', {}, 160, 32],
    ['TDatePicker', 'NB.DatePicker', 'calpicker', {}, 150, 32],
    ['TTimePicker', 'NK.TimePicker', 'timepicker', {}, 150, 32],
    ['TSearchBox', 'NB.SearchBox', 'searchbox', {}, 121, 23],
  ]],
  ['Samples', [
    ['TGauge', 'NK.Gauge', 'gauge', { Progress: 50 }, 100, 100],
    ['TColorGrid', 'NK.ColorGrid', 'colorgrid', {}, 100, 100],
    ['TSpinButton', 'NK.UpDown', 'spinbutton', {}, 20, 25],
    ['TSpinEdit', 'NK.SpinEdit', 'spinedit', {}, 121, 23],
    ['TDirectoryOutline', 'VB.DirListBox', 'outline', {}, 145, 97],
    ['TCalendar', 'NK.MonthCalendar', 'calendar', {}, 320, 120],
  ]],
  ['Internet', [
    ['TWebBrowser', 'NB.WebBrowser', 'web', {}, 300, 150],
    ['TEdgeBrowser', 'NB.WebBrowser', 'edge', {}, 300, 150],
  ]],
  ['TeeChart', [
    ['TChart', 'NK.Chart', 'chart', {}, 400, 250],
  ]],
  ['dbExpress', [
    ['TSQLConnection', 'NK.Component', 'conn'], ['TSQLDataSet', 'NK.Component', 'db'], ['TSQLQuery', 'NK.Component', 'query'], ['TSQLStoredProc', 'NK.Component', 'storedproc'], ['TSQLTable', 'NK.Component', 'table'], ['TSQLMonitor', 'NK.Component', 'monitor'], ['TSimpleDataSet', 'NK.Component', 'clientds'],
  ]],
  ['Xml', [['TXMLDocument', 'NK.Component', 'xml'], ['TXMLTransform', 'NK.Component', 'xml'], ['TXMLTransformProvider', 'NK.Component', 'provider'], ['TXMLTransformClient', 'NK.Component', 'provider']]],
  ['LiveBindings', [['TBindingsList', 'NK.Component', 'bind'], ['TBindSourceDB', 'NK.Component', 'datasource'], ['TPrototypeBindSource', 'NK.Component', 'bind'], ['TBindNavigator', 'NB.NavigationBar', 'navigator', { Align: 0 }, 240, 25]]],
  ['LiveBindings Misc', [['TBindScope', 'NK.Component', 'bind'], ['TBindScopeDB', 'NK.Component', 'bind'], ['TBindExpression', 'NK.Component', 'bind'], ['TBindLink', 'NK.Component', 'bind']]],
  ['Gestures', [['TGestureManager', 'NK.Component', 'gesture'], ['TGesturePreview', 'NB.Panel', 'gesture', { Caption: '' }, 200, 200], ['TGestureRecorder', 'NB.Panel', 'gesture', { Caption: '' }, 200, 200], ['TGestureListView', 'NK.ListView', 'listview', {}, 200, 150]]],
  ['Net', [['TNetHTTPClient', 'NK.Component', 'web'], ['TNetHTTPRequest', 'NK.Component', 'web'], ['TRESTClient', 'NK.Component', 'web'], ['TRESTRequest', 'NK.Component', 'command'], ['TRESTResponse', 'NK.Component', 'xml']]],
  ['Tethering', [['TTetheringManager', 'NK.Component', 'tether'], ['TTetheringAppProfile', 'NK.Component', 'tether']]],
  ['Vista Dialogs', [['TFileOpenDialog', 'NK.Dialog', 'dlgopen'], ['TFileSaveDialog', 'NK.Dialog', 'dlgsave'], ['TTaskDialog', 'NK.Dialog', 'dlgtask']]],
  ['Sensors', [['TLocationSensor', 'NK.Component', 'sensor'], ['TMotionSensor', 'NK.Component', 'sensor'], ['TOrientationSensor', 'NK.Component', 'sensor'], ['TLightSensor', 'NK.Component', 'sensor']]],
  ['Neo Kiva', [
    ['Data', 'VB.Data', 'data', {}, 129, 23],
    ['NavigationBar', 'NB.NavigationBar', 'navigator'],
    ['FormReport', 'NB.FormReport', 'report'],
    ['Line', 'VB.Line', 'line'],
    ['DataGrid', 'NB.DataGrid', 'dbgrid'],
    ['GroupBox', 'NB.GroupBox', 'groupbox'],
  ]],
  ['Visual Basic', null], // preenchida com a caixa de ferramentas original (VB.*)
];
const NK_PAL = new Map(); // classe minúscula -> item
for (const [cat, items] of NK_PALETTE) {
  if (!items) continue;
  for (const it of items) { const [cls, type, glyph, preset, w, h, db] = it; NK_PAL.set(cls.toLowerCase(), { cls, type, glyph, preset: preset || {}, w, h, db: !!db, cat }); }
}
{
  const vb = NK_PALETTE.find(c => c[0] === 'Visual Basic');
  vb[1] = (typeof TOOL_ORDER !== 'undefined' ? TOOL_ORDER : []).filter(t => /^VB\./.test(t)).map(t => [t.replace(/^VB\./, ''), t, null]);
  for (const [cls, type] of vb[1]) NK_PAL.set('vb:' + cls.toLowerCase(), { cls, type, glyph: null, preset: {}, cat: 'Visual Basic', vb: true });
}
function nkPalKey(it) { return it.vb ? 'vb:' + it.cls.toLowerCase() : it.cls.toLowerCase(); }
function nkPalItem(key) { if (!key || typeof key !== 'string') return null; return NK_PAL.get(key.toLowerCase()) || null; }
function nkPaletteIcon(cls) { const d = typeof nkDIcon === 'function' ? nkDIcon(cls, 24) : ''; if (d) return d; const it = nkPalItem(String(cls || '')); return it ? nkIconSvg(it.glyph, it.db) : nkIconSvg('component'); }
function nkItemIcon(it, size) { if (!it.vb && typeof nkDIcon === 'function') { const d = nkDIcon(it.cls, size || 24); if (d) return d; } if (it.glyph) return nkIconSvg(it.glyph, it.db); return (typeof TOOL_ICONS !== 'undefined' && TOOL_ICONS[it.type]) || nkIconSvg('component'); }
// nome base no estilo Delphi: TButton -> Button1
function nkBaseName(it) {
  if (it.vb) return ctlBaseName(it.type);
  if (it.cls === 'Frames') return 'Frame';
  if (it.type === 'NB.NavigationBar' && it.cls === 'NavigationBar') return 'NavigationBar';
  return it.cls.replace(/^T(?=[A-Z])/, '');
}
const nkRaw = v => typeof v === 'boolean' ? (v ? '-1' : '0') : typeof v === 'number' ? String(v) : quote(String(v));

// ---------- a aba da esquerda ----------
function nkBuildPalette() {
  const panel = $('#toolbox'); if (!panel) return;
  if (!panel.dataset.nk) {
    panel.dataset.nk = '1';
    panel.innerHTML = `<div class="ptitle">Tool Palette <span class="nkp-tools"><button class="nkp-view" title="Show names / icons only"></button></span></div><input class="nkp-search" placeholder="Search components…" spellcheck="false"><div class="tools nkp-list"></div>`;
    $('.nkp-search', panel).addEventListener('input', () => nkBuildPalette());
    $('.nkp-search', panel).addEventListener('keydown', e => { if (e.key === 'Escape') { e.target.value = ''; nkBuildPalette(); } if (e.key === 'Enter') { const f = $('.nkp-item', panel); if (f) f.dispatchEvent(new MouseEvent('dblclick')); } });
    $('.nkp-view', panel).onclick = () => { IDE.opts.palNames = !IDE.opts.palNames; try { localStorage.setItem('neokiva.opts', JSON.stringify(IDE.opts)); } catch (e) { } nkBuildPalette(); };
  }
  const names = !!IDE.opts.palNames;
  panel.classList.toggle('nkp-names', names);
  $('.nkp-view', panel).innerHTML = names ? '<svg class="i" viewBox="0 0 24 24"><rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/></svg>' : '<svg class="i" viewBox="0 0 24 24"><path d="M4 6h3M10 6h10M4 12h3M10 12h10M4 18h3M10 18h10"/></svg>';
  const q = ($('.nkp-search', panel).value || '').trim().toLowerCase();
  const box = $('.nkp-list', panel); const scroll = box.scrollTop; box.innerHTML = '';
  let collapsed = {}; try { collapsed = JSON.parse(localStorage.getItem('neokiva.palcats') || '{}'); } catch (e) { }
  if (collapsed.__v !== 2) { collapsed = { __v: 2 }; for (const [c] of NK_PALETTE) if (c !== 'Standard') collapsed[c] = true; }
  const cur = IDE.tool || 'pointer';
  const ptr = h('div', { class: 'nkp-item nkp-ptr' + (cur === 'pointer' ? ' on' : ''), title: 'Pointer', html: `${TOOL_ICONS.pointer}<span>Pointer</span>` });
  ptr.onclick = () => { IDE.tool = null; nkBuildPalette(); };
  box.appendChild(ptr);
  for (const [cat, items] of NK_PALETTE) {
    const list = (items || []).filter(it => !q || it[0].toLowerCase().includes(q) || cat.toLowerCase().includes(q));
    if (!list.length) continue;
    const open = q ? true : !collapsed[cat];
    const head = h('div', { class: 'nkp-cat' + (open ? ' open' : ''), html: `<i></i><span>${esc(cat)}</span><em>${list.length}</em>` });
    head.onclick = () => { collapsed[cat] = !collapsed[cat]; try { localStorage.setItem('neokiva.palcats', JSON.stringify(collapsed)); } catch (e) { } nkBuildPalette(); };
    box.appendChild(head);
    if (!open) continue;
    const grid = h('div', { class: 'nkp-grid' });
    for (const raw of list) {
      const it = cat === 'Visual Basic' ? NK_PAL.get('vb:' + raw[0].toLowerCase()) : NK_PAL.get(raw[0].toLowerCase());
      const key = nkPalKey(it);
      const label = it.vb ? it.cls : it.cls;
      const tip = it.vb ? `${label} (Visual Basic)` : it.type === '#menu' ? `${label} — opens the Menu Editor` : `${label}${it.db ? ' (data-aware)' : ''}`;
      const el = h('div', { class: 'nkp-item' + (cur === key ? ' on' : ''), title: tip, html: `${nkItemIcon(it, names ? 16 : 24)}<span>${esc(label)}</span>` });
      el.draggable = it.type !== '#menu';
      el.onclick = () => { if (it.type === '#menu') { cmd('menuEditor'); return; } IDE.tool = key; nkBuildPalette(); };
      el.ondblclick = () => { if (it.type === '#menu') return; addControlDefault(key); IDE.tool = null; nkBuildPalette(); };
      el.addEventListener('dragstart', e => { e.dataTransfer.setData('text/x-neokiva-tool', key); e.dataTransfer.effectAllowed = 'copy'; });
      grid.appendChild(el);
    }
    box.appendChild(grid);
  }
  if (!box.children.length || box.children.length === 1) box.appendChild(h('div', { class: 'nkp-empty', html: 'No component matches.' }));
  box.scrollTop = scroll;
}
// aplica os padrões do item da paleta num controle recém-criado
function nkApplyPreset(m, n, it) {
  if (!it || it.vb) return;
  const base = nkBaseName(it); n.name = '\u0000'; const name = uniqueCtlName(m, base); n.name = name;
  const def = ctlDef(it.type);
  if (['VB.Label', 'VB.CommandButton', 'VB.CheckBox', 'VB.OptionButton', 'VB.Frame', 'VB.Data', 'NB.Panel', 'NB.GroupBox', 'NK.RadioGroup', 'NK.LabeledEdit', 'NK.SpeedButton'].includes(it.type)) n.setRaw('Caption', quote(it.type === 'NK.SpeedButton' ? '' : name));
  if (it.type === 'VB.TextBox' || it.type === 'VB.ComboBox') n.setRaw('Text', quote(it.cls === 'TMaskEdit' || /^TDB/.test(it.cls) ? '' : name));
  if (it.type === 'NK.Component' || it.type === 'NK.Dialog') n.setRaw('DelphiClass', quote(it.cls));
  if (/^TDB/.test(it.cls) && def.props.some(p => /^DataField/i.test(p))) n.setRaw('DataField', quote(''));
  for (const k in it.preset) n.setRaw(k, nkRaw(it.preset[k]));
  if (it.cls === 'TRadioGroup' || it.cls === 'TDBRadioGroup') { n.setRaw('Items', quote('Option 1|Option 2|Option 3')); }
  if (it.cls === 'TListView') n.setRaw('Items', quote('Item 1;10|Item 2;20|Item 3;30'));
  if (it.cls === 'TComboBoxEx' || it.cls === 'TFilterComboBox') { /* lista vazia */ }
}
