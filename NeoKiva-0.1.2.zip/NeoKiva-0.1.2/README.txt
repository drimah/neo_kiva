Neo Kiva 0.1.2 - free visual IDE in the style of Delphi and Visual Basic
======================================================================

Neo Kiva is a free development environment for Visual Basic 5/6-style projects.
It runs on Windows and Linux with the same interface.

This package includes:
- Neo Kiva launcher and application
- Complete JavaScript/CSS source code
- Standalone HTML build
- Bundled fonts and application icon

Version 0.7.1:
- Delphi import fixes (tested with a real ERP project):
  * identifiers and names with accented letters (e.g. "Descrição") are read
  * images embedded in .dfm files (PNG, JPEG, BMP, GIF, ICO) are imported
    into the form's .frx file (TImage pictures and button glyphs)
  * constructors and destructors with any name (not only Create/Destroy)
  * statements that use database components (ADO, FireDAC, BDE...) are kept
    as comments marked "[Delphi] (database)" so the program still runs
  * TDateTimePicker.Date / DateTime map to DatePicker.Value
- Runtime: a modal form opened from another modal form now shows on top
- Runtime: DatePicker.Value set from code now appears in the control

Version 0.7.0:
- Delphi import: File > Import Delphi Project... (or open a folder that has a
  .dpr file) converts a Delphi VCL project into a Neo Kiva project.
  * Forms (.dfm, text and binary): labels, edits, memos, buttons, check boxes,
    radio buttons, radio groups, list/combo boxes, group boxes, panels,
    images, shapes, bevels, timers, scroll bars, page controls, status bars,
    toolbars, main and popup menus, actions, open/save dialogs; positions,
    fonts, colors, anchors and alignment
  * Object Pascal code: units, procedures and functions, records, enums,
    classes with properties, if/case/for/while/repeat/with/try, exceptions,
    strings, dynamic arrays, TStringList, Format, ShowMessage, MessageDlg,
    ShowModal/ModalResult, events (OnClick, OnChange, OnKeyPress, OnClose...)
  * The original Delphi files are not changed; the Neo Kiva files are saved
    next to them. Anything that could not be converted is marked [Delphi] in
    the code and listed in the import report.
  * Not converted yet: database components (FireDAC, BDE, ADO, dbExpress),
    Canvas drawing, FireMonkey forms, anonymous methods, generics.

Version 0.6.13:
- Fixes over 0.6.12 (see CORRECOES-0.6.13.txt): MySQL installer for Windows
  (download with progress, UAC, NeoBasicMySQL service); Linux installer with real
  progress and Ubuntu fallback; readable MySQL databases
  (nb_<project>_<database>) with real table names

Version 0.6.12:
- Mandatory MySQL on Linux; new toolbox controls; WebForms editor

Version 0.6.11:
- NavigationBar buttons match the IDE toolbar (rounded-square hover)
- TextBox Mask property with presets (phone, CPF, CNPJ, CEP, date, time...)
  and ClipText

Version 0.6.10:
- NavigationBar Align property (0 None, 1 Top, 2 Bottom); docking moves the
  other controls so nothing is hidden under the bar
- Pick lists for DatabaseName, RecordSource, DataSource and DataField

Version 0.6.9:
- DataNav renamed NavigationBar: docks at the top of the form (below the menu)
  and fills its width; toolbar-style line icons; ButtonOrder (drag to reorder),
  ButtonSize (Small/Normal/Large); new Copy, Paste, Undo and Redo buttons

Version 0.6.8:
- DataNav control: record navigation bar with First/Previous/Next/Last, New,
  Edit, Delete, Save and Cancel (icons, icons+text or text; each button can be
  hidden); works alone (DatabaseName + RecordSource) or with a Data control
- Rename a project database (double-click it)
- Position and size in the toolbar can be typed
- Right-side panels can be minimized; the Immediate window is hidden (Ctrl+G)

Version 0.6.7:
- New Menu Editor: items and sub-items with drag and drop, and what each item
  does (open a form, close, end, message or your own code)
- Format Painter: copies color, font, size and style to controls of the same kind
- Inkscape-style align and distribute buttons (several controls align to the
  first one selected)
- New Project asks for the startup form

Version 0.6.6 interface updates:
- Light blue-and-white visual theme by default
- Compact Toolbox with two columns of blue line icons
- Circular hover/selection highlight for Toolbox tools
- Capsule-shaped buttons throughout the interface
- English locale by default
- Existing project and runtime files retained

Build:
Run codigo-fonte/build.py with Python 3 to regenerate codigo-fonte/dist/NeoKiva.html.


NEW IN THIS PROTOTYPE
- Project > Insert WebForm opens an integrated WebForm Designer.
- Classic Forms can be copied into WebForms; original .FRM files are preserved.
- WebForms are saved in the project WebForms/ folder as .nbweb.json.
- Export HTML creates a standalone HTML5 page.


MySQL obrigatório no Linux:
- O Neo Kiva exige MySQL Server para iniciar; não oferece SQLite como alternativa de backend.
- Abra pelo NeoKiva.sh. Não abra o HTML diretamente.
- O Neo Kiva mostra primeiro sua tela de inicialização e, somente se o MySQL estiver ausente, pergunta se a pessoa autoriza a instalação.
- Se a pessoa escolher Não, a inicialização é encerrada sem instalar nada.
- A instalação do MySQL Community Server 8.4 LTS (em instalações novas), Python/PyMySQL e a configuração do serviço são executadas somente pelo NeoKiva.sh.
- O serviço do Neo Kiva escuta somente em 127.0.0.1; não abre a porta MySQL para a rede.
- Os dados persistentes são gravados no MySQL. O runtime mantém um espelho SQL.js em memória para preservar a compatibilidade síncrona com o DAO clássico do VB5/6.
- Os aplicativos Linux exportados incluem o bridge e um lançador em modo de verificação; não instalam MySQL. A instalação é feita pelo Neo Kiva.
