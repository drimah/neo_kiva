﻿# NeoBasic 0.6.13 — MySQL Server on Windows (called by NeoBasic.exe; Windows PowerShell 5.1)
#
#   -Phase start  : MySQL ready -> starts the local service, writes the URL to -Out, exit 0
#                   not ready   -> exit 3 (NeoBasic.exe opens the main window, then calls -Phase setup)
#   -Phase setup  : asks to install MySQL (Install / Exit), downloads with a progress bar,
#                   installs as administrator (UAC), starts the local service. exit 0 = ok, 2 = closed
#   -Worker -Job <file.json> : internal, the elevated part of the installation
#
# Only NeoBasic installs MySQL: exported programs (App other than NeoBasic) never install anything.
param(
    [string]$App = 'NeoBasic',
    [string]$Phase = 'start',
    [string]$Html = '',
    [string]$Out = '',
    [switch]$Worker,
    [string]$Job = '',
    [switch]$Library   # only loads the functions (tests)
)

$ErrorActionPreference = 'Stop'
$NB_VERSION   = '0.6.13'
$NB_BASE      = Join-Path $env:ProgramFiles 'NeoBasic'
$PY_DIR       = Join-Path $NB_BASE 'runtime\python'
$MY_BASE      = Join-Path $NB_BASE 'MySQL\server'
$NB_DATA      = Join-Path $env:ProgramData 'NeoBasic'
$MY_DATA      = Join-Path $NB_DATA 'MySQL\data'
$MY_INI       = Join-Path $NB_DATA 'MySQL\my.ini'
$ROOT_PW_FILE = Join-Path $NB_DATA 'mysql-root.txt'
$SERVICE      = 'NeoBasicMySQL'
$IDE_PORT     = 43821
$SCRIPT_PATH  = $MyInvocation.MyCommand.Path
$SCRIPT_DIR   = Split-Path -Parent $SCRIPT_PATH
$LOCAL        = Join-Path $env:LOCALAPPDATA 'NeoBasic'
$UTF8         = New-Object System.Text.UTF8Encoding $false

# ---------------------------------------------------------------- utilitários
function Write-NBLog([string]$file, [string]$text) {
    try {
        $dir = Split-Path -Parent $file
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        [IO.File]::AppendAllText($file, ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $text + "`r`n"), $UTF8)
    } catch { }
}
function Write-Utf8([string]$path, [string]$text) {
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [IO.File]::WriteAllText($path, $text, $UTF8)
}
function New-Secret([int]$bytes = 24) {
    $b = New-Object byte[] $bytes
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($b); $rng.Dispose()
    return (($b | ForEach-Object { $_.ToString('x2') }) -join '')
}
function Get-ConfigPath([string]$userProfile) { return (Join-Path $userProfile '.config\neobasic\mysql.json') }
function Read-Config([string]$path) {
    if (-not (Test-Path $path)) { return $null }
    try { return ([IO.File]::ReadAllText($path, $UTF8).TrimStart([char]0xFEFF) | ConvertFrom-Json) } catch { return $null }
}
function Get-StableHash([string]$text) {
    $md5 = [Security.Cryptography.MD5]::Create()
    $h = $md5.ComputeHash($UTF8.GetBytes($text.ToLowerInvariant())); $md5.Dispose()
    return [BitConverter]::ToUInt32($h, 0)
}
function Get-ListeningPorts {
    try { return @([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | ForEach-Object { $_.Port }) } catch { return @() }
}
function Get-AppTarget([string]$app, [string]$html) {
    # pasta servida pelo bridge, endereço relativo do .html e porta
    $dir = Split-Path -Parent $html
    $leaf = Split-Path -Leaf $html
    $root = $dir; $rel = $leaf
    if ((Split-Path -Leaf $dir) -ieq 'Executables') { $root = Split-Path -Parent $dir; $rel = 'Executables/' + $leaf }
    if ($app -ieq 'NeoBasic') { $port = $IDE_PORT } else { $port = 44000 + ((Get-StableHash $root) % 15000) }
    $urlRel = (($rel -split '/') | ForEach-Object { [Uri]::EscapeDataString($_) }) -join '/'
    return @{ Root = $root; Rel = $urlRel; Port = [int]$port }
}

# ---------------------------------------------------------------- estado
function Get-NBState {
    $svc = Get-Service -Name $SERVICE -ErrorAction SilentlyContinue
    if (-not $svc -or -not (Test-Path (Join-Path $PY_DIR 'python.exe')) -or -not (Test-Path (Join-Path $PY_DIR 'pymysql\__init__.py'))) { return 'missing' }
    if ($svc.Status -ne 'Running') { return 'stopped' }
    $cfg = Read-Config (Get-ConfigPath $env:USERPROFILE)
    if (-not $cfg -or -not $cfg.token -or [int]$cfg.config_version -lt 2) { return 'unconfigured' }
    return 'ready'
}

# ---------------------------------------------------------------- serviço local (bridge)
function Get-Health([int]$port) {
    try {
        $req = [Net.HttpWebRequest]::Create("http://127.0.0.1:$port/api/health")
        $req.Timeout = 2500; $req.Proxy = $null
        try { $resp = $req.GetResponse() } catch [Net.WebException] { $resp = $_.Exception.Response; if (-not $resp) { return $null } }
        $sr = New-Object IO.StreamReader($resp.GetResponseStream(), $UTF8); $txt = $sr.ReadToEnd(); $sr.Close(); $resp.Close()
        if (-not $txt) { return $null }
        return ($txt | ConvertFrom-Json)
    } catch { return $null }
}
function Start-Bridge([string]$root, [int]$port) {
    $bridge = Join-Path $SCRIPT_DIR 'mysql-bridge.py'
    if (-not (Test-Path $bridge)) { throw "mysql-bridge.py is missing from $SCRIPT_DIR." }
    $rootFull = (Resolve-Path -LiteralPath $root).ProviderPath.TrimEnd('\')
    for ($try = 0; $try -lt 6; $try++) {
        $h = Get-Health $port
        if ($h) {
            if ($h.ok -and $h.version -eq $NB_VERSION -and ([string]$h.root).TrimEnd('\') -ieq $rootFull) { return $port }
            $old = $null
            if ($h.pid) { $old = Get-Process -Id ([int]$h.pid) -ErrorAction SilentlyContinue }
            if ($old -and $old.ProcessName -match '^pythonw?$') { Stop-Process -Id $old.Id -Force; Start-Sleep -Milliseconds 600 }
            else { $port++; continue }   # port used by another program
        } elseif ((Get-ListeningPorts) -contains $port) { $port++; continue }
        if (-not (Test-Path $LOCAL)) { New-Item -ItemType Directory -Force -Path $LOCAL | Out-Null }
        $bridgeArgs = @('-I', ('"' + $bridge + '"'), '--root', ('"' + $rootFull + '"'), '--port', $port, '--pidfile', ('"' + (Join-Path $LOCAL "bridge-$port.pid") + '"'))
        $pyw = Join-Path $PY_DIR 'pythonw.exe'; if (-not (Test-Path $pyw)) { $pyw = Join-Path $PY_DIR 'python.exe' }
        Start-Process -FilePath $pyw -ArgumentList $bridgeArgs `
            -RedirectStandardOutput (Join-Path $LOCAL "bridge-$port.log") -RedirectStandardError (Join-Path $LOCAL "bridge-$port-errors.log") | Out-Null
        for ($i = 0; $i -lt 60; $i++) {
            Start-Sleep -Milliseconds 250
            Invoke-Serve
            $h = Get-Health $port
            if ($h -and $h.ok) { return $port }
        }
        break
    }
    throw "The NeoBasic local service did not start. See $LOCAL\bridge-$port-errors.log"
}

# ---------------------------------------------------------------- downloads (sem administrador, com progresso)
function Get-Download([string[]]$urls, [string]$dest, $ui, [int]$lo, [int]$hi, [string]$label) {
    if ((Test-Path $dest) -and (Test-ZipOk $dest)) { Set-Progress $ui $hi "$label — already downloaded"; return }
    $part = "$dest.part"; $lastErr = ''
    foreach ($u in $urls) {
        try {
            Set-Progress $ui $lo "$label — connecting..."
            $req = [Net.HttpWebRequest]::Create($u)
            $req.UserAgent = "NeoBasic/$NB_VERSION (Windows)"; $req.Timeout = 30000; $req.ReadWriteTimeout = 60000
            $req.AllowAutoRedirect = $true; $req.MaximumAutomaticRedirections = 10
            $resp = $req.GetResponse()
            $total = $resp.ContentLength
            $in = $resp.GetResponseStream(); $out = [IO.File]::Create($part)
            $buf = New-Object byte[] 262144; $done = 0L; $sw = [Diagnostics.Stopwatch]::StartNew()
            try {
                while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
                    $out.Write($buf, 0, $n); $done += $n
                    if ($sw.ElapsedMilliseconds -gt 200) {
                        $sw.Restart()
                        if ($total -gt 0) {
                            $pct = [int](100 * $done / $total)
                            Set-Progress $ui ($lo + [int](($hi - $lo) * $done / $total)) ("{0} — {1:N0} MB of {2:N0} MB ({3}%)" -f $label, ($done / 1MB), ($total / 1MB), $pct)
                        } else { Set-Progress $ui $lo ("{0} — {1:N0} MB" -f $label, ($done / 1MB)) }
                    }
                }
            } finally { $out.Close(); $in.Close(); $resp.Close() }
            if ($total -gt 0 -and $done -ne $total) { throw "incomplete download ($done of $total bytes)" }
            if (-not (Test-ZipOk $part) -and $dest -match '\.zip$') { throw 'the downloaded file is not a valid ZIP' }
            Move-Item -Force $part $dest
            Set-Progress $ui $hi "$label — done"
            return
        } catch { $lastErr = "$u -> $($_.Exception.Message)"; Write-NBLog (Join-Path $LOCAL 'instalacao.log') "download failed: $lastErr"; Remove-Item -Force $part -ErrorAction SilentlyContinue }
    }
    throw "Could not download: $label.`n$lastErr"
}
function Test-ZipOk([string]$path) {
    if ($path -notmatch '\.(zip|part)$' -or -not (Test-Path $path)) { return (Test-Path $path) }
    try { Add-Type -AssemblyName System.IO.Compression.FileSystem; $z = [IO.Compression.ZipFile]::OpenRead($path); $n = $z.Entries.Count; $z.Dispose(); return ($n -gt 0) } catch { return $false }
}
function Get-MySQLUrls {
    $versions = New-Object System.Collections.Generic.List[int]
    try {
        $req = [Net.HttpWebRequest]::Create('https://dev.mysql.com/downloads/mysql/8.4.html')
        $req.UserAgent = "Mozilla/5.0 NeoBasic/$NB_VERSION"; $req.Timeout = 15000
        $resp = $req.GetResponse(); $sr = New-Object IO.StreamReader($resp.GetResponseStream()); $page = $sr.ReadToEnd(); $sr.Close(); $resp.Close()
        foreach ($m in [regex]::Matches($page, 'mysql-8\.4\.(\d+)-winx64\.zip')) { $v = [int]$m.Groups[1].Value; if (-not $versions.Contains($v)) { $versions.Add($v) } }
    } catch { }
    $sorted = @($versions | Sort-Object -Descending)
    foreach ($v in 14, 13, 12, 11, 10, 9, 8) { if ($sorted -notcontains $v) { $sorted += $v } }
    $urls = @()
    foreach ($v in $sorted) {
        $urls += "https://dev.mysql.com/get/Downloads/MySQL-8.4/mysql-8.4.$v-winx64.zip"
        $urls += "https://cdn.mysql.com/archives/mysql-8.4/mysql-8.4.$v-winx64.zip"
    }
    return $urls
}
function Test-VCRedist {
    foreach ($k in 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64') {
        $r = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
        if ($r -and $r.Installed -eq 1 -and ([int]$r.Major -gt 14 -or ([int]$r.Major -eq 14 -and [int]$r.Minor -ge 29))) { return $true }
    }
    return $false
}

# ---------------------------------------------------------------- janelas
function New-NBForm([string]$title, [int]$w, [int]$h) {
    $f = New-Object Windows.Forms.Form
    $f.Text = $title; $f.ClientSize = New-Object Drawing.Size($w, $h)
    $f.StartPosition = 'CenterScreen'; $f.TopMost = $true; $f.ShowInTaskbar = $true
    $f.BackColor = [Drawing.Color]::White; $f.Font = New-Object Drawing.Font('Segoe UI', 10)
    $ico = Join-Path $SCRIPT_DIR 'icone\neobasic.ico'
    if (Test-Path $ico) { try { $f.Icon = New-Object Drawing.Icon($ico) } catch { } }
    return $f
}
function Show-Question([string]$title, [string]$heading, [string]$text, [string]$okText, [string]$cancelText) {
    # custom window: buttons always in English (a MessageBox would show the Windows language)
    $f = New-NBForm $title 540 250
    $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $png = Join-Path $SCRIPT_DIR 'icone\neobasic.png'
    if (Test-Path $png) {
        $pb = New-Object Windows.Forms.PictureBox; $pb.SizeMode = 'Zoom'; $pb.SetBounds(24, 24, 64, 64)
        try { $pb.Image = [Drawing.Image]::FromFile($png) } catch { }
        $f.Controls.Add($pb)
    }
    $h = New-Object Windows.Forms.Label; $h.Text = $heading
    $h.Font = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold); $h.ForeColor = [Drawing.Color]::FromArgb(23, 52, 95)
    $h.SetBounds(104, 22, 412, 28); $f.Controls.Add($h)
    $l = New-Object Windows.Forms.Label; $l.Text = $text; $l.SetBounds(104, 56, 412, 120); $f.Controls.Add($l)
    $ok = New-Object Windows.Forms.Button; $ok.Text = $okText; $ok.SetBounds(270, 196, 136, 34); $ok.DialogResult = 'OK'
    $ok.BackColor = [Drawing.Color]::FromArgb(47, 111, 237); $ok.ForeColor = [Drawing.Color]::White; $ok.FlatStyle = 'Flat'
    $no = New-Object Windows.Forms.Button; $no.Text = $cancelText; $no.SetBounds(414, 196, 102, 34); $no.DialogResult = 'Cancel'; $no.FlatStyle = 'Flat'
    $f.Controls.Add($ok); $f.Controls.Add($no); $f.AcceptButton = $ok; $f.CancelButton = $no
    $f.Add_Shown({ $f.Activate() })
    $r = $f.ShowDialog(); $f.Dispose()
    return ($r -eq [Windows.Forms.DialogResult]::OK)
}
function Show-ProgressWindow([string]$title) {
    $f = New-NBForm $title 580 190
    $f.FormBorderStyle = 'FixedDialog'; $f.ControlBox = $false; $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $h = New-Object Windows.Forms.Label; $h.Text = 'MySQL Server is required to use NeoBasic.'
    $h.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold); $h.ForeColor = [Drawing.Color]::FromArgb(23, 52, 95)
    $h.SetBounds(24, 20, 532, 26); $f.Controls.Add($h)
    $l = New-Object Windows.Forms.Label; $l.Text = 'Preparing...'; $l.SetBounds(24, 58, 532, 44); $f.Controls.Add($l)
    $p = New-Object Windows.Forms.ProgressBar; $p.Style = 'Continuous'; $p.Minimum = 0; $p.Maximum = 100; $p.SetBounds(24, 108, 532, 22); $f.Controls.Add($p)
    $n = New-Object Windows.Forms.Label; $n.Text = '0%'; $n.TextAlign = 'MiddleRight'; $n.ForeColor = [Drawing.Color]::FromArgb(98, 115, 141)
    $n.SetBounds(356, 140, 200, 22); $f.Controls.Add($n)
    $f.Show(); [Windows.Forms.Application]::DoEvents()
    return @{ Form = $f; Label = $l; Bar = $p; Pct = $n }
}
# ---------------------------------------------------------------- setup service for the NeoBasic main window
# The main window (file://…?setup=1) asks http://127.0.0.1:43820/status what is happening and shows it
# inside NeoBasic: /install = "Install MySQL" was clicked, /exit = "Exit" / "Close NeoBasic".
$script:ST = [ordered]@{ stage = 'checking'; title = ''; text = 'Checking MySQL Server…'; pct = 0; error = ''; log = '' }
$script:Listener = $null
$script:Action = ''
$script:LastPoll = Get-Date
function Start-SetupServer([int]$port) {
    $l = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $port)
    $l.Start(); $script:Listener = $l
}
function Stop-SetupServer { if ($script:Listener) { try { $script:Listener.Stop() } catch { } ; $script:Listener = $null } }
function Invoke-Serve {
    if (-not $script:Listener) { return }
    while ($script:Listener.Pending()) {
        $c = $script:Listener.AcceptTcpClient()
        try {
            $c.ReceiveTimeout = 2000; $c.SendTimeout = 2000
            $stream = $c.GetStream()
            $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
            $first = $reader.ReadLine()
            while ($true) { $hl = $reader.ReadLine(); if ($null -eq $hl -or $hl -eq '') { break } }
            $path = ''; if ($first -match '^[A-Z]+\s+(\S+)') { $path = $Matches[1] }
            if ($path -like '/install*' -and $script:ST.stage -eq 'ask') { $script:Action = 'install' }
            elseif ($path -like '/exit*') { $script:Action = 'exit' }
            $script:LastPoll = Get-Date
            $body = $UTF8.GetBytes(($script:ST | ConvertTo-Json -Compress))
            $head = "HTTP/1.1 200 OK`r`nContent-Type: application/json; charset=utf-8`r`nAccess-Control-Allow-Origin: *`r`n" +
                    "Cache-Control: no-store`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
            $hb = [Text.Encoding]::ASCII.GetBytes($head)
            $stream.Write($hb, 0, $hb.Length); $stream.Write($body, 0, $body.Length); $stream.Flush()
        } catch { } finally { $c.Close() }
    }
}
function Set-Stage([string]$stage, [string]$title, [string]$text, [int]$pct) {
    $script:ST.stage = $stage; if ($title) { $script:ST.title = $title }
    if ($null -ne $text) { $script:ST.text = $text }; $script:ST.pct = $pct
    Invoke-Serve
}
function Set-Progress($ui, [int]$pct, [string]$text) {
    # $ui is not used anymore: progress is shown inside the NeoBasic main window
    if ($pct -lt 0) { $pct = 0 }; if ($pct -gt 100) { $pct = 100 }
    $script:ST.pct = $pct
    if ($text) { $script:ST.text = $text }
    Invoke-Serve
}
function Wait-Serve([int]$ms) { $end = (Get-Date).AddMilliseconds($ms); while ((Get-Date) -lt $end) { Invoke-Serve; Start-Sleep -Milliseconds 100 } }
function Show-Error([string]$text, $owner) {
    # without a visible owner, use an invisible always-on-top window so the message is never hidden
    $tmp = $null
    if (-not $owner -or -not $owner.Visible) {
        $tmp = New-Object Windows.Forms.Form
        $tmp.TopMost = $true; $tmp.ShowInTaskbar = $false; $tmp.Opacity = 0; $tmp.StartPosition = 'CenterScreen'
        $tmp.Size = New-Object Drawing.Size(1, 1); $tmp.Show(); $owner = $tmp
    }
    [void][Windows.Forms.MessageBox]::Show($owner, $text, 'NeoBasic', 'OK', 'Error')
    if ($tmp) { $tmp.Close() }
}

# ---------------------------------------------------------------- instalação (lado do usuário)
function Invoke-Setup([string]$state) {
    # returns '' when MySQL is ready, otherwise the error text shown to the user
    $titles = @{ missing = 'Installing MySQL Server'; stopped = 'Starting MySQL Server'; unconfigured = 'Configuring MySQL Server' }
    Set-Stage 'running' $titles[$state] 'Preparing…' 1
    try {
        $dl = Join-Path $LOCAL 'downloads'
        if (-not (Test-Path $dl)) { New-Item -ItemType Directory -Force -Path $dl | Out-Null }
        $job = @{ mode = $state; userProfile = $env:USERPROFILE; status = (Join-Path $LOCAL 'setup-status.txt');
                  scriptDir = $SCRIPT_DIR; vcredist = ''; python = ''; mysql = '' }
        if ($state -eq 'missing') {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            if (-not (Test-VCRedist)) {
                $job.vcredist = Join-Path $dl 'vc_redist.x64.exe'
                Get-Download @('https://aka.ms/vs/17/release/vc_redist.x64.exe') $job.vcredist $null 1 5 'Downloading Microsoft Visual C++ (required by MySQL)'
            }
            if (-not (Test-Path (Join-Path $PY_DIR 'python.exe'))) {
                $job.python = Join-Path $dl 'python-3.12.10-embed-amd64.zip'
                Get-Download @('https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip',
                               'https://www.nuget.org/api/v2/package/python/3.12.10') $job.python $null 5 9 'Downloading the local service component (portable Python)'
            }
            if (-not (Test-Path (Join-Path $MY_BASE 'bin\mysqld.exe'))) {
                $job.mysql = Join-Path $dl 'mysql-8.4-winx64.zip'
                Set-Progress $null 9 'Looking for the latest MySQL 8.4 LTS version…'
                Get-Download (Get-MySQLUrls) $job.mysql $null 10 60 'Downloading MySQL Server 8.4 LTS'
            }
        }
        Write-Utf8 $job.status "60|Waiting for Windows administrator permission…`r`n"
        $jobFile = Join-Path $LOCAL 'setup-job.json'
        Write-Utf8 $jobFile ($job | ConvertTo-Json)
        Set-Progress $null 60 'Waiting for Windows administrator permission (click Yes in the Windows window)…'
        $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        try {
            $proc = Start-Process -FilePath $psExe -Verb RunAs -WindowStyle Hidden -PassThru -ArgumentList @(
                '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $SCRIPT_PATH + '"'), '-Worker', '-Job', ('"' + $jobFile + '"'))
        } catch {
            return 'Administrator permission was not given. NeoBasic requires MySQL Server, so it will close.'
        }
        $last = ''
        while (-not $proc.HasExited) {
            Start-Sleep -Milliseconds 200
            try {
                $lines = [IO.File]::ReadAllLines($job.status, $UTF8)
                if ($lines.Count -gt 0 -and $lines[-1] -ne $last) {
                    $last = $lines[-1]; $parts = $last.Split('|', 2)
                    if ($parts.Count -eq 2 -and $parts[0] -match '^\d+$') { Set-Progress $null ([int]$parts[0]) $parts[1] }
                }
            } catch { }
            Invoke-Serve
        }
        $lines = @(); try { $lines = [IO.File]::ReadAllLines($job.status, $UTF8) } catch { }
        $err = $lines | Where-Object { $_ -like 'ERRO|*' } | Select-Object -Last 1
        $ok = $null -ne ($lines | Where-Object { $_ -eq '100|PRONTO' })
        if ($err) { return $err.Substring(5) }
        if (-not $ok -or (Get-NBState) -ne 'ready') { return 'The MySQL Server installation did not finish.' }
        # installed: the downloaded files (about 280 MB) are no longer needed
        Remove-Item -Recurse -Force (Join-Path $LOCAL 'downloads') -ErrorAction SilentlyContinue
        return ''
    } catch {
        Write-NBLog (Join-Path $LOCAL 'setup.log') ($_ | Out-String)
        return $_.Exception.Message
    }
}

# ---------------------------------------------------------------- instalação (administrador)
function Invoke-Worker([string]$jobFile) {
    $job = [IO.File]::ReadAllText($jobFile, $UTF8).TrimStart([char]0xFEFF) | ConvertFrom-Json
    $log = Join-Path $NB_DATA 'setup.log'
    $status = $job.status
    function St([int]$p, [string]$t) { [IO.File]::AppendAllText($status, "$p|$t`r`n", $UTF8); Write-NBLog $log $t }
    try {
        New-Item -ItemType Directory -Force -Path $NB_DATA, $NB_BASE | Out-Null
        if ($job.mode -eq 'missing') {
            if ($job.vcredist) {
                St 61 'Installing Microsoft Visual C++...'
                $p = Start-Process -FilePath $job.vcredist -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru -NoNewWindow
                if (@(0, 1638, 3010) -notcontains $p.ExitCode) { throw "Microsoft Visual C++ was not installed (code $($p.ExitCode))." }
            }
            if ($job.python) {
                St 64 'Installing the local service component...'
                if (Test-Path $PY_DIR) { Remove-Item -Recurse -Force $PY_DIR }
                Expand-NBZip $job.python $PY_DIR '' $null 0 0
                if (Test-Path (Join-Path $PY_DIR 'tools\python.exe')) {   # NuGet package: Python is inside tools\
                    Get-ChildItem (Join-Path $PY_DIR 'tools') | Move-Item -Destination $PY_DIR -Force
                }
            }
            $wheel = Get-ChildItem (Join-Path $job.scriptDir 'runtime-windows') -Filter 'pymysql-*.whl' -ErrorAction SilentlyContinue | Select-Object -First 1
            if (-not $wheel) { throw 'runtime-windows\pymysql-*.whl is missing from the NeoBasic folder.' }
            Expand-NBZip $wheel.FullName $PY_DIR 'pymysql/' $null 0 0
            if (Test-Path (Join-Path $PY_DIR 'Lib\site-packages')) { Expand-NBZip $wheel.FullName (Join-Path $PY_DIR 'Lib\site-packages') 'pymysql/' $null 0 0 }
            if ($job.mysql) {
                St 66 'Extracting MySQL Server...'
                if (Test-Path $MY_BASE) { Remove-Item -Recurse -Force $MY_BASE }
                Expand-NBZip $job.mysql $MY_BASE '*' $status 66 88
            }
            St 89 'Configuring MySQL Server...'
            if (-not (Test-Path $MY_INI)) {
            $port = 3306
            $busy = Get-ListeningPorts
            while ($busy -contains $port -and $port -lt 3330) { $port++ }   # another MySQL on this computer: use the next port
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $MY_INI) | Out-Null
            $b = $MY_BASE.Replace('\', '/'); $d = $MY_DATA.Replace('\', '/')
            Write-Utf8 $MY_INI ("[mysqld]`r`nbasedir=`"$b`"`r`ndatadir=`"$d`"`r`nport=$port`r`nbind-address=127.0.0.1`r`nmysqlx=OFF`r`n" +
                "character-set-server=utf8mb4`r`ncollation-server=utf8mb4_unicode_ci`r`n[client]`r`nport=$port`r`nhost=127.0.0.1`r`n")
            }
            $mysqld = Join-Path $MY_BASE 'bin\mysqld.exe'
            if (-not (Test-Path (Join-Path $MY_DATA 'mysql'))) {
                St 91 'Creating the MySQL data files...'
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $MY_DATA) | Out-Null
                if (Test-Path $MY_DATA) { Remove-Item -Recurse -Force $MY_DATA }
                $p = Start-Process -FilePath $mysqld -ArgumentList "--defaults-file=`"$MY_INI`"", '--initialize-insecure', '--console' -Wait -PassThru -NoNewWindow `
                     -RedirectStandardError (Join-Path $NB_DATA 'mysql-init.log')
                if ($p.ExitCode -ne 0) { throw "MySQL could not create its data files (see $NB_DATA\mysql-init.log)." }
                Remove-Item -Force $ROOT_PW_FILE -ErrorAction SilentlyContinue
            }
            St 93 'Registering the MySQL Windows service...'
            if (-not (Get-Service -Name $SERVICE -ErrorAction SilentlyContinue)) {
                $p = Start-Process -FilePath $mysqld -ArgumentList '--install', $SERVICE, "--defaults-file=`"$MY_INI`"" -Wait -PassThru -NoNewWindow
                if ($p.ExitCode -ne 0) { throw 'The MySQL Windows service could not be registered.' }
            }
            & sc.exe config $SERVICE start= auto | Out-Null
            & sc.exe description $SERVICE "MySQL Server used by NeoBasic" | Out-Null
        }
        St 95 'Starting the MySQL service...'
        Start-Service -Name $SERVICE
        $port = Get-IniPort
        $mysql = Join-Path $MY_BASE 'bin\mysql.exe'
        $ok = $false
        for ($i = 0; $i -lt 60; $i++) {
            if (Test-PortOpen $port) { $ok = $true; break }
            Start-Sleep -Milliseconds 500
        }
        if (-not $ok) { throw 'MySQL Server did not respond after starting.' }
        if ($job.mode -eq 'stopped' -and (Read-Config (Get-ConfigPath $job.userProfile))) { St 100 'PRONTO'; return 0 }

        St 97 'Creating the NeoBasic user and database...'
        # root password: random, readable by administrators only
        $rootPw = ''
        if (Test-Path $ROOT_PW_FILE) { $rootPw = ([IO.File]::ReadAllText($ROOT_PW_FILE, $UTF8)).Trim() }
        if (-not $rootPw) {
            $rootPw = New-Secret 18
            Invoke-MySQL $mysql $port '' "ALTER USER 'root'@'localhost' IDENTIFIED BY '$rootPw';"
            Write-Utf8 $ROOT_PW_FILE $rootPw
            & icacls.exe $ROOT_PW_FILE /inheritance:r /grant:r '*S-1-5-32-544:F' '*S-1-5-18:F' | Out-Null
        }
        $cfgPath = Get-ConfigPath $job.userProfile
        $cfg = Read-Config $cfgPath
        $appPw = ''; $token = ''
        if ($cfg) { $appPw = [string]$cfg.password; $token = [string]$cfg.token }
        if (-not $appPw) { $appPw = New-Secret 24 }
        if (-not $token) { $token = New-Secret 32 }
        $sql = "CREATE DATABASE IF NOT EXISTS neobasic_runtime CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
        foreach ($hst in 'localhost', '127.0.0.1') {
            $sql += "CREATE USER IF NOT EXISTS 'neobasic_app'@'$hst' IDENTIFIED BY '$appPw';ALTER USER 'neobasic_app'@'$hst' IDENTIFIED BY '$appPw';"
            $sql += "GRANT ALL PRIVILEGES ON neobasic_runtime.* TO 'neobasic_app'@'$hst';GRANT ALL PRIVILEGES ON ``nb\_%``.* TO 'neobasic_app'@'$hst';"
        }
        $sql += 'FLUSH PRIVILEGES;'
        Invoke-MySQL $mysql $port $rootPw $sql
        $conf = [ordered]@{ config_version = 2; host = '127.0.0.1'; port = $port; database = 'neobasic_runtime'; user = 'neobasic_app';
                            password = $appPw; token = $token; ssl = $true }
        Write-Utf8 $cfgPath ($conf | ConvertTo-Json)
        St 100 'PRONTO'
        return 0
    } catch {
        [IO.File]::AppendAllText($status, ('ERRO|' + ($_.Exception.Message -replace '[\r\n]+', ' ') + "`r`n"), $UTF8)
        Write-NBLog $log ($_ | Out-String)
        return 1
    }
}
function Get-IniPort {
    if (Test-Path $MY_INI) { foreach ($l in [IO.File]::ReadAllLines($MY_INI)) { if ($l -match '^\s*port\s*=\s*(\d+)') { return [int]$Matches[1] } } }
    return 3306
}
function Test-PortOpen([int]$port) {
    try { $c = New-Object Net.Sockets.TcpClient; $r = $c.BeginConnect('127.0.0.1', $port, $null, $null); $ok = $r.AsyncWaitHandle.WaitOne(800); if ($ok) { $c.EndConnect($r) }; $c.Close(); return $ok } catch { return $false }
}
function Invoke-MySQL([string]$mysql, [int]$port, [string]$password, [string]$sql) {
    # password in a temporary file (never visible in the process list)
    $tmp = Join-Path $env:TEMP ('nb-' + (New-Secret 6) + '.cnf')
    Write-Utf8 $tmp ("[client]`r`nuser=root`r`npassword=`"$password`"`r`nhost=127.0.0.1`r`nport=$port`r`n")
    try {
        $sqlFile = "$tmp.sql"; Write-Utf8 $sqlFile $sql
        $errFile = "$tmp.err"
        $p = Start-Process -FilePath $mysql -ArgumentList "--defaults-extra-file=`"$tmp`"", '--protocol=TCP', '--connect-expired-password' `
             -Wait -PassThru -NoNewWindow -RedirectStandardInput $sqlFile -RedirectStandardError $errFile
        if ($p.ExitCode -ne 0) { throw ('MySQL error: ' + (Get-Content $errFile -Raw)) }
    } finally { Remove-Item -Force $tmp, "$tmp.sql", "$tmp.err" -ErrorAction SilentlyContinue }
}
function Expand-NBZip([string]$zip, [string]$dest, [string]$only, [string]$status, [int]$lo, [int]$hi) {
    # $only: '' = tudo; 'pymysql/' = só essa pasta; '*' = remove a pasta raiz do ZIP (mysql-8.4.x-winx64/)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($zip)
    try {
        $entries = @($z.Entries); $count = $entries.Count; $i = 0; $lastPct = -1
        foreach ($e in $entries) {
            $i++
            $name = $e.FullName.Replace('\', '/')
            if ($only -eq '*') {
                $slash = $name.IndexOf('/'); if ($slash -lt 0) { continue }
                $name = $name.Substring($slash + 1)
                # arquivos de programador (cabeçalhos, bibliotecas estáticas, símbolos) não são necessários
                if ($name -match '^(include|docs)/' -or $name -match '\.(pdb|lib)$') { continue }
            } elseif ($only -and -not $name.StartsWith($only)) { continue }
            if (-not $name -or $name.EndsWith('/')) { continue }
            $target = Join-Path $dest ($name.Replace('/', '\'))
            $dir = Split-Path -Parent $target
            if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
            if ($status) {
                $pct = $lo + [int](($hi - $lo) * $i / $count)
                if ($pct -ne $lastPct) { $lastPct = $pct; [IO.File]::AppendAllText($status, "$pct|Extracting MySQL Server... ($i of $count files)`r`n", $UTF8) }
            }
        }
    } finally { $z.Dispose() }
}

# ---------------------------------------------------------------- main
function Invoke-Start {
    # fast path: MySQL ready -> local service -> URL for NeoBasic.exe
    if (-not $Html -or -not (Test-Path -LiteralPath $Html)) { Show-Error "File not found: $Html" $null; return 2 }
    $state = Get-NBState
    if ($state -ne 'ready') {
        if ($App -ieq 'NeoBasic') { return 3 }   # NeoBasic.exe opens the main window, then calls -Phase setup
        Show-Error "$App uses MySQL Server, which is not ready on this computer yet.`n`nOpen NeoBasic once and allow it to install MySQL Server, then open $App again." $null
        return 2
    }
    $t = Get-AppTarget $App $Html
    $port = Start-Bridge $t.Root $t.Port
    Write-Utf8 $Out ("http://127.0.0.1:$port/" + $t.Rel + '?app=1')
    return 0
}
function Invoke-SetupPhase {
    # the NeoBasic main window is already open and shows everything this phase reports
    try { Start-SetupServer 43820 } catch { return 2 }   # another NeoBasic setup is already running
    $finish = {
        param([string]$msg)
        $script:ST.stage = 'error'; $script:ST.error = $msg; $script:ST.log = "$NB_DATA\setup.log"
        Write-NBLog (Join-Path $LOCAL 'setup.log') ("error: " + $msg)
        while ($script:Action -ne 'exit' -and ((Get-Date) - $script:LastPoll).TotalSeconds -lt 30) { Wait-Serve 200 }
        return 1
    }
    try {
        $state = Get-NBState
        if ($state -eq 'missing') {
            Set-Stage 'ask' '' '' 0
            while (-not $script:Action) {
                Wait-Serve 150
                if (((Get-Date) - $script:LastPoll).TotalSeconds -gt 120) { return 2 }   # main window closed
            }
            if ($script:Action -eq 'exit') { Wait-Serve 400; return 2 }
        }
        if ($state -ne 'ready') {
            $err = [string](@(Invoke-Setup $state) | Select-Object -Last 1)
            if ($err) { return (& $finish $err) }
        }
        Set-Stage 'starting' 'Starting NeoBasic' 'Connecting to MySQL Server…' 100
        $t = Get-AppTarget $App $Html
        $port = Start-Bridge $t.Root $t.Port
        if ($Out) { Write-Utf8 $Out ("http://127.0.0.1:$port/" + $t.Rel + '?app=1') }
        Set-Stage 'done' '' 'MySQL Server is ready.' 100
        $seen = $script:LastPoll; $end = (Get-Date).AddSeconds(6)
        while ((Get-Date) -lt $end -and $script:LastPoll -eq $seen) { Wait-Serve 150 }   # let the window see "done"
        Wait-Serve 400
        return 0
    } catch {
        return (& $finish $_.Exception.Message)
    } finally { Stop-SetupServer }
}

if ($Library) { return }
if ($Worker) { $rc = Invoke-Worker $Job }
else {
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    try {
        if ($Phase -eq 'setup') { $rc = Invoke-SetupPhase } else { $rc = Invoke-Start }
    } catch {
        Write-NBLog (Join-Path $LOCAL 'setup.log') ($_ | Out-String)
        Show-Error ("NeoBasic could not start MySQL Server.`n`n" + $_.Exception.Message) $null
        $rc = 2
    }
}
exit ([int](@($rc) | Select-Object -Last 1))
