NeoBasic 0.6.13 — MySQL (Linux Mint / Ubuntu e Windows)
=======================================================

LINUX
-----

Arquivos
- NeoBasic.sh ............ lançador (tela inicial, pergunta, abre a IDE)
- mysql-bootstrap.sh ..... verifica o estado do MySQL, mostra a barra de progresso,
                           liga o serviço local
- mysql-install-root.sh .. roda como administrador (pkexec): instala/configura
- mysql-bridge.py ........ serviço local em 127.0.0.1 entre a IDE e o MySQL

Estados verificados ao abrir
- missing ....... MySQL não instalado -> pergunta Sim/Não -> instala
- stopped ....... instalado mas parado -> só liga o serviço (pede senha)
- unconfigured .. falta o usuário/configuração do NeoBasic -> configura (pede senha)
- ready ......... abre direto
- mariadb ....... avisa e não mexe (o MariaDB e seus dados ficam intactos)

Instalação
- Tenta o repositório oficial da Oracle (MySQL 8.4 LTS). Se ele falhar (link
  fora do ar, problema de chave GPG), o repositório é removido para não
  atrapalhar as atualizações do sistema e é instalado o MySQL oficial do
  Ubuntu/Mint (8.0).
- A barra de progresso mostra o andamento real do download e da instalação.
- Um repositório quebrado de outro programa não impede a instalação.

Dados
- Usuário MySQL: neobasic_app (somente localhost), senha aleatória guardada em
  ~/.config/neobasic/mysql.json (permissão 0600). O navegador nunca recebe a senha.
- Catálogo: banco neobasic_runtime, tabela __nb_catalog_v2.
- Cada banco do NeoBasic = um banco MySQL "nb_<projeto>_<banco>", tabelas com os
  nomes reais. Datas e números viram DATETIME/BIGINT/DOUBLE quando os valores
  permitem; senão ficam como texto (nada é perdido).
- Cada gravação troca as tabelas de uma vez (RENAME TABLE): nunca fica pela metade.
- Tabelas criadas direto no MySQL também aparecem no NeoBasic ao reabrir.
- Bancos gravados pela 0.6.12 (tabelas nb_<código>) são convertidos sozinhos na
  primeira abertura.

Serviço local
- IDE: porta fixa 43821 (as opções e o projeto recente não se perdem ao trocar
  de versão ou de pasta). Programas exportados: porta própria.
- Se estiver rodando o serviço de outra versão/pasta, ele é substituído.
- Registro: ~/.local/state/neobasic/bridge.log

WINDOWS
-------
Arquivos
- NeoBasic.exe ............ chama o neobasic-windows.ps1 (sem janela de console) e abre o
                            endereço que ele devolver
- neobasic-windows.ps1 .... tela do NeoBasic, pergunta, downloads com barra de progresso,
                            instalação como administrador (UAC), serviço local
- runtime-windows\pymysql-*.whl .. biblioteca MySQL do serviço local (vai junto no ZIP)
- mysql-bridge.py ......... o mesmo serviço local do Linux

O que é instalado
- Microsoft Visual C++ 2015-2022 (só se faltar; o MySQL precisa dele)
- C:\Program Files\NeoBasic\MySQL\server ..... MySQL Community Server 8.4 LTS (versão mais
  nova encontrada no site da Oracle; se o site mudar, tenta as versões anteriores e o arquivo)
- C:\Program Files\NeoBasic\runtime\python ... Python 3.12 portátil (python.org; reserva: NuGet)
- C:\ProgramData\NeoBasic\MySQL ............... my.ini e dados
- Serviço do Windows "NeoBasicMySQL" (inicia com o Windows), só em 127.0.0.1, porta 3306
  (se já houver outro MySQL no computador, usa 3307, 3308...). Não mexe em outro MySQL.
- Senha do root: aleatória, em C:\ProgramData\NeoBasic\mysql-root.txt (só administradores)
- Usuário neobasic_app: senha aleatória em %USERPROFILE%\.config\neobasic\mysql.json
- Conexão do serviço local com o MySQL por TCP com SSL.

Estados verificados ao abrir: missing (pergunta e instala), stopped (só liga o serviço),
unconfigured (cria o usuário deste usuário do Windows), ready (abre direto).
Programas exportados (Agenda.exe etc.) nunca instalam: só verificam e ligam o serviço.
Os arquivos baixados são apagados depois que a instalação dá certo.
