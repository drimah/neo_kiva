#!/bin/sh
# NeoBasic 0.6.13 — MySQL Server installation/configuration (runs as administrator through pkexec).
# stdout = progress for the NeoBasic window ("NN" and "# text" lines); details go to stderr (log).
#   uso: mysql-install-root.sh <HOME> <USUARIO> <UID> <GID> [--start-only]
set -u
USER_HOME="${1:?HOME do usuário ausente}"
USER_NAME="${2:?Usuário ausente}"
USER_UID="${3:?UID ausente}"
USER_GID="${4:?GID ausente}"
MODE="${5:-}"
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C

step() { echo "$1"; echo "# $2"; echo "[$(date '+%H:%M:%S')] $2" >&2; }
die()  { echo "ERROR: $2" >&2; echo "# Error: $2"; exit "$1"; }

start_service() {
  if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
    systemctl enable mysql >&2 2>&1 || true
    systemctl start mysql >&2 2>&1 || true
  else
    service mysql start >&2 2>&1 || true
  fi
}
wait_ping() {
  n=0
  while [ "$n" -lt 40 ]; do
    mysqladmin --protocol=socket -uroot ping >/dev/null 2>&1 && return 0
    mysqladmin --defaults-file=/etc/mysql/debian.cnf ping >/dev/null 2>&1 && return 0
    sleep 1; n=$((n + 1))
  done
  return 1
}

# ---------- só ligar o serviço (MySQL já instalado, mas parado) ----------
if [ "$MODE" = "--start-only" ]; then
  step 30 "Starting the MySQL service..."
  start_service
  wait_ping || die 13 "MySQL Server is installed but did not start."
  step 100 "MySQL started."
  exit 0
fi

# ---------- sistema suportado ----------
. /etc/os-release
CODENAME="${UBUNTU_CODENAME:-${VERSION_CODENAME:-}}"
case "${ID:-}:${ID_LIKE:-}" in
  *ubuntu*|*debian*|linuxmint:*|pop:*) ;;
  *) die 10 "Automatic installation is not supported on this system: ${ID:-unknown}" ;;
esac

# Instala pacotes mostrando progresso real do apt (download + instalação) entre $1 e $2 %.
apt_progress() {
  LO="$1"; HI="$2"; LABEL="$3"; shift 3
  RCF="$(mktemp)"
  MID=$((LO + (HI - LO) * 2 / 5))   # 40% da faixa para o download, 60% para a instalação
  { apt-get install -y -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
      -o APT::Status-Fd=3 "$@" 3>&1 1>&2; echo $? > "$RCF"; } |
  while IFS=: read -r KIND PKG PCT MSG; do
    P="${PCT%%.*}"; case "$P" in ''|*[!0-9]*) continue ;; esac
    case "$KIND" in
      dlstatus) echo $((LO + (MID - LO) * P / 100)); echo "# $LABEL — downloading ($P%)" ;;
      pmstatus) echo $((MID + (HI - MID) * P / 100)); echo "# $LABEL — installing $PKG ($P%)" ;;
    esac
  done
  RC="$(cat "$RCF" 2>/dev/null || echo 1)"; rm -f "$RCF"
  return "$RC"
}

# MariaDB não é substituído (protege os dados de quem já usa MariaDB).
EXISTING_MYSQL=0
if command -v mysqld >/dev/null 2>&1 || [ -x /usr/sbin/mysqld ]; then
  VERSION="$(/usr/sbin/mysqld --version 2>/dev/null || mysqld --version 2>/dev/null || true)"
  case "$VERSION" in
    *MariaDB*) die 12 "MariaDB was found. NeoBasic requires MySQL and will not remove MariaDB." ;;
    *) EXISTING_MYSQL=1 ;;
  esac
fi

step 3 "Updating the package list..."
# Um repositório quebrado de outro programa não pode impedir a instalação.
apt-get update >&2 2>&1 || echo "warning: apt-get update failed (continuing)" >&2

step 8 "Installing required components..."
apt_progress 8 18 "Components" ca-certificates curl gnupg debconf-utils lsb-release wget \
  python3 python3-pymysql python3-cryptography openssl \
  || die 20 "Could not install the required components (python3-pymysql)."

if [ "$EXISTING_MYSQL" -eq 0 ]; then
  ORACLE_OK=0
  case "$CODENAME" in
    jammy|noble)
      step 20 "Downloading the official MySQL 8.4 LTS repository..."
      TMP_DEB="/tmp/mysql-apt-config-neobasic.deb"
      rm -f "$TMP_DEB"
      if curl -fsSL --retry 3 --retry-delay 2 -o "$TMP_DEB" "https://repo.mysql.com/mysql-apt-config.deb" >&2 2>&1 \
         || curl -fsSL --retry 2 -o "$TMP_DEB" "https://dev.mysql.com/get/mysql-apt-config_0.8.36-1_all.deb" >&2 2>&1; then
        {
          echo "mysql-apt-config mysql-apt-config/repo-distro select ubuntu"
          echo "mysql-apt-config mysql-apt-config/repo-codename select $CODENAME"
          echo "mysql-apt-config mysql-apt-config/select-server select mysql-8.4-lts"
          echo "mysql-apt-config mysql-apt-config/select-tools select Enabled"
          echo "mysql-apt-config mysql-apt-config/select-product select Ok"
        } | debconf-set-selections
        if dpkg -i "$TMP_DEB" >&2 2>&1 && apt-get update >&2 2>&1 \
           && apt-cache policy mysql-community-server 2>/dev/null | grep -q 'Candidate: [0-9]'; then
          ORACLE_OK=1
        else
          # Repositório da Oracle com problema (ex.: chave GPG): remove para não estragar o apt do sistema.
          echo "warning: Oracle MySQL repository unavailable; using the Ubuntu MySQL package" >&2
          dpkg --purge mysql-apt-config >&2 2>&1 || true
          rm -f /etc/apt/sources.list.d/mysql.list
          apt-get update >&2 2>&1 || true
        fi
      fi
      rm -f "$TMP_DEB"
      ;;
  esac
  # Senha de root vazia = acesso só pelo administrador do sistema (auth_socket).
  {
    echo "mysql-community-server mysql-community-server/root-pass password "
    echo "mysql-community-server mysql-community-server/re-root-pass password "
    echo "mysql-community-server mysql-server/default-auth-override select Use Strong Password Encryption (RECOMMENDED)"
  } | debconf-set-selections 2>/dev/null || true
  if [ "$ORACLE_OK" -eq 1 ]; then LABEL="MySQL 8.4 LTS"; else LABEL="MySQL Server"; fi
  step 25 "Downloading and installing $LABEL..."
  apt_progress 25 88 "$LABEL" mysql-server mysql-client || die 21 "The mysql-server package installation failed."
else
  step 60 "MySQL is already installed — keeping the current version and data."
fi

step 90 "Starting the MySQL service and enabling it at boot..."
start_service
wait_ping || die 13 "MySQL Server did not respond after installation."

step 94 "Creating the NeoBasic user and databases..."
ROOTSQL=""
if mysql --protocol=socket -uroot -e "SELECT 1" >/dev/null 2>&1; then
  ROOTSQL="mysql --protocol=socket -uroot"
elif [ -r /etc/mysql/debian.cnf ] && mysql --defaults-file=/etc/mysql/debian.cnf -e "SELECT 1" >/dev/null 2>&1; then
  ROOTSQL="mysql --defaults-file=/etc/mysql/debian.cnf"
else
  die 15 "MySQL already has a root password, so the NeoBasic user could not be created automatically."
fi

CONFIG_DIR="$USER_HOME/.config/neobasic"
CONFIG="$CONFIG_DIR/mysql.json"
mkdir -p "$CONFIG_DIR"
APP_PASSWORD=""; API_TOKEN=""
if [ -s "$CONFIG" ]; then
  APP_PASSWORD="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("password",""))' "$CONFIG" 2>/dev/null || true)"
  API_TOKEN="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("token",""))' "$CONFIG" 2>/dev/null || true)"
fi
[ -n "$APP_PASSWORD" ] || APP_PASSWORD="$(openssl rand -hex 24)"
[ -n "$API_TOKEN" ] || API_TOKEN="$(openssl rand -hex 32)"

# Senha em hexadecimal: sem caracteres que alterem o SQL.
# neobasic_runtime = catálogo; cada banco do NeoBasic vira um banco MySQL próprio "nb_<projeto>_<banco>".
$ROOTSQL >&2 2>&1 <<SQL || die 16 "Could not create the NeoBasic user in MySQL."
CREATE DATABASE IF NOT EXISTS neobasic_runtime CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'neobasic_app'@'localhost' IDENTIFIED BY '$APP_PASSWORD';
ALTER USER 'neobasic_app'@'localhost' IDENTIFIED BY '$APP_PASSWORD';
GRANT ALL PRIVILEGES ON neobasic_runtime.* TO 'neobasic_app'@'localhost';
GRANT ALL PRIVILEGES ON \`nb\\_%\`.* TO 'neobasic_app'@'localhost';
FLUSH PRIVILEGES;
SQL

python3 - "$CONFIG" "$APP_PASSWORD" "$API_TOKEN" <<'PY' || die 17 "Could not save the NeoBasic configuration."
import json, os, sys, tempfile
path, password, token = sys.argv[1:]
sock = "/var/run/mysqld/mysqld.sock"
for s in ("/var/run/mysqld/mysqld.sock", "/run/mysqld/mysqld.sock", "/tmp/mysql.sock"):
    if os.path.exists(s): sock = s; break
data = {"config_version": 2, "host": "127.0.0.1", "port": 3306, "database": "neobasic_runtime",
        "user": "neobasic_app", "password": password, "token": token, "socket": sock}
fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".mysql-", text=True)
with os.fdopen(fd, "w") as f:
    json.dump(data, f); f.write("\n")
os.chmod(tmp, 0o600)
os.replace(tmp, path)
PY
chown -R "$USER_UID:$USER_GID" "$CONFIG_DIR"
chmod 700 "$CONFIG_DIR"; chmod 600 "$CONFIG"
step 100 "MySQL is ready for NeoBasic."
exit 0
