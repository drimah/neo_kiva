// round-trip exato (byte a byte, normalizando só CRLF)
const F = require('../src/vbfiles.js'); const fs = require('fs'), path = require('path');
const root = '/mnt/user-data/uploads/VB/SAMPLES/PGUIDE'; let ok = 0, bad = 0;
for (const dir of fs.readdirSync(root)) for (const f of fs.readdirSync(path.join(root, dir))) {
  if (!/\.frm$/i.test(f)) continue;
  const txt = F.decode1252(fs.readFileSync(path.join(root, dir, f)));
  const back = F.serializeFrm(F.parseFrm(txt, f));
  const a = txt.replace(/\r/g, '').split('\n').map(l => l.replace(/\s+$/, '')), b = back.replace(/\r/g, '').split('\n').map(l => l.replace(/\s+$/, ''));
  while (a.length && a[a.length - 1] === '') a.pop(); while (b.length && b[b.length - 1] === '') b.pop();
  const i = a.findIndex((l, k) => l !== b[k]);
  if (i < 0 && a.length === b.length) ok++; else { bad++; console.log(f, i, JSON.stringify(a[i]), JSON.stringify(b[i])); }
}
console.log('exatos', ok, 'diferentes', bad);
