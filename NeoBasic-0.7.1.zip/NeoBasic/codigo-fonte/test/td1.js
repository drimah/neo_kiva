const D = require('../src/delphi.js');
const fs = require('fs');
const base = '/mnt/user-data/uploads/Program Files (x86)--Embarcadero/Studio/37.0/ObjRepos/en/DelphiWin32/';
const rep = { warns: [], data: [], warn(m){this.warns.push(m)}, data(m){this.data.push(m)} };
const R = { warns: [], datas: [], warn(m){this.warns.push(m)}, data(m){this.datas.push(m)} };
for (const f of process.argv.slice(2)) {
  const root = D.parseDfm(new Uint8Array(fs.readFileSync(base + f)));
  const fc = new D.FormConv(root, f, R);
  const txt = fc.convert();
  console.log(txt.slice(0, 2500));
  console.log('init:', fc.init, 'events:', fc.events.map(e => [e.ctl, e.vclEvent, e.handler || (e.action && e.action.name)]));
}
console.log(R.warns, R.datas);
