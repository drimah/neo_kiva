const F = require('../src/vbfiles.js'); const P = require('../src/vbparse.js');
const fs = require('fs'), path = require('path');
const root = '/mnt/user-data/uploads/VB/SAMPLES/PGUIDE';
let ok = 0, bad = 0, rtDiff = 0;
for (const dir of fs.readdirSync(root)) for (const f of fs.readdirSync(path.join(root, dir))) {
  const ext = f.split('.').pop().toLowerCase(); if (!['frm', 'bas', 'cls'].includes(ext)) continue;
  const fp = path.join(root, dir, f); const txt = F.decodeText(fs.readFileSync(fp));
  const m = ext === 'frm' ? F.parseFrm(txt, f) : ext === 'bas' ? F.parseBas(txt, f) : F.parseCls(txt, f);
  try { P.parseModuleSource(m.code, m.name); ok++; } catch (e) { bad++; console.log('SINTAXE', dir + '/' + f, 'linha', e.line, e.message, '|', (m.code.split(/\r?\n/)[e.line - 1] || '').trim()); }
  if (ext === 'frm') {
    const back = F.serializeFrm(m);
    const norm = s => s.replace(/\r/g, '').split('\n').map(l => l.trim().replace(/\s+/g, ' ')).filter(Boolean);
    const a = norm(txt), b = norm(back);
    const diffs = a.filter((l, i) => l !== b[i]);
    if (a.length !== b.length || diffs.length) { rtDiff++; const i = a.findIndex((l, i) => l !== b[i]); console.log('ROUNDTRIP', f, a.length, b.length, '\n  ', a[i], '\n  ', b[i]); }
  }
}
console.log('ok', ok, 'erros', bad, 'roundtrip diffs', rtDiff);
