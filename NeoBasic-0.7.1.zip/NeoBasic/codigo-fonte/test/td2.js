// converte uma pasta Delphi e valida os arquivos VB gerados com o parser do NeoBasic
const fs = require('fs'), path = require('path');
global.DelphiImport = require('../src/delphi.js');
const DC = require('../src/delphiconv.js');
const { parseFrm, parseBas, parseCls, parseVbp } = require('../src/vbfiles.js');
const { parseModuleSource } = require('../src/vbparse.js');
const dir = process.argv[2]; const outDir = process.argv[3];
const files = [];
const walk = (d, pre) => { for (const n of fs.readdirSync(d)) { const p = path.join(d, n); if (fs.statSync(p).isDirectory()) walk(p, pre + n + '/'); else if (/\.(dpr|pas|dfm|dproj)$/i.test(n)) files.push({ path: pre + n, bytes: new Uint8Array(fs.readFileSync(p)) }); } };
walk(dir, '');
const res = DC.convertProject(files);
if (outDir) { fs.mkdirSync(outDir, { recursive: true }); for (const f of res.files) fs.writeFileSync(path.join(outDir, f.path), f.bytes || f.text); }
let errs = 0;
for (const f of res.files) {
  try {
    let code = null;
    if (/\.frm$/.test(f.path)) { const fr = parseFrm(f.text, f.path); code = fr.code; }
    else if (/\.bas$/.test(f.path)) code = parseBas(f.text, f.path).code;
    else if (/\.cls$/.test(f.path)) code = parseCls(f.text, f.path).code;
    else if (/\.vbp$/.test(f.path)) parseVbp(f.text, f.path);
    if (code != null) parseModuleSource(code, f.path);
  } catch (e) { errs++; console.log('ERRO', f.path, e.message, e.line); if (e.line) { const lines = (/\.frm$/.test(f.path) ? parseFrm(f.text).code : f.text).split(/\r?\n/); console.log('   >', lines.slice(Math.max(0, e.line - 3), e.line + 1).join('\n   > ')); } }
}
console.log(res.reportText);
console.log('files:', res.files.map(f => f.path).join(', '), 'errors:', errs);
