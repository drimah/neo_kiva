const D = require('../src/delphi.js');
const ss = s => [s.length, ...Buffer.from(s, 'latin1')];
const bytes = [...Buffer.from('TPF0'), ...ss('TForm1'), ...ss('Form1'),
  ...ss('Caption'), 6, ...ss('Teste binario'), ...ss('ClientWidth'), 3, 0x2c, 0x01, ...ss('Font.Style'), 11, ...ss('fsBold'), 0,
  0,
  ...ss('TButton'), ...ss('Button1'), ...ss('Caption'), 6, ...ss('OK'), ...ss('Left'), 2, 10, ...ss('OnClick'), 7, ...ss('Button1Click'), ...ss('Default'), 9, 0, 0,
  0];
const root = D.parseDfm(new Uint8Array(bytes));
console.log(root.cls, root.name, [...root.props.values()].map(p => p.key + '=' + JSON.stringify(p.v.v)).join(' '), root.children.map(c => c.name + ':' + [...c.props.values()].map(p => p.key + '=' + JSON.stringify(p.v.v)).join(',')));
