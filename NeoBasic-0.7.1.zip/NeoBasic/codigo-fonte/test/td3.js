// converte todos os .dpr de uma árvore e conta erros
const fs = require('fs'), path = require('path');
global.DelphiImport = require('../src/delphi.js');
const DC = require('../src/delphiconv.js');
const { parseFrm, parseBas, parseCls, parseVbp } = require('../src/vbfiles.js');
const { parseModuleSource } = require('../src/vbparse.js');
const root = process.argv[2]; const verbose = process.argv[3] === '-v';
const dprs = []; const walk = d => { for (const n of fs.readdirSync(d)) { const p = path.join(d, n); if (fs.statSync(p).isDirectory()) walk(p); else if (/\.dpr$/i.test(n)) dprs.push(p); } }; walk(root);
let tot = { proj: 0, crash: 0, files: 0, perr: 0, todo: 0, lines: 0 };
const errKinds = {};
for (const dp of dprs) {
  const dir = path.dirname(dp); const files = [];
  const w2 = (d, pre, depth) => { for (const n of fs.readdirSync(d)) { const p = path.join(d, n); if (fs.statSync(p).isDirectory()) { if (depth < 2) w2(p, pre + n + '/', depth + 1); } else if (/\.(dpr|pas|dfm)$/i.test(n) && (!/\.dpr$/i.test(n) || p === dp)) files.push({ path: pre + n, bytes: new Uint8Array(fs.readFileSync(p)) }); } };
  w2(dir, '', 0);
  tot.proj++;
  let res;
  try { res = DC.convertProject(files); } catch (e) { tot.crash++; console.log('CRASH', dp, e.stack.split('\n').slice(0, 3).join(' | ')); continue; }
  tot.todo += res.report.todo; tot.lines += res.report.lines;
  for (const f of res.files) {
    tot.files++;
    try {
      let code = null;
      if (/\.frm$/.test(f.path)) code = parseFrm(f.text, f.path).code; else if (/\.bas$/.test(f.path)) code = parseBas(f.text, f.path).code; else if (/\.cls$/.test(f.path)) code = parseCls(f.text, f.path).code;
      if (code != null) parseModuleSource(code, f.path);
    } catch (e) {
      tot.perr++; const k = e.message.replace(/'[^']*'/g, "'x'").slice(0, 60); errKinds[k] = (errKinds[k] || 0) + 1;
      if (verbose) { const code = /\.frm$/.test(f.path) ? parseFrm(f.text).code : f.text; const lines = code.split(/\r?\n/); console.log('ERR', path.basename(dp), f.path, e.message, '\n   > ' + lines.slice(Math.max(0, (e.line || 1) - 2), (e.line || 1) + 1).join('\n   > ')); }
    }
  }
  const pw = res.report.warns.filter(w => /could not be read/.test(w)); if (pw.length) { tot.pasfail = (tot.pasfail || 0) + pw.length; if (verbose) console.log('PASFAIL', pw.join('\n')); }
}
console.log(tot); console.log(errKinds);
