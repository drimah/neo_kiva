const { VBRuntime } = require('../src/vbexec.js');
const out = [];
const host = { debugPrint: s => out.push(s.replace(/\r\n$/, '')), msgBox: async (p) => { out.push('MSG:' + p); return 1; } };
const src = `
Option Explicit
Type Ponto
  X As Long
  Y As Long
End Type
Enum Cor
  Vermelho = 1
  Verde
End Enum
Public Contador As Integer
Function Fat(ByVal n As Long) As Double
  If n <= 1 Then Fat = 1 Else Fat = n * Fat(n - 1)
End Function
Sub Dobra(x As Integer)
  x = x * 2
End Sub
Sub Main()
  Dim i As Integer, s As String, a(1 To 5) As Integer, d() As String
  For i = 1 To 5: a(i) = i * i: Next
  Debug.Print a(3), Fat(10)
  s = "Olá"
  s = s & " mundo"
  Debug.Print UCase$(s); Len(s)
  Dim k As Integer: k = 21: Dobra k: Debug.Print "k="; k
  Dim p As Ponto: p.X = 3: p.Y = 4: Debug.Print Sqr(p.X ^ 2 + p.Y ^ 2)
  ReDim d(2): d(0) = "a": d(1) = "b": d(2) = "c"
  ReDim Preserve d(3): d(3) = "d"
  Debug.Print Join(d, "-"), UBound(d)
  Dim c As New Collection
  c.Add "um", "k1": c.Add "dois"
  Dim it
  For Each it In c: Debug.Print it: Next
  Debug.Print c("k1"), c.Count
  Select Case Fat(4)
    Case 1 To 10: Debug.Print "baixo"
    Case Is > 10: Debug.Print "alto"
  End Select
  Debug.Print Format(1234.5, "#,##0.00"), Format(0.256, "0.0%"), Format(#12/25/2026#, "dd/mm/yyyy")
  Debug.Print Verde, 7 \ 2, 7 Mod 3, 2 ^ 10, -7 \ 2
  Do While Contador < 3
    Contador = Contador + 1
  Loop
  Debug.Print "cont"; Contador
  On Error GoTo erro
  i = 1 / 0
  Debug.Print "nao"
  Exit Sub
erro:
  Debug.Print "Erro"; Err.Number; Err.Description
  Resume fim
fim:
  Debug.Print Split("a,b,c", ",")(1); InStr("abcdef", "cd"); Mid("abcdef", 2, 3); Replace("aXbXc", "X", "-")
  Debug.Print IIf(3 > 2, "sim", "nao"), Val("12abc"), CInt(2.5), CInt(3.5), Str(5), CStr(1.5)
  Dim dic: Set dic = CreateObject("Scripting.Dictionary")
  dic.Add "a", 1: dic("b") = 2
  Debug.Print dic.Count, dic("b"), dic.Exists("a")
  MsgBox "fim"
End Sub
`;
(async () => {
  const rt = new VBRuntime(host);
  rt.load({ name: 'T', startup: 'Sub Main', modules: [{ name: 'Module1', kind: 'std', source: src }] });
  host.onError = e => out.push('ERRO: ' + e.number + ' ' + e.message + ' linha ' + e.line + (e.internal ? '\n' + e.internal.stack : ''));
  await rt.run();
  console.log(out.join('\n'));
})();
