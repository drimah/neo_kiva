// NeoBasic.exe 0.6.13 — prepares MySQL (neobasic-windows.ps1) and opens NeoBasic in its own window (modo aplicativo do Edge/Chrome/Brave),
// sem barra de endereço nem menus do navegador. Cria também o atalho no Menu Iniciar.
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define COBJMACROS
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <objbase.h>
#include <wchar.h>
#include <stdio.h>
#include <propsys.h>
#include <propidl.h>

// ---------- taskbar identity: NeoBasic icon instead of the Chrome icon ----------
// System.AppUserModel.* property keys
static const PROPERTYKEY NB_PKEY_AppUserModel_ID                  = { { 0x9F4C2855, 0x9F79, 0x4B39, { 0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3 } }, 5 };
static const PROPERTYKEY NB_PKEY_AppUserModel_RelaunchCommand     = { { 0x9F4C2855, 0x9F79, 0x4B39, { 0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3 } }, 2 };
static const PROPERTYKEY NB_PKEY_AppUserModel_RelaunchIconResource = { { 0x9F4C2855, 0x9F79, 0x4B39, { 0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3 } }, 3 };
static const PROPERTYKEY NB_PKEY_AppUserModel_RelaunchDisplayName = { { 0x9F4C2855, 0x9F79, 0x4B39, { 0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3 } }, 4 };
static const IID NB_IID_IPropertyStore = { 0x886D8EEB, 0x8CF2, 0x4446, { 0x8D, 0x02, 0xCD, 0xBA, 0x1D, 0xBD, 0xCF, 0x99 } };
typedef HRESULT (WINAPI *PFN_SHGetPropertyStoreForWindow)(HWND, REFIID, void **);

static void store_set_string(IPropertyStore *ps, const PROPERTYKEY *key, const wchar_t *value) {
    PROPVARIANT pv; PropVariantInit(&pv);
    size_t n = (wcslen(value) + 1) * sizeof(wchar_t);
    pv.vt = VT_LPWSTR; pv.pwszVal = (LPWSTR)CoTaskMemAlloc(n);
    if (!pv.pwszVal) return;
    memcpy(pv.pwszVal, value, n);
    IPropertyStore_SetValue(ps, key, &pv);
    PropVariantClear(&pv);
}

static wchar_t g_appid[200], g_relaunch[MAX_PATH * 2 + 8], g_iconres[MAX_PATH + 8], g_appname[MAX_PATH];
static HICON g_icon_big, g_icon_small;
static DWORD g_browser_pid;
static wchar_t g_browser_exe[64];
#define NB_MAX_WINDOWS 16
static HWND g_stamped[NB_MAX_WINDOWS]; static int g_nstamped;

static int window_is_ours(HWND w) {
    if (!IsWindowVisible(w) || GetWindow(w, GW_OWNER)) return 0;
    wchar_t cls[64]; if (!GetClassNameW(w, cls, 64) || wcscmp(cls, L"Chrome_WidgetWin_1") != 0) return 0;
    DWORD pid = 0; GetWindowThreadProcessId(w, &pid);
    if (pid && pid == g_browser_pid) return 1;
    // browser already running with this profile: the window belongs to that process — match by title
    wchar_t title[256]; if (!GetWindowTextW(w, title, 256) || !wcsstr(title, g_appname)) return 0;
    HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid); if (!h) return 0;
    wchar_t img[MAX_PATH]; DWORD sz = MAX_PATH; int ok = 0;
    if (QueryFullProcessImageNameW(h, 0, img, &sz)) { const wchar_t *b = wcsrchr(img, L'\\'); ok = _wcsicmp(b ? b + 1 : img, g_browser_exe) == 0; }
    CloseHandle(h);
    return ok;
}

static void stamp_window(HWND w) {
    // Chrome replaces the icon when the page loads, so the icon is applied again on every pass
    if (g_icon_big && !SendMessageTimeoutW(w, WM_SETICON, ICON_BIG, (LPARAM)g_icon_big, SMTO_ABORTIFHUNG, 500, NULL))
        PostMessageW(w, WM_SETICON, ICON_BIG, (LPARAM)g_icon_big);
    if (g_icon_small && !SendMessageTimeoutW(w, WM_SETICON, ICON_SMALL, (LPARAM)g_icon_small, SMTO_ABORTIFHUNG, 500, NULL))
        PostMessageW(w, WM_SETICON, ICON_SMALL, (LPARAM)g_icon_small);
    for (int i = 0; i < g_nstamped; i++) if (g_stamped[i] == w) return;
    if (g_nstamped < NB_MAX_WINDOWS) g_stamped[g_nstamped++] = w;
    static PFN_SHGetPropertyStoreForWindow getStore;
    if (!getStore) { HMODULE sh = GetModuleHandleW(L"shell32.dll"); if (sh) getStore = (PFN_SHGetPropertyStoreForWindow)(void *)GetProcAddress(sh, "SHGetPropertyStoreForWindow"); }
    IPropertyStore *ps = NULL;
    if (getStore && SUCCEEDED(getStore(w, &NB_IID_IPropertyStore, (void **)&ps)) && ps) {
        store_set_string(ps, &NB_PKEY_AppUserModel_ID, g_appid);
        store_set_string(ps, &NB_PKEY_AppUserModel_RelaunchCommand, g_relaunch);
        store_set_string(ps, &NB_PKEY_AppUserModel_RelaunchIconResource, g_iconres);
        store_set_string(ps, &NB_PKEY_AppUserModel_RelaunchDisplayName, g_appname);
        IPropertyStore_Commit(ps);
        IPropertyStore_Release(ps);
        // the taskbar regroups the button under the new identity (NeoBasic icon) after hide/show
        WINDOWPLACEMENT wp; wp.length = sizeof(wp); GetWindowPlacement(w, &wp);
        ShowWindow(w, SW_HIDE);
        ShowWindow(w, wp.showCmd == SW_SHOWMAXIMIZED ? SW_SHOWMAXIMIZED : SW_SHOWNORMAL);
    }
}
static BOOL CALLBACK stamp_enum(HWND w, LPARAM found) { if (window_is_ours(w)) { stamp_window(w); (*(int *)found)++; } return TRUE; }
// waits up to wait_ms for the window, then keeps stamping for keep_ms
static int stamp_loop(DWORD wait_ms, DWORD keep_ms) {
    DWORD t0 = GetTickCount(); int seen = 0;
    for (;;) {
        int found = 0; EnumWindows(stamp_enum, (LPARAM)&found);
        if (found && !seen) { seen = 1; t0 = GetTickCount(); }
        DWORD el = GetTickCount() - t0;
        if (!seen && el > wait_ms) return 0;
        if (seen && el > keep_ms) return 1;
        Sleep(seen ? 400 : 150);
    }
}
static BOOL CALLBACK close_enum(HWND w, LPARAM lp) { (void)lp; if (window_is_ours(w)) PostMessageW(w, WM_CLOSE, 0, 0); return TRUE; }

static int file_exists(const wchar_t *p) { DWORD a = GetFileAttributesW(p); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }

static int app_path_from_registry(const wchar_t *exe, wchar_t *out, DWORD cap) {
    wchar_t key[300];
    swprintf(key, 300, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\%ls", exe);
    HKEY roots[2] = { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE };
    for (int i = 0; i < 2; i++) {
        DWORD sz = cap * sizeof(wchar_t);
        if (RegGetValueW(roots[i], key, NULL, RRF_RT_REG_SZ, NULL, out, &sz) == ERROR_SUCCESS && file_exists(out)) return 1;
    }
    return 0;
}

// navegadores conhecidos: nome, exe no registro, caminhos comuns
typedef struct { const wchar_t *name; const wchar_t *exe; const wchar_t *paths[3]; } BrowserDef;
static const BrowserDef BROWSERS[] = {
    { L"chrome",   L"chrome.exe",  { L"%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe", L"%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe", L"%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe" } },
    { L"brave",    L"brave.exe",   { L"%ProgramFiles%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe", L"%ProgramFiles(x86)%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe", L"%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe" } },
    { L"vivaldi",  L"vivaldi.exe", { L"%LOCALAPPDATA%\\Vivaldi\\Application\\vivaldi.exe", L"%ProgramFiles%\\Vivaldi\\Application\\vivaldi.exe", NULL } },
    { L"chromium", NULL,           { L"%LOCALAPPDATA%\\Chromium\\Application\\chrome.exe", L"%ProgramFiles%\\Chromium\\Application\\chrome.exe", NULL } },
    { L"opera",    L"opera.exe",   { L"%LOCALAPPDATA%\\Programs\\Opera\\opera.exe", L"%ProgramFiles%\\Opera\\opera.exe", NULL } },
    { L"edge",     L"msedge.exe",  { L"%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe", L"%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe", NULL } },
};
#define NBROWSERS ((int)(sizeof(BROWSERS) / sizeof(BROWSERS[0])))

static int find_one(const BrowserDef *b, wchar_t *out, DWORD cap) {
    if (b->exe && app_path_from_registry(b->exe, out, cap)) return 1;
    for (int i = 0; i < 3 && b->paths[i]; i++) if (ExpandEnvironmentStringsW(b->paths[i], out, cap) && file_exists(out)) return 1;
    return 0;
}

// navegador.txt (ao lado do NeoBasic.exe): chrome, brave, vivaldi, chromium, opera, edge ou o caminho completo de um .exe
static int read_choice(const wchar_t *dir, wchar_t *choice, int cap) {
    wchar_t path[MAX_PATH]; swprintf(path, MAX_PATH, L"%ls\\navegador.txt", dir);
    FILE *f = _wfopen(path, L"rb"); if (!f) return 0;
    char buf[1024] = { 0 }; size_t n = fread(buf, 1, sizeof(buf) - 1, f); fclose(f); buf[n] = 0;
    char *p = buf; if ((unsigned char)p[0] == 0xEF && (unsigned char)p[1] == 0xBB && (unsigned char)p[2] == 0xBF) p += 3;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' || *p == '"') p++;
    char *e = p; while (*e && *e != '\r' && *e != '\n') e++;
    while (e > p && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '"')) e--;
    *e = 0; if (!*p) return 0;
    MultiByteToWideChar(CP_UTF8, 0, p, -1, choice, cap);
    return 1;
}

static int find_browser(const wchar_t *dir, wchar_t *out, DWORD cap) {
    wchar_t choice[512];
    if (read_choice(dir, choice, 512)) {
        if (wcschr(choice, L'\\') || wcschr(choice, L'/')) { ExpandEnvironmentStringsW(choice, out, cap); if (file_exists(out)) return 1; }
        for (int i = 0; i < NBROWSERS; i++) if (_wcsicmp(choice, BROWSERS[i].name) == 0 && find_one(&BROWSERS[i], out, cap)) return 1;
    }
    // sem escolha (ou não encontrado): Chrome, Brave, Vivaldi, Chromium, Opera e, por último, Edge
    for (int i = 0; i < NBROWSERS; i++) if (find_one(&BROWSERS[i], out, cap)) return 1;
    return 0;
}

// caminho do Windows -> file:///C:/... (UTF-8 com %XX), aceita acentos como em "MAÍRA"
static void path_to_url(const wchar_t *path, char *url, int cap) {
    char utf8[4096];
    WideCharToMultiByte(CP_UTF8, 0, path, -1, utf8, sizeof(utf8), NULL, NULL);
    int n = snprintf(url, cap, "file:///");
    for (unsigned char *p = (unsigned char *)utf8; *p && n < cap - 4; p++) {
        unsigned char c = *p;
        if (c == '\\') c = '/';
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || strchr("-._~/:", c)) url[n++] = (char)c;
        else n += snprintf(url + n, cap - n, "%%%02X", c);
    }
    url[n] = 0;
}

static void ensure_shortcut(const wchar_t *exePath, const wchar_t *workDir, const wchar_t *appname, const wchar_t *args) {
    wchar_t lnk[MAX_PATH];
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_PROGRAMS, NULL, 0, lnk))) return;
    wcscat(lnk, L"\\"); wcscat(lnk, appname); wcscat(lnk, L".lnk");
    if (file_exists(lnk)) {
        // atualiza se o programa mudou de pasta
        IShellLinkW *sl0 = NULL;
        if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl0))) {
            IPersistFile *pf0 = NULL; wchar_t cur[MAX_PATH] = L"";
            if (SUCCEEDED(IShellLinkW_QueryInterface(sl0, &IID_IPersistFile, (void **)&pf0))) {
                if (SUCCEEDED(IPersistFile_Load(pf0, lnk, STGM_READ))) IShellLinkW_GetPath(sl0, cur, MAX_PATH, NULL, 0);
                IPersistFile_Release(pf0);
            }
            IShellLinkW_Release(sl0);
            wchar_t curArgs[MAX_PATH * 2] = L"";
            { IShellLinkW *sl1 = NULL; if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl1))) { IPersistFile *pf1 = NULL; if (SUCCEEDED(IShellLinkW_QueryInterface(sl1, &IID_IPersistFile, (void **)&pf1))) { if (SUCCEEDED(IPersistFile_Load(pf1, lnk, STGM_READ))) IShellLinkW_GetArguments(sl1, curArgs, MAX_PATH * 2); IPersistFile_Release(pf1); } IShellLinkW_Release(sl1); } }
            (void)cur; (void)curArgs;   /* 0.6.13: always rewritten so old shortcuts get the AppUserModelID */
        }
    }
    IShellLinkW *sl = NULL;
    if (FAILED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl))) return;
    IShellLinkW_SetPath(sl, exePath);
    if (args && *args) IShellLinkW_SetArguments(sl, args);
    IShellLinkW_SetWorkingDirectory(sl, workDir);
    IShellLinkW_SetDescription(sl, appname);
    IShellLinkW_SetIconLocation(sl, exePath, 0);
    { IPropertyStore *ps = NULL;   // same AppUserModelID as the window: pinning and the taskbar icon use NeoBasic
      if (g_appid[0] && SUCCEEDED(IShellLinkW_QueryInterface(sl, &NB_IID_IPropertyStore, (void **)&ps)) && ps) {
          store_set_string(ps, &NB_PKEY_AppUserModel_ID, g_appid); IPropertyStore_Commit(ps); IPropertyStore_Release(ps); } }
    IPersistFile *pf = NULL;
    if (SUCCEEDED(IShellLinkW_QueryInterface(sl, &IID_IPersistFile, (void **)&pf))) { IPersistFile_Save(pf, lnk, TRUE); IPersistFile_Release(pf); }
    IShellLinkW_Release(sl);
}

// MySQL Server is required: neobasic-windows.ps1 checks/installs it and starts the local service.
// returns the script exit code (0 = url in outf, 2 = do not open, 3 = setup needed), -1 = script missing
static int run_ps(const wchar_t *dir, const wchar_t *appname, const wchar_t *html, const wchar_t *phase, const wchar_t *outf) {
    wchar_t ps1[MAX_PATH], ps[MAX_PATH];
    swprintf(ps1, MAX_PATH, L"%ls\\neobasic-windows.ps1", dir);
    if (!file_exists(ps1)) return -1;
    ExpandEnvironmentStringsW(L"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe", ps, MAX_PATH);
    if (!file_exists(ps)) return -1;
    DeleteFileW(outf);
    static wchar_t cmd[8192];
    swprintf(cmd, 8192, L"\"%ls\" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%ls\" -Phase %ls -App \"%ls\" -Html \"%ls\" -Out \"%ls\"",
             ps, ps1, phase, appname, html, outf);
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si); ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessW(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, dir, &si, &pi)) return -1;
    // keep stamping the main window while the setup dialog is open
    while (WaitForSingleObject(pi.hProcess, 400) == WAIT_TIMEOUT) { int found = 0; EnumWindows(stamp_enum, (LPARAM)&found); }
    DWORD code = 2; GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return (int)code;
}
static int read_url(const wchar_t *outf, wchar_t *url, int cap) {
    FILE *f = _wfopen(outf, L"rb"); if (!f) return 0;
    char buf[8192] = { 0 }; size_t n = fread(buf, 1, sizeof(buf) - 1, f); fclose(f); DeleteFileW(outf); buf[n] = 0;
    char *b = buf; if ((unsigned char)b[0] == 0xEF && (unsigned char)b[1] == 0xBB && (unsigned char)b[2] == 0xBF) b += 3;
    char *e = b + strlen(b); while (e > b && (e[-1] == '\r' || e[-1] == '\n' || e[-1] == ' ')) *--e = 0;
    if (strncmp(b, "http://127.0.0.1:", 17) != 0) return 0;
    MultiByteToWideChar(CP_UTF8, 0, b, -1, url, cap);
    return 1;
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmd, int show) {
    (void)hInst; (void)hPrev; (void)cmd; (void)show;
    wchar_t exe[MAX_PATH], dir[MAX_PATH], html[MAX_PATH], browser[MAX_PATH], profile[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy(dir, exe);
    wchar_t *slash = wcsrchr(dir, L'\\'); if (slash) *slash = 0;
    // o lançador abre o .html com o mesmo nome dele (NeoBasic.exe -> NeoBasic.html, Agenda.exe -> Agenda.html)
    wchar_t appname[MAX_PATH]; { const wchar_t *bn = wcsrchr(exe, L'\\'); wcscpy(appname, bn ? bn + 1 : exe); wchar_t *dt = wcsrchr(appname, L'.'); if (dt) *dt = 0; }
    swprintf(html, MAX_PATH, L"%ls\\%ls.html", dir, appname);
    // NeoBasic.exe Agenda.html (ou arrastar o .html para cima do NeoBasic.exe): abre esse programa e cria o atalho dele
    wchar_t appdir[MAX_PATH]; wcscpy(appdir, dir); wchar_t lnkArgs[MAX_PATH + 4] = L"";
    { int argc = 0; LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
      if (argv && argc >= 2) {
        wchar_t full[MAX_PATH]; if (GetFullPathNameW(argv[1], MAX_PATH, full, NULL)) {
          const wchar_t *ext = wcsrchr(full, L'.');
          if (ext && (_wcsicmp(ext, L".html") == 0 || _wcsicmp(ext, L".htm") == 0) && file_exists(full)) {
            wcscpy(html, full); wcscpy(appdir, full); wchar_t *sl2 = wcsrchr(appdir, L'\\'); if (sl2) *sl2 = 0;
            const wchar_t *bn = wcsrchr(full, L'\\'); wcscpy(appname, bn ? bn + 1 : full); wchar_t *dt = wcsrchr(appname, L'.'); if (dt) *dt = 0;
            swprintf(lnkArgs, MAX_PATH + 4, L"\"%ls\"", full);
          } } }
      if (argv) LocalFree(argv); }
    if (!file_exists(html)) {
        wchar_t msg[1024]; swprintf(msg, 1024, L"%ls.html was not found.\n\nKeep %ls.exe in the same folder as %ls.html.", appname, appname, appname);
        MessageBoxW(NULL, msg, appname, MB_ICONERROR);
        return 1;
    }
    { wchar_t nav[MAX_PATH]; swprintf(nav, MAX_PATH, L"%ls\\navegador.txt", appdir); if (!file_exists(nav)) wcscpy(appdir, dir); }
    if (!find_browser(appdir, browser, MAX_PATH)) {
        MessageBoxW(NULL, L"NeoBasic needs a Chromium browser (Chrome, Brave, Vivaldi, Chromium, Opera or Edge) and none was found.\n\nInstall one of them and try again.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    // perfil próprio: o NeoBasic vira um aplicativo separado do seu navegador
    // um perfil para cada navegador (Chrome e Edge não podem dividir a mesma pasta de perfil)
    { wchar_t base[MAX_PATH], bname[64]; ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\NeoBasic\\Perfil", base, MAX_PATH);
      const wchar_t *bn = wcsrchr(browser, L'\\'); bn = bn ? bn + 1 : browser; wcsncpy(bname, bn, 63); bname[63] = 0;
      wchar_t *dot = wcsrchr(bname, L'.'); if (dot) *dot = 0;
      if (_wcsicmp(appname, L"NeoBasic") == 0) swprintf(profile, MAX_PATH, L"%ls-%ls", base, bname);
      else { ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\NeoBasic\\Apps", base, MAX_PATH); swprintf(profile, MAX_PATH, L"%ls\\%ls-%ls", base, appname, bname); } }
    SHCreateDirectoryExW(NULL, profile, NULL);

    // taskbar identity of this program (the Chrome window gets it below)
    swprintf(g_appid, 200, L"Drimah.NeoBasic%ls%ls", _wcsicmp(appname, L"NeoBasic") == 0 ? L"" : L".", _wcsicmp(appname, L"NeoBasic") == 0 ? L"" : appname);
    for (wchar_t *c = g_appid; *c; c++) if (*c == L' ') *c = L'_';
    swprintf(g_relaunch, MAX_PATH * 2 + 8, L"\"%ls\"%ls%ls", exe, lnkArgs[0] ? L" " : L"", lnkArgs);
    swprintf(g_iconres, MAX_PATH + 8, L"%ls,0", exe);
    wcsncpy(g_appname, appname, MAX_PATH - 1);
    g_icon_big = (HICON)LoadImageW(GetModuleHandleW(NULL), MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), 0);
    g_icon_small = (HICON)LoadImageW(GetModuleHandleW(NULL), MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
    { const wchar_t *bn = wcsrchr(browser, L'\\'); wcsncpy(g_browser_exe, bn ? bn + 1 : browser, 63); }

    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    ensure_shortcut(exe, dir, appname, lnkArgs);

    wchar_t url[8192], tmp[MAX_PATH], outf[MAX_PATH];
    GetTempPathW(MAX_PATH, tmp);
    swprintf(outf, MAX_PATH, L"%lsneobasic-url-%lu.txt", tmp, (unsigned long)GetCurrentProcessId());
    // NeoBasic: the main window opens first and shows what is happening (connecting, the MySQL question,
    // installation progress, errors) — the setup phase reports it to the window. Exported apps: start phase.
    int isIDE = _wcsicmp(appname, L"NeoBasic") == 0;
    int rc = isIDE ? 3 : run_ps(dir, appname, html, L"start", outf);
    if (isIDE) { wchar_t ps1[MAX_PATH]; swprintf(ps1, MAX_PATH, L"%ls\\neobasic-windows.ps1", dir); if (!file_exists(ps1)) rc = -1; }
    if (rc < 0) {
        wchar_t msg[1024];
        swprintf(msg, 1024, L"neobasic-windows.ps1 is missing from the %ls folder.\n\nIt prepares MySQL Server, which is required. Extract the NeoBasic ZIP again, keeping all files together.", appname);
        MessageBoxW(NULL, msg, appname, MB_ICONERROR);
        return 1;
    }
    int setup = 0;
    if (rc == 0) { if (!read_url(outf, url, 8192)) return 1; }
    else if (rc == 3) {
        // 2) MySQL missing: the NeoBasic main window opens first, then the setup dialog appears on top of it
        char url8[8192]; path_to_url(html, url8, sizeof(url8)); strcat(url8, "?app=1&setup=1");
        MultiByteToWideChar(CP_UTF8, 0, url8, -1, url, 8192);
        setup = 1;
    } else return 0;

    wchar_t cmdline[16384];
    swprintf(cmdline, 16384,
        L"\"%ls\" --app=\"%ls\" --user-data-dir=\"%ls\" --start-maximized --no-first-run --no-default-browser-check "
        L"--lang=en-US --disable-features=Translate,msEdgeSidebarV2,msHubApps,msUndersideButton --disable-sync --hide-crash-restore-bubble",
        browser, url, profile);
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si); ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi)) {
        MessageBoxW(NULL, L"The NeoBasic window could not be opened.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    g_browser_pid = pi.dwProcessId;
    CloseHandle(pi.hThread);
    stamp_loop(20000, setup ? 800 : 8000);   // NeoBasic icon on the taskbar
    if (setup) {
        rc = run_ps(dir, appname, html, L"setup", outf);
        DeleteFileW(outf);
        if (rc != 0) {   // "Exit" or setup failed: close the main window
            EnumWindows(close_enum, 0);
            if (WaitForSingleObject(pi.hProcess, 4000) == WAIT_TIMEOUT) TerminateProcess(pi.hProcess, 0);
            CloseHandle(pi.hProcess); CoUninitialize();
            return 0;
        }
        stamp_loop(3000, 10000);   // the main window reloads connected to MySQL
    }
    CloseHandle(pi.hProcess);
    CoUninitialize();
    return 0;
}
