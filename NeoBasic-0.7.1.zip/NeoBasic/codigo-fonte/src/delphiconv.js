// ===== NeoBasic — tradutor Object Pascal -> Visual Basic e montagem do projeto =====
const DelphiConvert = (() => {
  'use strict';
  const D = typeof DelphiImport !== 'undefined' ? DelphiImport : require('./delphi.js');
  const { vbStr, vbStrExpr } = D;

  // identificadores que não podem ser nomes de variável no VB
  const VB_RESERVED = new Set(['name', 'line', 'loop', 'next', 'step', 'get', 'set', 'let', 'print', 'open', 'close', 'input', 'error', 'resume', 'stop', 'end', 'exit', 'sub', 'function', 'property', 'option', 'each', 'is', 'like', 'new', 'nothing', 'me', 'call', 'dim', 'redim', 'preserve', 'const', 'static', 'public', 'private', 'global', 'as', 'byval', 'byref', 'optional', 'paramarray', 'select', 'case', 'do', 'wend', 'until', 'for', 'to', 'then', 'else', 'elseif', 'if', 'on', 'goto', 'gosub', 'return', 'with', 'and', 'or', 'not', 'xor', 'mod', 'eqv', 'imp', 'true', 'false', 'empty', 'null', 'debug', 'integer', 'long', 'string', 'single', 'double', 'currency', 'boolean', 'byte', 'variant', 'object', 'date', 'event', 'declare', 'lib', 'alias', 'friend', 'enum', 'rem', 'lock', 'unlock', 'write', 'seek', 'put', 'kill', 'load', 'unload', 'binary', 'random', 'append', 'output', 'access', 'circle', 'pset', 'type', 'while', 'in', 'erase', 'date', 'time', 'len', 'mid', 'left', 'right', 'val', 'str', 'chr', 'asc', 'format', 'trim', 'dir', 'beep', 'width', 'tab', 'spc', 'text', 'caption', 'value', 'result', 'sender', 'form', 'forms', 'screen', 'app', 'err', 'array', 'split', 'join', 'replace', 'instr', 'round', 'fix', 'int', 'abs', 'sgn', 'sqr', 'rnd', 'now', 'day', 'month', 'year', 'hour', 'minute', 'second', 'weekday', 'timer', 'shell', 'environ', 'command', 'doevents', 'msgbox', 'inputbox', 'iif', 'choose', 'switch', 'typename', 'vartype', 'isnull', 'isempty', 'isarray', 'isdate', 'isnumeric', 'ismissing', 'isobject', 'clipboard', 'printer', 'controls', 'index', 'count', 'item', 'items', 'tag', 'top', 'height', 'visible', 'enabled', 'font', 'color', 'list', 'listindex', 'listcount', 'selected', 'hwnd', 'container']);
  // nomes realmente proibidos como variável (renomeados); os demais são permitidos pelo NeoBasic
  const MUST_RENAME = new Set(['name', 'line', 'loop', 'next', 'step', 'get', 'set', 'let', 'print', 'open', 'close', 'input', 'error', 'resume', 'stop', 'end', 'exit', 'sub', 'function', 'property', 'option', 'each', 'is', 'like', 'new', 'nothing', 'me', 'call', 'dim', 'redim', 'preserve', 'const', 'static', 'public', 'private', 'global', 'as', 'byval', 'byref', 'optional', 'paramarray', 'select', 'case', 'do', 'wend', 'until', 'for', 'to', 'then', 'else', 'elseif', 'if', 'on', 'goto', 'gosub', 'return', 'with', 'and', 'or', 'not', 'xor', 'mod', 'eqv', 'imp', 'true', 'false', 'empty', 'null', 'debug', 'integer', 'long', 'string', 'single', 'double', 'currency', 'boolean', 'byte', 'variant', 'object', 'date', 'event', 'declare', 'lib', 'alias', 'friend', 'enum', 'rem', 'lock', 'unlock', 'write', 'seek', 'put', 'kill', 'load', 'unload', 'binary', 'random', 'append', 'output', 'access', 'circle', 'pset', 'type', 'while', 'in', 'erase', 'time', 'beep', 'width', 'me', 'array', 'form', 'forms', 'screen', 'app', 'err', 'printer', 'clipboard', 'len', 'mid', 'left', 'right', 'val', 'str', 'chr', 'asc', 'format', 'trim', 'dir', 'now', 'day', 'month', 'year', 'hour', 'minute', 'second', 'timer', 'int', 'fix', 'abs', 'sqr', 'rnd', 'round', 'shell', 'split', 'join', 'replace', 'instr', 'iif', 'choose', 'switch']);

  const SIMPLE = { integer: 'Long', longint: 'Long', cardinal: 'Long', longword: 'Long', word: 'Long', smallint: 'Integer', shortint: 'Integer', byte: 'Byte', int64: 'Double', uint64: 'Double', nativeint: 'Long', nativeuint: 'Long', int8: 'Integer', int16: 'Integer', int32: 'Long', uint8: 'Byte', uint16: 'Long', uint32: 'Long', boolean: 'Boolean', bytebool: 'Boolean', wordbool: 'Boolean', longbool: 'Boolean', bool: 'Boolean', string: 'String', ansistring: 'String', widestring: 'String', unicodestring: 'String', shortstring: 'String', rawbytestring: 'String', utf8string: 'String', char: 'String', ansichar: 'String', widechar: 'String', pchar: 'String', pansichar: 'String', pwidechar: 'String', tcaption: 'String', tfilename: 'String', real: 'Double', real48: 'Double', double: 'Double', extended: 'Double', single: 'Single', currency: 'Currency', comp: 'Double', tdatetime: 'Date', tdate: 'Date', ttime: 'Date', variant: 'Variant', olevariant: 'Variant', tcolor: 'Long', tmodalresult: 'Long', tcloseaction: 'Long', tshiftstate: 'Long', tmousebutton: 'Long', hwnd: 'Long', thandle: 'Long', thandle: 'Long', tobject: 'Object', tcomponent: 'Object', tcontrol: 'Object', twincontrol: 'Object', tpersistent: 'Object', pointer: 'Variant', textfile: 'Variant', text: 'Variant', tvarrec: 'Variant', tbookmark: 'Variant', tguid: 'String', tbytes: 'Variant', tkeyboardstate: 'Variant', tcursor: 'Long', tborderstyle: 'Long', twindowstate: 'Long', tposition: 'Long', talignment: 'Long', tfontstyles: 'Long', tbrushstyle: 'Long', tpenstyle: 'Long', tmsgdlgtype: 'Long', tmsgdlgbuttons: 'Long', tdatasetstate: 'Long', tfieldtype: 'Long' };
  // classes VCL conhecidas -> família (para mapear propriedades no código)
  const VCL_KIND = Object.assign({}, D.KIND, { tcustomlistbox: 'list', tcustomcombobox: 'combo', tcustomedit: 'edit', tcustommemo: 'memo', tcustomlabel: 'label', tbutton: 'button', tcustomcheckbox: 'check', tbuttoncontrol: 'button', tform: 'form', tcustomform: 'form', tscrollingwincontrol: 'panel', tcustompanel: 'panel', tcustomgroupbox: 'group', tcustomradiogroup: 'radiogroup', tgraphiccontrol: 'control', tcustomcontrol: 'control', tstrings: 'strings', tstringlist: 'strings', twincontrol: 'control', tcontrol: 'control' });

  const PREC = { atom: 99, pow: 14, neg: 13, mul: 12, idiv: 11, mod: 10, add: 9, cat: 8, cmp: 7, not: 6, and: 5, or: 4, xor: 3 };
  const R = (c, t, p, extra) => Object.assign({ c, t: t || null, p: p == null ? PREC.atom : p }, extra || {});
  const wrap = (r, min) => (r.p < min ? `(${r.c})` : r.c);
  const T = { long: { vb: 'Long' }, int: { vb: 'Integer' }, str: { vb: 'String' }, dbl: { vb: 'Double' }, bool: { vb: 'Boolean' }, date: { vb: 'Date' }, var: { vb: 'Variant' }, obj: { vb: 'Object', obj: true }, cur: { vb: 'Currency' } };
  const isStrT = t => t && t.vb === 'String' && !t.arr;
  const isNumT = t => t && ['Long', 'Integer', 'Double', 'Single', 'Currency', 'Byte'].includes(t.vb) && !t.arr;

  // ---------------------------------------------------------------- relatório
  class Report {
    constructor() { this.warns = []; this.datas = []; this.todo = 0; this.lines = 0; this.converted = []; }
    warn(m) { if (!this.warns.includes(m)) this.warns.push(m); }
    data(m) { this.datas.push(m); }
  }

  // ---------------------------------------------------------------- módulo de compatibilidade (VB)
  const COMPAT_BAS = `Attribute VB_Name = "DelphiCompat"
' Converted by NeoBasic from a Delphi project.
' Helpers that give Delphi (Object Pascal / VCL) behavior to the converted code.
Option Explicit

Public Const mrNone = 0, mrOk = 1, mrCancel = 2, mrAbort = 3, mrRetry = 4, mrIgnore = 5, mrYes = 6, mrNo = 7, mrClose = 8, mrHelp = 9, mrAll = 12, mrNoToAll = 13, mrYesToAll = 14
Public Const idOk = 1, idCancel = 2, idAbort = 3, idRetry = 4, idIgnore = 5, idYes = 6, idNo = 7
Public Const MB_OK = 0, MB_OKCANCEL = 1, MB_ABORTRETRYIGNORE = 2, MB_YESNOCANCEL = 3, MB_YESNO = 4, MB_RETRYCANCEL = 5
Public Const MB_ICONERROR = 16, MB_ICONHAND = 16, MB_ICONSTOP = 16, MB_ICONQUESTION = 32, MB_ICONWARNING = 48, MB_ICONEXCLAMATION = 48, MB_ICONINFORMATION = 64, MB_ICONASTERISK = 64
Public Const MB_DEFBUTTON1 = 0, MB_DEFBUTTON2 = 256, MB_DEFBUTTON3 = 512, MB_APPLMODAL = 0, MB_SYSTEMMODAL = 4096, MB_TASKMODAL = 8192
Public Const caNone = 0, caHide = 1, caFree = 2, caMinimize = 3
Public Const ssShift = 1, ssCtrl = 2, ssAlt = 4
Public Const mbLeft = 1, mbRight = 2, mbMiddle = 4
Public Const wsNormal = 0, wsMinimized = 1, wsMaximized = 2
Public Const crDefault = 0, crArrow = 1, crCross = 2, crIBeam = 3, crSize = 15, crSizeAll = 15, crHourGlass = 11, crSQLWait = 11, crAppStart = 13, crNo = 12, crHandPoint = 0, crHelp = 14, crDrag = 12, crNoDrop = 12
Public Const tbHorizontal = 1, tbVertical = 2
Public Const LB_ERR = -1, CB_ERR = -1
Public Const VK_BACK = 8, VK_TAB = 9, VK_RETURN = 13, VK_SHIFT = 16, VK_CONTROL = 17, VK_MENU = 18, VK_ESCAPE = 27, VK_SPACE = 32, VK_PRIOR = 33, VK_NEXT = 34, VK_END = 35, VK_HOME = 36
Public Const VK_LEFT = 37, VK_UP = 38, VK_RIGHT = 39, VK_DOWN = 40, VK_INSERT = 45, VK_DELETE = 46, VK_F1 = 112, VK_F2 = 113, VK_F3 = 114, VK_F4 = 115, VK_F5 = 116, VK_F6 = 117, VK_F7 = 118, VK_F8 = 119, VK_F9 = 120, VK_F10 = 121, VK_F11 = 122, VK_F12 = 123
Public Const clBlack = &H0&, clMaroon = &H80&, clGreen = &H8000&, clOlive = &H8080&, clNavy = &H800000, clPurple = &H800080, clTeal = &H808000, clGray = &H808080, clSilver = &HC0C0C0
Public Const clRed = &HFF&, clLime = &HFF00&, clYellow = &HFFFF&, clBlue = &HFF0000, clFuchsia = &HFF00FF, clAqua = &HFFFF00, clWhite = &HFFFFFF, clLtGray = &HC0C0C0, clDkGray = &H808080
Public Const clMoneyGreen = &HC0DCC0, clSkyBlue = &HF0CAA6, clCream = &HF0FBFF, clMedGray = &HA4A0A0
Public Const clBtnFace = &H8000000F, clWindow = &H80000005, clWindowText = &H80000008, clBtnText = &H80000012, clHighlight = &H8000000D, clHighlightText = &H8000000E, clGrayText = &H80000011, clInfoBk = &H80000018, clInfoText = &H80000017, clAppWorkSpace = &H8000000C, clActiveCaption = &H80000002, clCaptionText = &H80000009, clMenu = &H80000004, clMenuText = &H80000007, clBtnShadow = &H80000010, clBtnHighlight = &H80000014, clDefault = &H80000005, clNone = &H1FFFFFFF
Public Const MaxInt = 2147483647, MaxLongint = 2147483647, MaxSmallint = 32767

Public Function NBStrToIntDef(ByVal S As Variant, ByVal Def As Long) As Long
    On Error GoTo bad
    S = Trim$(CStr(S))
    If S = "" Then GoTo bad
    If Left$(S, 1) = "$" Then S = "&H" & Mid$(S, 2)
    NBStrToIntDef = CLng(S)
    Exit Function
bad:
    NBStrToIntDef = Def
End Function

Public Function NBStrToFloatDef(ByVal S As Variant, ByVal Def As Double) As Double
    On Error GoTo bad
    NBStrToFloatDef = CDbl(S)
    Exit Function
bad:
    NBStrToFloatDef = Def
End Function

Public Function NBTryStrToInt(ByVal S As Variant, V As Variant) As Boolean
    On Error GoTo bad
    If Trim$(CStr(S)) = "" Then Exit Function
    V = CLng(S)
    NBTryStrToInt = True
    Exit Function
bad:
    NBTryStrToInt = False
End Function

Public Function NBTryStrToFloat(ByVal S As Variant, V As Variant) As Boolean
    On Error GoTo bad
    If Trim$(CStr(S)) = "" Then Exit Function
    V = CDbl(S)
    NBTryStrToFloat = True
    Exit Function
bad:
    NBTryStrToFloat = False
End Function

Public Function NBIntToHex(ByVal N As Variant, ByVal Digits As Long) As String
    Dim h As String
    h = Hex$(N)
    If Len(h) < Digits Then h = String$(Digits - Len(h), "0") & h
    NBIntToHex = h
End Function

Public Function NBOrd(ByVal X As Variant) As Long
    Select Case VarType(X)
        Case vbString
            If Len(X) = 0 Then NBOrd = 0 Else NBOrd = AscW(X)
        Case vbBoolean
            If X Then NBOrd = 1 Else NBOrd = 0
        Case Else
            NBOrd = CLng(X)
    End Select
End Function

Public Function NBMax(ByVal A As Variant, ByVal B As Variant) As Variant
    If A > B Then NBMax = A Else NBMax = B
End Function

Public Function NBMin(ByVal A As Variant, ByVal B As Variant) As Variant
    If A < B Then NBMin = A Else NBMin = B
End Function

Public Function NBQuoted(ByVal S As String) As String
    NBQuoted = "'" & Replace(S, "'", "''") & "'"
End Function

Public Function NBDupe(ByVal S As String, ByVal N As Long) As String
    Dim i As Long, r As String
    For i = 1 To N
        r = r & S
    Next i
    NBDupe = r
End Function

Public Function NBLength(X As Variant) As Long
    On Error GoTo bad
    If IsArray(X) Then
        NBLength = UBound(X) - LBound(X) + 1
    Else
        NBLength = Len(X)
    End If
    Exit Function
bad:
    NBLength = 0
End Function

Public Function NBHigh(X As Variant) As Long
    On Error GoTo bad
    If IsArray(X) Then NBHigh = UBound(X) Else NBHigh = Len(X)
    Exit Function
bad:
    NBHigh = -1
End Function

Public Function NBExtractFileName(ByVal F As String) As String
    Dim p As Long
    p = InStrRev(Replace(F, "/", "\\"), "\\")
    NBExtractFileName = Mid$(F, p + 1)
End Function

Public Function NBExtractFilePath(ByVal F As String) As String
    Dim p As Long
    p = InStrRev(Replace(F, "/", "\\"), "\\")
    NBExtractFilePath = Left$(F, p)
End Function

Public Function NBExtractFileExt(ByVal F As String) As String
    Dim p As Long, n As String
    n = NBExtractFileName(F)
    p = InStrRev(n, ".")
    If p > 0 Then NBExtractFileExt = Mid$(n, p) Else NBExtractFileExt = ""
End Function

Public Function NBChangeFileExt(ByVal F As String, ByVal Ext As String) As String
    Dim e As String
    e = NBExtractFileExt(F)
    NBChangeFileExt = Left$(F, Len(F) - Len(e)) & Ext
End Function

Public Function NBTrailingDelim(ByVal F As String) As String
    If Right$(F, 1) = "\\" Or Right$(F, 1) = "/" Then NBTrailingDelim = F Else NBTrailingDelim = F & "\\"
End Function

Public Function NBFileExists(ByVal F As String) As Boolean
    On Error GoTo bad
    NBFileExists = (F <> "" And Dir$(F) <> "")
    Exit Function
bad:
    NBFileExists = False
End Function

Public Function NBDeleteFile(ByVal F As String) As Boolean
    On Error GoTo bad
    Kill F
    NBDeleteFile = True
    Exit Function
bad:
    NBDeleteFile = False
End Function

Public Function NBInputQuery(ByVal Caption As String, ByVal Prompt As String, Value As Variant) As Boolean
    Dim r As String
    r = InputBox(Prompt, Caption, Value)
    If StrPtr(r) = 0 Then
        NBInputQuery = False
    Else
        Value = r
        NBInputQuery = True
    End If
End Function

Public Sub NBSleep(ByVal Ms As Long)
    Dim t As Double
    t = Timer
    Do While (Timer - t) * 1000 < Ms
        DoEvents
        If Timer < t Then Exit Do
    Loop
End Sub

' Format('%d items, %s, %.2f', [...])
Public Function NBFormat(ByVal F As String, Args As Variant) As String
    Dim r As String, i As Long, n As Long, c As String, spec As String, ai As Long, v As Variant, prec As Long, w As Long, j As Long, s As String
    i = 1: n = Len(F): ai = 0
    Do While i <= n
        c = Mid$(F, i, 1)
        If c = "%" Then
            If Mid$(F, i + 1, 1) = "%" Then
                r = r & "%": i = i + 2
            Else
                j = i + 1: spec = ""
                Do While j <= n
                    c = Mid$(F, j, 1)
                    If InStr("dsfgenmxuDSFGENMXU", c) > 0 Then Exit Do
                    spec = spec & c: j = j + 1
                Loop
                If IsArray(Args) Then
                    If ai <= UBound(Args) Then v = Args(ai) Else v = ""
                Else
                    v = Args
                End If
                ai = ai + 1
                prec = -1: w = 0
                If InStr(spec, ".") > 0 Then prec = Val(Mid$(spec, InStr(spec, ".") + 1)): w = Val(Replace(Left$(spec, InStr(spec, ".") - 1), "-", "")) Else w = Val(Replace(spec, "-", ""))
                Select Case LCase$(c)
                    Case "d", "u": s = CStr(Fix(v)): If prec > 0 Then If Len(s) < prec Then s = String$(prec - Len(s), "0") & s
                    Case "s": s = CStr(v): If prec >= 0 Then s = Left$(s, prec)
                    Case "f", "g", "e": If prec < 0 Then prec = 2
                        If prec = 0 Then s = Format$(v, "0") Else s = Format$(v, "0." & String$(prec, "0"))
                    Case "n": If prec < 0 Then prec = 2
                        If prec = 0 Then s = Format$(v, "#,##0") Else s = Format$(v, "#,##0." & String$(prec, "0"))
                    Case "m": s = Format$(v, "Currency")
                    Case "x": s = Hex$(v): If prec > 0 Then If Len(s) < prec Then s = String$(prec - Len(s), "0") & s
                End Select
                If w > Len(s) Then
                    If Left$(spec, 1) = "-" Then s = s & Space$(w - Len(s)) Else s = Space$(w - Len(s)) & s
                End If
                r = r & s
                i = j + 1
            End If
        Else
            r = r & c: i = i + 1
        End If
    Loop
    NBFormat = r
End Function

' Delphi MessageDlg -> MsgBox
Public Function NBMessageDlg(ByVal Msg As String, ByVal DlgType As Long, ByVal Buttons As Long) As Long
    NBMessageDlg = MsgBox(Msg, DlgType + Buttons, App.Title)
End Function

Public Function NBMDIChildCount() As Long
    Dim f As Object, n As Long
    For Each f In Forms
        If f.MDIChild Then n = n + 1
    Next
    NBMDIChildCount = n
End Function

' TStrings para ListBox, ComboBox e Memo
Public Function NBItems(Ctl As Object) As TStringsCtl
    Dim w As New TStringsCtl
    w.Attach Ctl, "list"
    Set NBItems = w
End Function

Public Function NBLines(Ctl As Object) As TStringsCtl
    Dim w As New TStringsCtl
    w.Attach Ctl, "memo"
    Set NBLines = w
End Function

Public Sub NBMemoAdd(Ctl As Object, ByVal S As String)
    If Ctl.Text = "" Then Ctl.Text = S Else Ctl.Text = Ctl.Text & vbCrLf & S
End Sub

Public Function NBMemoCount(Ctl As Object) As Long
    If Ctl.Text = "" Then NBMemoCount = 0 Else NBMemoCount = UBound(Split(Replace(Ctl.Text, vbCrLf, vbLf), vbLf)) + 1
End Function

Public Function NBMemoLine(Ctl As Object, ByVal Index As Long) As String
    Dim a As Variant
    a = Split(Replace(Ctl.Text, vbCrLf, vbLf), vbLf)
    If Index >= 0 And Index <= UBound(a) Then NBMemoLine = a(Index)
End Function

Public Function NBListIndexOf(Ctl As Object, ByVal S As String) As Long
    Dim i As Long
    For i = 0 To Ctl.ListCount - 1
        If StrComp(Ctl.List(i), S, vbTextCompare) = 0 Then NBListIndexOf = i: Exit Function
    Next i
    NBListIndexOf = -1
End Function

Public Sub NBListSelect(Ctl As Object, ByVal Index As Long, ByVal Value As Boolean)
    Dim i As Long
    If Index = -1 Then
        For i = 0 To Ctl.ListCount - 1
            Ctl.Selected(i) = Value
        Next i
    ElseIf Index >= 0 And Index < Ctl.ListCount Then
        Ctl.Selected(Index) = Value
        If Value Then Ctl.ListIndex = Index
    End If
End Sub

Public Function NBOptIndex(Opts As Object) As Long
    Dim o As Object
    For Each o In Opts
        If o.Value Then NBOptIndex = o.Index: Exit Function
    Next
    NBOptIndex = -1
End Function

Public Sub NBSetOptIndex(Opts As Object, ByVal Index As Long)
    Dim o As Object
    For Each o In Opts
        o.Value = (o.Index = Index)
    Next
End Sub

Public Function NBDialogExecute(Dlg As Object, ByVal Kind As String) As Boolean
    On Error GoTo cancelled
    Dlg.CancelError = True
    Select Case Kind
        Case "save": Dlg.ShowSave
        Case "color": Dlg.ShowColor
        Case "font": Dlg.ShowFont
        Case "print": Dlg.ShowPrinter
        Case Else: Dlg.ShowOpen
    End Select
    NBDialogExecute = True
    Exit Function
cancelled:
    NBDialogExecute = False
End Function

Public Function NBLoadText(ByVal F As String) As String
    Dim n As Integer, s As String, r As String
    n = FreeFile
    Open F For Input As #n
    Do While Not EOF(n)
        Line Input #n, s
        If r = "" Then r = s Else r = r & vbCrLf & s
    Loop
    Close #n
    NBLoadText = r
End Function

Public Sub NBSaveText(ByVal F As String, ByVal Text As String)
    Dim n As Integer
    n = FreeFile
    Open F For Output As #n
    Print #n, Text;
    Close #n
End Sub

' arquivos texto (AssignFile, Reset, Rewrite, Append)
Public Sub NBAssignFile(F As Variant, ByVal Name As String)
    F = "NB:" & Name
End Sub

Public Sub NBOpenFile(F As Variant, ByVal Mode As String)
    Dim nm As String, n As Integer
    nm = Mid$(CStr(F), 4)
    n = FreeFile
    Select Case Mode
        Case "reset": Open nm For Input As #n
        Case "rewrite": Open nm For Output As #n
        Case "append": Open nm For Append As #n
    End Select
    F = n
End Sub
`;

  const TSTRINGLIST_CLS = `VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "TStringList"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Delphi TStringList for converted projects
Option Explicit

Private mItems() As String
Private mObjs() As Variant
Private mCount As Long
Private mSorted As Boolean
Public Delimiter As String
Public CaseSensitive As Boolean
Public Duplicates As Long
Public NameValueSeparator As String

Private Sub Class_Initialize()
    ReDim mItems(0 To 15)
    ReDim mObjs(0 To 15)
    Delimiter = ","
    NameValueSeparator = "="
End Sub

Private Sub Grow()
    If mCount > UBound(mItems) Then
        ReDim Preserve mItems(0 To mCount * 2 + 16)
        ReDim Preserve mObjs(0 To mCount * 2 + 16)
    End If
End Sub

Public Property Get Count() As Long
    Count = mCount
End Property

Public Property Get Item(ByVal Index As Long) As String
Attribute Item.VB_UserMemId = 0
    If Index < 0 Or Index >= mCount Then Err.Raise 9, , "List index out of bounds (" & Index & ")"
    Item = mItems(Index)
End Property

Public Property Let Item(ByVal Index As Long, ByVal Value As String)
    If Index < 0 Or Index >= mCount Then Err.Raise 9, , "List index out of bounds (" & Index & ")"
    mItems(Index) = Value
End Property

Public Property Get Strings(ByVal Index As Long) As String
    Strings = Item(Index)
End Property

Public Property Let Strings(ByVal Index As Long, ByVal Value As String)
    Item(Index) = Value
End Property

Public Property Get Objects(ByVal Index As Long) As Variant
    If IsObject(mObjs(Index)) Then Set Objects = mObjs(Index) Else Objects = mObjs(Index)
End Property

Public Property Let Objects(ByVal Index As Long, ByVal Value As Variant)
    mObjs(Index) = Value
End Property

Public Property Set Objects(ByVal Index As Long, ByVal Value As Object)
    Set mObjs(Index) = Value
End Property

Public Function Add(ByVal S As String) As Long
    Dim i As Long, j As Long
    If mSorted Then
        i = 0
        Do While i < mCount
            If Cmp(mItems(i), S) > 0 Then Exit Do
            i = i + 1
        Loop
        Insert i, S
        Add = i
    Else
        Grow
        mItems(mCount) = S
        mObjs(mCount) = Empty
        mCount = mCount + 1
        Add = mCount - 1
    End If
End Function

Public Function AddObject(ByVal S As String, ByVal Obj As Variant) As Long
    Dim i As Long
    i = Add(S)
    If IsObject(Obj) Then Set mObjs(i) = Obj Else mObjs(i) = Obj
    AddObject = i
End Function

Public Sub Append(ByVal S As String)
    Add S
End Sub

Public Sub AddStrings(Other As Object)
    Dim i As Long
    For i = 0 To Other.Count - 1
        Add Other.Item(i)
    Next i
End Sub

Public Sub Insert(ByVal Index As Long, ByVal S As String)
    Dim i As Long
    Grow
    For i = mCount To Index + 1 Step -1
        mItems(i) = mItems(i - 1)
        If IsObject(mObjs(i - 1)) Then Set mObjs(i) = mObjs(i - 1) Else mObjs(i) = mObjs(i - 1)
    Next i
    mItems(Index) = S
    mObjs(Index) = Empty
    mCount = mCount + 1
End Sub

Public Sub Delete(ByVal Index As Long)
    Dim i As Long
    If Index < 0 Or Index >= mCount Then Exit Sub
    For i = Index To mCount - 2
        mItems(i) = mItems(i + 1)
        If IsObject(mObjs(i + 1)) Then Set mObjs(i) = mObjs(i + 1) Else mObjs(i) = mObjs(i + 1)
    Next i
    mCount = mCount - 1
End Sub

Public Sub Clear()
    mCount = 0
    ReDim mItems(0 To 15)
    ReDim mObjs(0 To 15)
End Sub

Public Sub BeginUpdate()
End Sub

Public Sub EndUpdate()
End Sub

Public Sub Free()
End Sub

Public Sub Exchange(ByVal A As Long, ByVal B As Long)
    Dim t As String, o As Variant
    t = mItems(A): mItems(A) = mItems(B): mItems(B) = t
    o = mObjs(A): mObjs(A) = mObjs(B): mObjs(B) = o
End Sub

Private Function Cmp(ByVal A As String, ByVal B As String) As Long
    If CaseSensitive Then Cmp = StrComp(A, B, vbBinaryCompare) Else Cmp = StrComp(A, B, vbTextCompare)
End Function

Public Function IndexOf(ByVal S As String) As Long
    Dim i As Long
    For i = 0 To mCount - 1
        If Cmp(mItems(i), S) = 0 Then IndexOf = i: Exit Function
    Next i
    IndexOf = -1
End Function

Public Function IndexOfName(ByVal N As String) As Long
    Dim i As Long
    For i = 0 To mCount - 1
        If Cmp(Names(i), N) = 0 Then IndexOfName = i: Exit Function
    Next i
    IndexOfName = -1
End Function

Public Function Find(ByVal S As String, Index As Variant) As Boolean
    Index = IndexOf(S)
    Find = (Index >= 0)
End Function

Public Sub Sort()
    Dim i As Long, j As Long, t As String, o As Variant
    For i = 1 To mCount - 1
        t = mItems(i): o = mObjs(i)
        j = i - 1
        Do While j >= 0
            If Cmp(mItems(j), t) <= 0 Then Exit Do
            mItems(j + 1) = mItems(j): mObjs(j + 1) = mObjs(j)
            j = j - 1
        Loop
        mItems(j + 1) = t: mObjs(j + 1) = o
    Next i
End Sub

Public Property Get Sorted() As Boolean
    Sorted = mSorted
End Property

Public Property Let Sorted(ByVal Value As Boolean)
    mSorted = Value
    If Value Then Sort
End Property

Public Property Get Text() As String
    Dim i As Long, r As String
    For i = 0 To mCount - 1
        r = r & mItems(i) & vbCrLf
    Next i
    Text = r
End Property

Public Property Let Text(ByVal Value As String)
    Dim a As Variant, i As Long
    Clear
    If Value = "" Then Exit Property
    a = Split(Replace(Value, vbCrLf, vbLf), vbLf)
    For i = 0 To UBound(a)
        If Not (i = UBound(a) And a(i) = "") Then Add a(i)
    Next i
End Property

Public Property Get CommaText() As String
    Dim i As Long, r As String
    For i = 0 To mCount - 1
        If i > 0 Then r = r & ","
        If InStr(mItems(i), ",") > 0 Or InStr(mItems(i), " ") > 0 Then r = r & """" & mItems(i) & """" Else r = r & mItems(i)
    Next i
    CommaText = r
End Property

Public Property Let CommaText(ByVal Value As String)
    DelimitedSplit Value, ","
End Property

Public Property Get DelimitedText() As String
    Dim i As Long, r As String
    For i = 0 To mCount - 1
        If i > 0 Then r = r & Delimiter
        r = r & mItems(i)
    Next i
    DelimitedText = r
End Property

Public Property Let DelimitedText(ByVal Value As String)
    DelimitedSplit Value, Delimiter
End Property

Private Sub DelimitedSplit(ByVal Value As String, ByVal D As String)
    Dim a As Variant, i As Long, s As String
    Clear
    If Value = "" Then Exit Sub
    a = Split(Value, D)
    For i = 0 To UBound(a)
        s = a(i)
        If Len(s) >= 2 And Left$(s, 1) = """" And Right$(s, 1) = """" Then s = Mid$(s, 2, Len(s) - 2)
        Add s
    Next i
End Sub

Public Property Get Names(ByVal Index As Long) As String
    Dim p As Long
    p = InStr(mItems(Index), NameValueSeparator)
    If p > 0 Then Names = Left$(mItems(Index), p - 1) Else Names = ""
End Property

Public Property Get ValueFromIndex(ByVal Index As Long) As String
    Dim p As Long
    p = InStr(mItems(Index), NameValueSeparator)
    If p > 0 Then ValueFromIndex = Mid$(mItems(Index), p + 1)
End Property

Public Property Get Values(ByVal N As String) As String
    Dim i As Long
    i = IndexOfName(N)
    If i >= 0 Then Values = ValueFromIndex(i)
End Property

Public Property Let Values(ByVal N As String, ByVal Value As String)
    Dim i As Long
    i = IndexOfName(N)
    If i >= 0 Then
        If Value = "" Then Delete i Else mItems(i) = N & NameValueSeparator & Value
    ElseIf Value <> "" Then
        Add N & NameValueSeparator & Value
    End If
End Property

Public Sub LoadFromFile(ByVal F As String)
    Text = NBLoadText(F)
End Sub

Public Sub SaveToFile(ByVal F As String)
    NBSaveText F, Text
End Sub
`;

  const TSTRINGSCTL_CLS = `VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "TStringsCtl"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' The Items of a ListBox/ComboBox or the Lines of a TextBox seen as Delphi TStrings
Option Explicit

Private mCtl As Object
Private mKind As String

Public Sub Attach(Ctl As Object, ByVal Kind As String)
    Set mCtl = Ctl
    mKind = Kind
End Sub

Private Function Lines() As Variant
    If mCtl.Text = "" Then
        Lines = Array()
    Else
        Lines = Split(Replace(mCtl.Text, vbCrLf, vbLf), vbLf)
    End If
End Function

Private Sub SetLines(A As Variant)
    If UBound(A) < 0 Then mCtl.Text = "" Else mCtl.Text = Join(A, vbCrLf)
End Sub

Public Property Get Count() As Long
    If mKind = "list" Then Count = mCtl.ListCount Else Count = UBound(Lines()) + 1
End Property

Public Property Get Item(ByVal Index As Long) As String
Attribute Item.VB_UserMemId = 0
    Dim a As Variant
    If mKind = "list" Then
        Item = mCtl.List(Index)
    Else
        a = Lines()
        Item = a(Index)
    End If
End Property

Public Property Let Item(ByVal Index As Long, ByVal Value As String)
    Dim a As Variant
    If mKind = "list" Then
        mCtl.List(Index) = Value
    Else
        a = Lines()
        a(Index) = Value
        SetLines a
    End If
End Property

Public Property Get Strings(ByVal Index As Long) As String
    Strings = Item(Index)
End Property

Public Property Let Strings(ByVal Index As Long, ByVal Value As String)
    Item(Index) = Value
End Property

Public Property Get Objects(ByVal Index As Long) As Variant
    If mKind = "list" Then Objects = mCtl.ItemData(Index) Else Objects = 0
End Property

Public Property Let Objects(ByVal Index As Long, ByVal Value As Variant)
    On Error Resume Next
    If mKind = "list" Then mCtl.ItemData(Index) = Value
End Property

Public Function Add(ByVal S As String) As Long
    If mKind = "list" Then
        mCtl.AddItem S
        Add = mCtl.NewIndex
    Else
        If mCtl.Text = "" Then mCtl.Text = S Else mCtl.Text = mCtl.Text & vbCrLf & S
        Add = Count - 1
    End If
End Function

Public Function AddObject(ByVal S As String, ByVal Obj As Variant) As Long
    Dim i As Long
    i = Add(S)
    On Error Resume Next
    If mKind = "list" And Not IsObject(Obj) Then mCtl.ItemData(i) = Obj
    AddObject = i
End Function

Public Sub Append(ByVal S As String)
    Add S
End Sub

Public Sub Insert(ByVal Index As Long, ByVal S As String)
    Dim a As Variant, i As Long, b() As String
    If mKind = "list" Then
        mCtl.AddItem S, Index
    Else
        a = Lines()
        ReDim b(0 To UBound(a) + 1)
        For i = 0 To UBound(b)
            If i < Index Then
                b(i) = a(i)
            ElseIf i = Index Then
                b(i) = S
            Else
                b(i) = a(i - 1)
            End If
        Next i
        SetLines b
    End If
End Sub

Public Sub Delete(ByVal Index As Long)
    Dim a As Variant, i As Long, b() As String
    If mKind = "list" Then
        mCtl.RemoveItem Index
    Else
        a = Lines()
        If UBound(a) = 0 Then mCtl.Text = "": Exit Sub
        ReDim b(0 To UBound(a) - 1)
        For i = 0 To UBound(a)
            If i < Index Then b(i) = a(i) Else If i > Index Then b(i - 1) = a(i)
        Next i
        SetLines b
    End If
End Sub

Public Sub Clear()
    If mKind = "list" Then mCtl.Clear Else mCtl.Text = ""
End Sub

Public Sub BeginUpdate()
End Sub

Public Sub EndUpdate()
End Sub

Public Function IndexOf(ByVal S As String) As Long
    Dim i As Long
    For i = 0 To Count - 1
        If StrComp(Item(i), S, vbTextCompare) = 0 Then IndexOf = i: Exit Function
    Next i
    IndexOf = -1
End Function

Public Property Get Text() As String
    Dim i As Long, r As String
    If mKind = "list" Then
        For i = 0 To mCtl.ListCount - 1
            r = r & mCtl.List(i) & vbCrLf
        Next i
        Text = r
    Else
        Text = mCtl.Text
    End If
End Property

Public Property Let Text(ByVal Value As String)
    Dim a As Variant, i As Long
    If mKind = "list" Then
        mCtl.Clear
        If Value = "" Then Exit Property
        a = Split(Replace(Value, vbCrLf, vbLf), vbLf)
        For i = 0 To UBound(a)
            If Not (i = UBound(a) And a(i) = "") Then mCtl.AddItem a(i)
        Next i
    Else
        mCtl.Text = Value
    End If
End Property

Public Sub AddStrings(Other As Object)
    Dim i As Long
    For i = 0 To Other.Count - 1
        Add Other.Item(i)
    Next i
End Sub

Public Sub LoadFromFile(ByVal F As String)
    Text = NBLoadText(F)
End Sub

Public Sub SaveToFile(ByVal F As String)
    NBSaveText F, Text
End Sub
`;

  // ---------------------------------------------------------------- tradução de uma unidade
  class UnitTranslator {
    constructor(proj, unit, opts) {
      this.P = proj; this.U = unit; this.opts = opts || {};
      this.form = opts.form || null; // FormInfo, se a unidade tiver formulário
      this.report = proj.report;
      this.out = [];
      this.labelN = 0;
      this.scopes = [];
      this.withStack = [];
      this.loopStack = [];
      this.fields = new Map(); // campos do formulário/classe
      this.methods = new Map();
      this.unitSyms = new Map(); // símbolos locais à unidade (implementação)
      this.curClass = opts.cls || null;
    }
    warn(m) { this.report.warn(`${this.U.file || this.U.name}: ${m}`); }
    // ----- tipos
    typeOf(tn) {
      if (!tn) return T.var;
      if (tn.kind === 'array') {
        const of = this.typeOf(tn.of);
        return Object.assign({}, of, { arr: { dims: tn.dims, of }, vb: of.vb });
      }
      if (tn.kind === 'record') return T.var;
      if (tn.kind === 'enum') return T.long;
      if (tn.kind === 'set') return T.long;
      if (tn.kind === 'file') return T.var;
      if (tn.kind === 'pointer') return T.var;
      if (tn.kind === 'proc') return T.var;
      if (tn.kind === 'class') return T.obj;
      const nm = String(tn.name || '').replace(/^.*\./, ''); const l = nm.toLowerCase();
      if (l === 'string' && tn.len) return { vb: 'String', fixed: tn.len };
      if (SIMPLE[l]) { const vb = SIMPLE[l]; return { vb, obj: vb === 'Object', charT: /char$/.test(l) }; }
      if (l === 'tstringlist' || l === 'tstrings') return { vb: 'TStringList', obj: true, cls: 'strings', declVb: l === 'tstrings' ? 'Object' : 'TStringList' };
      const rec = this.P.records.get(l); if (rec) return { vb: rec.vbName, rec };
      if (this.P.enums.has(l)) return { vb: 'Long', enumName: this.P.enums.get(l).name };
      const al = this.P.aliases.get(l); if (al && al !== tn) return this.typeOf(al);
      const f = this.P.formByClass.get(l); if (f) return { vb: f.name, obj: true, form: f };
      const uc = this.P.classes.get(l); if (uc) return { vb: uc.vbName, obj: true, ucls: uc };
      const vk = VCL_KIND[l]; if (vk) return { vb: vk === 'form' ? 'Object' : 'Object', obj: true, ctlKind: vk, vcl: l };
      if (/^t[a-z]/.test(l)) return { vb: 'Object', obj: true, vcl: l };
      return T.var;
    }
    vbDecl(name, t, opts = {}) {
      if (t.arr) {
        const dims = t.arr.dims;
        if (!dims) return `${name}() As ${this.vbTypeName(t.arr.of)}`;
        const parts = dims.map(d => { if (d.typeName) { const l = (d.typeName.name || '').toLowerCase(); const en = this.P.enums.get(l); if (en) return `0 To ${en.items.length - 1}`; if (l === 'boolean') return '0 To 1'; if (l === 'char') return '0 To 255'; return '0 To 255'; } return `${this.emitConstExpr(d.lo)} To ${this.emitConstExpr(d.hi)}`; });
        return `${name}(${parts.join(', ')}) As ${this.vbTypeName(t.arr.of)}`;
      }
      if (t.fixed && opts.allowFixed) return `${name} As String * ${this.emitConstExpr(t.fixed)}`;
      return `${name} As ${this.vbTypeName(t)}`;
    }
    vbTypeName(t) { if (!t) return 'Variant'; if (t.arr) return 'Variant'; if (t.declVb) return t.declVb; return t.vb || 'Variant'; }
    safeName(n) { const l = n.toLowerCase(); return MUST_RENAME.has(l) ? n + '_' : n; }
    // ----- escopo
    pushScope(s) { this.scopes.push(s); }
    popScope() { this.scopes.pop(); }
    lookupLocal(l) { for (let i = this.scopes.length - 1; i >= 0; i--) { const s = this.scopes[i]; if (s.vars.has(l)) return s.vars.get(l); } return null; }
    get curRoutine() { for (let i = this.scopes.length - 1; i >= 0; i--) if (this.scopes[i].routine) return this.scopes[i].routine; return null; }
    newLabel(pfx) { return `${pfx}${++this.labelN}`; }
    // ----- constantes
    emitConstExpr(e) { return this.expr(e).c; }

    // ======================================================== expressões
    expr(e) {
      switch (e.k) {
        case 'num': {
          if (e.hex) { const v = e.v; return R(v > 0x7fffffff ? String(v) : '&H' + v.toString(16).toUpperCase() + '&', T.long); }
          if (e.float) return R(e.raw, T.dbl);
          return R(String(e.v), Math.abs(e.v) > 2147483647 ? T.dbl : T.long);
        }
        case 'str': return this.strLit(e.pieces);
        case 'nil': return R('Nothing', T.obj);
        case 'paren': { const r = this.expr(e.a); return R(r.c, r.t, r.p, { paren: true, inner: r }); }
        case 'neg': { const a = this.expr(e.a); return R('-' + wrap(a, PREC.neg), a.t, PREC.neg); }
        case 'not': { const a = this.expr(e.a); return R('Not ' + wrap(a, PREC.not + 1), a.t && a.t.vb === 'Boolean' ? T.bool : a.t, PREC.not); }
        case 'addr': return this.expr(e.a);
        case 'bin': return this.binary(e);
        case 'is': { const a = this.expr(e.a); const vbT = this.vbClassName(e.type); return R(`TypeOf ${wrap(a, PREC.atom)} Is ${vbT}`, T.bool, PREC.cmp); }
        case 'as': return this.expr(e.a);
        case 'set': { const items = e.items.map(it => it.value ? this.expr(it.value).c : `${this.expr(it.range[0]).c}..${this.expr(it.range[1]).c}`); this.warn(`set constructor [${items.join(', ')}] was converted to an array (Delphi sets are not supported)`); return R(`Array(${e.items.filter(i => i.value).map(i => this.expr(i.value).c).join(', ')})`, T.var); }
        case 'fmtw': { const a = this.expr(e.a); if (e.d) return R(`Format$(${a.c}, "0.${'0'.repeat(Math.max(0, Number(this.expr(e.d).c) || 0))}")`, T.str); return a; }
        case 'inheritedExpr': return R('0', T.var);
        case 'id': case 'mem': case 'index': case 'call': return this.desig(e, false);
        case 'arrlit': return R(`Array(${e.items.map(i => this.expr(i).c).join(', ')})`, T.var);
        case 'anon': this.warn('anonymous methods are not converted'); this.report.todo++; return R(`Nothing ' [Delphi] anonymous method`, T.obj);
      }
      return R(`0 ' [Delphi] ?`, T.var);
    }
    vbClassName(tn) { const l = String(tn).toLowerCase().replace(/^.*\./, ''); const f = this.P.formByClass.get(l); if (f) return f.name; const uc = this.P.classes.get(l); if (uc) return uc.vbName; const m = { tbutton: 'CommandButton', tbitbtn: 'CommandButton', tspeedbutton: 'CommandButton', tedit: 'TextBox', tmemo: 'TextBox', tlabel: 'Label', tcheckbox: 'CheckBox', tradiobutton: 'OptionButton', tlistbox: 'ListBox', tcombobox: 'ComboBox', tpanel: 'PictureBox', tgroupbox: 'Frame', timage: 'Image', ttimer: 'Timer', tmenuitem: 'Menu', tform: 'Form', tstringlist: 'TStringList', tstrings: 'TStringList' }; return m[l] || 'Object'; }
    strLit(pieces) {
      const parts = []; let buf = null;
      const flush = () => { if (buf != null) { parts.push(vbStr(buf)); buf = null; } };
      for (let i = 0; i < pieces.length; i++) {
        const [k, v] = pieces[i];
        if (k === 's') { buf = (buf || '') + v; continue; }
        if (v === 13 && pieces[i + 1] && pieces[i + 1][0] === 'c' && pieces[i + 1][1] === 10) { flush(); parts.push('vbCrLf'); i++; continue; }
        flush();
        parts.push(v === 13 ? 'vbCr' : v === 10 ? 'vbLf' : v === 9 ? 'vbTab' : v === 0 ? 'vbNullChar' : (v >= 32 && v < 127 && v !== 34) ? vbStr(String.fromCharCode(v)) : `Chr$(${v})`);
      }
      flush();
      if (!parts.length) return R('""', T.str);
      if (parts.length === 1) return R(parts[0], { vb: 'String', charT: pieces.length === 1 && ((pieces[0][0] === 's' && pieces[0][1].length === 1) || pieces[0][0] === 'c') });
      return R(parts.join(' & '), T.str, PREC.cat);
    }
    binary(e) {
      const op = e.op;
      if (op === 'in' || op === 'notin') {
        const a = this.expr(e.a);
        let r = this.inSet(a, e.b);
        if (op === 'notin') r = R('Not ' + wrap(r, PREC.not + 1), T.bool, PREC.not);
        return r;
      }
      // comparação com nil
      if ((op === '=' || op === '<>') && (e.b.k === 'nil' || e.a.k === 'nil')) {
        const x = this.expr(e.b.k === 'nil' ? e.a : e.b);
        return op === '=' ? R(`${wrap(x, PREC.atom)} Is Nothing`, T.bool, PREC.cmp) : R(`Not ${wrap(x, PREC.atom)} Is Nothing`, T.bool, PREC.not);
      }
      const a = this.expr(e.a), b = this.expr(e.b);
      const map = { '+': ['+', PREC.add], '-': ['-', PREC.add], '*': ['*', PREC.mul], '/': ['/', PREC.mul], div: ['\\', PREC.idiv], mod: ['Mod', PREC.mod], and: ['And', PREC.and], or: ['Or', PREC.or], xor: ['Xor', PREC.xor], '=': ['=', PREC.cmp], '<>': ['<>', PREC.cmp], '<': ['<', PREC.cmp], '>': ['>', PREC.cmp], '<=': ['<=', PREC.cmp], '>=': ['>=', PREC.cmp] };
      if (op === 'shl') return R(`(${wrap(a, PREC.mul)} * 2 ^ ${wrap(b, PREC.pow + 1)})`, T.long);
      if (op === 'shr') return R(`(${wrap(a, PREC.idiv)} \\ 2 ^ ${wrap(b, PREC.pow + 1)})`, T.long);
      let [vop, prec] = map[op] || [op, PREC.cmp];
      let t = null;
      if (op === '+' && (isStrT(a.t) || isStrT(b.t))) { vop = '&'; prec = PREC.cat; t = T.str; }
      else if (['=', '<>', '<', '>', '<=', '>='].includes(op)) t = T.bool;
      else if (['and', 'or', 'xor'].includes(op)) t = (a.t && a.t.vb === 'Boolean') || (b.t && b.t.vb === 'Boolean') ? T.bool : T.long;
      else if (op === '/') t = T.dbl;
      else if (op === 'div' || op === 'mod') t = T.long;
      else t = isNumT(a.t) && isNumT(b.t) ? (a.t.vb === 'Double' || b.t.vb === 'Double' ? T.dbl : a.t) : (a.t || b.t);
      // operadores lógicos: VB compara em precedência diferente; parênteses explícitos
      const left = (['and', 'or', 'xor'].includes(op)) ? (a.p < PREC.atom && a.p !== prec ? `(${a.c})` : a.c) : wrap(a, prec);
      const right = (['and', 'or', 'xor'].includes(op)) ? (b.p < PREC.atom && b.p !== prec ? `(${b.c})` : b.c) : wrap(b, prec + 1);
      return R(`${left} ${vop} ${right}`, t, prec);
    }
    inSet(a, setE) {
      // x in [a, b, 'c'..'f'] -> comparações
      if (setE.k === 'set') {
        const conds = setE.items.map(it => {
          if (it.value) {
            const v = this.expr(it.value); const vl = (it.value.k === 'id') ? it.value.name.toLowerCase() : '';
            if (/^ss(shift|ctrl|alt)$/.test(vl)) return null;
            return `${wrap(a, PREC.cmp + 1)} = ${wrap(v, PREC.cmp + 1)}`;
          }
          const lo = this.expr(it.range[0]), hi = this.expr(it.range[1]);
          return `(${wrap(a, PREC.cmp + 1)} >= ${wrap(lo, PREC.cmp + 1)} And ${wrap(a, PREC.cmp + 1)} <= ${wrap(hi, PREC.cmp + 1)})`;
        }).filter(Boolean);
        if (!conds.length) return R('False', T.bool);
        return R(conds.length === 1 ? conds[0] : conds.map(c => c.startsWith('(') ? c : `(${c})`).join(' Or '), T.bool, conds.length === 1 ? PREC.cmp : PREC.or);
      }
      // ssShift in Shift
      const av = a.c.toLowerCase();
      if (/^ss(shift|ctrl|alt)$/.test(av)) { const b = this.expr(setE); return R(`(${b.c} And ${a.c}) <> 0`, T.bool, PREC.cmp); }
      // fsBold in Font.Style
      const fsm = { fsbold: 'Bold', fsitalic: 'Italic', fsunderline: 'Underline', fsstrikeout: 'Strikethrough' };
      if (fsm[av] && (setE.k === 'mem' && setE.name.toLowerCase() === 'style')) { const fontR = this.expr(setE.obj); return R(`${fontR.c}.${fsm[av]}`, T.bool); }
      const b = this.expr(setE);
      this.warn(`'${a.c} in ${b.c}' uses a Delphi set and was converted as a bit test`);
      return R(`(${b.c} And ${a.c}) <> 0`, T.bool, PREC.cmp);
    }

    // ======================================================== designadores
    // devolve nó "plano": base id + cadeia de passos
    flatten(e) {
      const steps = [];
      while (e.k === 'mem' || e.k === 'index' || e.k === 'call') {
        if (e.k === 'mem') { steps.unshift({ k: 'mem', name: e.name }); e = e.obj; }
        else if (e.k === 'index') { steps.unshift({ k: 'index', idx: e.idx }); e = e.obj; }
        else { steps.unshift({ k: 'call', args: e.args }); e = e.fn; }
      }
      return { base: e, steps };
    }
    // resolve identificador isolado
    resolveId(name) {
      const l = name.toLowerCase();
      // with: membro conhecido do objeto
      for (let i = this.withStack.length - 1; i >= 0; i--) {
        const w = this.withStack[i];
        if (this.hasMember(w.t, l)) return { k: 'withmem', w, name };
      }
      const loc = this.lookupLocal(l);
      if (loc) return { k: 'local', v: loc };
      if (this.form) {
        const ctl = this.form.controls.get(l);
        if (ctl && ctl.kind !== 'data' && ctl.kind !== 'unknown' && ctl.kind !== 'action' && ctl.kind !== 'actionlist') return { k: 'ctl', ctl };
        if (ctl && ctl.kind === 'data') return { k: 'data', ctl };
      }
      if (this.fields.has(l)) return { k: 'field', v: this.fields.get(l) };
      if (this.methods.has(l)) return { k: 'method', m: this.methods.get(l) };
      if (this.unitSyms.has(l)) return { k: 'sym', s: this.unitSyms.get(l) };
      const f = this.P.forms.get(l); if (f) return { k: 'form', form: f };
      const fc = this.P.formByClass.get(l); if (fc) return { k: 'formclass', form: fc };
      const uc = this.P.classes.get(l); if (uc) return { k: 'class', cls: uc };
      const g = this.P.globals.get(l); if (g) return { k: 'sym', s: g };
      if (this.form && FORM_MEMBERS.has(l)) return { k: 'formmem', name };
      if (this.curClass) { const cf = this.curClass.fieldMap && this.curClass.fieldMap.get(l); if (cf) return { k: 'field', v: cf }; }
      // with sem tipo conhecido: o que não existe vira membro
      if (this.withStack.length && !BUILTIN_NAMES.has(l) && !COMPAT_CONSTS.has(l) && !/^(true|false|mr|mb|mt|vk_|cl|fs|cr|ss|bs|po|ws|ta|al|sb|rf)/.test(l)) {
        const w = this.withStack[this.withStack.length - 1];
        if (!w.t || !w.t.ctlKind) return { k: 'withmem', w, name };
      }
      return { k: 'unknown', name };
    }
    hasMember(t, l) {
      if (!t) return false;
      if (t.rec) return t.rec.fieldMap.has(l);
      if (t.ucls) return t.ucls.memberSet.has(l);
      if (t.form) return FORM_MEMBERS.has(l) || t.form.controls.has(l);
      if (t.ctlKind || t.ctl) return CTL_MEMBERS.has(l) || (KIND_MEMBERS[(t.ctl && t.ctl.kind) || t.ctlKind] || new Set()).has(l);
      if (t.cls === 'strings') return STRINGS_MEMBERS.has(l);
      return false;
    }
    // código e tipo para um identificador base
    baseCode(name, asCallee) {
      const r = this.resolveId(name);
      const l = name.toLowerCase();
      switch (r.k) {
        case 'withmem': return R(`${r.w.simple ? r.w.c : ''}.${this.memberName(r.w.t, name)}`, this.memberType(r.w.t, l), PREC.atom, { withBase: r.w });
        case 'local': return R(r.v.vbName, r.v.type, PREC.atom, { local: r.v });
        case 'ctl': return R(r.ctl.name, { vb: 'Object', obj: true, ctl: r.ctl, ctlKind: r.ctl.kind });
        case 'data': this.warn(`database component ${r.ctl.name} (${r.ctl.vcl}) is used in code; database support for Delphi projects is not converted yet`); this._usedData = true; return R(r.ctl.name, T.obj);
        case 'field': return R(r.v.vbName, r.v.type, PREC.atom, { field: r.v });
        case 'method': return R(r.m.vbName, r.m.retType || null, PREC.atom, { routine: r.m });
        case 'sym': return R(r.s.vbName, r.s.type || null, PREC.atom, r.s.kind === 'routine' ? { routine: r.s } : { sym: r.s });
        case 'form': return R(r.form.name, { vb: r.form.name, obj: true, form: r.form });
        case 'formclass': return R(r.form.name, { vb: r.form.name, obj: true, form: r.form, isClassRef: true });
        case 'class': return R(r.cls.vbName, { vb: r.cls.vbName, obj: true, ucls: r.cls, isClassRef: true });
        case 'formmem': return R('Me', { vb: 'Object', obj: true, form: this.form, self: true }, PREC.atom, { implicitMe: name });
      }
      // constantes e nomes conhecidos
      if (l === 'self') return R(this.form || (this.curClass && this.curClass.isClass) ? 'Me' : 'Me', this.form ? { vb: 'Object', obj: true, form: this.form, self: true } : (this.curClass ? { vb: this.curClass.vbName, obj: true, ucls: this.curClass } : T.obj));
      if (l === 'true' || l === 'false') return R(l === 'true' ? 'True' : 'False', T.bool);
      if (l === 'result') { const rt = this.curRoutine; if (rt && rt.isFunc) return R('Result', rt.retType); }
      if (l === 'application') return R('App', { vb: 'Object', obj: true, app: true });
      if (l === 'screen') return R('Screen', { vb: 'Object', obj: true, screen: true });
      if (l === 'sender') return R('Sender', T.obj);
      if (l === 'pi') return R('(4 * Atn(1))', T.dbl);
      if (l === 'maxint' || l === 'high(integer)') return R('2147483647', T.long);
      if (l === 'emptystr') return R('""', T.str);
      if (l === 'slinebreak') return R('vbCrLf', T.str);
      if (l === 'pathdelim') return R('"\\"', T.str);
      if (/^(mb|mt)[a-z]/.test(l)) { const v = MSG_CONST[l]; if (v != null) return R(String(v), T.long); }
      if (/^cl[a-z]/.test(l) && D.colorIdentVB(l)) return R(D.colorIdentVB(l), T.long);
      if (WS_CONST[l] != null) return R(String(WS_CONST[l]), T.long);
      const enumItem = this.P.enumItems.get(l); if (enumItem) return R(enumItem.vbName, T.long);
      return R(name, null, PREC.atom, { unknown: true });
    }
    memberName(t, name) {
      const l = name.toLowerCase();
      if (t && (t.ctlKind || t.ctl || t.form)) { const m = PROP_RENAME[l]; if (m) return m; }
      if (t && t.rec) { const f = t.rec.fieldMap.get(l); if (f) return f.vbName; }
      return name;
    }
    memberType(t, l) {
      if (!t) return null;
      if (t.rec) { const f = t.rec.fieldMap.get(l); return f ? f.type : null; }
      if (t.ucls) { const m = t.ucls.members.get(l); return m ? m.type : null; }
      if (t.form) { const c = t.form.controls.get(l); if (c) return { vb: 'Object', obj: true, ctl: c, ctlKind: c.kind }; if (t.self && this.fields.has(l)) return this.fields.get(l).type; }
      return PROP_TYPES[l] || null;
    }
    // ----- designador completo (expressão)
    desig(e, stmt) {
      const { base, steps } = this.flatten(e);
      let cur;
      let i = 0;
      if (base.k === 'id' && base.name === '__with__' && this._withObj) { const w = this._withObj; this._withObj = null; let cur0 = R(w.c, w.t); return this.desigFrom(cur0, steps, stmt); }
      if (base.k === 'id') { const rw = this.resolveId(base.name); if (rw.k === 'withmem' && rw.w.simple) { const ex = this.rebase([{ k: 'mem', name: '__with__' }, { k: 'mem', name: base.name }, ...steps]); this._withObj = rw.w; try { return this.desig(ex, stmt); } finally { this._withObj = null; } } }
      if (base.k === 'id' && this.resolveId(base.name).k === 'formmem' && !this.builtinName(base.name.toLowerCase())) return this.desig(this.rebase([{ k: 'mem', name: 'Self' }, { k: 'mem', name: base.name }, ...steps].map((x, j) => j === 0 ? { k: 'mem', name: 'Self' } : x)), stmt);
      if (base.k !== 'id') { cur = this.expr(base); }
      else {
        const bl = base.name.toLowerCase();
        // chamadas de funções conhecidas
        if (steps.length && steps[0].k === 'call') {
          const r0 = this.resolveId(base.name);
          if (r0.k === 'unknown' || (r0.k === 'formmem') || (r0.k === 'sym' && r0.s.builtinOverride)) {
            const b = this.builtin(bl, steps[0].args, stmt);
            if (b) { cur = b; i = 1; }
          }
          // conversão de tipo: Integer(x), string(x), TButton(Sender)
          if (!cur && r0.k !== 'local' && r0.k !== 'method' && r0.k !== 'sym' && steps[0].args.length === 1) {
            const cast = this.typeCast(bl, steps[0].args[0]);
            if (cast) { cur = cast; i = 1; }
          }
          if (!cur && (r0.k === 'formclass' || r0.k === 'class') && false) { /* nada */ }
        }
        if (!cur && !steps.length) { const b = this.builtin(bl, [], stmt, true); if (b && this.resolveId(base.name).k === 'unknown') return b; }
        if (!cur && steps.length && steps[0].k === 'mem' && this.resolveId(base.name).k === 'unknown') {
          // Unit.Name -> Name
          const ul = bl; if (this.P.unitNames.has(ul) || /^(system|sysutils|classes|forms|dialogs|controls|windows|math|strutils|dateutils|graphics|vcl|winapi)$/.test(ul)) { return this.desig(this.rebase(steps), stmt); }
        }
        if (!cur) cur = this.baseCode(base.name, steps.length && steps[0].k === 'call');
      }
      return this.desigFrom(cur, steps.slice(i), stmt);
    }
    desigFrom(cur, steps, stmt) {
      for (let i = 0; i < steps.length; i++) {
        const s = steps[i];
        const nxt = steps[i + 1];
        if (s.k === 'mem') {
          const isCall = nxt && nxt.k === 'call';
          const args = isCall ? nxt.args : null;
          const isIdx = nxt && nxt.k === 'index';
          const rest = steps.slice(i + 1);
          const m = this.member(cur, s.name, args, stmt, isIdx ? nxt.idx : null, rest, stmt && (i + (isCall ? 2 : 1)) === steps.length);
          if (m) { cur = m.r; i += m.used; continue; }
          cur = R(`${wrap(cur, PREC.atom)}.${this.memberName(cur.t, s.name)}`, this.memberType(cur.t, s.name.toLowerCase()), PREC.atom, { prevObj: cur });
        } else if (s.k === 'index') {
          const idx = s.idx.map(x => this.expr(x).c);
          if (isStrT(cur.t) && !cur.t.arr) { cur = R(`Mid$(${cur.c}, ${idx[0]}, 1)`, { vb: 'String', charT: true }, PREC.atom, { strIndex: { s: cur, i: idx[0] } }); continue; }
          if (cur.t && cur.t.cls === 'strings') { cur = R(`${wrap(cur, PREC.atom)}.Item(${idx.join(', ')})`, T.str); continue; }
          if (cur.t && cur.t.arr) { const of = cur.t.arr.of; cur = R(`${cur.c}(${idx.join(', ')})`, of); continue; }
          if (cur.withBase && cur.c.startsWith('.')) { cur = R(`${cur.c}(${idx.join(', ')})`, null); continue; }
          cur = R(`${cur.c}(${idx.join(', ')})`, null);
        } else if (s.k === 'call') {
          const args = s.args.map(a => this.argExpr(a, cur));
          if (cur.isClassCtor) continue;
          const t = cur.routine ? cur.routine.retType : (cur.t || null);
          cur = R(`${cur.c}(${args.join(', ')})`, t, PREC.atom, { call: { callee: cur.c, args }, routine: cur.routine });
        }
      }
      return cur;
    }
    builtinName(l) { return ['close', 'show', 'hide'].includes(l) ? false : false; }
    rebase(steps) { let e = { k: 'id', name: steps[0].name }; for (const s of steps.slice(1)) { if (s.k === 'mem') e = { k: 'mem', obj: e, name: s.name }; else if (s.k === 'index') e = { k: 'index', obj: e, idx: s.idx }; else e = { k: 'call', fn: e, args: s.args }; } return e; }
    // argumento: Items de lista passado como objeto vira NBItems(...)
    argExpr(a, callee) {
      const r = this.expr(a);
      return r.c;
    }
    typeCast(l, arg) {
      const a = () => this.expr(arg);
      switch (l) {
        case 'integer': case 'longint': case 'cardinal': case 'word': case 'byte': case 'smallint': case 'int64': case 'nativeint': case 'longword': { const x = a(); if (isStrT(x.t) && x.t.charT) return R(`Asc(${x.c})`, T.long); return R(`CLng(${x.c})`, T.long); }
        case 'string': case 'ansistring': case 'widestring': case 'unicodestring': case 'pchar': case 'pansichar': case 'pwidechar': case 'utf8string': return R(`CStr(${a().c})`, T.str);
        case 'char': case 'ansichar': case 'widechar': return R(`Chr$(${a().c})`, { vb: 'String', charT: true });
        case 'boolean': return R(`CBool(${a().c})`, T.bool);
        case 'double': case 'extended': case 'real': return R(`CDbl(${a().c})`, T.dbl);
        case 'single': return R(`CSng(${a().c})`, T.dbl);
        case 'currency': return R(`CCur(${a().c})`, T.cur);
        case 'tdatetime': case 'tdate': return R(`CDate(${a().c})`, T.date);
        case 'variant': return a();
        case 'pointer': return a();
      }
      if (/^t[a-z]/.test(l) && (VCL_KIND[l] || this.P.formByClass.has(l) || this.P.classes.has(l) || l === 'tobject' || l === 'tcomponent' || l === 'tcontrol' || l === 'twincontrol' || l === 'tstrings' || l === 'tstringlist')) { const x = a(); const t = this.typeOf({ name: l }); return R(x.c, Object.assign({}, t, { ctl: x.t && x.t.ctl }), x.p); }
      return null;
    }
    // ----- membros especiais (VCL)
    member(obj, name, args, stmtAll, idx, rest, stmtHere) {
      const stmt = stmtHere;
      const l = name.toLowerCase();
      const t = obj.t || {};
      const o = wrap(obj, PREC.atom);
      const kind = (t.ctl && t.ctl.kind) || t.ctlKind || (t.form ? 'form' : null);
      const used = (args ? 1 : 0);
      const A = () => (args || []).map(x => this.expr(x).c);
      const ret = (c, ty, u, extra) => ({ r: R(c, ty, PREC.atom, extra), used: u == null ? used : u });
      // construtores
      const ctorName = t.ucls && t.ucls.ctor ? t.ucls.ctor.name.toLowerCase() : 'create';
      if (t.isClassRef && t.ucls && (l === ctorName || l === 'create')) { const as = A(); return { r: R(t.ucls.ctor || as.length ? `NBNew_${t.ucls.vbName}(${as.join(', ')})` : `New ${t.ucls.vbName}`, { vb: t.ucls.vbName, obj: true, ucls: t.ucls }), used }; }
      if (!t.isClassRef && stmt && !args && ((t.ucls && t.ucls.dtorName === l) || (!t.form && !t.ctl && [...this.P.classes.values()].some(c => c.dtorName === l)))) return { r: R(`Set ${obj.c} = Nothing`, null, PREC.atom, { rawStmt: true }), used };
      if (!t.isClassRef && t.ucls && t.ucls.ctor && l === ctorName) return { r: R(`' [Delphi] ${obj.c}.${t.ucls.ctor.name}`, null, PREC.atom, { rawStmt: true }), used };
      if (l === 'create' && t.isClassRef) {
        if (t.form) return { r: R(`New ${t.form.name}`, { vb: t.form.name, obj: true, form: t.form }, PREC.atom, { newForm: t.form }), used };
        if (t.ucls) { const ctor = t.ucls.ctor; const as = A(); return { r: R(ctor || as.length ? `NBNew_${t.ucls.vbName}(${as.join(', ')})` : `New ${t.ucls.vbName}`, { vb: t.ucls.vbName, obj: true, ucls: t.ucls }), used }; }
      }
      if (l === 'create' && /^tstring(list|s)$/i.test(obj.c)) return { r: R('New TStringList', { vb: 'TStringList', obj: true, cls: 'strings' }), used };
      if (l === 'create' && /^t[a-z]+$/i.test(obj.c) && obj.unknown) {
        const cl = obj.c.toLowerCase();
        if (cl === 'tstringlist' || cl === 'tstrings') return { r: R('New TStringList', { vb: 'TStringList', obj: true, cls: 'strings' }), used };
        if (cl === 'exception' || /^e[a-z]+$/.test(cl)) return { r: R(A()[0] || '""', T.str, PREC.atom, { exceptionMsg: true }), used };
        if (cl === 'tlist' || cl === 'tobjectlist' || /^tlist/.test(cl) || /^tobjectlist/.test(cl) || /^tdictionary/.test(cl)) return { r: R('New Collection', { vb: 'Collection', obj: true, coll: true }), used };
        this.warn(`${obj.c}.Create: the class ${obj.c} is not available in NeoBasic`);
        return { r: R(`Nothing ' [Delphi] ${obj.c}.Create`, T.obj), used };
      }
      if (/^(exception|e[a-z]+)$/i.test(obj.c) && obj.unknown && (l === 'createfmt')) { const as = A(); return { r: R(`NBFormat(${as[0]}, ${as[1] || '""'})`, T.str, PREC.atom, { exceptionMsg: true }), used }; }
      // Free / Destroy
      if (l === 'free' || l === 'destroy' || l === 'disposeof') { if (stmt) return { r: R(t.form || t.ctl ? `' [Delphi] ${obj.c}.Free` : `Set ${obj.c} = Nothing`, null, PREC.atom, { rawStmt: true }), used }; }
      // Application / Screen
      if (t.app) {
        switch (l) {
          case 'processmessages': return ret('DoEvents', null);
          case 'terminate': return ret('End', null, used, { rawStmt: true });
          case 'title': return ret('App.Title', T.str);
          case 'exename': return ret('(App.Path & "\\" & App.EXEName)', T.str);
          case 'mainform': return ret(this.P.mainForm || 'Forms(0)', T.obj);
          case 'messagebox': { const as = A(); return ret(`MsgBox(${as[0]}, ${as[2] || '0'}, ${as[1] || 'App.Title'})`, T.long); }
          case 'createform': case 'initialize': case 'run': return ret("' [Delphi] Application." + name, null, used, { rawStmt: true });
          case 'hint': case 'showhint': case 'hintpause': case 'onexception': case 'helpfile': case 'icon': case 'mainformontaskbar': return ret("App.Comments", T.str);
          case 'minimize': return ret(`' [Delphi] Application.Minimize`, null, used, { rawStmt: true });
        }
      }
      if (t.screen) {
        if (l === 'cursor') return ret('Screen.MousePointer', T.long);
        if (l === 'width') return ret('(Screen.Width / 15)', T.long);
        if (l === 'height') return ret('(Screen.Height / 15)', T.long);
        if (l === 'activeform') return ret('Screen.ActiveForm', T.obj);
        if (l === 'activecontrol') return ret('Screen.ActiveControl', T.obj);
      }
      // TStrings (TStringList, Items, Lines)
      if (t.cls === 'strings') {
        if (l === 'strings' && idx) return { r: R(`${o}.Item(${idx.map(x => this.expr(x).c).join(', ')})`, T.str), used: 1 };
        if (l === 'objects' && idx) return { r: R(`${o}.Objects(${idx.map(x => this.expr(x).c).join(', ')})`, T.var), used: 1 };
        if (l === 'count') return ret(`${o}.Count`, T.long);
        if (l === 'text') return ret(`${o}.Text`, T.str);
        if (l === 'names' && idx) return { r: R(`${o}.Names(${this.expr(idx[0]).c})`, T.str), used: 1 };
        if (l === 'values' && idx) return { r: R(`${o}.Values(${this.expr(idx[0]).c})`, T.str), used: 1 };
      }
      // listas (ListBox/ComboBox)
      if (kind === 'list' || kind === 'combo') {
        if (l === 'items') {
          const nx = rest[0];
          const nx2 = rest[1];
          if (nx && nx.k === 'index') return { r: R(`${o}.List(${nx.idx.map(x => this.expr(x).c).join(', ')})`, T.str), used: 1 };
          if (nx && nx.k === 'mem') {
            const m2 = nx.name.toLowerCase(); const a2 = nx2 && nx2.k === 'call' ? nx2.args.map(x => this.expr(x).c) : null; const u2 = 1 + (a2 ? 1 : 0);
            const isLast = rest.length === u2;
            switch (m2) {
              case 'add': case 'append': if (stmtAll && isLast) return { r: R(`${o}.AddItem ${a2[0]}`, null, PREC.atom, { rawStmt: true }), used: u2 }; return { r: R(`NBItems(${obj.c}).Add(${a2[0]})`, T.long), used: u2 };
              case 'addobject': if (stmtAll && isLast) return { r: R(`${o}.AddItem ${a2[0]}`, null, PREC.atom, { rawStmt: true }), used: u2 }; return { r: R(`NBItems(${obj.c}).Add(${a2[0]})`, T.long), used: u2 };
              case 'insert': return { r: R(`${o}.AddItem ${a2[1]}, ${a2[0]}`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'delete': return { r: R(`${o}.RemoveItem ${a2[0]}`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'clear': return { r: R(`${o}.Clear`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'count': return { r: R(`${o}.ListCount`, T.long), used: 1 };
              case 'indexof': return { r: R(`NBListIndexOf(${obj.c}, ${a2[0]})`, T.long), used: u2 };
              case 'strings': if (nx2 && nx2.k === 'index') return { r: R(`${o}.List(${nx2.idx.map(x => this.expr(x).c).join(', ')})`, T.str), used: 2 }; break;
              case 'objects': if (nx2 && nx2.k === 'index') return { r: R(`${o}.ItemData(${nx2.idx.map(x => this.expr(x).c).join(', ')})`, T.long), used: 2 }; break;
              case 'beginupdate': case 'endupdate': return { r: R(`' [Delphi] ${obj.c}.Items.${nx.name}`, null, PREC.atom, { rawStmt: true }), used: u2 };
            }
            return { r: R(`NBItems(${obj.c})`, { vb: 'TStringsCtl', obj: true, cls: 'strings' }), used: 0 };
          }
          return { r: R(`NBItems(${obj.c})`, { vb: 'TStringsCtl', obj: true, cls: 'strings' }), used: 0 };
        }
        if (l === 'itemindex') return ret(`${o}.ListIndex`, T.long);
        if (l === 'selected' && idx) { const ix = idx.map(x => this.expr(x).c).join(', '); return { r: R(`${o}.Selected(${ix})`, T.bool, PREC.atom, { setter: v => `NBListSelect ${obj.c}, ${ix}, ${v}` }), used: 1 }; }
        if (l === 'checked' && idx) return { r: R(`${o}.Selected(${idx.map(x => this.expr(x).c).join(', ')})`, T.bool), used: 1 };
        if (l === 'clear') return ret(`${o}.Clear`, null, used, { rawStmt: true });
        if (l === 'count') return ret(`${o}.ListCount`, T.long);
        if (l === 'selcount') return ret(`${o}.SelCount`, T.long);
        if (l === 'sorted') return ret(`${o}.Sorted`, T.bool);
        if (l === 'text') return ret(`${o}.Text`, T.str);
        if (l === 'itemheight' || l === 'dropdowncount' || l === 'style' || l === 'columns' || l === 'multiselect') return ret(`${o}.Tag`, T.long);
      }
      // memo / rich
      if (kind === 'memo' || kind === 'rich') {
        if (l === 'lines') {
          const nx = rest[0], nx2 = rest[1];
          if (nx && nx.k === 'index') return { r: R(`NBMemoLine(${obj.c}, ${this.expr(nx.idx[0]).c})`, T.str), used: 1 };
          if (nx && nx.k === 'mem') {
            const m2 = nx.name.toLowerCase(); const a2 = nx2 && nx2.k === 'call' ? nx2.args.map(x => this.expr(x).c) : null; const u2 = 1 + (a2 ? 1 : 0);
            switch (m2) {
              case 'add': case 'append': if (stmtAll && rest.length === u2) return { r: R(`NBMemoAdd ${obj.c}, ${a2[0]}`, null, PREC.atom, { rawStmt: true }), used: u2 }; break;
              case 'clear': return { r: R(`${o}.Text = ""`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'text': return { r: R(`${o}.Text`, T.str), used: 1 };
              case 'count': return { r: R(`NBMemoCount(${obj.c})`, T.long), used: 1 };
              case 'loadfromfile': return { r: R(`${o}.Text = NBLoadText(${a2[0]})`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'savetofile': return { r: R(`NBSaveText ${a2[0]}, ${o}.Text`, null, PREC.atom, { rawStmt: true }), used: u2 };
              case 'beginupdate': case 'endupdate': return { r: R(`' [Delphi] ${obj.c}.Lines.${nx.name}`, null, PREC.atom, { rawStmt: true }), used: u2 };
            }
          }
          return { r: R(`NBLines(${obj.c})`, { vb: 'TStringsCtl', obj: true, cls: 'strings' }), used: 0 };
        }
        if (l === 'clear') return ret(`${o}.Text = ""`, null, used, { rawStmt: true });
        if (l === 'wordwrap' || l === 'scrollbars' || l === 'wantreturns' || l === 'wanttabs') return ret(`${o}.Tag`, T.var);
      }
      if (kind === 'edit' || kind === 'memo' || kind === 'rich' || kind === 'combo') {
        if (l === 'clear') return ret(`${o}.Text = ""`, null, used, { rawStmt: true });
        if (l === 'readonly') return ret(`${o}.Locked`, T.bool);
        if (l === 'selectall') return ret(`${o}.SelStart = 0: ${o}.SelLength = Len(${o}.Text)`, null, used, { rawStmt: true });
        if (l === 'value' && t.ctl && /spinedit|numberbox/.test(t.ctl.vcl)) return ret(`Val(${o}.Text)`, T.long, used, { setter: v => `${o}.Text = CStr(${v})` });
        if (l === 'charcase' || l === 'numbersonly' || l === 'texthint' || l === 'autoselect') return ret(`${o}.Tag`, T.var);
      }
      if (kind === 'date') {
        if (l === 'date' || l === 'datetime' || l === 'time') return ret(`${o}.Value`, T.date);
      }
      if (kind === 'check') {
        if (l === 'checked') return ret(`(${o}.Value = 1)`, T.bool, used, { setter: v => `${o}.Value = IIf(${v}, 1, 0)` });
        if (l === 'state') return ret(`${o}.Value`, T.long);
      }
      if (kind === 'radio' && l === 'checked') return ret(`${o}.Value`, T.bool);
      if (kind === 'radiogroup' || (t.ctl && t.ctl.optName)) {
        const opt = t.ctl && t.ctl.optName;
        if (opt && l === 'itemindex') return ret(`NBOptIndex(${opt})`, T.long, used, { setter: v => `NBSetOptIndex ${opt}, ${v}` });
        if (opt && l === 'items') { const nx = rest[0]; if (nx && nx.k === 'index') return { r: R(`${opt}(${this.expr(nx.idx[0]).c}).Caption`, T.str), used: 1 }; if (nx && nx.k === 'mem' && nx.name.toLowerCase() === 'count') return { r: R(`${opt}.Count`, T.long), used: 1 }; }
      }
      if ((kind === 'scrollbar' || kind === 'trackbar' || kind === 'progress') && l === 'position') return ret(`${o}.Value`, T.long);
      if (kind === 'panel' || kind === 'status') {
        const cap = t.ctl && t.ctl.capName;
        if (cap && (l === 'caption' || l === 'simpletext')) return ret(`${cap}.Caption`, T.str);
        if (kind === 'status' && l === 'panels') { const nx = rest[0], nx2 = rest[1]; if (nx && nx.k === 'index' && nx2 && nx2.k === 'mem') return { r: R(`${cap}.Caption`, T.str), used: 2 }; }
      }
      if (kind === 'pages' && t.ctl) {
        const pg = this.form && this.form.conv.pages.get(t.ctl.name.toLowerCase());
        if (pg) {
          if (l === 'activepageindex' || l === 'tabindex') return ret(`NBPage_${pg.name}`, T.long, used, { setter: v => `NBShowPage_${pg.name} ${v}` });
          if (l === 'activepage') return ret(`${pg.sheets.length ? pg.sheets[0] : 'Nothing'}`, T.obj, used, { setter: v => `NBShowPage_${pg.name} NBSheetIndex_${pg.name}(${v})` });
          if (l === 'pagecount') return ret(String(pg.sheets.length), T.long);
          if (l === 'pages' && idx) return { r: R(`${pg.sheets[0] || 'Nothing'}`, T.obj), used: 1 };
        }
      }
      if (kind === 'sheet' && t.ctl && t.ctl.pages) {
        if (l === 'tabvisible') return ret(`${t.ctl.pages}Tab(${t.ctl.index}).Visible`, T.bool);
        if (l === 'caption') return ret(`${t.ctl.pages}Tab(${t.ctl.index}).Caption`, T.str);
        if (l === 'pageindex') return ret(String(t.ctl.index), T.long);
      }
      if ((t.ctl && /dlg$/.test(t.ctl.kind)) || (t.ctl && t.ctl.vbType === 'MSComDlg.CommonDialog')) {
        const k = t.ctl.kind;
        if (l === 'execute') return ret(`NBDialogExecute(${obj.c}, "${k === 'savedlg' ? 'save' : k === 'colordlg' ? 'color' : k === 'fontdlg' ? 'font' : k === 'printdlg' ? 'print' : 'open'}")`, T.bool);
        if (l === 'title') return ret(`${o}.DialogTitle`, T.str);
        if (l === 'initialdir') return ret(`${o}.InitDir`, T.str);
        if (l === 'files') return ret(`${o}.FileName`, T.str);
      }
      if (kind === 'timer') { if (l === 'ontimer') return ret(`${o}.Enabled`, T.bool); }
      if (kind === 'menuitem' && l === 'click') return ret(`${obj.c}_Click`, null, used, { rawStmt: true });
      if (kind === 'button' && l === 'click') { const ev = this.form && this.form.conv.events.find(ev2 => ev2.ctl && ev2.ctl.toLowerCase() === obj.c.toLowerCase()); return ret(ev ? `${obj.c}_Click` : `' [Delphi] ${obj.c}.Click`, null, used, { rawStmt: true }); }
      // Font
      if (l === 'font' && rest[0] && rest[0].k === 'mem') {
        const f = rest[0].name.toLowerCase();
        if (f === 'color') return { r: R(`${o}.ForeColor`, T.long), used: 1 };
        if (f === 'style') return { r: R(`${o}.Font`, { vb: 'Object', obj: true, fontObj: true }, PREC.atom, { fontStyleOf: o }), used: 1 };
        if (f === 'size') return { r: R(`${o}.Font.Size`, T.dbl), used: 1 };
        if (f === 'name') return { r: R(`${o}.Font.Name`, T.str), used: 1 };
        if (f === 'height') return { r: R(`${o}.Font.Size`, T.dbl), used: 1 };
      }
      // formulário (Self, Form1, etc.)
      if (kind === 'form' || t.form) {
        const self = t.self;
        switch (l) {
          case 'close': return ret(`${o}.CloseForm`, null, used, { rawStmt: true });
          case 'release': return ret(`Unload ${o}`, null, used, { rawStmt: true });
          case 'showmodal': return ret(`${o}.ShowModal`, T.long, used, stmt ? { rawStmt: true } : {});
          case 'modalresult': return ret(`${o}.ModalResult`, T.long, used, { setter: v => `${o}.SetModalResult ${v}` });
          case 'clientwidth': return ret(`${o}.ScaleWidth`, T.long, used, { setter: v => `${o}.Width = ${o}.Width + ((${v}) - ${o}.ScaleWidth) * 15` });
          case 'clientheight': return ret(`${o}.ScaleHeight`, T.long, used, { setter: v => `${o}.Height = ${o}.Height + ((${v}) - ${o}.ScaleHeight) * 15` });
          case 'width': case 'height': case 'left': case 'top': { const P2 = name[0].toUpperCase() + l.slice(1); return ret(`(${o}.${P2} / 15)`, T.long, used, { setter: v => `${o}.${P2} = (${v}) * 15` }); }
          case 'mdichildcount': return ret('NBMDIChildCount()', T.long);
          case 'activemdichild': return ret(`${o}.ActiveForm`, T.obj);
          case 'cascade': return ret(`${o}.Arrange 0`, null, used, { rawStmt: true });
          case 'tile': return ret(`${o}.Arrange IIf(NB_TileMode = 0, 1, NB_TileMode)`, null, used, { rawStmt: true });
          case 'tilemode': return ret('NB_TileMode', T.long);
          case 'arrangeicons': return ret(`${o}.Arrange 3`, null, used, { rawStmt: true });
          case 'canvas': this.warn('Form.Canvas drawing is not converted yet'); return ret(`${o}`, T.obj);
          case 'position': case 'formstyle': case 'borderstyle': case 'borderwidth': case 'scaled': case 'alphablend': case 'alphablendvalue': case 'doublebuffered': case 'autoscroll': case 'pixelsperinch': return ret(`${o}.Tag`, T.var);
          case 'show': if (!args) return ret(`${o}.Show`, null, used, { rawStmt: true }); break;
          case 'hide': return ret(`${o}.Hide`, null, used, { rawStmt: true });
          case 'setfocus': return ret(`${o}.SetFocus`, null, used, { rawStmt: true });
          case 'bringtofront': return ret(`${o}.ZOrder 0`, null, used, { rawStmt: true });
          case 'invalidate': case 'repaint': case 'update': return ret(`${o}.Refresh`, null, used, { rawStmt: true });
          case 'perform': return ret(`' [Delphi] ${o}.Perform`, null, used, { rawStmt: true });
          case 'print': return ret(`${o}.PrintForm`, null, used, { rawStmt: true });
          case 'componentcount': case 'controlcount': return ret(`${o}.Controls.Count`, T.long);
          case 'components': case 'controls': if (idx) return { r: R(`${o}.Controls(${this.expr(idx[0]).c})`, T.obj), used: 1 }; return ret(`${o}.Controls`, T.obj);
        }
        if (t.form) { const c = t.form.controls.get(l); if (c && c.kind === 'data') { this._usedData = true; this.warn(`database component ${c.name} (${c.vcl}) is used in code; database support for Delphi projects is not converted yet`); } if (c && !self) return ret(`${o}.${c.name}`, { vb: 'Object', obj: true, ctl: c, ctlKind: c.kind }, 0); }
      }
      // controles em geral
      if (kind && kind !== 'form') {
        switch (l) {
          case 'show': return ret(`${o}.Visible = True`, null, used, { rawStmt: true });
          case 'hide': return ret(`${o}.Visible = False`, null, used, { rawStmt: true });
          case 'bringtofront': return ret(`${o}.ZOrder 0`, null, used, { rawStmt: true });
          case 'sendtoback': return ret(`${o}.ZOrder 1`, null, used, { rawStmt: true });
          case 'invalidate': case 'repaint': case 'update': return ret(`${o}.Refresh`, null, used, { rawStmt: true });
          case 'setbounds': { const as = A(); return ret(`${o}.Move ${as.join(', ')}`, null, used, { rawStmt: true }); }
          case 'canfocus': return ret(`(${o}.Enabled And ${o}.Visible)`, T.bool);
          case 'focused': return ret(`(Me.ActiveControl Is ${obj.c})`, T.bool);
          case 'perform': case 'beginupdate': case 'endupdate': return ret(`' [Delphi] ${obj.c}.${name}`, null, used, { rawStmt: true });
          case 'clientwidth': return ret(`${o}.Width`, T.long);
          case 'clientheight': return ret(`${o}.Height`, T.long);
          case 'showhint': case 'parentfont': case 'parentcolor': case 'transparent': case 'flat': case 'autosize': case 'layout': case 'glyph': case 'numglyphs': case 'kind': case 'images': case 'imageindex': case 'popupmenu': case 'align': case 'anchors': case 'constraints': case 'margins': case 'alignwithmargins': case 'doublebuffered': case 'bevelinner': case 'bevelouter': case 'bevelkind': case 'ctl3d': case 'parentshowhint': case 'stylename': case 'styleelements': return ret(`${o}.Tag`, T.var);
        }
      }
      // propriedades com outro nome
      const rn = PROP_RENAME[l];
      if (rn && (kind || t.form || t.ctlKind)) return ret(`${o}.${rn}`, PROP_TYPES[l] || null, 0);
      return null;
    }

    // ----- funções da RTL
    builtin(l, args, stmt, bare) {
      const A = () => args.map(x => this.expr(x));
      const C = () => A().map(x => x.c);
      const r = (c, t, p) => R(c, t, p);
      switch (l) {
        case 'inttostr': case 'floattostr': case 'currtostr': case 'booltostr': case 'vartostr': case 'uinttostr': { const a = A(); if (l === 'booltostr') return r(`IIf(${a[0].c}, ${a[1] && a[1].c === 'True' ? '"True"' : '"-1"'}, ${a[1] && a[1].c === 'True' ? '"False"' : '"0"'})`, T.str); return r(`CStr(${a[0].c})`, T.str); }
        case 'strtoint': case 'strtoint64': return r(`CLng(${C()[0]})`, T.long);
        case 'strtointdef': { const c = C(); return r(`NBStrToIntDef(${c[0]}, ${c[1]})`, T.long); }
        case 'trystrtoint': { const c = C(); return r(`NBTryStrToInt(${c[0]}, ${c[1]})`, T.bool); }
        case 'trystrtofloat': { const c = C(); return r(`NBTryStrToFloat(${c[0]}, ${c[1]})`, T.bool); }
        case 'strtofloat': case 'strtocurr': return r(`CDbl(${C()[0]})`, T.dbl);
        case 'strtofloatdef': case 'strtocurrdef': { const c = C(); return r(`NBStrToFloatDef(${c[0]}, ${c[1]})`, T.dbl); }
        case 'strtobool': return r(`CBool(${C()[0]})`, T.bool);
        case 'strtodate': case 'strtodatetime': case 'strtotime': case 'vartodatetime': return r(`CDate(${C()[0]})`, T.date);
        case 'inttohex': { const c = C(); return r(`NBIntToHex(${c[0]}, ${c[1] || 0})`, T.str); }
        case 'format': { const a = args; const f = this.expr(a[0]).c; const lst = a[1] ? (a[1].k === 'set' ? `Array(${a[1].items.map(i => this.expr(i.value).c).join(', ')})` : this.expr(a[1]).c) : 'Array()'; return r(`NBFormat(${f}, ${lst})`, T.str); }
        case 'formatfloat': case 'formatcurr': { const c = C(); return r(`Format$(${c[1]}, ${c[0]})`, T.str); }
        case 'formatdatetime': { const c = C(); return r(`Format$(${c[1]}, ${c[0]})`, T.str); }
        case 'datetostr': return r(`Format$(${C()[0]}, "Short Date")`, T.str);
        case 'timetostr': return r(`Format$(${C()[0]}, "hh:nn:ss")`, T.str);
        case 'datetimetostr': return r(`CStr(${C()[0]})`, T.str);
        case 'now': return r('Now', T.date);
        case 'date': if (!args.length) return r('Date', T.date); break;
        case 'time': case 'gettime': if (!args.length) return r('Time', T.date); break;
        case 'yearof': return r(`Year(${C()[0]})`, T.long);
        case 'monthof': return r(`Month(${C()[0]})`, T.long);
        case 'dayof': return r(`Day(${C()[0]})`, T.long);
        case 'hourof': return r(`Hour(${C()[0]})`, T.long);
        case 'minuteof': return r(`Minute(${C()[0]})`, T.long);
        case 'secondof': return r(`Second(${C()[0]})`, T.long);
        case 'dayofweek': return r(`Weekday(${C()[0]})`, T.long);
        case 'encodedate': { const c = C(); return r(`DateSerial(${c.join(', ')})`, T.date); }
        case 'encodetime': { const c = C(); return r(`TimeSerial(${c.slice(0, 3).join(', ')})`, T.date); }
        case 'incday': { const c = C(); return r(`DateAdd("d", ${c[1] || 1}, ${c[0]})`, T.date); }
        case 'incmonth': { const c = C(); return r(`DateAdd("m", ${c[1] || 1}, ${c[0]})`, T.date); }
        case 'incyear': { const c = C(); return r(`DateAdd("yyyy", ${c[1] || 1}, ${c[0]})`, T.date); }
        case 'daysbetween': { const c = C(); return r(`Abs(DateDiff("d", ${c[0]}, ${c[1]}))`, T.long); }
        case 'length': { const a = A()[0]; if (a.t && a.t.arr) return r(`NBLength(${a.c})`, T.long); if (a.t && a.t.vb === 'Variant') return r(`NBLength(${a.c})`, T.long); return r(`Len(${a.c})`, T.long); }
        case 'high': { const ar = args[0]; if (ar && ar.k === 'id') { const tl = ar.name.toLowerCase(); if (tl === 'integer' || tl === 'longint') return r('2147483647', T.long); if (tl === 'byte') return r('255', T.long); if (tl === 'word') return r('65535', T.long); if (tl === 'char') return r('255', T.long); const en = this.P.enums.get(tl); if (en) return r(String(en.items.length - 1), T.long); } const a = A()[0]; if (a.t && a.t.arr && a.t.arr.dims) return r(`UBound(${a.c})`, T.long); if (a.t && a.t.arr) return r(`NBHigh(${a.c})`, T.long); if (isStrT(a.t)) return r(`Len(${a.c})`, T.long); return r(`NBHigh(${a.c})`, T.long); }
        case 'low': { const a = A()[0]; if (a.t && a.t.arr) return r(`LBound(${a.c})`, T.long); if (isStrT(a.t)) return r('1', T.long); return r('0', T.long); }
        case 'copy': case 'midstr': { const c = C(); return c.length >= 3 ? r(`Mid$(${c[0]}, ${c[1]}, ${c[2]})`, T.str) : r(`Mid$(${c[0]}, ${c[1]})`, T.str); }
        case 'leftstr': { const c = C(); return r(`Left$(${c[0]}, ${c[1]})`, T.str); }
        case 'rightstr': { const c = C(); return r(`Right$(${c[0]}, ${c[1]})`, T.str); }
        case 'pos': case 'ansipos': case 'posex': { const c = C(); return c[2] ? r(`InStr(${c[2]}, ${c[1]}, ${c[0]})`, T.long) : r(`InStr(${c[1]}, ${c[0]})`, T.long); }
        case 'uppercase': case 'ansiuppercase': case 'upcase': return r(`UCase$(${C()[0]})`, T.str);
        case 'lowercase': case 'ansilowercase': return r(`LCase$(${C()[0]})`, T.str);
        case 'trim': return r(`Trim$(${C()[0]})`, T.str);
        case 'trimleft': return r(`LTrim$(${C()[0]})`, T.str);
        case 'trimright': return r(`RTrim$(${C()[0]})`, T.str);
        case 'stringreplace': { const c = C(); const fl = args[3] ? JSON.stringify(args[3]).toLowerCase() : ''; const all = fl.includes('rfreplaceall'); const ic = fl.includes('rfignorecase'); return r(`Replace(${c[0]}, ${c[1]}, ${c[2]}${!all ? ', 1, 1' : ic ? ', 1, -1' : ''}${ic ? ', vbTextCompare' : ''})`, T.str); }
        case 'replacestr': case 'ansireplacestr': { const c = C(); return r(`Replace(${c[0]}, ${c[1]}, ${c[2]})`, T.str); }
        case 'stringofchar': { const c = C(); return r(`String$(${c[1]}, ${c[0]})`, T.str); }
        case 'dupestring': { const c = C(); return r(`NBDupe(${c[0]}, ${c[1]})`, T.str); }
        case 'reversestring': case 'ansireversestring': return r(`StrReverse(${C()[0]})`, T.str);
        case 'comparetext': case 'ansicomparetext': { const c = C(); return r(`StrComp(${c[0]}, ${c[1]}, vbTextCompare)`, T.long); }
        case 'comparestr': case 'ansicomparestr': { const c = C(); return r(`StrComp(${c[0]}, ${c[1]}, vbBinaryCompare)`, T.long); }
        case 'sametext': case 'ansisametext': { const c = C(); return r(`(StrComp(${c[0]}, ${c[1]}, vbTextCompare) = 0)`, T.bool); }
        case 'samestr': case 'ansisamestr': { const c = C(); return r(`(${c[0]} = ${c[1]})`, T.bool); }
        case 'containsstr': case 'ansicontainsstr': { const c = C(); return r(`(InStr(${c[0]}, ${c[1]}) > 0)`, T.bool); }
        case 'containstext': case 'ansicontainstext': { const c = C(); return r(`(InStr(1, ${c[0]}, ${c[1]}, vbTextCompare) > 0)`, T.bool); }
        case 'startsstr': case 'ansistartsstr': { const c = C(); return r(`(Left$(${c[1]}, Len(${c[0]})) = ${c[0]})`, T.bool); }
        case 'endsstr': case 'ansiendsstr': { const c = C(); return r(`(Right$(${c[1]}, Len(${c[0]})) = ${c[0]})`, T.bool); }
        case 'startstext': case 'ansistartstext': { const c = C(); return r(`(StrComp(Left$(${c[1]}, Len(${c[0]})), ${c[0]}, vbTextCompare) = 0)`, T.bool); }
        case 'quotedstr': case 'ansiquotedstr': return r(`NBQuoted(${C()[0]})`, T.str);
        case 'chr': return r(`Chr$(${C()[0]})`, { vb: 'String', charT: true });
        case 'ord': { const a = A()[0]; if (isStrT(a.t)) return r(`Asc(${a.c})`, T.long); if (a.t && a.t.vb === 'Boolean') return r(`IIf(${a.c}, 1, 0)`, T.long); if (isNumT(a.t)) return r(`CLng(${a.c})`, T.long); return r(`NBOrd(${a.c})`, T.long); }
        case 'succ': return r(`(${C()[0]} + 1)`, T.long);
        case 'pred': return r(`(${C()[0]} - 1)`, T.long);
        case 'odd': return r(`(${C()[0]} Mod 2 <> 0)`, T.bool);
        case 'abs': return r(`Abs(${C()[0]})`, A()[0].t);
        case 'sqr': { const a = A()[0]; return r(`${wrap(a, PREC.pow + 1)} ^ 2`, T.dbl, PREC.pow); }
        case 'sqrt': return r(`Sqr(${C()[0]})`, T.dbl);
        case 'round': return r(`Round(${C()[0]})`, T.long);
        case 'trunc': return r(`Fix(${C()[0]})`, T.long);
        case 'int': return r(`Int(${C()[0]})`, T.dbl);
        case 'frac': { const c = C()[0]; return r(`(${c} - Fix(${c}))`, T.dbl); }
        case 'ceil': return r(`-Int(-(${C()[0]}))`, T.long, PREC.neg);
        case 'floor': return r(`Int(${C()[0]})`, T.long);
        case 'power': case 'intpower': { const a = A(); return r(`${wrap(a[0], PREC.pow + 1)} ^ ${wrap(a[1], PREC.pow + 1)}`, T.dbl, PREC.pow); }
        case 'exp': return r(`Exp(${C()[0]})`, T.dbl);
        case 'ln': return r(`Log(${C()[0]})`, T.dbl);
        case 'log10': return r(`(Log(${C()[0]}) / Log(10))`, T.dbl);
        case 'sin': case 'cos': case 'tan': return r(`${l[0].toUpperCase() + l.slice(1)}(${C()[0]})`, T.dbl);
        case 'arctan': return r(`Atn(${C()[0]})`, T.dbl);
        case 'random': return args.length ? r(`Int(Rnd * ${wrap(A()[0], PREC.mul + 1)})`, T.long) : r('Rnd', T.dbl);
        case 'randomrange': { const c = C(); return r(`(${c[0]} + Int(Rnd * ((${c[1]}) - (${c[0]}))))`, T.long); }
        case 'randomize': return r('Randomize', null, PREC.atom);
        case 'max': { const c = C(); return r(`NBMax(${c[0]}, ${c[1]})`, A()[0].t); }
        case 'min': { const c = C(); return r(`NBMin(${c[0]}, ${c[1]})`, A()[0].t); }
        case 'sign': return r(`Sgn(${C()[0]})`, T.long);
        case 'iszero': return r(`(Abs(${C()[0]}) < 0.000000000001)`, T.bool);
        case 'ifthen': { const c = C(); return r(`IIf(${c[0]}, ${c[1]}, ${c[2] || '""'})`, A()[1] ? A()[1].t : null); }
        case 'assigned': { const a = A()[0]; return r(`Not ${wrap(a, PREC.atom)} Is Nothing`, T.bool, PREC.not); }
        case 'fileexists': return r(`NBFileExists(${C()[0]})`, T.bool);
        case 'directoryexists': return r(`(Dir$(${C()[0]}, vbDirectory) <> "")`, T.bool);
        case 'extractfilename': return r(`NBExtractFileName(${C()[0]})`, T.str);
        case 'extractfilepath': case 'extractfiledir': return r(`NBExtractFilePath(${C()[0]})`, T.str);
        case 'extractfileext': return r(`NBExtractFileExt(${C()[0]})`, T.str);
        case 'changefileext': { const c = C(); return r(`NBChangeFileExt(${c[0]}, ${c[1]})`, T.str); }
        case 'includetrailingpathdelimiter': case 'includetrailingbackslash': return r(`NBTrailingDelim(${C()[0]})`, T.str);
        case 'getcurrentdir': return r('CurDir$', T.str);
        case 'deletefile': return stmt ? r(`Kill ${C()[0]}`, null, PREC.atom) : r(`NBDeleteFile(${C()[0]})`, T.bool);
        case 'inputbox': { const c = C(); return r(`InputBox(${c[1]}, ${c[0]}, ${c[2] || '""'})`, T.str); }
        case 'inputquery': { const c = C(); return r(`NBInputQuery(${c[0]}, ${c[1]}, ${c[2]})`, T.bool); }
        case 'messagedlg': case 'messagedlgpos': {
          const m0 = this.expr(args[0]).c; const dt = this.dlgType(args[1]); const bt = this.dlgButtons(args[2]);
          return r(`MsgBox(${m0}, ${dt + bt}, App.Title)`, T.long);
        }
        case 'messagebox': { const c = C(); return c.length >= 4 ? r(`MsgBox(${c[1]}, ${c[3]}, ${c[2]})`, T.long) : r(`MsgBox(${c[0]}, ${c[2] || 0}, ${c[1] || 'App.Title'})`, T.long); }
        case 'showmessage': return r(`MsgBox(${C()[0]})`, null);
        case 'showmessagefmt': { const f = this.expr(args[0]).c; const lst = args[1] && args[1].k === 'set' ? `Array(${args[1].items.map(i => this.expr(i.value).c).join(', ')})` : (args[1] ? this.expr(args[1]).c : 'Array()'); return r(`MsgBox(NBFormat(${f}, ${lst}))`, null); }
        case 'eof': return args.length ? r(`EOF(${C()[0]})`, T.bool) : null;
        case 'getkeystate': return r('0', T.long);
        case 'beep': case 'messagebeep': return r('Beep', null);
        case 'sleep': return r(`NBSleep ${C()[0]}`, null);
        case 'varisnull': return r(`IsNull(${C()[0]})`, T.bool);
        case 'varisempty': return r(`IsEmpty(${C()[0]})`, T.bool);
        case 'vararrayof': return r(`Array(${args[0] && args[0].k === 'set' ? args[0].items.map(i => this.expr(i.value).c).join(', ') : C().join(', ')})`, T.var);
        case 'concat': return r(C().join(' & '), T.str, PREC.cat);
        case 'charinset': { const a = this.expr(args[0]); return this.inSet(a, args[1]); }
        case 'isdigit': return r(`(${C()[0]} Like "#")`, T.bool);
        case 'adjustlinebreaks': return r(C()[0], T.str);
        case 'gettickcount': case 'gettickcount64': return r('CLng(Timer * 1000)', T.long);
      }
      return null;
    }
    dlgType(e) { const l = e && e.k === 'id' ? e.name.toLowerCase() : ''; return ({ mtwarning: 48, mterror: 16, mtinformation: 64, mtconfirmation: 32, mtcustom: 0 })[l] || 0; }
    dlgButtons(e) {
      if (!e) return 0;
      if (e.k === 'id') { const l = e.name.toLowerCase(); return ({ mbyesno: 4, mbyesnocancel: 3, mbokcancel: 1, mbabortretryignore: 2, mbok: 0 })[l] || 0; }
      if (e.k === 'set') {
        const s = new Set(e.items.map(i => i.value && i.value.k === 'id' ? i.value.name.toLowerCase() : ''));
        if (s.has('mbyes') && s.has('mbno') && s.has('mbcancel')) return 3;
        if (s.has('mbyes') && s.has('mbno')) return 4;
        if (s.has('mbabort') || s.has('mbignore')) return 2;
        if (s.has('mbretry') && s.has('mbcancel')) return 5;
        if (s.has('mbok') && s.has('mbcancel')) return 1;
      }
      return 0;
    }

    // ======================================================== comandos
    emit(line, ind) { this.out.push('    '.repeat(ind) + line); }
    comments(st, ind) { if (st && st.comments) for (const c of st.comments) this.commentLines(c.v, ind); }
    commentLines(text, ind) {
      for (const ln of String(text).replace(/\r/g, '').split('\n')) { const s = ln.trim(); if (!s) continue; if (/^\{?\$R /i.test(s)) continue; this.emit(`' ${s}`, ind); }
    }
    stmtList(list, ind) { for (const st of list || []) this.stmt(st, ind); }
    body(st, ind) { if (!st) return; if (st.k === 'block') { this.comments(st, ind); this.stmtList(st.body, ind); if (st.endComments) for (const c of st.endComments) this.commentLines(c.v, ind); } else this.stmt(st, ind); }
    stmt(st, ind) {
      if (!st) return;
      if (st.k !== 'block') this.comments(st, ind);
      const simple = st.k === 'assign' || st.k === 'call';
      const mark = this.out.length; if (simple) this._usedData = false;
      try { this.stmtInner(st, ind); if (simple && this._usedData) { for (let i = mark; i < this.out.length; i++) this.out[i] = this.out[i].replace(/^(\s*)/, "$1' [Delphi] (database) "); this.report.todo++; } }
      catch (err) { this.report.todo++; this.emit(`' [Delphi] could not convert this statement (line ${st.line || '?'}): ${String(err.message || err).slice(0, 120)}`, ind); }
    }
    stmtInner(st, ind) {
      switch (st.k) {
        case 'empty': return;
        case 'raw': this.emit(st.text, ind); return;
        case 'block': this.body(st, ind); return;
        case 'label': this.emit(`L_${st.name}:`, 0); return;
        case 'goto': this.emit(`GoTo L_${st.name}`, ind); return;
        case 'inherited': this.emit(`' [Delphi] inherited`, ind); return;
        case 'assign': return this.assign(st, ind);
        case 'call': return this.callStmt(st.expr, ind);
        case 'if': {
          const c = this.cond(st.cond);
          // if simples em uma linha quando possível
          this.emit(`If ${c} Then`, ind);
          this.body(st.then, ind + 1);
          let els = st.els;
          while (els && els.k === 'if' && !els.comments) { this.emit(`ElseIf ${this.cond(els.cond)} Then`, ind); this.body(els.then, ind + 1); els = els.els; }
          if (els) { this.emit('Else', ind); this.body(els, ind + 1); }
          this.emit('End If', ind); return;
        }
        case 'while': {
          const lp = { kind: 'do', cont: null };
          this.loopStack.push(lp);
          const start = this.out.length;
          this.emit(`Do While ${this.cond(st.cond)}`, ind);
          this.body(st.body, ind + 1);
          if (lp.cont) this.emit(`${lp.cont}:`, 0);
          this.emit('Loop', ind);
          this.loopStack.pop(); return;
        }
        case 'repeat': {
          const lp = { kind: 'do', cont: null };
          this.loopStack.push(lp);
          this.emit('Do', ind);
          this.stmtList(st.body, ind + 1);
          if (lp.cont) this.emit(`${lp.cont}:`, 0);
          this.emit(`Loop Until ${this.cond(st.cond)}`, ind);
          this.loopStack.pop(); return;
        }
        case 'for': {
          const v = this.expr(st.v); const from = this.expr(st.from).c, to = this.expr(st.to).c;
          const lp = { kind: 'for', cont: null };
          this.loopStack.push(lp);
          this.emit(`For ${v.c} = ${from} To ${to}${st.down ? ' Step -1' : ''}`, ind);
          this.body(st.body, ind + 1);
          if (lp.cont) this.emit(`${lp.cont}:`, 0);
          this.emit(`Next ${v.c}`, ind);
          this.loopStack.pop(); return;
        }
        case 'forin': {
          const v = this.expr(st.v); const coll = this.expr(st.coll);
          const lp = { kind: 'for', cont: null };
          this.loopStack.push(lp);
          if (isStrT(coll.t)) { const iv = this.tempVar('NB_i', 'Long'); this.emit(`For ${iv} = 1 To Len(${coll.c})`, ind); this.emit(`${v.c} = Mid$(${coll.c}, ${iv}, 1)`, ind + 1); this.body(st.body, ind + 1); if (lp.cont) this.emit(`${lp.cont}:`, 0); this.emit(`Next ${iv}`, ind); }
          else { this.emit(`For Each ${v.c} In ${coll.c}`, ind); this.body(st.body, ind + 1); if (lp.cont) this.emit(`${lp.cont}:`, 0); this.emit(`Next`, ind); }
          this.loopStack.pop(); return;
        }
        case 'case': {
          const sel = this.expr(st.sel);
          this.emit(`Select Case ${sel.c}`, ind);
          for (const arm of st.arms) {
            const labs = arm.labels.map(lb => lb.range ? `${this.expr(lb.range[0]).c} To ${this.expr(lb.range[1]).c}` : this.expr(lb.value).c);
            this.emit(`Case ${labs.join(', ')}`, ind + 1);
            if (arm.st) this.body(arm.st, ind + 2);
          }
          if (st.els) { this.emit('Case Else', ind + 1); this.stmtList(st.els, ind + 2); }
          this.emit('End Select', ind); return;
        }
        case 'with': {
          const objs = st.objs.map(o => this.expr(o));
          for (const o of objs) { const simple = /^[A-Za-z_][\w.]*$/.test(o.c) && !!(o.t && (o.t.ctl || o.t.ctlKind || o.t.form)); this.withStack.push({ c: o.c, t: o.t, simple }); this.emit(`With ${o.c}`, ind); ind++; }
          this.body(st.body, ind);
          for (let i = 0; i < objs.length; i++) { ind--; this.emit('End With', ind); this.withStack.pop(); }
          return;
        }
        case 'tryfinally': {
          this.emit("' try", ind);
          this.stmtList(st.body, ind);
          this.emit("' finally", ind);
          this.stmtList(st.fin, ind);
          this.emit("' end try", ind);
          return;
        }
        case 'tryexcept': {
          const rt = this.curRoutine;
          const h = this.newLabel('NB_Except'), done = this.newLabel('NB_EndTry');
          if (rt) rt.usesErr = true;
          this.emit(`On Error GoTo ${h}`, ind);
          this.stmtList(st.body, ind);
          this.emit('On Error GoTo 0', ind);
          this.emit(`GoTo ${done}`, ind);
          this.emit(`${h}:`, 0);
          if (st.plain) { this.withExceptVar(null, () => this.stmtList(st.plain, ind)); }
          else {
            let first = true;
            for (const hd of st.handlers) {
              const isAll = /^(exception|tobject)$/i.test(hd.type.replace(/^.*\./, ''));
              if (isAll) { if (!first) this.emit('Else', ind); this.withExceptVar(hd.v, () => this.body(hd.st, ind + (first ? 0 : 1))); if (!first) this.emit('End If', ind); first = true; break; }
              this.emit(`${first ? 'If' : 'ElseIf'} ${this.excCond(hd.type)} Then`, ind); this.withExceptVar(hd.v, () => this.body(hd.st, ind + 1)); first = false;
            }
            if (!first) { if (st.els) { this.emit('Else', ind); this.stmtList(st.els, ind + 1); } this.emit('End If', ind); }
          }
          this.emit(`Resume ${done}`, ind);
          this.emit(`${done}:`, 0);
          return;
        }
        case 'raise': {
          if (!st.expr) { this.emit('Err.Raise Err.Number, Err.Source, Err.Description', ind); return; }
          const e = this.expr(st.expr);
          this.emit(`Err.Raise vbObjectError + 1000, , ${e.exceptionMsg ? e.c : (isStrT(e.t) ? e.c : '"' + 'Error' + '"')}`, ind); return;
        }
        case 'inlinevar': {
          const t = st.type ? this.typeOf(st.type) : (st.init ? this.expr(st.init).t || T.var : T.var);
          for (const nm of st.names) {
            const v = this.declLocal(nm, t, st.isConst);
            if (st.init) { const val = this.expr(st.init); this.emit(`${t.obj ? 'Set ' : ''}${v.vbName} = ${val.c}`, ind); }
          }
          return;
        }
      }
      this.emit(`' [Delphi] statement not converted: ${st.k}`, ind); this.report.todo++;
    }
    excCond(type) { const l = type.toLowerCase().replace(/^.*\./, ''); const m = { ezerodivide: 11, edivbyzero: 11, econverterror: 13, erangeerror: 9, eaccessviolation: 91, einouterror: 53, efopenerror: 53, efcreateerror: 75, eoverflow: 6, einvalidop: 5, eintoverflow: 6, emathhrror: 6, elisterror: 9, estringlisterror: 9, einvalidcast: 13, evarianttypecasterror: 13 }; return m[l] ? `Err.Number = ${m[l]}` : 'True'; }
    withExceptVar(v, fn) {
      if (!v) return fn();
      const sc = { vars: new Map([[v.toLowerCase(), { name: v, vbName: 'Err', type: { vb: 'Object', obj: true, errObj: true } }]]) };
      this.pushScope(sc); try { fn(); } finally { this.popScope(); }
    }
    tempVar(base, vbType) { const rt = this.curRoutine; let n = base; let i = 1; while (rt && rt.vars.has(n.toLowerCase())) n = base + (++i); if (rt) rt.vars.set(n.toLowerCase(), { name: n, vbName: n, type: { vb: vbType }, temp: true }); return n; }
    declLocal(name, t, isConst) {
      const rt = this.curRoutine; const scope = this.scopes[this.scopes.length - 1];
      const v = { name, vbName: this.safeName(name), type: t };
      scope.vars.set(name.toLowerCase(), v);
      if (rt) rt.inlineDecl.push(v);
      return v;
    }
    cond(e) { const r = this.expr(e); return r.c; }
    assign(st, ind) {
      const tgt = st.target;
      // Result / nome da função
      const rt = this.curRoutine;
      if (tgt.k === 'id' && rt && rt.isFunc && (tgt.name.toLowerCase() === 'result' || tgt.name.toLowerCase() === rt.name.toLowerCase().replace(/^.*\./, ''))) {
        const v = this.expr(st.value);
        this.emit(`${rt.retType && rt.retType.obj ? 'Set ' : ''}Result = ${v.c}`, ind); return;
      }
      // Font.Style := [fsBold, ...]
      if (tgt.k === 'mem' && tgt.name.toLowerCase() === 'style' && tgt.obj.k === 'mem' && tgt.obj.name.toLowerCase() === 'font') {
        const fo = this.expr(tgt.obj).c;
        const val = st.value;
        const flags = { fsbold: 'Bold', fsitalic: 'Italic', fsunderline: 'Underline', fsstrikeout: 'Strikethrough' };
        const setItems = s => s.k === 'set' ? s.items.map(i => i.value && i.value.k === 'id' ? i.value.name.toLowerCase() : '') : null;
        if (val.k === 'set') { const its = setItems(val); for (const k of Object.keys(flags)) this.emit(`${fo}.${flags[k]} = ${its.includes(k) ? 'True' : 'False'}`, ind); return; }
        if (val.k === 'bin' && (val.op === '+' || val.op === '-') && val.b.k === 'set') { for (const it of setItems(val.b)) if (flags[it]) this.emit(`${fo}.${flags[it]} = ${val.op === '+' ? 'True' : 'False'}`, ind); return; }
      }
      // s[i] := c
      if (tgt.k === 'index') {
        const base = this.expr(tgt.obj);
        if (isStrT(base.t)) { const i = this.expr(tgt.idx[0]).c; this.emit(`Mid$(${base.c}, ${i}, 1) = ${this.expr(st.value).c}`, ind); return; }
      }
      const t = this.expr(tgt);
      const v = this.expr(st.value);
      if (t.setter) { this.emit(t.setter(v.c), ind); return; }
      if (t.strIndex) { this.emit(`Mid$(${t.strIndex.s.c}, ${t.strIndex.i}, 1) = ${v.c}`, ind); return; }
      const isObj = (t.t && t.t.obj && !(t.t.ctl) && !t.t.form) || (v.t && v.t.obj && !v.t.ctl && !v.newForm && !v.t.form && !(t.t && !t.t.obj)) || v.newForm || (v.t && v.t.form && t.t && t.t.form) || v.c.startsWith('New ') || v.c === 'Nothing';
      const setKw = isObj && !(t.t && (t.t.vb === 'String' || t.t.vb === 'Long' || t.t.vb === 'Double' || t.t.vb === 'Boolean')) ? 'Set ' : '';
      this.emit(`${setKw}${t.c} = ${v.c}`, ind);
      if (v.newForm && (v.newForm.conv.isMDIChild || D.pBool(v.newForm.conv.root, 'Visible', false))) this.emit(`${t.c}.Show`, ind);
    }
    callStmt(e, ind) {
      // procedimentos especiais
      const { base, steps } = this.flatten(e);
      if (base.k === 'id') {
        const l = base.name.toLowerCase();
        const r0 = this.resolveId(base.name);
        const args = steps.length && steps[0].k === 'call' ? steps[0].args : [];
        const only = steps.length === 0 || (steps.length === 1 && steps[0].k === 'call');
        if (only && (r0.k === 'unknown' || r0.k === 'formmem')) {
          const C = () => args.map(a => this.expr(a).c);
          switch (l) {
            case 'inc': case 'dec': { const v = this.expr(args[0]).c; const n = args[1] ? this.expr(args[1]) : null; this.emit(`${v} = ${v} ${l === 'inc' ? '+' : '-'} ${n ? wrap(n, PREC.add + 1) : '1'}`, ind); return; }
            case 'exit': { const rt = this.curRoutine; if (args.length && rt && rt.isFunc) this.emit(`${rt.retType && rt.retType.obj ? 'Set ' : ''}Result = ${this.expr(args[0]).c}`, ind); this.emitExit(ind); return; }
            case 'break': { const lp = this.loopStack[this.loopStack.length - 1]; this.emit(lp && lp.kind === 'for' ? 'Exit For' : 'Exit Do', ind); return; }
            case 'continue': { const lp = this.loopStack[this.loopStack.length - 1]; if (lp) { if (!lp.cont) lp.cont = this.newLabel('NB_Continue'); this.emit(`GoTo ${lp.cont}`, ind); } return; }
            case 'halt': this.emit('End', ind); return;
            case 'abort': this.emit('Exit Sub', ind); return;
            case 'showmessage': this.emit(`MsgBox ${C()[0]}`, ind); return;
            case 'delete': { const c = C(); this.emit(`${c[0]} = Left$(${c[0]}, ${c[1]} - 1) & Mid$(${c[0]}, ${c[1]} + ${c[2]})`, ind); return; }
            case 'insert': { const c = C(); this.emit(`${c[1]} = Left$(${c[1]}, ${c[2]} - 1) & ${c[0]} & Mid$(${c[1]}, ${c[2]})`, ind); return; }
            case 'setlength': {
              const a = this.expr(args[0]); const dims = args.slice(1).map(x => this.expr(x));
              if (isStrT(a.t)) { this.emit(`${a.c} = Left$(${a.c} & Space$(${dims[0].c}), ${dims[0].c})`, ind); return; }
              if (dims.length === 1) { this.emit(`If ${wrap(dims[0], PREC.cmp + 1)} > 0 Then ReDim Preserve ${a.c}(0 To ${wrap(dims[0], PREC.add)} - 1) Else Erase ${a.c}`, ind); return; }
              this.emit(`ReDim ${a.c}(${dims.map(d => `0 To ${wrap(d, PREC.add)} - 1`).join(', ')})`, ind); return;
            }
            case 'freeandnil': this.emit(`Set ${C()[0]} = Nothing`, ind); return;
            case 'decodedate': { const c = C(); this.emit(`${c[1]} = Year(${c[0]}): ${c[2]} = Month(${c[0]}): ${c[3]} = Day(${c[0]})`, ind); return; }
            case 'decodetime': { const c = C(); this.emit(`${c[1]} = Hour(${c[0]}): ${c[2]} = Minute(${c[0]}): ${c[3]} = Second(${c[0]})`, ind); if (c[4]) this.emit(`${c[4]} = 0`, ind); return; }
            case 'assignfile': case 'assign': { const c = C(); this.emit(`NBAssignFile ${c[0]}, ${c[1]}`, ind); return; }
            case 'reset': case 'rewrite': case 'append': { if (args.length === 1) { this.emit(`NBOpenFile ${C()[0]}, "${l}"`, ind); return; } break; }
            case 'closefile': case 'close': if (args.length === 1) { this.emit(`Close #${C()[0]}`, ind); return; } break;
            case 'writeln': case 'write': {
              const fileArg = args.length && this.isFileVar(args[0]);
              const items = (fileArg ? args.slice(1) : args).map(a => this.expr(a).c);
              if (fileArg) this.emit(`Print #${this.expr(args[0]).c}, ${items.join(' & ')}${l === 'write' ? ';' : ''}`, ind);
              else this.emit(`Debug.Print ${items.join(' & ')}${l === 'write' ? ';' : ''}`, ind);
              return;
            }
            case 'readln': case 'read': {
              if (args.length >= 2 && this.isFileVar(args[0])) { this.emit(`Line Input #${this.expr(args[0]).c}, ${this.expr(args[1]).c}`, ind); return; }
              this.emit(`' [Delphi] ${base.name}`, ind); return;
            }
            case 'randomize': this.emit('Randomize', ind); return;
            case 'beep': case 'messagebeep': this.emit('Beep', ind); return;
            case 'renamefile': { const c = C(); this.emit(`Name ${c[0]} As ${c[1]}`, ind); return; }
            case 'createdir': case 'forcedirectories': case 'mkdir': this.emit(`MkDir ${C()[0]}`, ind); return;
            case 'removedir': case 'rmdir': this.emit(`RmDir ${C()[0]}`, ind); return;
            case 'chdir': case 'setcurrentdir': this.emit(`ChDir ${C()[0]}`, ind); return;
            case 'fillchar': case 'move': case 'zeromemory': this.emit(`' [Delphi] ${base.name} (memory operation) was not converted`, ind); this.report.todo++; return;
            case 'include': { const c = C(); this.emit(`${c[0]} = ${c[0]} Or ${c[1]}`, ind); return; }
            case 'exclude': { const c = C(); this.emit(`${c[0]} = ${c[0]} And Not ${c[1]}`, ind); return; }
            case 'new': case 'dispose': case 'getmem': case 'freemem': case 'reallocmem': this.emit(`' [Delphi] ${base.name} (pointer) was not converted`, ind); this.report.todo++; return;
            case 'close': if (this.form) { this.emit('Me.CloseForm', ind); return; } break;
          }
        }
      }
      const r = this.desig(e, true);
      if (r.rawStmt) { this.emit(r.c, ind); return; }
      // chamada genérica: tira os parênteses do último passo
      if (r.call) {
        const callee = r.call.callee;
        if (r.call.args.length) this.emit(`${callee} ${r.call.args.join(', ')}`, ind); else this.emit(`${callee}`, ind);
        return;
      }
      if (/^MsgBox\(/.test(r.c)) { this.emit(r.c.replace(/^MsgBox\((.*)\)$/, 'MsgBox $1'), ind); return; }
      this.emit(r.c, ind);
    }
    isFileVar(e) { if (e.k !== 'id') return false; const r = this.resolveId(e.name); const t = r.k === 'local' ? r.v.type : r.k === 'field' ? r.v.type : r.k === 'sym' ? r.s.type : null; return !!(t && t.textFile); }
    emitExit(ind) { const rt = this.curRoutine; if (!rt) { this.emit('Exit Sub', ind); return; } if (rt.isFunc) { this.emit(`${rt.vbName} = Result`, ind); this.emit('Exit Function', ind); } else if (rt.isProp) { this.emit('Exit Property', ind); } else this.emit('Exit Sub', ind); }

    // ======================================================== rotinas
    // rotina -> linhas VB
    routine(r, opts) {
      const shortName = r.name.replace(/^.*\./, '');
      const isFunc = r.kind === 'function';
      const ctx = { name: shortName, vbName: opts.vbName || this.safeName(shortName), isFunc, retType: isFunc ? this.typeOf(r.ret) : null, vars: new Map(), inlineDecl: [], usesErr: false };
      const scope = { vars: new Map(), routine: ctx };
      const params = [];
      const extraParams = opts.prependParams || [];
      for (const p of r.params) {
        const t = this.typeOf(p.type); const vbName = this.safeName(p.name);
        scope.vars.set(p.name.toLowerCase(), { name: p.name, vbName, type: t, param: true });
        let decl = (p.mode === 'var' ? '' : 'ByVal ') + vbName;
        if (t.arr) decl = vbName + '() As ' + this.vbTypeName(t.arr.of);
        else if (p.mode === 'var' && (t.vb === 'Variant' || t.textFile)) decl += ' As Variant';
        else decl += ' As ' + this.vbTypeName(t);
        if (p.def) decl = 'Optional ' + decl + ' = ' + this.expr(p.def).c;
        params.push(decl);
      }
      for (const loc of r.locals || []) {
        if (loc.kind === 'var') { const t = this.typeOf(loc.type); if (loc.type && /^(textfile|text)$/i.test(loc.type.name || '')) t.textFile = true; scope.vars.set(loc.name.toLowerCase(), { name: loc.name, vbName: this.safeName(loc.name), type: t, init: loc.init }); }
        else if (loc.kind === 'const') scope.vars.set(loc.name.toLowerCase(), { name: loc.name, vbName: this.safeName(loc.name), type: loc.type ? this.typeOf(loc.type) : this.expr(loc.value).t, isConst: true, value: loc.value });
      }
      ctx.vars = scope.vars;
      this.pushScope(scope);
      const saveOut = this.out; this.out = [];
      try {
        if (r.nested && r.nested.length) this.warn(`nested routines inside ${shortName} were moved out (they may not see the outer variables)`);
        this.body(r.body, 1);
      } finally { this.popScope(); }
      const bodyLines = this.out; this.out = saveOut;
      const vis = opts.vis || 'Private';
      const head = isFunc ? `${vis} Function ${ctx.vbName}(${params.join(', ')}) As ${this.vbTypeName(ctx.retType)}` : `${vis} Sub ${ctx.vbName}(${params.join(', ')})`;
      const lines = [];
      if (r.comments) for (const c of r.comments) for (const ln of String(c.v).split('\n')) if (ln.trim() && !/^\$/.test(ln.trim())) lines.push(`' ${ln.trim()}`);
      lines.push(head);
      // declarações locais
      for (const v of scope.vars.values()) {
        if (v.param) continue;
        if (v.isConst) { lines.push(`    Const ${v.vbName} = ${this.expr(v.value).c}`); continue; }
        lines.push(`    Dim ${this.vbDecl(v.vbName, v.type)}`);
      }
      for (const v of ctx.inlineDecl) if (!scope.vars.has(v.name.toLowerCase())) lines.push(`    Dim ${this.vbDecl(v.vbName, v.type)}`);
      for (const v of ctx.vars.values()) if (v.temp) lines.push(`    Dim ${v.vbName} As ${v.type.vb}`);
      if (isFunc) lines.push(`    Dim ${this.vbDecl('Result', ctx.retType)}`);
      for (const v of scope.vars.values()) if (v.init && !v.param) lines.push(`    ${v.type.obj ? 'Set ' : ''}${v.vbName} = ${this.expr(v.init).c}`);
      if (opts.preamble) for (const p of opts.preamble) lines.push('    ' + p);
      lines.push(...bodyLines);
      if (isFunc) lines.push(`    ${ctx.retType && ctx.retType.obj ? 'Set ' : ''}${ctx.vbName} = Result`);
      lines.push(isFunc ? 'End Function' : 'End Sub');
      this.report.lines += bodyLines.length;
      // rotinas internas
      for (const n of r.nested || []) { lines.push(''); lines.push(...this.routine(n, { vis: 'Private' })); }
      return lines;
    }
  }

  // nomes conhecidos (não viram membros de with)
  const BUILTIN_NAMES = new Set(['inttostr', 'strtoint', 'strtointdef', 'floattostr', 'strtofloat', 'format', 'formatfloat', 'formatdatetime', 'datetostr', 'timetostr', 'now', 'date', 'time', 'length', 'high', 'low', 'copy', 'pos', 'uppercase', 'lowercase', 'trim', 'chr', 'ord', 'inc', 'dec', 'exit', 'break', 'continue', 'showmessage', 'messagedlg', 'inputbox', 'assigned', 'freeandnil', 'setlength', 'round', 'trunc', 'abs', 'sqrt', 'sqr', 'random', 'randomize', 'max', 'min', 'self', 'result', 'nil', 'true', 'false', 'application', 'screen', 'sender', 'writeln', 'readln', 'fileexists', 'extractfilename', 'extractfilepath', 'quotedstr', 'stringreplace', 'sametext', 'comparetext', 'odd', 'succ', 'pred', 'delete', 'insert', 'halt', 'beep', 'sleep', 'power', 'frac', 'int', 'exp', 'ln', 'sin', 'cos', 'tan', 'arctan', 'pi']);
  const COMPAT_CONSTS = new Set(['mrnone', 'mrok', 'mrcancel', 'mrabort', 'mrretry', 'mrignore', 'mryes', 'mrno', 'mrall', 'lb_err', 'cb_err', 'mb_ok', 'mb_yesno', 'idyes', 'idno', 'idok', 'idcancel', 'cafree', 'canone', 'cahide', 'caminimize', 'wsnormal', 'wsmaximized', 'wsminimized', 'crdefault', 'crhourglass', 'mbleft', 'mbright', 'mbmiddle', 'ssshift', 'ssctrl', 'ssalt']);
  const MSG_CONST = { mbyes: 6, mbno: 7, mbok: 1, mbcancel: 2, mbabort: 3, mbretry: 4, mbignore: 5, mtwarning: 48, mterror: 16, mtinformation: 64, mtconfirmation: 32, mtcustom: 0, mbyesno: 4, mbyesnocancel: 3, mbokcancel: 1, mbabortretryignore: 2 };
  const WS_CONST = { wsnormal: 0, wsminimized: 1, wsmaximized: 2, poscreencenter: 2, bsnone: 0, bssingle: 1, bssizeable: 2, bsdialog: 3, taleftjustify: 0, tarightjustify: 1, tacenter: 2, alnone: 0, altop: 1, albottom: 2, alleft: 3, alright: 4, alclient: 5 };
  const FORM_MEMBERS = new Set(['caption', 'close', 'show', 'showmodal', 'hide', 'width', 'height', 'left', 'top', 'clientwidth', 'clientheight', 'color', 'font', 'modalresult', 'release', 'activecontrol', 'mdichildcount', 'mdichildren', 'activemdichild', 'cascade', 'tile', 'tilemode', 'arrangeicons', 'windowstate', 'visible', 'enabled', 'borderstyle', 'position', 'canvas', 'keypreview', 'hint', 'cursor', 'setfocus', 'invalidate', 'repaint', 'refresh', 'update', 'menu', 'tag', 'handle', 'setbounds', 'components', 'componentcount', 'controlcount', 'controls', 'autoscroll', 'formstyle', 'print', 'scaled', 'alphablend', 'doublebuffered', 'bringtofront', 'perform', 'borderwidth']);
  const CTL_MEMBERS = new Set(['caption', 'text', 'enabled', 'visible', 'left', 'top', 'width', 'height', 'color', 'font', 'hint', 'tag', 'setfocus', 'show', 'hide', 'items', 'lines', 'itemindex', 'checked', 'selected', 'clear', 'readonly', 'maxlength', 'passwordchar', 'selstart', 'sellength', 'seltext', 'position', 'min', 'max', 'interval', 'picture', 'stretch', 'cursor', 'align', 'alignment', 'autosize', 'wordwrap', 'count', 'name', 'parent', 'tabstop', 'taborder', 'showhint', 'bringtofront', 'sendtoback', 'refresh', 'repaint', 'invalidate', 'setbounds', 'canfocus', 'focused', 'selectall', 'sorted', 'state', 'clientwidth', 'clientheight', 'default', 'cancel', 'flat', 'transparent', 'activepage', 'activepageindex', 'pagecount', 'simpletext', 'panels', 'execute', 'filename', 'filter', 'defaultext', 'initialdir', 'title', 'value', 'selcount', 'brush', 'pen', 'shape']);
  const KIND_MEMBERS = {};
  const STRINGS_MEMBERS = new Set(['add', 'addobject', 'insert', 'delete', 'clear', 'count', 'strings', 'objects', 'text', 'commatext', 'delimitedtext', 'delimiter', 'sorted', 'indexof', 'names', 'values', 'valuefromindex', 'loadfromfile', 'savetofile', 'beginupdate', 'endupdate', 'sort', 'duplicates', 'casesensitive', 'exchange', 'append', 'addstrings', 'find']);
  const PROP_RENAME = { color: 'BackColor', hint: 'ToolTipText', readonly: 'Locked', taborder: 'TabIndex', cursor: 'MousePointer', parent: 'Container', handle: 'hWnd', itemindex: 'ListIndex' };
  const PROP_TYPES = { caption: T.str, text: T.str, enabled: T.bool, visible: T.bool, left: T.long, top: T.long, width: T.long, height: T.long, tag: T.long, checked: T.bool, value: T.var, interval: T.long, listindex: T.long, listcount: T.long, hint: T.str, filename: T.str, seltext: T.str, selstart: T.long, sellength: T.long, maxlength: T.long };

  // ---------------------------------------------------------------- projeto
  function baseName(p) { return p.replace(/\\/g, '/').split('/').pop(); }
  function stem(p) { return baseName(p).replace(/\.[^.]*$/, ''); }
  function vbIdent(s) { let x = String(s).replace(/[^A-Za-z0-9_]/g, '_'); if (!/^[A-Za-z]/.test(x)) x = 'P' + x; return x.slice(0, 40); }

  // files: [{path, bytes}] ; devolve {files: [{path, text}], report, projectName}
  function convertProject(files, opts = {}) {
    const report = new Report();
    const byLower = new Map(); for (const f of files) byLower.set(f.path.replace(/\\/g, '/').toLowerCase(), f);
    const byStem = new Map(); for (const f of files) { const ext = (f.path.split('.').pop() || '').toLowerCase(); const k = stem(f.path).toLowerCase(); if (!byStem.has(k)) byStem.set(k, {}); byStem.get(k)[ext] = f; }
    // projeto
    const dprs = files.filter(f => /\.dpr$/i.test(f.path));
    let dpr = opts.dpr ? files.find(f => f.path === opts.dpr) : dprs[0];
    const P = { report, forms: new Map(), formByClass: new Map(), globals: new Map(), records: new Map(), enums: new Map(), enumItems: new Map(), aliases: new Map(), classes: new Map(), unitNames: new Set(), mainForm: null };
    let projName = 'DelphiProject';
    const unitsOrder = []; // {name, file}
    const autoCreate = [];
    let dprUnit = null;
    if (dpr) {
      projName = vbIdent(stem(dpr.path));
      try { dprUnit = new D.PasParser(D.decodeBytes(dpr.bytes)).parseUnit(); projName = vbIdent(dprUnit.name || projName); } catch (e) { report.warn(`${baseName(dpr.path)}: could not read the project file (${e.message})`); }
      if (dprUnit) {
        for (const u of dprUnit.ifaceUses) if (u.file) unitsOrder.push({ name: u.name, file: u.file });
        if (dprUnit.main) for (const st of dprUnit.main.body) {
          if (st.k === 'call' && st.expr.k === 'call' && st.expr.fn.k === 'mem' && /createform/i.test(st.expr.fn.name)) { const a = st.expr.args; if (a[1] && a[1].k === 'id') autoCreate.push({ cls: a[0].name, var: a[1].name }); }
          if (st.k === 'assign' && st.target.k === 'mem' && /^title$/i.test(st.target.name) && st.value.k === 'str') P.title = st.value.pieces.map(p => p[0] === 's' ? p[1] : '').join('');
        }
      }
    }
    // unidades a converter: as do .dpr; se não houver .dpr, todas as .pas
    let pasFiles = [];
    if (unitsOrder.length) {
      for (const u of unitsOrder) { const nm = baseName(u.file).toLowerCase(); const f = files.find(x => baseName(x.path).toLowerCase() === nm) || (byStem.get(stem(u.file).toLowerCase()) || {}).pas; if (f) pasFiles.push(f); else report.warn(`unit ${u.name} (${u.file}) was not found in the folder`); }
    } else pasFiles = files.filter(f => /\.pas$/i.test(f.path));
    // análise das unidades
    const units = [];
    for (const f of pasFiles) {
      const src = D.decodeBytes(f.bytes);
      let U;
      try { U = new D.PasParser(src).parseUnit(); }
      catch (e) { report.warn(`${baseName(f.path)}: the Pascal code could not be read (${e.message}); the unit was imported as comments`); U = { name: stem(f.path), failed: true, src, ifaceDecls: [], implDecls: [], routines: [], classes: [], ifaceUses: [], implUses: [] }; }
      U.file = baseName(f.path); U.path = f.path;
      if (!U.name) U.name = stem(f.path);
      P.unitNames.add(U.name.toLowerCase());
      const ds = byStem.get(stem(f.path).toLowerCase()) || {};
      const dfm = ds.dfm || ds.xfm || null;
      if (ds.fmx && !dfm) report.warn(`${U.file}: FireMonkey forms (.fmx) are not supported; only VCL forms (.dfm) are converted`);
      U.dfm = dfm;
      units.push(U);
    }
    // formulários
    for (const U of units) {
      if (!U.dfm) continue;
      let root;
      try { root = D.parseDfm(U.dfm.bytes); } catch (e) { report.warn(`${baseName(U.dfm.path)}: the form could not be read (${e.message})`); continue; }
      if (root.kind === 'inherited') report.warn(`${baseName(U.dfm.path)}: inherited forms are converted without the controls of the parent form`);
      const conv = new D.FormConv(root, U.file, report, {});
      const design = conv.convert();
      const F = { name: conv.formName, cls: root.cls, unit: U, conv, controls: conv.controls, design };
      U.form = F;
      P.forms.set(F.name.toLowerCase(), F);
      P.formByClass.set(root.cls.toLowerCase(), F);
    }
    // nome do formulário principal
    if (autoCreate.length) { const f = P.formByClass.get(autoCreate[0].cls.toLowerCase()); if (f) P.mainForm = f.name; }
    if (!P.mainForm) { const f = [...P.forms.values()][0]; if (f) P.mainForm = f.name; }
    // símbolos globais (interface) de todas as unidades
    const recDefs = [];
    const regType = (U, d, isPublic) => {
      const l = d.name.toLowerCase();
      if (d.kind === 'record') { const fm = new Map(); const rec = { name: d.name, vbName: vbIdent(d.name), fields: d.fields, fieldMap: fm, unit: U, isPublic }; P.records.set(l, rec); recDefs.push(rec); }
      else if (d.kind === 'enum') { const en = { name: d.name, items: d.items, unit: U, isPublic }; P.enums.set(l, en); d.items.forEach((it, i) => P.enumItems.set(it.name.toLowerCase(), { vbName: it.name, value: i, en })); }
      else if (d.kind === 'alias') { P.aliases.set(l, d.type); }
      else if (d.kind === 'class') {
        if (P.formByClass.has(l)) return;
        if (d.parent && /^t(form|frame|datamodule)$/i.test(d.parent)) { if (/tdatamodule/i.test(d.parent)) report.warn(`${U.file}: data module ${d.name} is not converted yet (database support comes in a later phase)`); return; }
        const C = { name: d.name, vbName: vbIdent(d.name.replace(/^T(?=[A-Z])/, 'T')), decl: d, unit: U, members: new Map(), memberSet: new Set(), fieldMap: new Map(), ctor: null, isClass: true };
        P.classes.set(l, C);
      }
    };
    for (const U of units) {
      for (const d of U.ifaceDecls || []) {
        if (['record', 'enum', 'alias', 'class'].includes(d.kind)) regType(U, d, true);
      }
      for (const d of U.implDecls || []) if (['record', 'enum', 'alias', 'class'].includes(d.kind)) regType(U, d, false);
      for (const c of U.classes || []) if (!P.classes.has(c.name.toLowerCase()) && !P.formByClass.has(c.name.toLowerCase())) regType(U, c, true);
    }
    // campos de registros (precisam de tipos)
    const tmpTr = new UnitTranslator(P, { name: '', file: '' }, {});
    for (const rec of recDefs) for (const f of rec.fields) rec.fieldMap.set(f.name.toLowerCase(), { name: f.name, vbName: tmpTr.safeName(f.name), type: tmpTr.typeOf(f.type) });
    for (const C of P.classes.values()) {
      const d = C.decl;
      // herança de classes do próprio projeto: copia membros do pai
      const chain = []; let cur = d; const seen = new Set();
      while (cur && !seen.has(cur.name.toLowerCase())) { seen.add(cur.name.toLowerCase()); chain.unshift(cur); const par = cur.parent && P.classes.get(cur.parent.toLowerCase()); cur = par ? par.decl : null; }
      if (d.parent && !P.classes.has(d.parent.toLowerCase()) && !/^tobject$|^tinterfacedobject$|^tpersistent$/i.test(d.parent)) report.warn(`${C.unit.file}: class ${d.name} inherits from ${d.parent}, which is not available; only its own members were converted`);
      C.chain = chain;
      for (const cd of chain) {
        for (const f of cd.fields) { const fm = { name: f.name, vbName: tmpTr.safeName(f.name), type: tmpTr.typeOf(f.type) }; C.fieldMap.set(f.name.toLowerCase(), fm); C.members.set(f.name.toLowerCase(), fm); C.memberSet.add(f.name.toLowerCase()); }
        for (const m of cd.methods) { const sn = m.name.toLowerCase(); C.memberSet.add(sn); C.members.set(sn, { name: m.name, type: m.ret ? tmpTr.typeOf(m.ret) : null, method: m }); if (m.kind === 'constructor') C.ctor = m; if (m.kind === 'destructor') C.dtorName = sn; }
        for (const pr of cd.props) { C.memberSet.add(pr.name.toLowerCase()); C.members.set(pr.name.toLowerCase(), { name: pr.name, type: pr.type ? tmpTr.typeOf(pr.type) : null, prop: pr }); }
      }
    }
    for (const U of units) {
      const tr = new UnitTranslator(P, U, {});
      for (const d of U.ifaceDecls || []) {
        if (d.kind === 'var') { const t = tr.typeOf(d.type); if (d.type && /^(textfile|text)$/i.test(d.type.name || '')) t.textFile = true; if (U.form && t.form === U.form) continue; if (P.formByClass.has(String(d.type.name || '').toLowerCase())) continue; P.globals.set(d.name.toLowerCase(), { kind: 'var', name: d.name, vbName: tr.safeName(d.name), type: t, unit: U, decl: d }); }
        else if (d.kind === 'const') P.globals.set(d.name.toLowerCase(), { kind: 'const', name: d.name, vbName: tr.safeName(d.name), type: d.type ? tr.typeOf(d.type) : null, unit: U, decl: d });
        else if (d.kind === 'routineDecl') { const r = d.routine; const nm = r.name.replace(/^.*\./, ''); P.globals.set(nm.toLowerCase(), { kind: 'routine', name: nm, vbName: tr.safeName(nm), retType: r.ret ? tr.typeOf(r.ret) : null, type: r.ret ? tr.typeOf(r.ret) : null, unit: U, routine: r }); }
      }
    }
    // tradução
    const out = [];
    const modules = [], formsOut = [], classesOut = [];
    const initCalls = [];
    for (const U of units) {
      if (U.failed) {
        const mn = vbIdent(U.name) + (U.form ? 'Code' : '');
        const txt = [`Attribute VB_Name = "${mn}"`, `' [Delphi] the unit ${U.file} could not be converted automatically.`, `' Original Pascal code:`, ...U.src.split(/\r?\n/).map(l => "' " + l)].join('\r\n') + '\r\n';
        modules.push({ path: mn + '.bas', text: txt });
        if (U.form) formsOut.push({ path: U.form.name + '.frm', text: U.form.design + "' [Delphi] the code of this form could not be converted. See " + mn + '.bas\r\n' });
        continue;
      }
      const res = translateUnit(P, U);
      if (res.form) formsOut.push(res.form);
      if (res.module) modules.push(res.module);
      for (const c of res.classes) classesOut.push(c);
      if (res.initCall) initCalls.push(res.initCall);
    }
    const factories = classesOut.map(c => c.factory).filter(Boolean);
    // .dpr: formulários criados automaticamente e Sub Main
    const startLines = [];
    startLines.push(`Attribute VB_Name = "DelphiStartup"`);
    startLines.push(`' Startup of the converted Delphi project ${projName}`);
    startLines.push('Option Explicit');
    startLines.push('');
    startLines.push('Public Sub Main()');
    if (P.title) startLines.push(`    App.Title = ${vbStr(P.title)}`);
    for (const c of initCalls) startLines.push(`    ${c}`);
    const mainF = P.mainForm;
    const others = autoCreate.map(a => P.formByClass.get(a.cls.toLowerCase())).filter(f => f && f.name !== mainF);
    if (mainF) startLines.push(`    ${mainF}.Show`);
    for (const f of others) startLines.push(`    Load ${f.name}`);
    if (!mainF) startLines.push(`    ' [Delphi] the project has no form`);
    startLines.push('End Sub');
    for (const fx of factories) startLines.push(...fx.split('\r\n'));
    modules.push({ path: 'DelphiStartup.bas', text: startLines.join('\r\n') + '\r\n' });
    modules.push({ path: 'DelphiCompat.bas', text: COMPAT_BAS.replace(/\n/g, '\r\n') });
    classesOut.push({ path: 'TStringList.cls', text: TSTRINGLIST_CLS.replace(/\n/g, '\r\n') });
    classesOut.push({ path: 'TStringsCtl.cls', text: TSTRINGSCTL_CLS.replace(/\n/g, '\r\n') });
    // .vbp
    const usesComDlg = [...P.forms.values()].some(f => f.conv.usesComDlg);
    const vbp = ['Type=Exe', 'Reference=*\\G{00020430-0000-0000-C000-000000000046}#2.0#0#..\\..\\WINDOWS\\SYSTEM\\STDOLE2.TLB#OLE Automation'];
    if (usesComDlg) vbp.push('Object={F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0; COMDLG32.OCX');
    for (const f of formsOut) vbp.push(`Form=${f.path}`);
    for (const m of modules) vbp.push(`Module=${m.path.replace(/\.bas$/, '')}; ${m.path}`);
    for (const c of classesOut) vbp.push(`Class=${c.path.replace(/\.cls$/, '')}; ${c.path}`);
    vbp.push('Startup="Sub Main"', `Title=${vbStr(P.title || projName)}`, 'ExeName32=' + vbStr(projName + '.exe'), `Name=${vbStr(projName)}`, 'HelpContextID="0"', 'CompatibleMode="0"', 'MajorVer=1', 'MinorVer=0', 'RevisionVer=0', 'AutoIncrementVer=0', 'ServerSupportFiles=0', 'CompilationType=0', 'OptimizationType=0', 'NoAliasing=0', 'BoundsCheck=0', 'OverflowCheck=0', 'FlPointCheck=0', 'FDIVCheck=0', 'UnroundedFP=0', 'StartMode=0', 'Unattended=0', 'Retained=0', 'ThreadPerObject=0', 'MaxNumberOfThreads=1');
    // relatório
    const rep = buildReport(projName, report, units, P);
    const frxOut = []; for (const F of P.forms.values()) { const fb = F.conv.frxBytes(); if (fb) frxOut.push({ path: F.name + '.frx', bytes: fb }); }
    out.push(...frxOut);
    out.push({ path: projName + '.vbp', text: vbp.join('\r\n') + '\r\n' }, ...formsOut, ...modules, ...classesOut, { path: 'DelphiImport-Report.txt', text: rep });
    return { files: out, report, projectName: projName, reportText: rep, mainForm: mainF };
  }

  function buildReport(projName, report, units, P) {
    const L = [];
    L.push(`NeoBasic - Delphi import report`);
    L.push(`Project: ${projName}`);
    L.push('');
    L.push(`Units: ${units.length}   Forms: ${P.forms.size}   Classes: ${P.classes.size}   Lines of code converted: ${report.lines}`);
    L.push(`Statements left as comments for review: ${report.todo}`);
    L.push('');
    L.push('In the code, search for  [Delphi]  to find the places that need attention.');
    if (report.datas.length) { L.push(''); L.push('Database components (not converted yet - planned for the next phase):'); for (const d of report.datas) L.push('  - ' + d); }
    if (report.warns.length) { L.push(''); L.push('Notes:'); for (const w of report.warns) L.push('  - ' + w); }
    return L.join('\r\n') + '\r\n';
  }

  // ---------------------------------------------------------------- unidade -> arquivos VB
  function translateUnit(P, U) {
    const F = U.form || null;
    const tr = new UnitTranslator(P, U, { form: F });
    const res = { form: null, module: null, classes: [], initCall: null };
    const formCls = F ? (U.classes || []).find(c => c.name.toLowerCase() === F.cls.toLowerCase()) : null;
    // campos e métodos do formulário
    if (formCls) {
      for (const f of formCls.fields) {
        const l = f.name.toLowerCase();
        if (F.controls.has(l) || F.conv.names.has(l)) continue; // componentes do DFM
        const t = tr.typeOf(f.type); tr.fields.set(l, { name: f.name, vbName: tr.safeName(f.name), type: t, vis: f.vis });
      }
      for (const m of formCls.methods) { const nm = m.name.toLowerCase(); tr.methods.set(nm, { name: m.name, vbName: tr.safeName(m.name), retType: m.ret ? tr.typeOf(m.ret) : null, vis: m.vis, decl: m }); }
      for (const r of U.routines) { const parts = r.name.split('.'); if (parts.length >= 2 && parts[parts.length - 2].toLowerCase() === F.cls.toLowerCase()) mergeParams(r, formCls.methods.find(m => m.name.toLowerCase() === parts[parts.length - 1].toLowerCase())); }
    }
    // símbolos locais da unidade (implementação e interface)
    const unitLevel = [];
    const addSym = (d, isPublic) => {
      if (d.kind === 'var') { const t = tr.typeOf(d.type); if (d.type && /^(textfile|text)$/i.test(d.type.name || '')) t.textFile = true; if (F && (t.form === F)) return; if (P.formByClass.has(String((d.type && d.type.name) || '').toLowerCase())) return; const s = { kind: 'var', name: d.name, vbName: tr.safeName(d.name), type: t, decl: d, isPublic }; tr.unitSyms.set(d.name.toLowerCase(), s); unitLevel.push(s); }
      else if (d.kind === 'const') { const s = { kind: 'const', name: d.name, vbName: tr.safeName(d.name), type: d.type ? tr.typeOf(d.type) : null, decl: d, isPublic }; tr.unitSyms.set(d.name.toLowerCase(), s); unitLevel.push(s); }
      else if (d.kind === 'routineDecl') { const r = d.routine; const nm = r.name.replace(/^.*\./, ''); tr.unitSyms.set(nm.toLowerCase(), { kind: 'routine', name: nm, vbName: tr.safeName(nm), retType: r.ret ? tr.typeOf(r.ret) : null, type: r.ret ? tr.typeOf(r.ret) : null, routine: r }); }
      else if (['record', 'enum'].includes(d.kind)) unitLevel.push({ kind: d.kind, decl: d, isPublic });
    };
    for (const d of U.ifaceDecls || []) addSym(d, true);
    for (const d of U.implDecls || []) addSym(d, false);
    for (const r of U.routines) { if (!r.name.includes('.')) { const dd = (U.ifaceDecls || []).find(d => d.kind === 'routineDecl' && d.routine.name.toLowerCase() === r.name.toLowerCase()); if (dd) mergeParams(r, dd.routine); } else { const parts = r.name.split('.'); const C = P.classes.get(parts[parts.length - 2].toLowerCase()); if (C) for (const cd of C.chain || [C.decl]) { const m = cd.methods.find(mm => mm.name.toLowerCase() === parts[parts.length - 1].toLowerCase()); if (m) { mergeParams(r, m); break; } } } }
    for (const r of U.routines) { const nm = r.name.replace(/^.*\./, ''); if (!r.name.includes('.')) { if (!tr.unitSyms.has(nm.toLowerCase())) tr.unitSyms.set(nm.toLowerCase(), { kind: 'routine', name: nm, vbName: tr.safeName(nm), retType: r.ret ? tr.typeOf(r.ret) : null, type: r.ret ? tr.typeOf(r.ret) : null, routine: r }); } }
    // separação: o que vai para o formulário e o que vai para o módulo .bas da unidade
    const formMethods = [], modRoutines = [], formRoutines = [], classMethods = new Map();
    for (const r of U.routines) {
      const parts = r.name.split('.');
      if (parts.length >= 2) {
        const cn = parts[parts.length - 2].toLowerCase();
        if (F && cn === F.cls.toLowerCase()) { formMethods.push(r); continue; }
        if (P.classes.has(cn)) { if (!classMethods.has(cn)) classMethods.set(cn, []); classMethods.get(cn).push(r); continue; }
        tr.warn(`method ${r.name} belongs to a class that was not converted`); continue;
      }
      const isIface = (U.ifaceDecls || []).some(d => d.kind === 'routineDecl' && d.routine.name.toLowerCase() === r.name.toLowerCase());
      if (F && !isIface) formRoutines.push(r); else modRoutines.push({ r, isPublic: isIface || !F });
    }
    const needModule = !F || modRoutines.length || unitLevel.some(s => s.isPublic && s.kind !== 'record' && s.kind !== 'enum') || unitLevel.some(s => s.isPublic && (s.kind === 'record' || s.kind === 'enum')) || U.init || U.fin;
    const modName = F ? vbIdent(U.name) + 'Unit' : vbIdent(U.name);
    // ----------------------------------------------- módulo .bas
    const declLines = (s, vis, inForm) => {
      const L = [];
      if (s.kind === 'var') {
        if (s.decl.init) { L.push(`${vis} ${tr.vbDecl(s.vbName, s.type.arr ? Object.assign({}, s.type, { arr: Object.assign({}, s.type.arr) }) : s.type)}`); s.needsInit = true; }
        else L.push(`${vis} ${tr.vbDecl(s.vbName, s.type, { allowFixed: !inForm })}`);
      } else if (s.kind === 'const') {
        const v = s.decl.value;
        if (v && v.k === 'arrlit' || (s.type && s.type.arr) || (s.type && s.type.rec)) { L.push(`${vis} ${s.vbName} As Variant`); s.needsInit = true; s.arrInit = true; }
        else { const ex = tr.expr(v); if (/^(Array|NB|CStr|Chr|IIf)/.test(ex.c) || /\(/.test(ex.c) && !/^-?\(/.test(ex.c)) { L.push(`${vis} ${s.vbName} As Variant`); s.needsInit = true; } else L.push(`${vis} Const ${s.vbName} = ${ex.c}`); }
      } else if (s.kind === 'record') {
        L.push(`${vis} Type ${vbIdent(s.decl.name)}`);
        const rec = P.records.get(s.decl.name.toLowerCase());
        for (const f of rec.fieldMap.values()) L.push(`    ${tr.vbDecl(f.vbName, f.type, { allowFixed: true })}`);
        L.push('End Type');
      } else if (s.kind === 'enum') {
        L.push(`${vis} Enum ${vbIdent(s.decl.name)}`);
        let n = 0; for (const it of s.decl.items) { if (it.value) { const v = tr.expr(it.value).c; L.push(`    ${it.name} = ${v}`); n = Number(v) + 1; } else L.push(`    ${it.name} = ${n++}`); }
        L.push('End Enum');
      }
      return L;
    };
    const initLines = syms => { const L = []; for (const s of syms) if (s.needsInit) { const v = s.decl.init || s.decl.value; const ex = tr.expr(v); L.push(`${s.type && s.type.obj ? 'Set ' : ''}${s.vbName} = ${ex.c}`); } return L; };
    if (needModule) {
      const L = [`Attribute VB_Name = "${modName}"`, `' Converted from the Delphi unit ${U.name} (${U.file}) by NeoBasic`];
      const modSyms = F ? unitLevel.filter(s => s.isPublic) : unitLevel;
      for (const s of modSyms) L.push(...declLines(s, s.isPublic || !F ? 'Public' : 'Private', false));
      const inits = initLines(modSyms);
      let hasInit = false;
      if (inits.length || U.init) {
        L.push('', `Public Sub ${modName}_Init()`);
        for (const x of inits) L.push('    ' + x);
        if (U.init) { tr.pushScope({ vars: new Map(), routine: { name: modName + '_Init', vbName: modName + '_Init', isFunc: false, vars: new Map(), inlineDecl: [] } }); const save = tr.out; tr.out = []; tr.stmtList(U.init, 1); L.push(...tr.out); tr.out = save; tr.popScope(); }
        L.push('End Sub'); hasInit = true;
      }
      for (const { r, isPublic } of modRoutines) { L.push(''); L.push(...tr.routine(r, { vis: isPublic ? 'Public' : 'Private' })); }
      if (U.fin) L.push('', "' [Delphi] the finalization section of this unit was not converted");
      res.module = { path: modName + '.bas', text: L.join('\r\n') + '\r\n' };
      if (hasInit) res.initCall = `${modName}_Init`;
    }
    // ----------------------------------------------- classes do usuário
    for (const C of P.classes.values()) {
      if (C.unit !== U) continue;
      res.classes.push(translateClass(P, tr, C, classMethods.get(C.name.toLowerCase()) || []));
    }
    // ----------------------------------------------- formulário
    if (F) {
      const L = [];
      L.push(`' Converted from the Delphi unit ${U.name} (${U.file}) by NeoBasic`);
      L.push('');
      // variáveis privadas da unidade e campos
      for (const s of unitLevel.filter(x => !x.isPublic)) L.push(...declLines(s, 'Private', true));
      for (const f of tr.fields.values()) L.push(`${f.vis === 'public' || f.vis === 'published' ? 'Public' : 'Private'} ${tr.vbDecl(f.vbName, f.type)}`);
      L.push('Public ModalResult As Long');
      L.push('Private NB_IsModal As Boolean');
      L.push('Private NB_TileMode As Long');
      L.push('');
      L.push('Public Function ShowModal() As Long', '    ModalResult = 0', '    NB_IsModal = True', '    Me.Show vbModal', '    NB_IsModal = False', '    ShowModal = ModalResult', 'End Function', '');
      L.push('Public Sub SetModalResult(ByVal Value As Long)', '    ModalResult = Value', '    If NB_IsModal And Value <> 0 Then Me.Hide', 'End Sub', '');
      L.push('Public Sub CloseForm()', '    If NB_IsModal Then', '        If ModalResult = 0 Then ModalResult = mrCancel', '        Me.Hide', '    Else', '        Unload Me', '    End If', 'End Sub', '');
      // páginas
      for (const pg of F.conv.pages.values()) {
        L.push(`Private Sub ${pg.tabsName}_Click(Index As Integer)`, `    NBShowPage_${pg.name} Index`, 'End Sub', '');
        L.push(`Private Function NBPage_${pg.name}() As Long`, `    NBPage_${pg.name} = NB_ActivePage_${pg.name}`, 'End Function', '');
        L.push(`Private Sub NBShowPage_${pg.name}(ByVal Index As Long)`);
        pg.sheets.forEach((s, i) => L.push(`    ${s}.Visible = (Index = ${i})`));
        L.push(`    NB_ActivePage_${pg.name} = Index`);
        if (pg.onChange) L.push(`    ${pg.onChange} ${pg.name}`);
        L.push('End Sub', '');
        L.push(`Private Function NBSheetIndex_${pg.name}(Sheet As Object) As Long`);
        pg.sheets.forEach((s, i) => L.push(`    If Sheet Is ${s} Then NBSheetIndex_${pg.name} = ${i}`));
        L.push('End Function', '');
        L.splice(L.indexOf('Private NB_TileMode As Long') + 1, 0, `Private NB_ActivePage_${pg.name} As Long`);
        if (pg.active) F.conv.init.push(`NB_ActivePage_${pg.name} = ${pg.active}`);
      }
      // eventos
      L.push(...eventStubs(P, tr, F, formMethods));
      // inicialização de constantes da unidade (privadas) -> Form_Load já incluso nos stubs
      for (const r of formMethods) {
        const mn = r.name.split('.').pop().toLowerCase();
        const mInfo = tr.methods.get(mn);
        const vis = mInfo && (mInfo.vis === 'public' || mInfo.vis === 'published' && !isEventHandler(F, r)) ? 'Public' : (mInfo && mInfo.vis === 'public' ? 'Public' : 'Private');
        L.push(''); L.push(...tr.routine(r, { vis }));
      }
      for (const r of formRoutines) { L.push(''); L.push(...tr.routine(r, { vis: 'Private' })); }
      const code = L.join('\r\n') + '\r\n';
      res.form = { path: F.name + '.frm', text: F.design + code };
    }
    return res;
  }
  function mergeParams(r, decl) {
    if (!decl || !decl.params) return;
    if (!r.params.length && decl.params.length) { r.params = decl.params; return; }
    r.params.forEach((p, i) => { const d = decl.params[i]; if (d && d.def && !p.def) p.def = d.def; });
    if (!r.ret && decl.ret) r.ret = decl.ret;
  }
  function isEventHandler(F, r) { const nm = r.name.split('.').pop().toLowerCase(); return F.conv.events.some(e => e.handler && e.handler.toLowerCase() === nm); }

  // eventos VB a partir dos eventos Delphi
  const EV = {
    onclick: 'Click', ondblclick: 'DblClick', onchange: 'Change', onenter: 'GotFocus', onexit: 'LostFocus', onkeypress: 'KeyPress', onkeydown: 'KeyDown', onkeyup: 'KeyUp',
    onmousedown: 'MouseDown', onmouseup: 'MouseUp', onmousemove: 'MouseMove', ontimer: 'Timer', oncreate: 'Load', onshow: 'Activate', onactivate: 'Activate', ondeactivate: 'Deactivate',
    onclose: 'Unload', onclosequery: 'QueryUnload', ondestroy: 'Terminate', onresize: 'Resize', onpaint: 'Paint', onscroll: 'Scroll', onselect: 'Click', ondropdown: 'DropDown', onhide: 'Deactivate',
  };
  const EV_SIG = { Click: '', DblClick: '', Change: '', GotFocus: '', LostFocus: '', KeyPress: 'KeyAscii As Integer', KeyDown: 'KeyCode As Integer, Shift As Integer', KeyUp: 'KeyCode As Integer, Shift As Integer', MouseDown: 'Button As Integer, Shift As Integer, X As Single, Y As Single', MouseUp: 'Button As Integer, Shift As Integer, X As Single, Y As Single', MouseMove: 'Button As Integer, Shift As Integer, X As Single, Y As Single', Timer: '', Load: '', Activate: '', Deactivate: '', Unload: 'Cancel As Integer', QueryUnload: 'Cancel As Integer, UnloadMode As Integer', Terminate: '', Resize: '', Paint: '', Scroll: '', DropDown: '' };
  function eventStubs(P, tr, F, formMethods) {
    const conv = F.conv;
    const groups = new Map(); // "ctl|Event" -> {ctl, ev, array, lines[]}
    const get = (ctl, ev, array) => { const k = (ctl || 'Form').toLowerCase() + '|' + ev; if (!groups.has(k)) groups.set(k, { ctl, ev, array, lines: [], pre: [], post: [] }); return groups.get(k); };
    const handlerOf = name => formMethods.find(r => r.name.split('.').pop().toLowerCase() === name.toLowerCase());
    // form load: inicialização
    const load = get(null, 'Load');
    for (const x of conv.init) load.pre.push(x);
    for (const ev of conv.events) {
      const vclEv = ev.vclEvent.toLowerCase();
      let vbEv = EV[vclEv];
      const isForm = !ev.ctl;
      if (!vbEv) { tr.warn(`event ${ev.vclEvent} of ${ev.ctl || F.name} has no NeoBasic equivalent`); continue; }
      if (vclEv === 'onchange' && (ev.kind === 'combo')) { const g2 = get(ev.ctl, 'Click', ev.array); addCall(g2, ev, 'Click'); }
      if (vclEv === 'onchange' && (ev.kind === 'check' || ev.kind === 'radio')) vbEv = 'Click';
      if (vclEv === 'onclick' && isForm) vbEv = 'Click';
      const g = get(ev.ctl, vbEv, ev.array);
      addCall(g, ev, vbEv);
    }
    function addCall(g, ev, vbEv) {
      const sender = ev.sender ? ev.sender : (ev.ctl ? (ev.array ? `${ev.ctl}(Index)` : ev.ctl) : 'Me');
      if (ev.raw) { g.lines.push(ev.raw); return; }
      if (ev.action) { g.lines.push(...conv.actionCall(ev.action, sender).split('\n')); return; }
      const h = handlerOf(ev.handler);
      const hn = tr.safeName(ev.handler);
      if (!h) { tr.warn(`the event handler ${ev.handler} was not found in ${F.unit.file}`); g.lines.push(`' [Delphi] ${ev.handler} ${sender}`); return; }
      const np = h.params.length;
      const vcl = ev.vclEvent.toLowerCase();
      switch (vcl) {
        case 'onclose': g.pre.push('Dim Action As Long', 'Action = caFree'); g.lines.push(`${hn} ${sender}, Action`); g.post.push('If Action = caNone Then Cancel = 1'); return;
        case 'onclosequery': g.pre.push('Dim CanClose As Boolean', 'CanClose = True'); g.lines.push(`${hn} ${sender}, CanClose`); g.post.push('If Not CanClose Then Cancel = 1'); return;
        case 'onkeypress': g.pre.push('Dim Key As String', 'Key = Chr$(KeyAscii)'); g.lines.push(`${hn} ${sender}, Key`); g.post.push('If Key = "" Then KeyAscii = 0 Else KeyAscii = Asc(Key)'); return;
        case 'onkeydown': case 'onkeyup': g.lines.push(`${hn} ${sender}, KeyCode, Shift`); return;
        case 'onmousedown': case 'onmouseup': g.lines.push(`${hn} ${sender}, Button, Shift, X, Y`); return;
        case 'onmousemove': g.lines.push(`${hn} ${sender}, Shift, X, Y`); return;
      }
      const extra = np > 1 ? ', ' + h.params.slice(1).map(() => '0').join(', ') : '';
      if (np > 1) tr.warn(`event ${ev.vclEvent} of ${ev.ctl || F.name}: extra parameters of ${ev.handler} receive 0`);
      g.lines.push(np === 0 ? hn : `${hn} ${sender}${extra}`);
    }
    // botões com ModalResult
    for (const mb of conv.modalButtons) { const g = get(mb.name, 'Click'); g.pre.unshift(`ModalResult = ${mb.value}`); g.post.push('SetModalResult ModalResult'); }
    // layout (âncoras / alinhamento)
    const lay = layoutLines(conv);
    if (lay.length) { const g = get(null, 'Resize'); g.pre.unshift(...lay); }
    const L = [];
    for (const g of groups.values()) {
      if (!g.lines.length && !g.pre.length && !g.post.length) continue;
      const name = (g.ctl || (conv.isMDI ? 'MDIForm' : 'Form')) + '_' + g.ev;
      let sig = EV_SIG[g.ev] || '';
      if (g.array) sig = 'Index As Integer' + (sig ? ', ' + sig : '');
      L.push(`Private Sub ${name}(${sig})`);
      for (const x of g.pre) L.push('    ' + x);
      for (const x of g.lines) L.push('    ' + x);
      for (const x of g.post) L.push('    ' + x);
      L.push('End Sub', '');
    }
    return L;
  }
  // redimensionamento: controles alinhados/ancorados no formulário
  function layoutLines(conv) {
    if (conv.isMDI) return [];
    const L = [];
    const cw = conv.clientW, ch = conv.clientH;
    for (const c of conv.root.children) {
      if (!c.name) continue;
      const info = conv.controls.get(c.name.toLowerCase());
      if (!info || !info.vbType || info.aligned || /Menu|Timer|CommonDialog/.test(info.vbType)) continue;
      const al = D.pIdent(c, 'Align', 'alNone').toLowerCase();
      let an = D.pSet(c, 'Anchors') || ['akleft', 'aktop'];
      if (al === 'alclient') an = ['akleft', 'aktop', 'akright', 'akbottom'];
      else if (al === 'altop') an = ['akleft', 'aktop', 'akright'];
      else if (al === 'albottom') an = ['akleft', 'akbottom', 'akright'];
      else if (al === 'alleft') an = ['akleft', 'aktop', 'akbottom'];
      else if (al === 'alright') an = ['akright', 'aktop', 'akbottom'];
      const R2 = an.includes('akright'), B = an.includes('akbottom'), Lf = an.includes('akleft'), Tp = an.includes('aktop');
      if (!R2 && !B) continue;
      const l = D.pNum(c, 'Left', 0), t = D.pNum(c, 'Top', 0), w = D.pNum(c, 'Width', 100), h = D.pNum(c, 'Height', 25);
      const rm = cw - (l + w), bm = ch - (t + h);
      const X = Lf ? `${l}` : `Me.ScaleWidth - ${rm + w}`;
      const Y = Tp ? `${t}` : `Me.ScaleHeight - ${bm + h}`;
      const W = Lf && R2 ? `NBMax(0, Me.ScaleWidth - ${l + rm})` : `${w}`;
      const H = Tp && B ? `NBMax(0, Me.ScaleHeight - ${t + bm})` : `${h}`;
      L.push(`${info.name}.Move ${X}, ${Y}, ${W}, ${H}`);
    }
    if (L.length) { L.unshift('If Me.WindowState = vbMinimized Then Exit Sub', 'On Error Resume Next'); L.push('On Error GoTo 0'); }
    return L;
  }

  // classe do usuário -> .cls
  function translateClass(P, unitTr, C, methods) {
    const tr = new UnitTranslator(P, C.unit, { cls: C });
    tr.unitSyms = unitTr.unitSyms;
    for (const f of C.fieldMap.values()) tr.fields.set(f.name.toLowerCase(), f);
    for (const [k, m] of C.members) if (m.method) tr.methods.set(k, { name: m.name, vbName: tr.safeName(m.name), retType: m.type, decl: m.method });
    const L = ['VERSION 1.0 CLASS', 'BEGIN', '  MultiUse = -1  \'True', 'END', `Attribute VB_Name = "${C.vbName}"`, 'Attribute VB_GlobalNameSpace = False', 'Attribute VB_Creatable = True', 'Attribute VB_PredeclaredId = False', 'Attribute VB_Exposed = False', `' Converted from the Delphi class ${C.name} (${C.unit.file}) by NeoBasic`, ''];
    for (const f of C.fieldMap.values()) L.push(`Public ${tr.vbDecl(f.vbName, f.type)}`);
    // propriedades com read/write
    for (const cd of C.chain) for (const pr of cd.props) {
      if (!pr.type) continue;
      const t = tr.typeOf(pr.type); const tn = tr.vbTypeName(t);
      const rd = pr.read && pr.read.toLowerCase(), wr = pr.write && pr.write.toLowerCase();
      if (rd) { L.push('', `Public Property Get ${pr.name}() As ${tn}`); L.push(`    ${t.obj ? 'Set ' : ''}${pr.name} = ${C.fieldMap.has(rd) ? C.fieldMap.get(rd).vbName : tr.safeName(pr.read)}`); L.push('End Property'); }
      if (wr) { L.push('', `Public Property ${t.obj ? 'Set' : 'Let'} ${pr.name}(${t.obj ? '' : 'ByVal '}NewValue As ${tn})`); L.push(C.fieldMap.has(wr) ? `    ${t.obj ? 'Set ' : ''}${C.fieldMap.get(wr).vbName} = NewValue` : `    ${tr.safeName(pr.write)} NewValue`); L.push('End Property'); }
    }
    for (const r of methods) {
      const nm = r.name.split('.').pop();
      if (r.kind === 'constructor') { L.push(''); L.push(...tr.routine(Object.assign({}, r, { name: 'Create' }), { vis: 'Public', vbName: 'Create' })); continue; }
      if (r.kind === 'destructor') { L.push(''); L.push(...tr.routine(r, { vis: 'Public', vbName: 'Destroy' })); L.push('', 'Private Sub Class_Terminate()', '    Destroy', 'End Sub'); continue; }
      const prop = [...C.members.values()].find(m => m.prop && ((m.prop.read || '').toLowerCase() === nm.toLowerCase() || (m.prop.write || '').toLowerCase() === nm.toLowerCase()));
      L.push(''); L.push(...tr.routine(r, { vis: prop ? 'Private' : 'Public' }));
    }
    const text = L.join('\r\n') + '\r\n';
    // fábrica para construtor com parâmetros
    if (C.ctor) {
      const ps = C.ctor.params.map(p => (p.mode === 'var' ? '' : 'ByVal ') + tr.safeName(p.name) + ' As ' + tr.vbTypeName(tr.typeOf(p.type)));
      const extra = `\r\nPublic Function NBNew_${C.vbName}(${ps.join(', ')}) As ${C.vbName}\r\n    Dim o As New ${C.vbName}\r\n    o.Create ${C.ctor.params.map(p => tr.safeName(p.name)).join(', ')}\r\n    Set NBNew_${C.vbName} = o\r\nEnd Function\r\n`;
      C.factory = extra;
    }
    return { path: C.vbName + '.cls', text, factory: C.factory };
  }

  return { convertProject, Report, COMPAT_BAS, TSTRINGLIST_CLS, TSTRINGSCTL_CLS, UnitTranslator };
})();
if (typeof module !== 'undefined') module.exports = DelphiConvert;
