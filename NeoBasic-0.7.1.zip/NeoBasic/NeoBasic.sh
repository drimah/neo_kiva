#!/bin/sh
# NeoBasic 0.6.13 — Linux launcher (also used by exported apps: Agenda.sh opens Agenda.html).
# Order: 1) the NeoBasic main window opens and shows what is happening
#        2) if MySQL is missing, it asks inside NeoBasic: Install MySQL / Exit
#        3) installation progress inside NeoBasic  4) the main window connects to MySQL by itself.
set -u
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
APP="$(basename "$0" .sh)"
HTML="$DIR/$APP.html"
BOOT="$DIR/mysql-bootstrap.sh"
ICON_FILE="$DIR/icone/neobasic.png"
[ -f "$DIR/$APP.png" ] && ICON_FILE="$DIR/$APP.png"
[ -f "$ICON_FILE" ] || ICON_FILE="$DIR/../icone/neobasic.png"
SLUG="$(printf '%s' "$APP" | tr 'A-Z ' 'a-z-')"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/neobasic"
if [ "$APP" = "NeoBasic" ]; then PERFIL="$DATA/perfil"; else PERFIL="$DATA/apps/$APP"; fi

aviso() {
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --title="$APP" --width=480 --ok-label="OK" --text="$1" 2>/dev/null || true
  else
    printf '%s: %s\n' "$APP" "$1" >&2
  fi
}

[ -f "$HTML" ] || { aviso "$APP.html was not found. Keep $APP.sh in the same folder as $APP.html."; exit 1; }
[ -f "$BOOT" ] || { aviso "mysql-bootstrap.sh is missing from the $APP folder."; exit 1; }
chmod +x "$DIR/$APP.sh" "$BOOT" 2>/dev/null || true

# ---------- menu entry and taskbar icon ----------
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
if [ -f "$ICON_FILE" ] && [ -z "${NEOBASIC_DRYRUN:-}" ]; then
  mkdir -p "$APPS"
  cat > "$APPS/$SLUG.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=$APP
Comment=$APP
Exec="$DIR/$APP.sh"
Path=$DIR
Icon=$ICON_FILE
Terminal=false
Categories=Development;IDE;
StartupWMClass=$SLUG
StartupNotify=true
DESKTOP
  chmod +x "$APPS/$SLUG.desktop" 2>/dev/null || true
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
fi

# ---------- browser (Chromium family) ----------
LISTA="google-chrome google-chrome-stable chromium chromium-browser brave-browser brave vivaldi vivaldi-stable opera microsoft-edge microsoft-edge-stable"
if [ -f "$DIR/navegador.txt" ]; then
  ESC="$(head -n 1 "$DIR/navegador.txt" | tr -d '\r"' | sed 's/^[ \t]*//;s/[ \t]*$//')"
  case "$(printf '%s' "$ESC" | tr 'A-Z' 'a-z')" in
    chrome) LISTA="google-chrome google-chrome-stable $LISTA" ;;
    brave) LISTA="brave-browser brave $LISTA" ;;
    vivaldi) LISTA="vivaldi vivaldi-stable $LISTA" ;;
    chromium) LISTA="chromium chromium-browser $LISTA" ;;
    opera) LISTA="opera $LISTA" ;;
    edge) LISTA="microsoft-edge microsoft-edge-stable $LISTA" ;;
    "") ;;
    *) [ -x "$ESC" ] && LISTA="$ESC $LISTA" ;;
  esac
fi
BROWSER=""
for B in $LISTA; do command -v "$B" >/dev/null 2>&1 && { BROWSER="$B"; break; }; done
if [ -z "$BROWSER" ] && command -v flatpak >/dev/null 2>&1; then
  for F in com.google.Chrome org.chromium.Chromium com.brave.Browser com.microsoft.Edge; do
    flatpak info "$F" >/dev/null 2>&1 && { BROWSER="flatpak:$F"; break; }
  done
fi
[ -n "$BROWSER" ] || { aviso "$APP needs Chrome, Chromium, Brave or Vivaldi. Install one of them (Software Manager) and try again."; exit 1; }

FLAGS="--start-maximized --no-first-run --no-default-browser-check --disable-features=Translate --lang=en-US"
browser_bg() { # browser_bg <url>  -> prints the browser pid (it leads its own process group)
  if [ "${BROWSER#flatpak:}" != "$BROWSER" ]; then
    setsid flatpak run --filesystem=home "${BROWSER#flatpak:}" --app="$1" --user-data-dir="$PERFIL" --class="$SLUG" $FLAGS >/dev/null 2>&1 < /dev/null &
  else
    setsid "$BROWSER" --app="$1" --user-data-dir="$PERFIL" --class="$SLUG" $FLAGS >/dev/null 2>&1 < /dev/null &
  fi
  echo $!
}
# the real NeoBasic icon on the window (Chrome itself only sets a 16 px favicon)
ICON_ARGB="$DIR/icone/neobasic-icon.argb"
start_icon() {
  [ -f "$ICON_ARGB" ] && [ -f "$DIR/neobasic-wmicon.py" ] && command -v python3 >/dev/null 2>&1 || return 0
  setsid python3 "$DIR/neobasic-wmicon.py" --class "$SLUG" --pid "$1" --icon "$ICON_ARGB" >/dev/null 2>&1 < /dev/null &
}
file_url() { python3 -c 'import sys, urllib.parse; print("file://" + urllib.parse.quote(sys.argv[1]))' "$1" 2>/dev/null || printf 'file://%s' "$1"; }
mkdir -p "$PERFIL"

if [ "$APP" = "NeoBasic" ]; then
  # fixed port: options, recent project and remembered folder survive version/folder changes
  PORT=43821
  if [ -z "${NEOBASIC_DRYRUN:-}" ] && [ -f "$DIR/neobasic-setup.py" ] && command -v python3 >/dev/null 2>&1; then
    # 1) the NeoBasic main window opens first and shows the user what is happening
    #    (connecting, "MySQL Server is required", installation progress, errors)
    BPID="$(browser_bg "$(file_url "$HTML")?app=1&setup=1")"
    start_icon "$BPID"
    # 2) the setup service answers the main window; it installs MySQL only if the user clicks "Install MySQL"
    python3 "$DIR/neobasic-setup.py" --port 43820 --bridge-port "$PORT"
    RC=$?
    # 3) "Exit", or an error the user already saw: close the main window
    [ "$RC" -eq 0 ] || kill -TERM -- "-$BPID" 2>/dev/null || kill "$BPID" 2>/dev/null || true
    exit 0
  fi
  STATE="$(sh "$BOOT" status)"
  [ "$STATE" = ready ] || sh "$BOOT" install "$DIR" || exit 1
  PORT="$(sh "$BOOT" bridge "$DIR" "$PORT")" || exit 1
  URL="http://127.0.0.1:$PORT/NeoBasic.html?app=1"
else
  # Exported app: never installs anything. Only NeoBasic installs MySQL.
  ROOT="$DIR"; REL="$APP.html"
  if [ "$(basename "$DIR")" = "Executables" ]; then ROOT="$(dirname "$DIR")"; REL="Executables/$APP.html"; fi
  if [ "$(sh "$BOOT" status)" != ready ]; then
    aviso "$APP uses MySQL Server, which is not ready on this computer yet.\n\nOpen NeoBasic once and allow it to install MySQL, then open $APP again."
    exit 1
  fi
  H="$(printf '%s' "$ROOT" | cksum | awk '{print $1}')"
  PORT="$(sh "$BOOT" bridge "$ROOT" $((44000 + H % 15000)))" || exit 1
  URL="http://127.0.0.1:$PORT/$REL?app=1"
fi

[ -n "${NEOBASIC_DRYRUN:-}" ] && { echo "$BROWSER --app=$URL"; exit 0; }
start_icon $$
if [ "${BROWSER#flatpak:}" != "$BROWSER" ]; then
  exec flatpak run --filesystem=home "${BROWSER#flatpak:}" --app="$URL" --user-data-dir="$PERFIL" --class="$SLUG" $FLAGS
fi
exec "$BROWSER" --app="$URL" --user-data-dir="$PERFIL" --class="$SLUG" $FLAGS
