#!/bin/sh
# NeoBasic — instalação obrigatória do MySQL Server (Linux Mint/Ubuntu).
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/neobasic"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/mysql-install.log"
SERVER_ROOT="$DIR"
if [ "$(basename "$DIR")" = "Executables" ]; then SERVER_ROOT="$(dirname "$DIR")"; fi
ROOT_HASH="$(printf '%s' "$SERVER_ROOT" | cksum | awk '{print $1}')"
PORT=$((40000 + ROOT_HASH % 20000))

bridge_ok() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1
  else
    python3 -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:$PORT/api/health', timeout=2)" >/dev/null 2>&1
  fi
}

fail() {
  MSG="$1"
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --title="NeoBasic — MySQL obrigatório" --width=520 --text="$MSG" 2>/dev/null || true
  else
    printf '%s\n' "$MSG" >&2
  fi
  exit 1
}

mysql_ok() {
  command -v mysqladmin >/dev/null 2>&1 && mysqladmin --protocol=socket -uroot ping >/dev/null 2>&1
}

# MySQL já operacional: não reinstala. Ainda assim, cria a conta/configuração
# específica do NeoBasic se esta for a primeira execução neste usuário.
CONFIG="$HOME/.config/neobasic/mysql.json"
if ! mysql_ok || [ ! -s "$CONFIG" ] || ! /usr/bin/python3 -c 'import pymysql, cryptography' >/dev/null 2>&1; then
  if ! command -v zenity >/dev/null 2>&1; then
    fail "O NeoBasic precisa do MySQL Server e da interface Zenity para a instalação automática. Instale zenity e tente novamente."
  fi
  (
    echo "5"
    echo "# Verificando o sistema e preparando a instalação do MySQL Server..."
    if command -v pkexec >/dev/null 2>&1; then
      pkexec /bin/sh "$DIR/mysql-install-root.sh" "$HOME" "$USER" "$(id -u)" "$(id -g)" >>"$LOG" 2>&1
    elif command -v sudo >/dev/null 2>&1; then
      sudo /bin/sh "$DIR/mysql-install-root.sh" "$HOME" "$USER" "$(id -u)" "$(id -g)" >>"$LOG" 2>&1
    else
      exit 90
    fi
    echo "100"
    echo "# MySQL instalado e configurado."
  ) | zenity --progress --title="NeoBasic — Instalando MySQL" \
      --text="O MySQL Server é obrigatório para utilizar o NeoBasic." \
      --percentage=0 --pulsate --auto-close --no-cancel --width=520
  STATUS=$?
  if [ "$STATUS" -ne 0 ] || ! mysql_ok; then
    fail "Não foi possível instalar ou iniciar o MySQL Server. Consulte o registro em:
$LOG"
  fi
fi

# Não aceita MariaDB como substituto silencioso do MySQL.
MYSQL_VERSION="$(mysqld --version 2>/dev/null || true)"
case "$MYSQL_VERSION" in
  *MariaDB*) fail "Foi encontrado MariaDB, mas o NeoBasic exige MySQL Server. Nenhum banco existente foi removido." ;;
  *MySQL*) ;;
  *) fail "Não consegui confirmar que o servidor instalado é MySQL Server. Consulte $LOG." ;;
esac

# Inicia o bridge local, que serve o HTML e mantém o banco MySQL acessível ao runtime.
if bridge_ok; then
  exit 0
fi
PYTHON="/usr/bin/python3"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3 || true)"
[ -n "$PYTHON" ] || fail "Python 3 não foi encontrado."
"$PYTHON" "$DIR/mysql-bridge.py" --root "$SERVER_ROOT" --port "$PORT" >>"$LOG" 2>&1 &
BRIDGE_PID=$!
i=0
while [ "$i" -lt 40 ]; do
  if bridge_ok; then
    exit 0
  fi
  if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then break; fi
  sleep 0.25
  i=$((i + 1))
done
fail "O serviço local de integração com MySQL não iniciou. Consulte $LOG."
