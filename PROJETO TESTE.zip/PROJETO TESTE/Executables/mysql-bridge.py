#!/usr/bin/env python3
"""NeoBasic local MySQL bridge. Binds only to 127.0.0.1."""
import argparse, base64, hashlib, json, os, secrets, sqlite3, threading, tempfile
from datetime import date, datetime, time
from decimal import Decimal
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlparse

try:
    import pymysql
except Exception as exc:
    raise SystemExit("python3-pymysql não está instalado: " + str(exc))

CONFIG = Path.home() / ".config" / "neobasic" / "mysql.json"
CATALOG = "__nb_mysql_catalog"

def config():
    with CONFIG.open("r", encoding="utf-8") as f:
        return json.load(f)

def connect():
    c = config()
    return pymysql.connect(
        unix_socket=c.get("socket", "/var/run/mysqld/mysqld.sock"),
        host="localhost", user=c["user"], password=c["password"],
        database=c["database"], charset="utf8mb4", autocommit=False,
        cursorclass=pymysql.cursors.DictCursor
    )

def ensure_catalog(conn):
    with conn.cursor() as cur:
        cur.execute(f"""CREATE TABLE IF NOT EXISTS `{CATALOG}` (
          db_key CHAR(64) NOT NULL,
          table_name VARCHAR(255) NOT NULL,
          mysql_table VARCHAR(64) NOT NULL,
          create_sql LONGTEXT,
          PRIMARY KEY (db_key, table_name),
          UNIQUE KEY uq_mysql_table (mysql_table)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
    conn.commit()

def ident(value):
    return "`" + str(value).replace("`", "``") + "`"

def key_hash(key):
    return hashlib.sha256(str(key).encode("utf-8")).hexdigest()

def sqlite_type(declared):
    t = (declared or "").upper()
    if "INT" in t: return "BIGINT"
    if any(x in t for x in ("REAL", "FLOA", "DOUB")): return "DOUBLE"
    if any(x in t for x in ("NUM", "DEC")): return "DECIMAL(38,10)"
    if "BLOB" in t: return "LONGBLOB"
    if any(x in t for x in ("DATE", "TIME")): return "DATETIME"
    return "LONGTEXT"

def to_mysql_value(value):
    if isinstance(value, (datetime, date, time)): return value.isoformat(sep=" ") if isinstance(value, datetime) else value.isoformat()
    if isinstance(value, Decimal): return str(value)
    if isinstance(value, memoryview): return bytes(value)
    return value

def sqlite_snapshot(blob):
    fd, path = tempfile.mkstemp(prefix="neobasic-db-", suffix=".sqlite")
    with os.fdopen(fd, "wb") as f:
        f.write(blob)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    _TEMP_DB_PATHS[id(db)] = path
    return db

_TEMP_DB_PATHS = {}

def close_snapshot(db):
    path = _TEMP_DB_PATHS.pop(id(db), None)
    db.close()
    if path:
        try: os.unlink(path)
        except OSError: pass

def table_definitions(db):
    names = [r[0] for r in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    )]
    result = []
    for name in names:
        info = list(db.execute(f"PRAGMA table_info({ident(name)})"))
        if not info: continue
        create_row = db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        create_sql = create_row[0] if create_row else None
        pk = [r["name"] for r in sorted(info, key=lambda x: x["pk"]) if r["pk"]]
        auto = bool(create_sql and "AUTOINCREMENT" in create_sql.upper())
        cols = []
        for col in info:
            ty = sqlite_type(col["type"])
            if col["pk"] and ty == "LONGTEXT":
                ty = "VARCHAR(191)"
            part = ident(col["name"]) + " " + ty
            if col["notnull"]: part += " NOT NULL"
            if auto and len(pk) == 1 and col["name"] == pk[0] and "INT" in (col["type"] or "").upper():
                part = ident(col["name"]) + " BIGINT NOT NULL AUTO_INCREMENT"
            cols.append(part)
        if pk: cols.append("PRIMARY KEY (" + ",".join(ident(x) for x in pk) + ")")
        # Preserva índices únicos simples do SQLite.
        ddl = "CREATE TABLE " + ident("tmp") + " (" + ",".join(cols) + ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        result.append((name, create_sql, ddl, [r["name"] for r in info]))
    return result

def import_snapshot(conn, dbkey, blob):
    db = sqlite_snapshot(blob)
    defs = table_definitions(db)
    old_tables = []
    with conn.cursor() as cur:
        cur.execute(f"SELECT mysql_table FROM `{CATALOG}` WHERE db_key=%s", (dbkey,))
        old_tables = [r["mysql_table"] for r in cur.fetchall()]
    version = secrets.token_hex(4)
    new_catalog = []
    try:
        with conn.cursor() as cur:
            for name, create_sql, ddl, columns in defs:
                suffix = hashlib.sha1(name.encode("utf-8")).hexdigest()[:10]
                physical = f"nb_{dbkey[:10]}_{suffix}_{version}"
                ddl = ddl.replace(ident("tmp"), ident(physical), 1)
                cur.execute(ddl)
                colsql = ",".join(ident(c) for c in columns)
                placeholders = ",".join(["%s"] * len(columns))
                rows = db.execute(f"SELECT {','.join(ident(c) for c in columns)} FROM {ident(name)}")
                batch = []
                for row in rows:
                    batch.append(tuple(to_mysql_value(row[c]) for c in columns))
                    if len(batch) >= 500:
                        cur.executemany(f"INSERT INTO {ident(physical)} ({colsql}) VALUES ({placeholders})", batch)
                        batch.clear()
                if batch:
                    cur.executemany(f"INSERT INTO {ident(physical)} ({colsql}) VALUES ({placeholders})", batch)
                new_catalog.append((dbkey, name, physical, create_sql))
            cur.execute(f"DELETE FROM `{CATALOG}` WHERE db_key=%s", (dbkey,))
            if new_catalog:
                cur.executemany(f"INSERT INTO `{CATALOG}` (db_key,table_name,mysql_table,create_sql) VALUES (%s,%s,%s,%s)", new_catalog)
        conn.commit()
    except Exception:
        conn.rollback()
        with conn.cursor() as cur:
            for _, _, physical, _ in new_catalog:
                cur.execute(f"DROP TABLE IF EXISTS {ident(physical)}")
        conn.commit()
        raise
    with conn.cursor() as cur:
        for table in old_tables:
            if table not in [x[2] for x in new_catalog]:
                cur.execute(f"DROP TABLE IF EXISTS {ident(table)}")
    conn.commit()
    close_snapshot(db)

def export_snapshot(conn, dbkey):
    fd, out_path = tempfile.mkstemp(prefix="neobasic-export-", suffix=".sqlite")
    os.close(fd)
    out = sqlite3.connect(out_path)
    with conn.cursor() as cur:
        cur.execute(f"SELECT table_name,mysql_table,create_sql FROM `{CATALOG}` WHERE db_key=%s ORDER BY table_name", (dbkey,))
        catalog = cur.fetchall()
    for item in catalog:
        name, physical, create_sql = item["table_name"], item["mysql_table"], item["create_sql"]
        if create_sql:
            out.execute(create_sql)
        else:
            with conn.cursor() as cur:
                cur.execute(f"SHOW COLUMNS FROM {ident(physical)}")
                cols = cur.fetchall()
            parts = [ident(c["Field"]) + " " + ("INTEGER" if "int" in c["Type"].lower() else "TEXT") for c in cols]
            out.execute("CREATE TABLE " + ident(name) + " (" + ",".join(parts) + ")")
        with conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {ident(physical)}")
            rows = cur.fetchall()
            columns = [d[0] for d in cur.description]
        if rows:
            values = []
            for row in rows:
                vals = []
                for col in columns:
                    v = row[col]
                    if isinstance(v, (datetime, date, time)): v = v.isoformat(sep=" ") if isinstance(v, datetime) else v.isoformat()
                    elif isinstance(v, Decimal): v = float(v)
                    elif isinstance(v, memoryview): v = bytes(v)
                    vals.append(v)
                values.append(tuple(vals))
            out.executemany(
                "INSERT INTO " + ident(name) + " (" + ",".join(ident(c) for c in columns) + ") VALUES (" + ",".join(["?"]*len(columns)) + ")",
                values
            )
    out.commit()
    out.close()
    try:
        with open(out_path, "rb") as f:
            return f.read()
    finally:
        try: os.unlink(out_path)
        except OSError: pass

class Handler(SimpleHTTPRequestHandler):
    server_version = "NeoBasicMySQLBridge/1.0"
    def translate_path(self, path):
        rel = unquote(urlparse(path).path).lstrip("/")
        target = (self.server.web_root / rel).resolve()
        try: target.relative_to(self.server.web_root.resolve())
        except ValueError: return str(self.server.web_root / "__not_found__")
        return str(target)

    def send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/api/health"):
            try:
                with connect() as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT VERSION() AS version")
                        row = cur.fetchone()
                return self.send_json(200, {"ok": True, "mysql": row["version"]})
            except Exception as exc:
                return self.send_json(503, {"ok": False, "error": str(exc)})
        super().do_GET()

    def do_POST(self):
        if self.path not in ("/api/db/open", "/api/db/save"):
            return self.send_json(404, {"error": "Endpoint não encontrado."})
        try:
            cfg = config()
            if self.headers.get("X-NeoBasic-Token", "") != cfg.get("token"):
                return self.send_json(403, {"error": "Token local inválido."})
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 150 * 1024 * 1024:
                return self.send_json(413, {"error": "Tamanho de solicitação inválido."})
            payload = json.loads(self.rfile.read(length))
            key = str(payload.get("key", ""))
            if not key or len(key) > 1000: return self.send_json(400, {"error": "Identificador de banco inválido."})
            dbkey = key_hash(key)
            with connect() as conn:
                ensure_catalog(conn)
                if self.path.endswith("/open"):
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT COUNT(*) AS n FROM `{CATALOG}` WHERE db_key=%s", (dbkey,))
                        exists = cur.fetchone()["n"] > 0
                    if exists:
                        blob = export_snapshot(conn, dbkey)
                    else:
                        blob = base64.b64decode(payload.get("sqlite_b64", ""), validate=True)
                        import_snapshot(conn, dbkey, blob)
                    return self.send_json(200, {"ok": True, "sqlite_b64": base64.b64encode(blob).decode("ascii"), "source": "mysql" if exists else "imported"})
                blob = base64.b64decode(payload.get("sqlite_b64", ""), validate=True)
                import_snapshot(conn, dbkey, blob)
                return self.send_json(200, {"ok": True})
        except Exception as exc:
            return self.send_json(500, {"error": str(exc)})

    def end_headers(self):
        super().end_headers()
        # Local IDE pages are served from the same origin; API calls need no CORS.

    def do_HEAD(self):
        super().do_HEAD()

    def send_head(self):
        path = self.translate_path(self.path)
        if path.lower().endswith(".html") and os.path.isfile(path):
            try:
                data = Path(path).read_bytes()
                token = config()["token"]
                inject = ("<script>window.NB_MYSQL_API_TOKEN=" + json.dumps(token) +
                          ";window.NB_MYSQL_API_BASE=location.origin;</script>").encode("utf-8")
                if b"</head>" in data.lower():
                    idx = data.lower().find(b"</head>")
                    data = data[:idx] + inject + data[idx:]
                else:
                    data = inject + data
                import io
                f = io.BytesIO(data)
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                return f
            except Exception as exc:
                self.send_error(500, str(exc))
                return None
        return super().send_head()

    def log_message(self, fmt, *args):
        # Keep a compact local log without query contents or credentials.
        print("%s - %s" % (self.address_string(), fmt % args), flush=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--port", type=int, default=43821)
    args = ap.parse_args()
    root = Path(args.root).resolve()
    cfg = config()
    with connect() as conn: ensure_catalog(conn)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.web_root = root
    print(f"NeoBasic MySQL bridge ativo em http://127.0.0.1:{args.port}/", flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
