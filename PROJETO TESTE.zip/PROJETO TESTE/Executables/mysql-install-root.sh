#!/bin/sh
# Executado com privilégios administrativos pelo mysql-bootstrap.sh.
set -eu
USER_HOME="${1:?HOME do usuário ausente}"
USER_NAME="${2:?Usuário ausente}"
USER_UID="${3:?UID ausente}"
USER_GID="${4:?GID ausente}"
LOG="${XDG_STATE_HOME:-/var/log}/neobasic-mysql-install.log"
export DEBIAN_FRONTEND=noninteractive

. /etc/os-release
CODENAME="${UBUNTU_CODENAME:-${VERSION_CODENAME:-}}"
case "${ID:-}" in
  ubuntu|linuxmint|pop) ;;
  *) echo "Sistema não suportado para instalação automática: ${ID:-desconhecido}" >&2; exit 10 ;;
esac
case "$CODENAME" in
  jammy|noble|oracular|questing) ;;
  *) echo "Base Ubuntu não suportada: $CODENAME" >&2; exit 11 ;;
esac

# Se houver MariaDB, não o substitui. Se já houver MySQL 8.x, preserva a versão e os dados.
EXISTING_MYSQL=0
if command -v mysqld >/dev/null 2>&1; then
  VERSION="$(mysqld --version 2>/dev/null || true)"
  case "$VERSION" in
    *MariaDB*) echo "MariaDB detectado. O instalador não o remove nem o substitui." >&2; exit 12 ;;
    *) EXISTING_MYSQL=1 ;;
  esac
fi

apt-get update
apt-get install -y ca-certificates curl gnupg debconf-utils python3 python3-pymysql python3-cryptography openssl

if [ "$EXISTING_MYSQL" -eq 0 ]; then
  # Repositório oficial MySQL APT, com a série LTS 8.4 selecionada sem diálogo interativo.
  TMP_DEB="$(mktemp /tmp/mysql-apt-config-XXXXXX.deb)"
  trap 'rm -f "$TMP_DEB"' EXIT
  curl -fL --retry 3 --retry-delay 2 "https://dev.mysql.com/get/mysql-apt-config_0.8.40-1_all.deb" -o "$TMP_DEB"
  printf '%s\n' "mysql-apt-config mysql-apt-config/repo-distro select ubuntu" | debconf-set-selections
  printf '%s\n' "mysql-apt-config mysql-apt-config/repo-codename select $CODENAME" | debconf-set-selections
  printf '%s\n' "mysql-apt-config mysql-apt-config/select-server select mysql-8.4-lts" | debconf-set-selections
  printf '%s\n' "mysql-apt-config mysql-apt-config/select-tools select Enabled" | debconf-set-selections
  printf '%s\n' "mysql-apt-config mysql-apt-config/select-product select Ok" | debconf-set-selections
  printf '%s\n' "mysql-community-server mysql-community-server/root-pass password " "mysql-community-server mysql-community-server/re-root-pass password " | debconf-set-selections
  DEBIAN_FRONTEND=noninteractive dpkg -i "$TMP_DEB"
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y mysql-server mysql-client
else
  echo "MySQL existente detectado; mantendo a versão e os dados atuais."
fi

systemctl enable mysql
systemctl start mysql
for n in $(seq 1 30); do
  if mysqladmin --protocol=socket -uroot ping >/dev/null 2>&1; then break; fi
  sleep 1
done
mysqladmin --protocol=socket -uroot ping >/dev/null 2>&1 || {
  echo "MySQL Server não respondeu após a instalação." >&2
  exit 13
}
if [ "$EXISTING_MYSQL" -eq 0 ]; then
  MYSQL_VERSION="$(mysqld --version 2>/dev/null || true)"
  case "$MYSQL_VERSION" in
    *"Ver 8.4."*) ;;
    *) echo "A instalação não confirmou MySQL 8.4 LTS: $MYSQL_VERSION" >&2; exit 14 ;;
  esac
fi

CONFIG_DIR="$USER_HOME/.config/neobasic"
CONFIG="$CONFIG_DIR/mysql.json"
mkdir -p "$CONFIG_DIR"
chmod 700 "$CONFIG_DIR"

if [ -s "$CONFIG" ]; then
  APP_PASSWORD="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("password",""))' "$CONFIG" 2>/dev/null || true)"
  API_TOKEN="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("token",""))' "$CONFIG" 2>/dev/null || true)"
else
  APP_PASSWORD=""
  API_TOKEN=""
fi
[ -n "$APP_PASSWORD" ] || APP_PASSWORD="$(openssl rand -hex 32)"
[ -n "$API_TOKEN" ] || API_TOKEN="$(openssl rand -hex 32)"

# Senha gerada em hexadecimal: sem caracteres que alterem o SQL.
mysql --protocol=socket -uroot <<SQL
CREATE DATABASE IF NOT EXISTS neobasic_runtime CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'neobasic_app'@'localhost' IDENTIFIED BY '$APP_PASSWORD';
ALTER USER 'neobasic_app'@'localhost' IDENTIFIED BY '$APP_PASSWORD';
GRANT ALL PRIVILEGES ON neobasic_runtime.* TO 'neobasic_app'@'localhost';
FLUSH PRIVILEGES;
SQL

python3 - "$CONFIG" "$APP_PASSWORD" "$API_TOKEN" <<'PY'
import json, os, sys, tempfile
path, password, token = sys.argv[1:]
data = {
  "host": "127.0.0.1",
  "port": 3306,
  "database": "neobasic_runtime",
  "user": "neobasic_app",
  "password": password,
  "token": token,
  "socket": "/var/run/mysqld/mysqld.sock"
}
os.makedirs(os.path.dirname(path), exist_ok=True)
fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".mysql-", text=True)
with os.fdopen(fd, "w") as f:
    json.dump(data, f)
    f.write("\n")
os.chmod(tmp, 0o600)
os.replace(tmp, path)
PY
chown -R "$USER_UID:$USER_GID" "$CONFIG_DIR"
chmod 600 "$CONFIG"
echo "MySQL Server instalado; banco neobasic_runtime e usuário local configurados."
