VERSION 5.00
Begin VB.Form frmAlunos 
   Caption         =   "Alunos"
   ClientHeight    =   7440
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   12600
   LinkTopic       =   "Form1"
   ScaleHeight     =   7440
   ScaleWidth      =   12600
   Icon            =   "BOOKS.frx":0000
   WindowState     =   0  'Normal
   StartUpPosition =   2  'CenterScreen
   BorderStyle     =   1  'Fixed Single
   Begin VB.Label lblRA 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "RA"
      Height          =   350
      Left            =   360
      Top             =   1077
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtRA 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   360
      TabIndex        =   1
      Top             =   1380
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "RA"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblNome 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Nome"
      Height          =   350
      Left            =   360
      Top             =   2220
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtNome 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   4440
      TabIndex        =   2
      Top             =   2610
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "Nome"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblPrograma 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Programa"
      Height          =   350
      Left            =   360
      Top             =   3300
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.ComboBox cboPrograma 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   517
      Left            =   360
      TabIndex        =   3
      Top             =   3803
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "Programa"
   End
   Begin VB.Label lblCurso 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Curso"
      Height          =   350
      Left            =   360
      Top             =   4639
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.ComboBox cboCurso 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   517
      Left            =   360
      TabIndex        =   4
      Top             =   5052
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "Curso"
   End
   Begin VB.Label lblDialetivo 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Dia Letivo"
      Height          =   350
      Left            =   4440
      Top             =   1077
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtDialetivo 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   4440
      TabIndex        =   5
      Top             =   1380
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "DiaLetivo"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblIdiomaestrangeiro 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Idioma Estrangeiro"
      Height          =   350
      Left            =   4440
      Top             =   2220
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtIdiomaestrangeiro 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   360
      TabIndex        =   6
      Top             =   2592
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "IdiomaEstrangeiro"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblProjetodepesquisa 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Projeto de Pesquisa"
      Height          =   350
      Left            =   4440
      Top             =   3300
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtProjetodepesquisa 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   4440
      TabIndex        =   7
      Top             =   3840
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "ProjetoDePesquisa"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblIntegralizacaodecreditos 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Integraliza��o de Cr�ditos"
      Height          =   350
      Left            =   4440
      Top             =   4639
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtIntegralizacaodecreditos 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   4440
      TabIndex        =   8
      Top             =   5070
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "IntegralizacaoDeCreditos"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblAtividadecomplementar 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Atividade Complementar"
      Height          =   350
      Left            =   4440
      Top             =   5924
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtAtividadecomplementar 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   4440
      TabIndex        =   9
      Top             =   6300
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "AtividadeComplementar"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblExamedequalificacao 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Exame de Qualifica��o"
      Height          =   350
      Left            =   360
      Top             =   5924
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtExamedequalificacao 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   360
      TabIndex        =   10
      Top             =   6300
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "ExameDeQualificacao"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblEntregadoboneco 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Entrega do Boneco"
      Height          =   350
      Left            =   8520
      Top             =   1055
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtEntregadoboneco 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   8520
      TabIndex        =   11
      Top             =   1380
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "EntregaDoBoneco"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblDefesa 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Defesa"
      Height          =   350
      Left            =   8520
      Top             =   2267
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtDefesa 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   8520
      TabIndex        =   12
      Top             =   2605
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "Defesa"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblEntregadeexemplaresdefinitivos 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Entrega de Exemplares Definitivos"
      Height          =   350
      Left            =   8520
      Top             =   3479
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtEntregadeexemplaresdefinitivos 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   8520
      TabIndex        =   13
      Top             =   3829
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "EntregaDeExemplaresDefinitivos"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblEntregadeexemplaresdefinitivos2 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Entrega de Exemplares Definitivos"
      Height          =   350
      Left            =   8520
      Top             =   4690
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtEntregadeexemplaresdefinitivos2 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   8520
      TabIndex        =   14
      Top             =   5054
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "EntregaDeExemplaresDefinitivos2"
      Corners         =   2  'Capsule
   End
   Begin VB.Label lblLinguaportuguesaparaestrangeiro 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "L�ngua Portuguesa para Estrangeiro"
      Height          =   350
      Left            =   8520
      Top             =   5902
      Width           =   3600
      AutoSize        =   -1  'True
   End
   Begin VB.TextBox txtLinguaportuguesaparaestrangeiro 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Text            =   ""
      Height          =   480
      Left            =   8520
      TabIndex        =   15
      Top             =   6278
      Width           =   3600
      DataSource      =   "DataNav1"
      DataField       =   "LinguaPortuguesaParaEstrangeiro"
      Corners         =   2  'Capsule
   End
   Begin NB.NavigationBar DataNav1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   630
      Left            =   0
      Top             =   0
      Width           =   12600
      ButtonStyle     =   0  'Icons
      DatabaseName    =   "Alunos.db"
      ButtonSize      =   1  'Normal
      Align           =   1  'Top
      RecordSource    =   "Exigido"
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&Sair"
   End
End
Attribute VB_Name = "frmAlunos"
Option Explicit
Dim nRepos As Integer
Private Sub datTitles_Reposition()
  nRepos = nRepos + 1
  datTitles.Caption = "Record " & (datTitles.Recordset.AbsolutePosition + 1) & " of " & datTitles.Recordset.RecordCount
End Sub
Private Sub cmdCount_Click()
  Dim db As Database, rs As Recordset
  Set db = OpenDatabase(App.Path & "\BIBLIO.MDB")
  Set rs = db.OpenRecordset("SELECT COUNT(*) AS N FROM Authors")
  cmdCount.Caption = rs!N & " authors"
  Debug.Print "repos=" & nRepos
End Sub

Private Sub datExigido_Reposition()
  If datExigido.Recordset.RecordCount = 0 Then
    datExigido.Caption = "Exigido: (empty)"
  Else
    datExigido.Caption = "Exigido: " & (datExigido.Recordset.AbsolutePosition + 1) & " / " & datExigido.Recordset.RecordCount
  End If
End Sub

Private Sub Form_Load()
  cboCurso.AddItem "DO"
  cboCurso.AddItem "ME"
  cboPrograma.AddItem "PCA"
  cboPrograma.AddItem "PEE"
  cboPrograma.AddItem "PEM"
  cboPrograma.AddItem "PEP"
  cboCurso.AddItem "DO"
  cboCurso.AddItem "ME"

  cboPrograma.AddItem "PCA"
  cboPrograma.AddItem "PEE"
  cboPrograma.AddItem "PEM"
  cboPrograma.AddItem "PEP"
    
End Sub

Private Sub cmdNovo_Click()
  datExigido.Recordset.AddNew
End Sub

Private Sub cmdSalvar_Click()
  Dim novo As Boolean
  novo = (datExigido.Recordset.EditMode = dbEditAdd)
  datExigido.UpdateRecord
  If novo Then datExigido.Recordset.Bookmark = datExigido.Recordset.LastModified
  MsgBox "Registro salvo.", vbInformation
End Sub

Private Sub cmdExcluir_Click()
  If datExigido.Recordset.RecordCount = 0 Then Exit Sub
  If MsgBox("Excluir este registro?", vbYesNo + vbQuestion) = vbNo Then Exit Sub
  datExigido.Recordset.Delete
  datExigido.Recordset.MoveNext
  If datExigido.Recordset.EOF Then datExigido.Recordset.MoveLast
End Sub

Private Sub mnuFile_Click()
    Unload Me
End Sub
