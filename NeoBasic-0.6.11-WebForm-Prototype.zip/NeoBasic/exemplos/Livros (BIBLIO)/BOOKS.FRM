VERSION 5.00
Begin VB.Form frmBooks 
   Caption         =   "Books"
   ClientHeight    =   3600
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3600
   ScaleWidth      =   6000
   Begin VB.Data datTitles 
      Caption         =   "Titles"
      Connect         =   "Access"
      DatabaseName    =   "BIBLIO.MDB"
      Height          =   345
      Left            =   240
      RecordSource    =   "SELECT * FROM Titles ORDER BY Title"
      Top             =   2400
      Width           =   5400
   End
   Begin VB.TextBox txtTitle 
      DataField       =   "Title"
      DataSource      =   "datTitles"
      Height          =   315
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   5400
   End
   Begin VB.Label lblYear 
      DataField       =   "Year Published"
      DataSource      =   "datTitles"
      Height          =   255
      Left            =   240
      TabIndex        =   1
      Top             =   720
      Width           =   2000
   End
   Begin VB.CommandButton cmdCount 
      Caption         =   "Count"
      Height          =   400
      Left            =   240
      TabIndex        =   2
      Top             =   1200
      Width           =   1500
   End
End
Attribute VB_Name = "frmBooks"
Option Explicit
Dim nRepos As Integer
Private Sub datTitles_Reposition()
  nRepos = nRepos + 1
  datTitles.Caption = "Record " & (datTitles.Recordset.AbsolutePosition + 1) & " of " & datTitles.Recordset.RecordCount
End Sub
Private Sub cmdCount_Click()
  Dim db As Database, rs As Recordset
  Set db = OpenDatabase(App.Path & "\BIBLIO.MDB")
  Set rs = db.OpenRecordset("SELECT COUNT(*) AS N FROM Authors")
  cmdCount.Caption = rs!N & " authors"
  Debug.Print "repos=" & nRepos
End Sub
