NeoBasic 0.6.13 - free Visual Basic 5/6-style IDE
================================================

NeoBasic is a free development environment for Visual Basic 5/6-style projects.
It runs on Windows and Linux with the same interface.

This package includes:
- NeoBasic launcher and application
- Complete JavaScript/CSS source code
- Standalone HTML build
- Bundled fonts and application icon

Version 0.6.13:
- Fixes over 0.6.12 (see CORRECOES-0.6.13.txt): MySQL installer for Windows
  (download with progress, UAC, NeoBasicMySQL service); Linux installer with real
  progress and Ubuntu fallback; readable MySQL databases
  (nb_<project>_<database>) with real table names

Version 0.6.12:
- Mandatory MySQL on Linux; new toolbox controls; WebForms editor

Version 0.6.11:
- NavigationBar buttons match the IDE toolbar (rounded-square hover)
- TextBox Mask property with presets (phone, CPF, CNPJ, CEP, date, time...)
  and ClipText

Version 0.6.10:
- NavigationBar Align property (0 None, 1 Top, 2 Bottom); docking moves the
  other controls so nothing is hidden under the bar
- Pick lists for DatabaseName, RecordSource, DataSource and DataField

Version 0.6.9:
- DataNav renamed NavigationBar: docks at the top of the form (below the menu)
  and fills its width; toolbar-style line icons; ButtonOrder (drag to reorder),
  ButtonSize (Small/Normal/Large); new Copy, Paste, Undo and Redo buttons

Version 0.6.8:
- DataNav control: record navigation bar with First/Previous/Next/Last, New,
  Edit, Delete, Save and Cancel (icons, icons+text or text; each button can be
  hidden); works alone (DatabaseName + RecordSource) or with a Data control
- Rename a project database (double-click it)
- Position and size in the toolbar can be typed
- Right-side panels can be minimized; the Immediate window is hidden (Ctrl+G)

Version 0.6.7:
- New Menu Editor: items and sub-items with drag and drop, and what each item
  does (open a form, close, end, message or your own code)
- Format Painter: copies color, font, size and style to controls of the same kind
- Inkscape-style align and distribute buttons (several controls align to the
  first one selected)
- New Project asks for the startup form

Version 0.6.6 interface updates:
- Light blue-and-white visual theme by default
- Compact Toolbox with two columns of blue line icons
- Circular hover/selection highlight for Toolbox tools
- Capsule-shaped buttons throughout the interface
- English locale by default
- Existing project and runtime files retained

Build:
Run codigo-fonte/build.py with Python 3 to regenerate codigo-fonte/dist/NeoBasic.html.


NEW IN THIS PROTOTYPE
- Project > Insert WebForm opens an integrated WebForm Designer.
- Classic Forms can be copied into WebForms; original .FRM files are preserved.
- WebForms are saved in the project WebForms/ folder as .nbweb.json.
- Export HTML creates a standalone HTML5 page.


MySQL obrigatório no Linux:
- O NeoBasic exige MySQL Server para iniciar; não oferece SQLite como alternativa de backend.
- Abra pelo NeoBasic.sh. Não abra o HTML diretamente.
- O NeoBasic mostra primeiro sua tela de inicialização e, somente se o MySQL estiver ausente, pergunta se a pessoa autoriza a instalação.
- Se a pessoa escolher Não, a inicialização é encerrada sem instalar nada.
- A instalação do MySQL Community Server 8.4 LTS (em instalações novas), Python/PyMySQL e a configuração do serviço são executadas somente pelo NeoBasic.sh.
- O serviço do NeoBasic escuta somente em 127.0.0.1; não abre a porta MySQL para a rede.
- Os dados persistentes são gravados no MySQL. O runtime mantém um espelho SQL.js em memória para preservar a compatibilidade síncrona com o DAO clássico do VB5/6.
- Os aplicativos Linux exportados incluem o bridge e um lançador em modo de verificação; não instalam MySQL. A instalação é feita pelo NeoBasic.
