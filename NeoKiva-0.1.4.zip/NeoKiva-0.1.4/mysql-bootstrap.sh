#!/bin/sh
# Neo Kiva 0.1 — prepara o MySQL e liga o serviço local (bridge).
#   mysql-bootstrap.sh status                 -> imprime: ready | stopped | unconfigured | missing | mariadb
#   mysql-bootstrap.sh install <dir-raiz>     -> instala/configura com janela de progresso (pede senha de administrador)
#   mysql-bootstrap.sh bridge <dir-raiz> <porta> -> garante o bridge ativo; imprime a porta em uso
# Nunca é chamado ao abrir um .html: só pelos lançadores .sh.
set -u
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
VERSION="0.1"
STATE_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/neokiva"
mkdir -p "$STATE_DIR"
LOG="$STATE_DIR/mysql-install.log"
CONFIG="$HOME/.config/neobasic/mysql.json"
ICON="$DIR/icone/neokiva.png"; [ -f "$ICON" ] || ICON="$DIR/../icone/neokiva.png"
PY=/usr/bin/python3; [ -x "$PY" ] || PY="$(command -v python3 || echo python3)"

msg_error() {
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --title="Neo Kiva" --width=480 --ok-label="OK" --text="$1" 2>/dev/null || true
  elif command -v notify-send >/dev/null 2>&1; then notify-send -i "$ICON" "Neo Kiva" "$1"
  else printf 'Neo Kiva: %s\n' "$1" >&2; fi
}

mysqld_bin() { [ -x /usr/sbin/mysqld ] && echo /usr/sbin/mysqld || command -v mysqld 2>/dev/null; }

state() {
  B="$(mysqld_bin)"
  [ -n "$B" ] || { echo missing; return; }
  case "$("$B" --version 2>/dev/null)" in *MariaDB*) echo mariadb; return ;; esac
  if ! mysqladmin --protocol=socket ping >/dev/null 2>&1; then echo stopped; return; fi
  if [ ! -s "$CONFIG" ] || ! "$PY" -c 'import json,sys,pymysql; c=json.load(open(sys.argv[1])); sys.exit(0 if c.get("config_version",1)>=2 else 1)' "$CONFIG" >/dev/null 2>&1; then
    echo unconfigured; return
  fi
  echo ready
}

health() { # porta -> JSON do /api/health (vazio se nada responde)
  "$PY" - "$1" <<'PY' 2>/dev/null
import sys, urllib.request
try:
    print(urllib.request.urlopen("http://127.0.0.1:%s/api/health" % sys.argv[1], timeout=2).read().decode())
except Exception as e:
    body = getattr(e, "read", None)
    print(body().decode() if body else "")
PY
}

do_install() {
  ROOT="${1:-$DIR}"
  S="$(state)"
  case "$S" in
    ready) return 0 ;;
    mariadb) msg_error "This computer uses MariaDB. Neo Kiva requires MySQL Server and will not remove MariaDB (your data stays safe)."; return 1 ;;
  esac
  MODE=""; TITLE="Neo Kiva — Installing MySQL Server"
  [ "$S" = stopped ] && { MODE="--start-only"; TITLE="Neo Kiva — Starting MySQL"; }
  [ "$S" = unconfigured ] && TITLE="Neo Kiva — Configuring MySQL"
  command -v pkexec >/dev/null 2>&1 || { msg_error "pkexec (administrator authorization) was not found."; return 1; }
  : > "$LOG"
  RCF="$(mktemp)"
  # Progresso real: o instalador (como administrador) escreve "NN" e "# etapa" na janela.
  { echo "1"; echo "# Waiting for administrator authorization..."
    pkexec /bin/sh "$DIR/mysql-install-root.sh" "$HOME" "$(id -un)" "$(id -u)" "$(id -g)" $MODE 2>>"$LOG"
    echo $? > "$RCF"; } |
  if command -v zenity >/dev/null 2>&1; then
    zenity --progress --title="$TITLE" --window-icon="$ICON" --width=560 \
      --text="MySQL Server is required to use Neo Kiva." \
      --percentage=0 --auto-close --no-cancel 2>/dev/null
  else
    cat >/dev/null
  fi
  RC="$(cat "$RCF" 2>/dev/null || echo 1)"; rm -f "$RCF"
  if [ "$RC" = 126 ] || [ "$RC" = 127 ]; then
    msg_error "Administrator authorization was cancelled. Neo Kiva requires MySQL and will now close."; return 1
  fi
  if [ "$RC" != 0 ] || [ "$(state)" != ready ]; then
    LAST="$(grep -E '^ERROR:' "$LOG" | tail -n 1 | sed 's/^ERROR: //')"
    msg_error "MySQL Server could not be set up.${LAST:+

$LAST}

Details: $LOG"; return 1
  fi
  return 0
}

do_bridge() {
  ROOT="$1"; PORT="$2"
  [ "$(state)" = ready ] || return 1
  ROOT_REAL="$(cd "$ROOT" && pwd -P)"
  TRY=0
  while [ "$TRY" -lt 6 ]; do
    H="$(health "$PORT")"
    if [ -n "$H" ]; then
      if printf '%s' "$H" | "$PY" -c 'import json,sys; h=json.load(sys.stdin); sys.exit(0 if h.get("ok") and h.get("version")==sys.argv[1] and h.get("root")==sys.argv[2] else 1)' "$VERSION" "$ROOT_REAL" 2>/dev/null; then
        echo "$PORT"; return 0
      fi
      # Bridge de outra versão/pasta do Neo Kiva: encerra e sobe o desta pasta.
      OLDPID="$(printf '%s' "$H" | "$PY" -c 'import json,sys; print(json.load(sys.stdin).get("pid",""))' 2>/dev/null)"
      # bridge da 0.6.12 não informava o pid: procura pelo processo que usa esta porta
      [ -n "$OLDPID" ] || OLDPID="$(pgrep -u "$(id -u)" -f "mysql-bridge\.py .*--port $PORT( |\$)" 2>/dev/null | head -n 1)"
      if [ -n "$OLDPID" ] && tr '\0' ' ' < "/proc/$OLDPID/cmdline" 2>/dev/null | grep -q 'mysql-bridge.py'; then
        kill "$OLDPID" 2>/dev/null; sleep 0.5
      else
        PORT=$((PORT + 1)); TRY=$((TRY + 1)); continue   # porta ocupada por outro programa
      fi
    fi
    # setsid + nohup: o serviço continua ativo mesmo se o terminal for fechado
    setsid nohup "$PY" "$DIR/mysql-bridge.py" --root "$ROOT_REAL" --port "$PORT" \
      --pidfile "$STATE_DIR/bridge-$PORT.pid" >>"$STATE_DIR/bridge.log" 2>&1 < /dev/null &
    i=0
    while [ "$i" -lt 40 ]; do
      H="$(health "$PORT")"
      printf '%s' "$H" | grep -q '"ok": true' && { echo "$PORT"; return 0; }
      sleep 0.25; i=$((i + 1))
    done
    break
  done
  msg_error "The Neo Kiva local service (MySQL) did not start.

Details: $STATE_DIR/bridge.log"
  return 1
}

case "${1:-}" in
  status) state ;;
  install) do_install "${2:-$DIR}" ;;
  bridge) do_bridge "${2:?pasta}" "${3:?porta}" ;;
  *) echo "uso: $0 status | install <pasta> | bridge <pasta> <porta>" >&2; exit 2 ;;
esac
