#!/usr/bin/env python3
"""Neo Kiva — gives the Chrome app window the real Neo Kiva icon on Linux (X11).

Chrome only sets a 16x16 favicon on --app windows, so panels (Cinnamon, MATE, Xfce)
show a blurry or wrong icon. This helper finds the window (by WM_CLASS class or by
process id) and sets _NET_WM_ICON with 16..256 px icons, re-applying it while the
window is open (Chrome resets it when the page changes). Standard library only.

  neokiva-wmicon.py --class neokiva --pid 1234 --icon icone/neokiva-icon.argb
  neokiva-wmicon.py --class neokiva --wait 15     (only waits for the window; exit 0 = shown)
"""
import argparse, ctypes, ctypes.util, struct, sys, time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--class", dest="cls", default="neokiva")
    ap.add_argument("--pid", type=int, default=0)
    ap.add_argument("--icon")
    ap.add_argument("--wait", type=float, default=0)
    a = ap.parse_args()

    name = ctypes.util.find_library("X11") or "libX11.so.6"
    try:
        X = ctypes.cdll.LoadLibrary(name)
    except OSError:
        return 0
    X.XOpenDisplay.restype = ctypes.c_void_p
    X.XOpenDisplay.argtypes = [ctypes.c_char_p]
    X.XDefaultRootWindow.restype = ctypes.c_ulong
    X.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
    X.XInternAtom.restype = ctypes.c_ulong
    X.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    X.XQueryTree.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_ulong),
                             ctypes.POINTER(ctypes.POINTER(ctypes.c_ulong)), ctypes.POINTER(ctypes.c_uint)]
    X.XGetWindowProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_long, ctypes.c_long, ctypes.c_int,
                                     ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_int),
                                     ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_void_p)]
    X.XChangeProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                                  ctypes.c_void_p, ctypes.c_int]
    X.XFree.argtypes = [ctypes.c_void_p]
    X.XFlush.argtypes = [ctypes.c_void_p]

    class XClassHint(ctypes.Structure):
        _fields_ = [("res_name", ctypes.c_char_p), ("res_class", ctypes.c_char_p)]
    X.XGetClassHint.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(XClassHint)]

    # windows can disappear at any moment: ignore X errors instead of aborting
    HANDLER = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
    ignore = HANDLER(lambda d, e: 0)
    X.XSetErrorHandler(ignore)

    dpy = X.XOpenDisplay(None)
    if not dpy:
        return 0
    root = X.XDefaultRootWindow(dpy)
    A_ICON = X.XInternAtom(dpy, b"_NET_WM_ICON", 0)
    A_PID = X.XInternAtom(dpy, b"_NET_WM_PID", 0)
    A_CARD = X.XInternAtom(dpy, b"CARDINAL", 0)
    A_STATE = X.XInternAtom(dpy, b"WM_STATE", 0)

    def prop_len(w, atom):
        t = ctypes.c_ulong(); f = ctypes.c_int(); n = ctypes.c_ulong(); rest = ctypes.c_ulong(); data = ctypes.c_void_p()
        if X.XGetWindowProperty(dpy, w, atom, 0, 1, 0, 0, ctypes.byref(t), ctypes.byref(f), ctypes.byref(n), ctypes.byref(rest), ctypes.byref(data)) != 0:
            return -1, 0
        first = ctypes.cast(data, ctypes.POINTER(ctypes.c_ulong))[0] if data.value and n.value else 0
        if data.value:
            X.XFree(data)
        return (n.value + rest.value // 4) if t.value else -1, first

    def children(w):
        r = ctypes.c_ulong(); p = ctypes.c_ulong(); kids = ctypes.POINTER(ctypes.c_ulong)(); n = ctypes.c_uint()
        if not X.XQueryTree(dpy, w, ctypes.byref(r), ctypes.byref(p), ctypes.byref(kids), ctypes.byref(n)):
            return []
        out = [kids[i] for i in range(n.value)]
        if kids:
            X.XFree(kids)
        return out

    def matches(w):
        h = XClassHint()
        if X.XGetClassHint(dpy, w, ctypes.byref(h)):
            ok = (h.res_class or b"").decode("utf-8", "replace").lower() == a.cls.lower()
            if ok:
                return True
        if a.pid:
            n, first = prop_len(w, A_PID)
            return n > 0 and first == a.pid
        return False

    def find():
        found, stack = [], [(root, 0)]
        while stack:
            w, depth = stack.pop()
            for c in children(w):
                if matches(c) and prop_len(c, A_STATE)[0] >= 0:   # WM_STATE = real top-level window
                    found.append(c)
                elif depth < 3:
                    stack.append((c, depth + 1))
        return found

    if a.wait:
        end = time.time() + a.wait
        while time.time() < end:
            if find():
                return 0
            time.sleep(0.3)
        return 1

    if not a.icon:
        return 0
    raw = open(a.icon, "rb").read()
    vals = struct.unpack("<%dI" % (len(raw) // 4), raw)
    data = (ctypes.c_ulong * len(vals))(*vals)     # format 32 = C long per item

    seen = False; gone_since = None; start = time.time()
    while True:
        wins = find()
        if wins:
            seen = True; gone_since = None
            for w in wins:
                if prop_len(w, A_ICON)[0] != len(vals):
                    X.XChangeProperty(dpy, w, A_ICON, A_CARD, 32, 0, ctypes.cast(data, ctypes.c_void_p), len(vals))
            X.XFlush(dpy)
        elif seen:
            gone_since = gone_since or time.time()
            if time.time() - gone_since > 5:
                return 0
        elif time.time() - start > 60:
            return 0
        time.sleep(1.0 if seen else 0.3)


if __name__ == "__main__":
    sys.exit(main() or 0)
