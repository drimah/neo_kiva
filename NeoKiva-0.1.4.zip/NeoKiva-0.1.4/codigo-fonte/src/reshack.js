// ===== Neo Kiva 0.1 — Resource Explorer: abre .exe/.dll/.res como o Resource Hacker e cria formulários =====
'use strict';
const NKRes = (() => {
  const TYPES = { 1: 'Cursor', 2: 'Bitmap', 3: 'Icon', 4: 'Menu', 5: 'Dialog', 6: 'String Table', 7: 'Font Directory', 8: 'Font', 9: 'Accelerators', 10: 'RCData', 11: 'Message Table', 12: 'Cursor Group', 14: 'Icon Group', 16: 'Version Info', 17: 'DlgInclude', 19: 'Plug and Play', 20: 'VXD', 21: 'Animated Cursor', 22: 'Animated Icon', 23: 'HTML', 24: 'Manifest', 240: 'DlgInit', 241: 'Toolbar' };
  const RC_NAMES = { 1: 'CURSOR', 2: 'BITMAP', 3: 'ICON', 4: 'MENU', 5: 'DIALOG', 6: 'STRINGTABLE', 9: 'ACCELERATORS', 10: 'RCDATA', 12: 'CURSOR', 14: 'ICON', 16: 'VERSIONINFO', 23: 'HTML', 24: 'MANIFEST' };
  const u16 = (b, o) => b[o] | (b[o + 1] << 8);
  const i16 = (b, o) => { const v = u16(b, o); return v & 0x8000 ? v - 0x10000 : v; };
  const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
  const ascii = (b, o, n) => { let s = ''; for (let i = 0; i < n && b[o + i]; i++) s += String.fromCharCode(b[o + i]); return s; };
  const wstrz = (b, o) => { let s = ''; let p = o; while (p + 1 < b.length) { const c = u16(b, p); p += 2; if (!c) break; s += String.fromCharCode(c); } return { s, end: p }; };
  const align4 = n => (n + 3) & ~3;
  const hexId = n => '0x' + n.toString(16).toUpperCase();

  // ---------------------------------------------------------------- leitura de PE
  function parsePE(b) {
    if (b.length < 64 || b[0] !== 0x4D || b[1] !== 0x5A) throw new Error('This file is not a Windows executable (MZ header missing).');
    const pe = u32(b, 0x3C); if (pe + 24 > b.length || ascii(b, pe, 4) !== 'PE') throw new Error('This is an old DOS/16-bit program (no PE header). Only 32-bit and 64-bit Windows files are supported.');
    const machine = u16(b, pe + 4), nsec = u16(b, pe + 6), optSize = u16(b, pe + 20), chars = u16(b, pe + 22);
    const opt = pe + 24, magic = u16(b, opt), is64 = magic === 0x20B;
    const entry = u32(b, opt + 16); const imageBase = is64 ? u32(b, opt + 24) + u32(b, opt + 28) * 4294967296 : u32(b, opt + 28);
    const subsystem = u16(b, opt + (is64 ? 68 : 68));
    const ddir = opt + (is64 ? 112 : 96); const ndd = u32(b, opt + (is64 ? 108 : 92));
    const dir = i => i < ndd ? { rva: u32(b, ddir + i * 8), size: u32(b, ddir + i * 8 + 4) } : { rva: 0, size: 0 };
    const secs = []; let so = opt + optSize;
    for (let i = 0; i < nsec; i++, so += 40) secs.push({ name: ascii(b, so, 8), vsize: u32(b, so + 8), va: u32(b, so + 12), rawSize: u32(b, so + 16), raw: u32(b, so + 20) });
    const off = rva => { for (const s of secs) if (rva >= s.va && rva < s.va + Math.max(s.vsize, s.rawSize)) return rva - s.va + s.raw; return -1; };
    const info = { kind: 'pe', is64, machine: { 0x14c: 'x86 (32-bit)', 0x8664: 'x64 (64-bit)', 0xaa64: 'ARM64', 0x1c0: 'ARM' }[machine] || hexId(machine), dll: !!(chars & 0x2000), subsystem: { 2: 'Windows GUI', 3: 'Console', 1: 'Native' }[subsystem] || String(subsystem), sections: secs.map(s => s.name), entry, imageBase };
    const res = []; const rdir = dir(2);
    if (rdir.rva) {
      const base = off(rdir.rva);
      if (base >= 0) {
        const nameAt = o => { const n = u16(b, base + o); let s = ''; for (let i = 0; i < n; i++) s += String.fromCharCode(u16(b, base + o + 2 + i * 2)); return s; };
        const readDir = (o, depth, path) => {
          if (depth > 3 || base + o + 16 > b.length) return;
          const nNamed = u16(b, base + o + 12), nId = u16(b, base + o + 14);
          for (let i = 0; i < nNamed + nId && i < 4000; i++) {
            const e = base + o + 16 + i * 8; const nm = u32(b, e), of = u32(b, e + 4);
            const key = nm & 0x80000000 ? nameAt(nm & 0x7FFFFFFF) : nm;
            if (of & 0x80000000) readDir(of & 0x7FFFFFFF, depth + 1, [...path, key]);
            else { const de = base + of; const drva = u32(b, de), sz = u32(b, de + 4), cp = u32(b, de + 8); const fo = off(drva); if (fo >= 0 && path.length === 2) res.push({ type: path[0], name: path[1], lang: key, codepage: cp, data: b.subarray(fo, Math.min(b.length, fo + sz)) }); }
          }
        };
        readDir(0, 0, []);
      }
    }
    info.vb = detectVB(b, info, off);
    if (!info.vb && res.some(r => r.type === 10 && r.data.length > 4 && ascii(r.data, 0, 4) === 'TPF0')) info.delphi = true;
    if (!info.delphi && res.some(r => typeof r.name === 'string' && /^(DVCLAL|PACKAGEINFO|PLATFORMTARGETS)$/i.test(r.name))) info.delphi = true;
    return { info, res };
  }
  // Visual Basic 5/6: "push VBHeader; call ThunRTMain" no ponto de entrada
  function detectVB(b, info, off) {
    if (info.is64) return null;
    const e = off(info.entry); if (e < 0 || b[e] !== 0x68) return null;
    const hdrVA = u32(b, e + 1); const h = off(hdrVA - info.imageBase); if (h < 0 || ascii(b, h, 4) !== 'VB5!') return null;
    const vb = { forms: u16(b, h + 0x44), objects: [] };
    const str = va => { const o = va ? off(va - info.imageBase) : -1; return o >= 0 ? ascii(b, o, 260) : ''; };
    vb.exeName = str(u32(b, h + 0x5C)); vb.projectName = str(u32(b, h + 0x64)); vb.description = str(u32(b, h + 0x58));
    try {
      const pi = off(u32(b, h + 0x30) - info.imageBase); const ot = off(u32(b, pi + 4) - info.imageBase);
      const total = u16(b, ot + 0x2A); const arr = off(u32(b, ot + 0x30) - info.imageBase);
      for (let i = 0; i < total && i < 2000; i++) { const d = arr + i * 0x30; const nm = str(u32(b, d + 0x18)); const t = u32(b, d + 0x28); const kind = t & 0x100 ? 'UserControl' : t & 0x80 ? 'Form' : t & 0x02 ? 'Class' : 'Module'; if (nm) vb.objects.push({ name: nm, kind, methods: u32(b, d + 0x1C) }); }
    } catch (er) { }
    return vb;
  }
  // arquivos .res de 32 bits
  function parseRES(b) {
    const res = []; let p = 0;
    const idOrName = () => { if (u16(b, p) === 0xFFFF) { const v = u16(b, p + 2); p += 4; return v; } const r = wstrz(b, p); p = r.end; return r.s; };
    while (p + 32 <= b.length) {
      const start = p; const dsz = u32(b, p), hsz = u32(b, p + 4); p += 8;
      const type = idOrName(), name = idOrName(); p = align4(p);
      const lang = u16(b, p + 6); p = start + hsz;
      if (!(type === 0 && name === 0 && dsz === 0)) res.push({ type, name, lang, codepage: 0, data: b.subarray(p, p + dsz) });
      p = align4(p + dsz); if (hsz < 16) break;
    }
    const info = { kind: 'res' };
    if (res.some(r => r.type === 10 && r.data.length > 4 && ascii(r.data, 0, 4) === 'TPF0')) info.delphi = true;
    return { info, res };
  }
  function open(bytes, fileName) {
    const r = /\.res$/i.test(fileName || '') || (bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 0 && bytes[3] === 0 && u32(bytes, 4) === 32) ? parseRES(bytes) : parsePE(bytes);
    r.fileName = fileName; r.bytes = bytes; return r;
  }

  // ---------------------------------------------------------------- decodificadores
  const typeName = t => typeof t === 'number' ? (TYPES[t] || 'Type ' + t) : t;
  const resName = n => typeof n === 'number' ? String(n) : n;
  function findRes(R, type, name) { return R.res.find(r => r.type === type && (r.name === name || (typeof name === 'string' && typeof r.name === 'string' && r.name.toUpperCase() === name.toUpperCase()))); }
  function iconGroupToIco(R, g, cursor) {
    const d = g.data; const count = u16(d, 4); const parts = [];
    for (let i = 0; i < count; i++) {
      const e = 6 + i * 14; const id = u16(d, e + 12); const img = findRes(R, cursor ? 1 : 3, id); if (!img) continue;
      let data = img.data, hx = 0, hy = 0; if (cursor) { hx = u16(data, 0); hy = u16(data, 2); data = data.subarray(4); }
      parts.push({ w: d[e], h: d[e + 1], colors: d[e + 2], planes: cursor ? hx : u16(d, e + 6), bpp: cursor ? hy : u16(d, e + 8), data });
    }
    return buildIco(parts, cursor ? 2 : 1);
  }
  function buildIco(parts, kind) {
    const total = 6 + 16 * parts.length + parts.reduce((t, p) => t + p.data.length, 0); const o = new Uint8Array(total); const dv = new DataView(o.buffer);
    dv.setUint16(2, kind || 1, true); dv.setUint16(4, parts.length, true); let off = 6 + 16 * parts.length;
    parts.forEach((p, i) => { const e = 6 + i * 16; o[e] = p.w; o[e + 1] = p.h; o[e + 2] = p.colors; dv.setUint16(e + 4, p.planes || 1, true); dv.setUint16(e + 6, p.bpp || 32, true); dv.setUint32(e + 8, p.data.length, true); dv.setUint32(e + 12, off, true); o.set(p.data, off); off += p.data.length; });
    return o;
  }
  function singleIcon(data) {
    if (data[0] === 0x89 && data[1] === 0x50) return { mime: 'image/png', bytes: data };
    const w = u32(data, 4), hh = u32(data, 8) / 2, bpp = u16(data, 14);
    return { mime: 'image/x-icon', bytes: buildIco([{ w: w >= 256 ? 0 : w, h: hh >= 256 ? 0 : hh, colors: 0, planes: 1, bpp, data }]) };
  }
  function bitmapFile(d) {
    const hs = u32(d, 0); let pal = 0;
    if (hs >= 40) { const bpp = u16(d, 14), used = u32(d, 32), comp = u32(d, 16); pal = (used || (bpp <= 8 ? 1 << bpp : 0)) * 4; if (comp === 3 && hs === 40) pal += 12; } else { const bpp = u16(d, 10); pal = bpp <= 8 ? (1 << bpp) * 3 : 0; }
    const o = new Uint8Array(14 + d.length); const dv = new DataView(o.buffer); o[0] = 0x42; o[1] = 0x4D; dv.setUint32(2, o.length, true); dv.setUint32(10, 14 + hs + pal, true); o.set(d, 14); return o;
  }
  function strings(r) {
    const d = r.data; const out = []; let p = 0; const base = ((r.name | 0) - 1) * 16;
    for (let i = 0; i < 16 && p + 2 <= d.length; i++) { const n = u16(d, p); p += 2; let s = ''; for (let k = 0; k < n; k++) s += String.fromCharCode(u16(d, p + k * 2)); p += n * 2; if (n) out.push({ id: base + i, s }); }
    return out;
  }
  function accelerators(d) {
    const out = []; for (let p = 0; p + 8 <= d.length; p += 8) { const f = u16(d, p), key = u16(d, p + 2), id = u16(d, p + 4); out.push({ f, key, id }); if (f & 0x80) break; }
    return out;
  }
  function versionInfo(d) {
    const out = { fixed: null, strings: [] };
    const node = (p, end, depth) => {
      const len = u16(d, p), vlen = u16(d, p + 2), typ = u16(d, p + 4); const k = wstrz(d, p + 6); let v = align4(k.end); const stop = Math.min(end, p + len);
      if (k.s === 'VS_VERSION_INFO' && vlen >= 52) { const f = v; const ver = (a, b2) => `${u32(d, f + a) >>> 16}.${u32(d, f + a) & 0xffff}.${u32(d, f + b2) >>> 16}.${u32(d, f + b2) & 0xffff}`; out.fixed = { file: ver(8, 12), product: ver(16, 20) }; }
      if (depth >= 3 && typ === 1 && vlen) { out.strings.push([k.s, wstrz(d, v).s]); }
      let c = align4(v + (typ === 1 ? vlen * 2 : vlen)); if (len === 0) return stop;
      while (c + 6 < stop) { const n = node(c, stop, depth + 1); if (n <= c) break; c = align4(n); }
      return stop;
    };
    try { node(0, d.length, 0); } catch (e) { }
    return out;
  }
  function text(d) {
    if (d[0] === 0xFF && d[1] === 0xFE) return new TextDecoder('utf-16le').decode(d.subarray(2));
    if (d.length > 3 && d[1] === 0 && d[3] === 0 && d[0] && d[2]) return new TextDecoder('utf-16le').decode(d);
    try { return new TextDecoder('utf-8', { fatal: true }).decode(d); } catch (e) { return new TextDecoder('windows-1252').decode(d); }
  }
  function hexDump(d, max) {
    const n = Math.min(d.length, max || 65536); const L = [];
    for (let i = 0; i < n; i += 16) { const row = d.subarray(i, Math.min(n, i + 16)); L.push(i.toString(16).toUpperCase().padStart(8, '0') + '  ' + [...row].map(x => x.toString(16).toUpperCase().padStart(2, '0')).join(' ').padEnd(48) + '  ' + [...row].map(x => x >= 32 && x < 127 ? String.fromCharCode(x) : '.').join('')); }
    if (d.length > n) L.push(`… ${d.length - n} more bytes`);
    return L.join('\n');
  }
  // ---------------------------------------------------------------- menus
  function parseMenu(d) {
    const items = [];
    if (u16(d, 0) === 1) { // MENUEX
      let p = 4 + u16(d, 2);
      const rd = (list) => { for (;;) { if (p + 14 > d.length) return; const type = u32(d, p), state = u32(d, p + 4), id = u32(d, p + 8), flags = u16(d, p + 12); const t = wstrz(d, p + 14); p = align4(t.end); const it = { text: t.s, id, sep: !!(type & 0x800), checked: !!(state & 8), grayed: !!(state & 3), items: null }; if (flags & 1) { p += 4; it.items = []; rd(it.items); } list.push(it); if (flags & 0x80) return; } };
      rd(items); return items;
    }
    let p = 4 + u16(d, 2);
    const rd = (list) => { for (;;) { if (p + 2 > d.length) return; const f = u16(d, p); p += 2; let id = 0; if (!(f & 0x10)) { id = u16(d, p); p += 2; } const t = wstrz(d, p); p = t.end; const it = { text: t.s, id, sep: !(f & 0x10) && !id && !t.s, checked: !!(f & 8), grayed: !!(f & 3), items: null }; if (f & 0x10) { it.items = []; rd(it.items); } list.push(it); if (f & 0x80) return; } };
    rd(items); return items;
  }
  // ---------------------------------------------------------------- diálogos
  function parseDialog(d) {
    const ex = u16(d, 0) === 1 && u16(d, 2) === 0xFFFF; let p;
    const dlg = { ex, items: [] };
    const sz = () => { const v = u16(d, p); if (v === 0) { p += 2; return null; } if (v === 0xFFFF) { const n = u16(d, p + 2); p += 4; return n; } const r = wstrz(d, p); p = r.end; return r.s; };
    if (ex) { dlg.helpId = u32(d, 4); dlg.exStyle = u32(d, 8); dlg.style = u32(d, 12); dlg.count = u16(d, 16); dlg.x = i16(d, 18); dlg.y = i16(d, 20); dlg.cx = i16(d, 22); dlg.cy = i16(d, 24); p = 26; }
    else { dlg.style = u32(d, 0); dlg.exStyle = u32(d, 4); dlg.count = u16(d, 8); dlg.x = i16(d, 10); dlg.y = i16(d, 12); dlg.cx = i16(d, 14); dlg.cy = i16(d, 16); p = 18; }
    dlg.menu = sz(); dlg.cls = sz(); { const t = wstrz(d, p); dlg.title = t.s; p = t.end; }
    if (dlg.style & 0x40) { dlg.pt = u16(d, p); p += 2; if (ex) { dlg.weight = u16(d, p); dlg.italic = d[p + 2]; dlg.charset = d[p + 3]; p += 4; } const f = wstrz(d, p); dlg.font = f.s; p = f.end; }
    const CLS = { 0x80: 'BUTTON', 0x81: 'EDIT', 0x82: 'STATIC', 0x83: 'LISTBOX', 0x84: 'SCROLLBAR', 0x85: 'COMBOBOX' };
    for (let i = 0; i < dlg.count && p < d.length; i++) {
      p = align4(p); const it = {};
      if (ex) { it.helpId = u32(d, p); it.exStyle = u32(d, p + 4); it.style = u32(d, p + 8); it.x = i16(d, p + 12); it.y = i16(d, p + 14); it.cx = i16(d, p + 16); it.cy = i16(d, p + 18); it.id = u32(d, p + 20); p += 24; }
      else { it.style = u32(d, p); it.exStyle = u32(d, p + 4); it.x = i16(d, p + 8); it.y = i16(d, p + 10); it.cx = i16(d, p + 12); it.cy = i16(d, p + 14); it.id = u16(d, p + 16); p += 18; }
      const c = sz(); it.cls = typeof c === 'number' ? (CLS[c] || hexId(c)) : (c || ''); const t = sz(); it.title = t == null ? '' : t;
      const extra = u16(d, p); p += 2 + extra; dlg.items.push(it);
    }
    return dlg;
  }
  const rcStr = s => '"' + String(s).replace(/"/g, '""').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
  const rcId = v => typeof v === 'number' ? String(v) : v;
  function styleNames(style, cls) {
    const out = []; const add = (m, n) => { if ((style & m) === m) out.push(n); };
    const c = String(cls).toUpperCase();
    if (c === 'BUTTON') out.push(['BS_PUSHBUTTON', 'BS_DEFPUSHBUTTON', 'BS_CHECKBOX', 'BS_AUTOCHECKBOX', 'BS_RADIOBUTTON', 'BS_3STATE', 'BS_AUTO3STATE', 'BS_GROUPBOX', 'BS_USERBUTTON', 'BS_AUTORADIOBUTTON', 'BS_PUSHBOX', 'BS_OWNERDRAW'][style & 0xF] || '');
    if (c === 'EDIT') { add(4, 'ES_MULTILINE'); add(0x80, 'ES_AUTOHSCROLL'); add(0x40, 'ES_AUTOVSCROLL'); add(0x20, 'ES_PASSWORD'); add(0x800, 'ES_READONLY'); add(0x2000, 'ES_NUMBER'); }
    if (c === 'STATIC') { const k = style & 0x1F; out.push({ 1: 'SS_CENTER', 2: 'SS_RIGHT', 3: 'SS_ICON', 14: 'SS_BITMAP', 16: 'SS_ETCHEDHORZ', 17: 'SS_ETCHEDVERT', 18: 'SS_ETCHEDFRAME', 7: 'SS_BLACKFRAME', 8: 'SS_GRAYFRAME' }[k] || ''); }
    if (c === 'COMBOBOX') out.push(['', 'CBS_SIMPLE', 'CBS_DROPDOWN', 'CBS_DROPDOWNLIST'][style & 3] || '');
    add(0x10000000, 'WS_VISIBLE'); add(0x08000000, 'WS_DISABLED'); add(0x00800000, 'WS_BORDER'); add(0x00200000, 'WS_VSCROLL'); add(0x00100000, 'WS_HSCROLL'); add(0x00010000, 'WS_TABSTOP'); add(0x00020000, 'WS_GROUP');
    return out.filter(Boolean).join(' | ');
  }
  function dialogScript(dlg, name, lang) {
    const L = [`${rcId(name)} ${dlg.ex ? 'DIALOGEX' : 'DIALOG'} ${dlg.x}, ${dlg.y}, ${dlg.cx}, ${dlg.cy}`];
    const st = []; const S = (m, n) => { if ((dlg.style & m) === m) st.push(n); };
    S(0x80, 'DS_MODALFRAME'); S(0x40, 'DS_SETFONT'); S(0x800, 'DS_CENTER'); S(0x80000000, 'WS_POPUP'); S(0x40000000, 'WS_CHILD'); S(0x00C00000, 'WS_CAPTION'); S(0x00080000, 'WS_SYSMENU'); S(0x00040000, 'WS_THICKFRAME'); S(0x10000000, 'WS_VISIBLE');
    L.push(`STYLE ${st.join(' | ') || '0x' + dlg.style.toString(16)}`);
    if (dlg.exStyle) L.push(`EXSTYLE 0x${dlg.exStyle.toString(16).toUpperCase()}`);
    if (dlg.title) L.push(`CAPTION ${rcStr(dlg.title)}`);
    if (dlg.menu != null) L.push(`MENU ${rcId(dlg.menu)}`);
    if (dlg.cls != null) L.push(`CLASS ${rcStr(dlg.cls)}`);
    if (dlg.font) L.push(`FONT ${dlg.pt}, ${rcStr(dlg.font)}${dlg.ex ? `, ${dlg.weight || 400}, ${dlg.italic || 0}, ${dlg.charset || 0}` : ''}`);
    L.push(`LANGUAGE ${langName(lang)}`, '{');
    for (const it of dlg.items) {
      const t = typeof it.title === 'number' ? it.title : rcStr(it.title);
      L.push(`   CONTROL ${t}, ${it.id === 0xFFFF || it.id === 0xFFFFFFFF ? -1 : it.id}, ${rcStr(it.cls)}, ${styleNames(it.style, it.cls) || '0x' + it.style.toString(16).toUpperCase()}, ${it.x}, ${it.y}, ${it.cx}, ${it.cy}${it.exStyle ? ', 0x' + it.exStyle.toString(16).toUpperCase() : ''}`);
    }
    L.push('}'); return L.join('\r\n');
  }
  function menuScript(items, name, lang) {
    const L = [`${rcId(name)} MENU`, `LANGUAGE ${langName(lang)}`, '{'];
    const w = (list, ind) => { for (const it of list) { const sp = ' '.repeat(ind); if (it.items) { L.push(`${sp}POPUP ${rcStr(it.text)}${it.grayed ? ', GRAYED' : ''}`, `${sp}{`); w(it.items, ind + 3); L.push(`${sp}}`); } else if (it.sep || (!it.text && !it.id)) L.push(`${sp}MENUITEM SEPARATOR`); else L.push(`${sp}MENUITEM ${rcStr(it.text)}, ${it.id}${it.checked ? ', CHECKED' : ''}${it.grayed ? ', GRAYED' : ''}`); } };
    w(items, 3); L.push('}'); return L.join('\r\n');
  }
  const LANGS = { 0x0409: 'LANG_ENGLISH, SUBLANG_ENGLISH_US', 0x0416: 'LANG_PORTUGUESE, SUBLANG_PORTUGUESE_BRAZILIAN', 0x0816: 'LANG_PORTUGUESE, SUBLANG_PORTUGUESE', 0x0000: 'LANG_NEUTRAL, SUBLANG_NEUTRAL', 0x0809: 'LANG_ENGLISH, SUBLANG_ENGLISH_UK', 0x0C0A: 'LANG_SPANISH, SUBLANG_SPANISH_MODERN', 0x040A: 'LANG_SPANISH, SUBLANG_SPANISH', 0x0407: 'LANG_GERMAN, SUBLANG_GERMAN', 0x040C: 'LANG_FRENCH, SUBLANG_FRENCH', 0x0410: 'LANG_ITALIAN, SUBLANG_ITALIAN', 0x0411: 'LANG_JAPANESE, SUBLANG_DEFAULT', 0x0804: 'LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED', 0x0419: 'LANG_RUSSIAN, SUBLANG_DEFAULT' };
  const langName = l => typeof l === 'number' ? (LANGS[l] || `0x${l.toString(16).toUpperCase().padStart(4, '0')}`) : String(l);
  function stringsScript(list, lang) { return ['STRINGTABLE', `LANGUAGE ${langName(lang)}`, '{', ...list.map(x => `   ${x.id}, \t${rcStr(x.s)}`), '}'].join('\r\n'); }
  function versionScript(v, name) {
    const L = [`${rcId(name)} VERSIONINFO`]; if (v.fixed) L.push(`FILEVERSION ${v.fixed.file.replace(/\./g, ',')}`, `PRODUCTVERSION ${v.fixed.product.replace(/\./g, ',')}`);
    L.push('{', '   BLOCK "StringFileInfo"', '   {'); for (const [k, s] of v.strings) L.push(`      VALUE ${rcStr(k)}, ${rcStr(s)}`); L.push('   }', '}'); return L.join('\r\n');
  }
  const VK = { 8: 'VK_BACK', 9: 'VK_TAB', 13: 'VK_RETURN', 27: 'VK_ESCAPE', 32: 'VK_SPACE', 33: 'VK_PRIOR', 34: 'VK_NEXT', 35: 'VK_END', 36: 'VK_HOME', 37: 'VK_LEFT', 38: 'VK_UP', 39: 'VK_RIGHT', 40: 'VK_DOWN', 45: 'VK_INSERT', 46: 'VK_DELETE' };
  function accelScript(list, name) { return [`${rcId(name)} ACCELERATORS`, '{', ...list.map(a => { const virt = a.f & 1; const key = virt ? (VK[a.key] || (a.key >= 112 && a.key <= 135 ? 'VK_F' + (a.key - 111) : (a.key >= 48 && a.key <= 90 ? rcStr(String.fromCharCode(a.key)) : String(a.key)))) : rcStr(String.fromCharCode(a.key)); const mods = [virt ? 'VIRTKEY' : 'ASCII', a.f & 4 ? 'SHIFT' : '', a.f & 8 ? 'CONTROL' : '', a.f & 16 ? 'ALT' : ''].filter(Boolean).join(', '); return `   ${key}, ${a.id}, ${mods}`; }), '}'].join('\r\n'); }

  // ---------------------------------------------------------------- DFM binário -> texto
  function dfmText(u8) {
    const D = typeof DelphiImport !== 'undefined' ? DelphiImport : null; if (!D) return '';
    const root = D.parseDfmBinary(u8);
    const L = [];
    const str = s => { if (s === '') return "''"; let out = '', q = false; for (const ch of s) { const c = ch.charCodeAt(0); if (c >= 32 && c < 127) { if (!q) { out += "'"; q = true; } out += ch === "'" ? "''" : ch; } else { if (q) { out += "'"; q = false; } out += '#' + c; } } if (q) out += "'"; return out; };
    const val = (v, ind) => {
      switch (v.t) {
        case 'int': case 'float': return String(v.v);
        case 'str': return str(v.v);
        case 'ident': return v.v === '' ? 'Null' : v.v;
        case 'bool': return v.v ? 'True' : 'False';
        case 'set': return '[' + v.v.join(', ') + ']';
        case 'list': return '(' + v.v.map(x => '\r\n' + ' '.repeat(ind + 2) + val(x, ind + 2)).join('') + ')';
        case 'bin': { const rows = []; for (let i = 0; i < v.v.length; i += 64) rows.push(' '.repeat(ind + 2) + v.v.slice(i, i + 64).toUpperCase()); return '{\r\n' + rows.join('\r\n') + '}'; }
        case 'coll': return '<' + v.v.map(item => '\r\n' + ' '.repeat(ind + 2) + 'item' + [...item.values()].map(p => '\r\n' + ' '.repeat(ind + 4) + p.key + ' = ' + val(p.v, ind + 4)).join('') + '\r\n' + ' '.repeat(ind + 2) + 'end').join('') + '>';
      }
      return '';
    };
    const obj = (n, ind) => { L.push(' '.repeat(ind) + `${n.kind} ${n.name ? n.name + ': ' : ''}${n.cls}`); for (const p of n.props.values()) L.push(' '.repeat(ind + 2) + p.key + ' = ' + val(p.v, ind + 2)); for (const c of n.children) obj(c, ind + 2); L.push(' '.repeat(ind) + 'end'); };
    obj(root, 0); return { text: L.join('\r\n'), root };
  }

  // ---------------------------------------------------------------- diálogo Win32 -> formulário (.frm)
  function vbs(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
  function dialogToFrm(dlg, formName, opts) {
    const R = opts && opts.R;
    const pt = dlg.pt || 8; const fontName = dlg.font && !/^ms shell dlg/i.test(dlg.font) ? dlg.font : 'MS Sans Serif';
    const bx = Math.max(5, Math.round(pt * 0.75)) / 4, by = Math.round(pt * 96 / 72 * 1.22) / 8; // unidades de diálogo -> pixels
    const tw = (v, k) => Math.round(v * k * 15);
    const L = ['VERSION 5.00', `Begin VB.Form ${formName} `];
    const P = (ind, k, v) => L.push(' '.repeat(ind) + k.padEnd(16) + '=   ' + v);
    const caption = dlg.title || formName;
    const sizable = !!(dlg.style & 0x40000);
    P(3, 'BorderStyle', sizable ? '2  \'Sizable' : '3  \'Fixed Dialog');
    P(3, 'Caption', vbs(caption));
    P(3, 'ClientHeight', String(tw(dlg.cy, by))); P(3, 'ClientLeft', '45'); P(3, 'ClientTop', '435'); P(3, 'ClientWidth', String(tw(dlg.cx, bx)));
    if (fontName !== 'MS Sans Serif' || pt !== 8) { L.push('   BeginProperty Font '); P(6, 'Name', vbs(fontName)); P(6, 'Size', String(pt)); P(6, 'Charset', '0'); P(6, 'Weight', String(dlg.weight || 400)); P(6, 'Underline', '0   \'False'); P(6, 'Italic', dlg.italic ? '-1  \'True' : '0   \'False'); P(6, 'Strikethrough', '0   \'False'); L.push('   EndProperty'); }
    P(3, 'LinkTopic', vbs(formName)); P(3, 'MaxButton', sizable ? '-1  \'True' : '0   \'False'); P(3, 'MinButton', sizable ? '-1  \'True' : '0   \'False');
    P(3, 'ScaleHeight', String(tw(dlg.cy, by))); P(3, 'ScaleWidth', String(tw(dlg.cx, bx))); P(3, 'StartUpPosition', '1  \'CenterOwner');
    const names = new Set([formName.toLowerCase()]); const uniq = b => { let i = 1; while (names.has((b + i).toLowerCase())) i++; names.add((b + i).toLowerCase()); return b + i; };
    let tab = 0; const notes = [];
    const pending = {};
    for (const it of dlg.items) {
      const c = String(it.cls).toUpperCase(); const s = it.style; let type = null, base = null; const extra = [];
      const txt = typeof it.title === 'string' ? it.title : '';
      if (c === 'BUTTON') { const k = s & 0xF; if (k === 7) { type = 'VB.Frame'; base = 'Frame'; } else if (k === 2 || k === 3 || k === 5 || k === 6) { type = 'VB.CheckBox'; base = 'Check'; } else if (k === 4 || k === 9) { type = 'VB.OptionButton'; base = 'Option'; } else { type = 'VB.CommandButton'; base = 'Command'; if (k === 1) extra.push(['Default', '-1  \'True']); if (it.id === 2) extra.push(['Cancel', '-1  \'True']); } }
      else if (c === 'EDIT') { type = 'VB.TextBox'; base = 'Text'; if (s & 4) { extra.push(['MultiLine', '-1  \'True']); if (s & 0x200000) extra.push(['ScrollBars', '2  \'Vertical']); } if (s & 0x20) extra.push(['PasswordChar', '"*"']); if (s & 0x800) extra.push(['Locked', '-1  \'True']); if (s & 1) extra.push(['Alignment', '2  \'Center']); else if (s & 2) extra.push(['Alignment', '1  \'Right Justify']); }
      else if (c === 'STATIC') { const k = s & 0x1F; if (k === 3 || k === 14) { type = 'VB.Image'; base = 'Image'; } else if (k >= 4 && k <= 9 || k >= 16 && k <= 18) { type = 'NK.Bevel'; base = 'Bevel'; extra.push(['Shape', k === 16 ? '2' : k === 17 ? '4' : k === 18 ? '1' : '0']); } else { type = 'VB.Label'; base = 'Label'; if (k === 1) extra.push(['Alignment', '2  \'Center']); else if (k === 2) extra.push(['Alignment', '1  \'Right Justify']); } }
      else if (c === 'LISTBOX') { type = 'VB.ListBox'; base = 'List'; }
      else if (c === 'COMBOBOX' || c === 'COMBOBOXEX32') { type = 'VB.ComboBox'; base = 'Combo'; const k = s & 3; if (k === 3) extra.push(['Style', '2  \'Dropdown List']); else if (k === 1) extra.push(['Style', '1  \'Simple Combo']); }
      else if (c === 'SCROLLBAR') { type = s & 1 ? 'VB.VScrollBar' : 'VB.HScrollBar'; base = s & 1 ? 'VScroll' : 'HScroll'; }
      else { const m = { SYSLISTVIEW32: ['NK.ListView', 'ListView'], SYSTREEVIEW32: ['NB.TreeView', 'TreeView'], MSCTLS_PROGRESS32: ['NB.ProgressBar', 'ProgressBar'], MSCTLS_TRACKBAR32: ['NB.Slider', 'TrackBar'], MSCTLS_UPDOWN32: ['NK.UpDown', 'UpDown'], SYSTABCONTROL32: ['NB.TabControl', 'TabControl'], SYSDATETIMEPICK32: ['NB.DatePicker', 'DateTimePicker'], SYSMONTHCAL32: ['NK.MonthCalendar', 'MonthCalendar'], MSCTLS_HOTKEY32: ['NK.HotKey', 'HotKey'], SYSANIMATE32: ['NK.Animate', 'Animate'], SYSLINK: ['VB.Label', 'Link'], SYSIPADDRESS32: ['VB.TextBox', 'IPAddress'], MSCTLS_STATUSBAR32: ['NK.StatusBar', 'StatusBar'], TOOLBARWINDOW32: ['NK.ToolBar', 'ToolBar'], SYSHEADER32: ['NK.HeaderControl', 'Header'] }[c];
        if (m) { [type, base] = m; } else if (/^RICHEDIT/i.test(c)) { type = 'NB.RichTextBox'; base = 'RichEdit'; } else { type = 'NB.Panel'; base = 'Custom'; notes.push(`control ${it.id} uses the window class "${it.cls}" (shown as a Panel)`); } }
      const nm = uniq(base);
      L.push(`   Begin ${type} ${nm} `);
      const cap = c === 'SYSLINK' ? txt.replace(/<\/?a[^>]*>/gi, '') : txt;
      if (['VB.CommandButton', 'VB.CheckBox', 'VB.OptionButton', 'VB.Frame', 'VB.Label', 'NB.Panel'].includes(type)) P(6, 'Caption', vbs(type === 'NB.Panel' && !cap ? it.cls : cap));
      if (type === 'VB.TextBox' || type === 'VB.ComboBox' || type === 'NB.RichTextBox') P(6, 'Text', vbs(cap));
      if (type === 'VB.Label') P(6, 'BackStyle', '0  \'Transparent');
      if (!(s & 0x10000000)) P(6, 'Visible', '0   \'False');
      if (s & 0x08000000) P(6, 'Enabled', '0   \'False');
      for (const [k, v] of extra) P(6, k, v);
      P(6, 'Height', String(tw(type === 'VB.ComboBox' ? Math.min(it.cy, 14) : it.cy, by))); P(6, 'Left', String(tw(it.x, bx)));
      if (!['VB.Label', 'VB.Frame', 'VB.Image', 'NK.Bevel'].includes(type)) P(6, 'TabIndex', String(tab++));
      if (type === 'VB.Image') P(6, 'Stretch', '-1  \'True');
      P(6, 'Tag', vbs('ID ' + (it.id === 0xFFFF || it.id === 0xFFFFFFFF ? -1 : it.id)));
      P(6, 'Top', String(tw(it.y, by))); P(6, 'Width', String(tw(it.cx, bx)));
      L.push('   End');
      // imagem de SS_ICON/SS_BITMAP
      if (type === 'VB.Image' && R && it.title != null && it.title !== '') { const pic = picFor(R, it.title, (s & 0x1F) === 14); if (pic) pending[nm] = pic; }
    }
    // menu do diálogo
    if (dlg.menu != null && R) { const m = findRes(R, 4, dlg.menu); if (m) { try { writeMenus(L, parseMenu(m.data), 3, names); } catch (e) { } } }
    L.push('End', `Attribute VB_Name = ${vbs(formName)}`, 'Attribute VB_GlobalNameSpace = False', 'Attribute VB_Creatable = False', 'Attribute VB_PredeclaredId = True', 'Attribute VB_Exposed = False',
      `' Form created by Neo Kiva from the dialog resource ${rcId(opts && opts.resName != null ? opts.resName : '')} of ${opts && opts.file || 'the executable'}.`, `' The Tag of each control keeps the original control ID.`, 'Option Explicit', '');
    const hasOk = dlg.items.some(it => it.id === 1 && String(it.cls).toUpperCase() === 'BUTTON');
    return { text: L.join('\r\n'), notes, pending };
  }
  function writeMenus(L, items, ind, names) {
    const uniqM = b => { let n = 'mnu' + (String(b).replace(/&/g, '').replace(/[^A-Za-z0-9]/g, '').slice(0, 20) || 'Item'); let k = n, i = 2; while (names.has(k.toLowerCase())) k = n + (i++); names.add(k.toLowerCase()); return k; };
    for (const it of items) {
      const sep = it.sep || (!it.text && !it.items); const nm = sep ? uniqM('Sep') : uniqM(it.text.split('\t')[0]);
      L.push(' '.repeat(ind) + `Begin VB.Menu ${nm} `); L.push(' '.repeat(ind + 3) + 'Caption'.padEnd(16) + '=   ' + vbs(sep ? '-' : it.text.split('\t')[0]));
      if (it.checked) L.push(' '.repeat(ind + 3) + 'Checked'.padEnd(16) + '=   -1  \'True'); if (it.grayed) L.push(' '.repeat(ind + 3) + 'Enabled'.padEnd(16) + '=   0   \'False');
      if (it.items) writeMenus(L, it.items, ind + 3, names);
      L.push(' '.repeat(ind) + 'End');
    }
  }
  function picFor(R, title, bitmap) {
    if (bitmap) { const b = findRes(R, 2, title); if (b) { const f = bitmapFile(b.data); return { mime: 'image/bmp', bytes: f }; } return null; }
    const g = findRes(R, 14, title); if (g) return { mime: 'image/x-icon', bytes: iconGroupToIco(R, g) };
    return null;
  }

  // ---------------------------------------------------------------- tela do Resource Explorer
  function nodeLabel(r) { return `${resName(r.name)}${r.lang != null ? ' : ' + r.lang : ''}`; }
  function viewFor(R, r) {
    const t = r.type; const out = { kind: 'hex', script: null, preview: null, canForm: false };
    try {
      if (t === 14 || t === 12) { const ico = iconGroupToIco(R, r, t === 12); out.kind = 'image'; out.img = { mime: t === 12 ? 'image/x-icon' : 'image/x-icon', bytes: ico }; out.save = { ext: t === 12 ? 'cur' : 'ico', bytes: ico }; const d = r.data; const n = u16(d, 4); out.meta = []; for (let i = 0; i < n; i++) { const e = 6 + i * 14; out.meta.push(`${d[e] || 256} × ${d[e + 1] || 256}, ${u16(d, e + 8) || '?'}-bit`); } out.script = `${rcId(r.name)} ${t === 12 ? 'CURSOR' : 'ICON'} "${String(resName(r.name)).toLowerCase()}.${t === 12 ? 'cur' : 'ico'}"`; }
      else if (t === 3 || t === 1) { const d = t === 1 ? r.data.subarray(4) : r.data; const im = singleIcon(d); out.kind = 'image'; out.img = im; out.save = { ext: im.mime === 'image/png' ? 'png' : 'ico', bytes: im.bytes }; }
      else if (t === 2) { const f = bitmapFile(r.data); out.kind = 'image'; out.img = { mime: 'image/bmp', bytes: f }; out.save = { ext: 'bmp', bytes: f }; out.meta = [`${u32(r.data, 4)} × ${Math.abs(u32(r.data, 8) | 0)}, ${u16(r.data, 14)}-bit`]; out.script = `${rcId(r.name)} BITMAP "${String(resName(r.name)).toLowerCase()}.bmp"`; }
      else if (t === 6) { out.kind = 'script'; out.script = stringsScript(strings(r), r.lang); }
      else if (t === 16) { const v = versionInfo(r.data); out.kind = 'script'; out.script = versionScript(v, r.name); out.version = v; }
      else if (t === 24 || t === 23) { out.kind = 'text'; out.text = text(r.data); out.save = { ext: t === 24 ? 'manifest' : 'html', bytes: r.data }; }
      else if (t === 4) { const m = parseMenu(r.data); out.kind = 'script'; out.script = menuScript(m, r.name, r.lang); out.menu = m; }
      else if (t === 9) { out.kind = 'script'; out.script = accelScript(accelerators(r.data), r.name); }
      else if (t === 5) { const dlg = parseDialog(r.data); out.kind = 'dialog'; out.dlg = dlg; out.script = dialogScript(dlg, r.name, r.lang); out.canForm = true; }
      else if (t === 10 && r.data.length > 4 && ascii(r.data, 0, 4) === 'TPF0') { const d = dfmText(r.data); out.kind = 'dfm'; out.script = d.text; out.dfm = d.root; out.canForm = true; out.save = { ext: 'dfm', bytes: r.data }; }
      else if (r.data.length > 4 && r.data[0] === 0x89 && ascii(r.data, 1, 3) === 'PNG') { out.kind = 'image'; out.img = { mime: 'image/png', bytes: r.data }; out.save = { ext: 'png', bytes: r.data }; }
      else if (r.data.length > 3 && r.data[0] === 0xFF && r.data[1] === 0xD8) { out.kind = 'image'; out.img = { mime: 'image/jpeg', bytes: r.data }; out.save = { ext: 'jpg', bytes: r.data }; }
      else if (r.data.length > 3 && ascii(r.data, 0, 3) === 'GIF') { out.kind = 'image'; out.img = { mime: 'image/gif', bytes: r.data }; out.save = { ext: 'gif', bytes: r.data }; }
      else if (r.data.length && [...r.data.subarray(0, Math.min(400, r.data.length))].every(x => x === 9 || x === 10 || x === 13 || (x >= 32 && x < 127) || x >= 0xA0)) { out.kind = 'text'; out.text = text(r.data); }
    } catch (e) { out.kind = 'hex'; out.error = e.message; }
    if (!out.save) out.save = { ext: 'bin', bytes: r.data };
    return out;
  }
  return { open, viewFor, typeName, resName, nodeLabel, parseDialog, dialogToFrm, dfmText, hexDump, langName, findRes, TYPES, RC_NAMES, iconGroupToIco, bitmapFile };
})();
if (typeof module !== 'undefined') module.exports = NKRes;
