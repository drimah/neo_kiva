// ===== Neo Kiva 0.1 — importador de projetos Clipper (.prg) =====
// Fase 1: telas (@ SAY/GET, PROMPT/MENU TO, caixas) viram formulários; o código vira módulos .bas;
// comandos de banco de dados (DBF) ficam marcados com [Clipper] e as tabelas .dbf viram .csv.
'use strict';
const NKClipper = (() => {
  // ---------------------------------------------------------------- texto (DOS CP850 / Windows-1252 / UTF-8)
  const CP850 = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈıÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■ ';
  function decode(bytes) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (e) { }
    let dos = 0, win = 0;
    for (const b of bytes) { if (b >= 0x80 && b <= 0xA5 || b === 0xC6 || b === 0xE4 || (b >= 0xB3 && b <= 0xDA)) dos++; if (b >= 0xC0 && b <= 0xFC && !(b >= 0xC4 && b <= 0xDA)) win++; }
    if (dos >= win) { let s = ''; for (const b of bytes) s += b < 128 ? String.fromCharCode(b) : CP850[b - 128]; return s; }
    return new TextDecoder('windows-1252').decode(bytes);
  }
  const VB_KW = new Set('and as boolean byref byte byval call case const currency date debug dim do double each else elseif empty end enum eqv erase error exit false for function get global gosub goto if imp in integer is let lib like long loop lset me mod new next not nothing null on option optional or paramarray preserve private property public raiseevent redim rem resume return rset select set single static step stop string sub then to true type typeof until variant wend while with xor object print len val str left right mid form forms screen app err timer time year month day hour minute second now text name caption value tag'.split(' '));
  const safe = n => VB_KW.has(n.toLowerCase()) ? n + '_' : n;

  // ---------------------------------------------------------------- léxico
  const OPS = [':=', '==', '!=', '<>', '<=', '>=', '->', '++', '--', '+=', '-=', '*=', '/=', '**', '.AND.', '.OR.', '.NOT.', '.T.', '.F.', '.Y.', '.N.', '+', '-', '*', '/', '%', '^', '=', '<', '>', '#', '$', '!', '(', ')', '{', '}', '[', ']', ',', '|', '@', '&', ':', ';', '.'];
  function lex(src) {
    const t = []; let i = 0; const n = src.length;
    const prevIsValue = () => { const p = t[t.length - 1]; return p && (p.k === 'id' || p.k === 'num' || p.k === 'str' || (p.k === 'op' && (p.v === ')' || p.v === ']' || p.v === '}'))); };
    while (i < n) {
      const c = src[i];
      if (c === ' ' || c === '\t' || c === '\r' || c === '\n') { i++; continue; }
      if (c === '"' || c === "'") { const e = src.indexOf(c, i + 1); const end = e < 0 ? n : e; t.push({ k: 'str', v: src.slice(i + 1, end) }); i = end + 1; continue; }
      if (c === '[' && !prevIsValue()) { const e = src.indexOf(']', i + 1); if (e >= 0) { t.push({ k: 'str', v: src.slice(i + 1, e) }); i = e + 1; continue; } }
      if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) { let j = i; while (j < n && /[0-9.]/.test(src[j])) { if (src[j] === '.' && !/[0-9]/.test(src[j + 1] || '')) break; j++; } t.push({ k: 'num', v: src.slice(i, j) }); i = j; continue; }
      if (/[A-Za-z_À-ɏ]/.test(c)) { let j = i; while (j < n && /[A-Za-z0-9_À-ɏ]/.test(src[j])) j++; t.push({ k: 'id', v: src.slice(i, j) }); i = j; continue; }
      let op = null; for (const o of OPS) if (src.substr(i, o.length).toUpperCase() === o) { op = o; break; }
      if (op) { t.push({ k: 'op', v: op }); i += op.length; continue; }
      t.push({ k: 'op', v: c }); i++;
    }
    return t;
  }

  // ---------------------------------------------------------------- expressões -> VB
  // contexto: { funcs: Set de funções do usuário (minúsculas), todo: fn(msg) }
  const FN = {
    str: 'NKStr', val: 'Val', len: 'NKLen', substr: 'Mid', left: 'Left', right: 'Right', upper: 'UCase', lower: 'LCase', alltrim: 'Trim', trim: 'RTrim', rtrim: 'RTrim', ltrim: 'LTrim',
    space: 'Space', replicate: 'NKReplicate', padr: 'NKPadR', pad: 'NKPadR', padl: 'NKPadL', padc: 'NKPadC', strtran: 'NKStrTran', date: 'Date', time: 'Time', year: 'Year', month: 'Month', day: 'Day',
    ctod: 'NKCToD', dtoc: 'NKDToC', dtos: 'NKDToS', stod: 'NKSToD', chr: 'Chr', asc: 'Asc', int: 'Int', round: 'Round', abs: 'Abs', max: 'NKMax', min: 'NKMin', empty: 'NKEmpty', type: 'NKType', valtype: 'NKValType',
    iif: 'IIf', if: 'IIf', transform: 'NKTransform', inkey: 'NKInkey', lastkey: 'NKLastKey', nextkey: 'NKNextKey', alert: 'NKAlert', seconds: 'Timer', cdow: 'NKCDoW', cmonth: 'NKCMonth', dow: 'Weekday', file: 'NKFile',
    sqrt: 'Sqr', exp: 'Exp', log: 'Log', isalpha: 'NKIsAlpha', isdigit: 'NKIsDigit', isupper: 'NKIsUpper', islower: 'NKIsLower', strzero: 'NKStrZero', mod: 'NKMod', aadd: 'NKAAdd', asize: 'NKASize', ascan: 'NKAScan',
    adel: 'NKADel', ains: 'NKAIns', array: 'NKArrayN', acopy: 'NKACopy', aclone: 'NKAClone', afill: 'NKAFill', asort: 'NKASort', atail: 'NKATail', achoice: 'NKAChoice', setcolor: 'NKSetColor', setcursor: 'NKSetColor',
    savescreen: 'NKSaveScreen', restscreen: 'NKRestScreen', row: 'NKRow', col: 'NKCol', pcol: 'NKCol', prow: 'NKRow', maxrow: 'NKMaxRow', maxcol: 'NKMaxCol', setpos: 'NKSetPos', devpos: 'NKSetPos', dispout: 'NKQQOut', qout: 'NKQOut', qqout: 'NKQQOut',
    eof: 'NKEof', bof: 'NKBof', recno: 'NKRecNo', reccount: 'NKRecCount', lastrec: 'NKRecCount', found: 'NKFound', deleted: 'NKDeleted', alias: 'NKAlias', select: 'NKSelect', used: 'NKUsed', neterr: 'NKNetErr', rlock: 'NKLock', flock: 'NKLock',
    dbskip: 'NKSkip', dbgotop: 'NKGoTop', dbgobottom: 'NKGoBottom', dbgoto: 'NKGoTo', dbseek: 'NKSeek', dbappend: 'NKAppend', dbdelete: 'NKDelete', dbcommit: 'NKCommit', dbunlock: 'NKUnlock', dbclosearea: 'NKClose', dbusearea: 'NKUse', dbselectarea: 'NKSelect', fieldget: 'NKFieldGet', fieldput: 'NKFieldPut', fieldname: 'NKFieldName', fcount: 'NKFCount', ordsetfocus: 'NKSetOrder', indexord: 'NKIndexOrd',
    descend: 'NKDescend', soundex: 'NKSoundex', at: '#at', rat: '#rat', memoline: 'NKMemoLine', mlcount: 'NKMLCount', hardcr: 'NKHardCR', memotran: 'NKMemoTran', curdir: 'CurDir', getenv: 'Environ', os: 'NKOS', version: 'NKVersion',
    tone: 'NKTone', set: 'NKSetFn', errorlevel: 'NKErrorLevel', __keyboard: 'NKKeyboard', readvar: 'NKReadVar', updated: 'NKUpdated', devout: 'NKQQOut', ntoc: 'NKStr', val_: 'Val', cstr: 'CStr',
  };
  class Expr {
    constructor(toks, ctx) { this.t = toks; this.p = 0; this.ctx = ctx; }
    get c() { return this.t[this.p]; }
    isOp(v) { const c = this.c; return c && c.k === 'op' && c.v.toUpperCase() === v; }
    eat(v) { if (this.isOp(v)) { this.p++; return true; } return false; }
    parse(minPrec = 0) {
      let left = this.unary();
      for (;;) {
        const c = this.c; if (!c || c.k !== 'op') break; const op = c.v.toUpperCase();
        const P = { '.OR.': 1, '.AND.': 2, '=': 4, '==': 4, '!=': 4, '<>': 4, '#': 4, '<': 4, '>': 4, '<=': 4, '>=': 4, '$': 4, '+': 5, '-': 5, '*': 6, '/': 6, '%': 6, '**': 7, '^': 7 }[op];
        if (P === undefined || P <= minPrec - 1 || P < minPrec) break;
        this.p++;
        const right = this.parse(P + (op === '**' || op === '^' ? 0 : 1));
        const wrap = (x, mine) => x.prec !== undefined && x.prec < mine ? '(' + x.s + ')' : x.s;
        let s;
        switch (op) {
          case '.OR.': s = `${wrap(left, 1)} Or ${wrap(right, 1)}`; break;
          case '.AND.': s = `${wrap(left, 2)} And ${wrap(right, 2)}`; break;
          case '==': case '=': s = `${wrap(left, 5)} = ${wrap(right, 5)}`; break;
          case '!=': case '<>': case '#': s = `${wrap(left, 5)} <> ${wrap(right, 5)}`; break;
          case '$': s = `InStr(1, ${right.s}, ${left.s}) > 0`; break;
          case '%': s = `${wrap(left, 6)} Mod ${wrap(right, 6)}`; break;
          case '**': case '^': s = `${wrap(left, 8)} ^ ${wrap(right, 8)}`; break;
          default: s = `${wrap(left, P)} ${op} ${wrap(right, P + (op === '-' || op === '/' ? 1 : 0))}`;
        }
        left = { s, prec: P === 4 ? 4 : P };
      }
      return left;
    }
    unary() {
      if (this.eat('!') || this.eat('.NOT.')) { const x = this.unary(); return { s: `Not (${x.s})`, prec: 3 }; }
      if (this.eat('-')) { const x = this.unary(); return { s: `-${x.prec !== undefined ? '(' + x.s + ')' : x.s}`, prec: 7.5 }; }
      if (this.eat('+')) return this.unary();
      if (this.eat('++') || this.eat('--')) { const x = this.unary(); this.ctx.todo('increment inside an expression'); return x; }
      return this.postfix(this.atom());
    }
    args(close) {
      const a = []; if (this.eat(close)) return a;
      for (;;) {
        if (this.isOp(',')) { a.push(''); this.p++; continue; }
        if (this.isOp(close)) { a.push(''); this.p++; break; }
        a.push(this.parse().s);
        if (this.eat(',')) { if (this.isOp(close)) { a.push(''); this.p++; break; } continue; }
        if (!this.eat(close)) break; break;
      }
      return a;
    }
    postfix(x) {
      for (;;) {
        if (this.isOp('[')) { this.p++; const idx = this.args(']'); x = { s: idx.length > 1 ? `NKAt(${x.s}, ${idx.join(', ')})` : `${x.s}(${idx[0]})` }; continue; }
        if (this.isOp(':') && this.t[this.p + 1] && this.t[this.p + 1].k === 'id') { this.p++; const m = this.c.v; this.p++; let a = ''; if (this.eat('(')) a = '(' + this.args(')').join(', ') + ')'; this.ctx.todo(`object method ${m}`); x = { s: `${x.s}.${m}${a}` }; continue; }
        if (this.isOp('++') || this.isOp('--')) { this.p++; this.ctx.todo('increment inside an expression'); continue; }
        break;
      }
      return x;
    }
    atom() {
      const c = this.c; if (!c) return { s: 'Empty' };
      if (c.k === 'num') { this.p++; return { s: c.v.startsWith('.') ? '0' + c.v : c.v }; }
      if (c.k === 'str') { this.p++; return { s: vbStr(c.v) }; }
      if (c.k === 'op') {
        const v = c.v.toUpperCase();
        if (v === '.T.' || v === '.Y.') { this.p++; return { s: 'True' }; }
        if (v === '.F.' || v === '.N.') { this.p++; return { s: 'False' }; }
        if (v === '(') { this.p++; const x = this.parse(); const more = []; while (this.eat(',')) more.push(this.parse().s); this.eat(')'); return more.length ? { s: `NKLast(${[x.s, ...more].join(', ')})` } : { s: '(' + x.s + ')' }; }
        if (v === '{') {
          this.p++;
          if (this.isOp('|')) { let depth = 1; while (this.c && depth) { if (this.isOp('{')) depth++; if (this.isOp('}')) depth--; this.p++; } this.ctx.todo('code block {|| }'); return { s: '"[Clipper] code block"' }; }
          const a = this.args('}'); return { s: `NKArray(${a.join(', ')})` };
        }
        if (v === '&') { this.p++; let inner; if (this.isOp('(')) { this.p++; inner = this.parse().s; this.eat(')'); } else { inner = this.c ? safe(this.c.v) : '""'; this.p++; if (this.isOp('.')) this.p++; } this.ctx.todo('macro &'); return { s: `NKMacro(${inner})` }; }
        if (v === '@') { this.p++; return this.unary(); } // passagem por referência
      }
      if (c.k === 'id') {
        this.p++; const name = c.v; const ln = name.toLowerCase();
        if (ln === 'nil') return { s: 'Empty' };
        if (this.isOp('->')) { this.p++; const f = this.c; this.p++; if (ln === 'm' || ln === 'memvar') return { s: safe(f.v) }; if (ln === 'field' || ln === '_field') return { s: `NKField("", "${f.v}")` }; this.ctx.db = true; return { s: `NKField("${name}", "${f.v}")` }; }
        if (this.isOp('(')) {
          this.p++; const a = this.args(')');
          if (this.ctx.funcs.has(ln)) return { s: `${this.ctx.funcName(name)}(${a.join(', ')})` };
          const m = FN[ln];
          if (m === '#at') return { s: `InStr(1, ${a[1] || '""'}, ${a[0] || '""'})` };
          if (m === '#rat') return { s: `InStrRev(${a[1] || '""'}, ${a[0] || '""'})` };
          if (m && !a.length && /^(Date|Time|Timer)$/.test(m)) return { s: m };
          if (m) { if (/^NK(Eof|Bof|RecNo|RecCount|Found|Deleted|Alias|Select|Used|Skip|GoTop|GoBottom|GoTo|Seek|Append|Delete|Commit|Unlock|Close|Use|FieldGet|FieldPut|FieldName|FCount|SetOrder|IndexOrd|Lock|NetErr)$/.test(m)) this.ctx.db = true; return { s: `${m}(${a.join(', ')})` }; }
          this.ctx.unknownFn(name); return { s: `${safe(name)}(${a.join(', ')})` };
        }
        return { s: this.ctx.varName(name) };
      }
      this.p++; return { s: c.v };
    }
  }
  function vbStr(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
  function exprOf(src, ctx) { const toks = Array.isArray(src) ? src : lex(src); if (!toks.length) return ''; const e = new Expr(toks, ctx); const r = e.parse().s; if (e.p < toks.length) ctx.todo('part of an expression was not understood'); return r; }

  // ---------------------------------------------------------------- pré-processamento
  function preprocess(text, defines) {
    // tira comentários /* */ e junta linhas terminadas em ';'
    let src = text.replace(/\r\n?/g, '\n');
    src = src.replace(/\/\*[\s\S]*?\*\//g, m => m.replace(/[^\n]/g, ' '));
    const raw = src.split('\n'); const out = [];
    let buf = '', startLine = 0, inText = false;
    for (let i = 0; i < raw.length; i++) {
      let L = raw[i];
      if (inText) { if (/^\s*endtext\b/i.test(L)) { inText = false; out.push({ line: i + 1, text: 'ENDTEXT' }); } else out.push({ line: i + 1, text: '\u0001' + L }); continue; }
      if (/^\s*(\*|note\b)/i.test(L)) { L = ''; }
      L = stripLineComment(L);
      if (/^\s*text\b\s*$/i.test(L)) { inText = true; out.push({ line: i + 1, text: 'TEXT' }); continue; }
      if (!buf) startLine = i + 1;
      if (/;\s*$/.test(L) && !/^\s*#/.test(L)) { buf += L.replace(/;\s*$/, ' '); continue; }
      buf += L; const full = buf.trim(); buf = '';
      if (!full) continue;
      const d = /^#\s*define\s+(\w+)\s*(.*)$/i.exec(full); if (d) { defines.set(d[1].toLowerCase(), d[2].trim()); continue; }
      if (/^#/.test(full)) continue;
      // vários comandos na mesma linha separados por ';' (fora de strings) já foram unidos; separa por ';' restante não ocorre
      out.push({ line: startLine, text: full });
    }
    return out;
  }
  function stripLineComment(L) {
    let q = null;
    for (let i = 0; i < L.length; i++) {
      const c = L[i];
      if (q) { if (c === q) q = null; continue; }
      if (c === '"' || c === "'") { q = c; continue; }
      if ((c === '&' && L[i + 1] === '&') || (c === '/' && L[i + 1] === '/')) return L.slice(0, i);
    }
    return L;
  }
  const INKEY = { k_esc: 27, k_enter: 13, k_return: 13, k_up: 5, k_down: 24, k_left: 19, k_right: 4, k_home: 1, k_end: 6, k_pgup: 18, k_pgdn: 3, k_ins: 22, k_del: 7, k_bs: 8, k_tab: 9, k_space: 32, k_f1: 28, k_f2: -1, k_f3: -2, k_f4: -3, k_f5: -4, k_f6: -5, k_f7: -6, k_f8: -7, k_f9: -8, k_f10: -9, k_ctrl_enter: 10, k_alt_x: 301 };
  function applyDefines(s, defines) {
    if (!defines.size && !/\bK_/i.test(s)) return s;
    return s.replace(/("[^"]*"|'[^']*')|\b([A-Za-z_]\w*)\b/g, (m, str, id) => { if (str) return str; const k = id.toLowerCase(); if (defines.has(k)) return defines.get(k); if (k in INKEY) return String(INKEY[k]); return id; });
  }

  // ---------------------------------------------------------------- telas
  const CW = 8, RH = 23; // pixels por coluna / linha da tela de texto 80x25
  function numOrNull(s) { const t = String(s).trim(); return /^-?\d+$/.test(t) ? Number(t) : null; }
  function splitTop(s, sep) { // separa por vírgula/espaço no nível 0 (fora de parênteses e strings)
    const out = []; let d = 0, q = null, cur = '';
    for (let i = 0; i < s.length; i++) { const c = s[i]; if (q) { cur += c; if (c === q) q = null; continue; } if (c === '"' || c === "'") { q = c; cur += c; continue; } if (c === '(' || c === '[' || c === '{') d++; if (c === ')' || c === ']' || c === '}') d--; if (c === sep && d === 0) { out.push(cur); cur = ''; continue; } cur += c; }
    out.push(cur); return out.map(x => x.trim());
  }
  // divide "@ r, c SAY x PICTURE p GET v VALID ..." em cláusulas
  function atClauses(rest) {
    const KW = ['SAY', 'GET', 'PICTURE', 'PICT', 'VALID', 'WHEN', 'RANGE', 'COLOR', 'COLO', 'PROMPT', 'MESSAGE', 'TO', 'DOUBLE', 'CLEAR', 'BOX', 'SEND', 'CAPTION'];
    const out = []; let cur = { k: '', v: '' }; let d = 0, q = null, i = 0;
    while (i < rest.length) {
      const c = rest[i];
      if (q) { cur.v += c; if (c === q) q = null; i++; continue; }
      if (c === '"' || c === "'") { q = c; cur.v += c; i++; continue; }
      if (c === '[' && !/[\w)\]]\s*$/.test(cur.v)) { q = ']'; cur.v += c; i++; continue; }
      if (c === '(' || c === '{') d++; if (c === ')' || c === '}') d--;
      if (d === 0 && /[A-Za-z]/.test(c) && (i === 0 || /[\s,)]/.test(rest[i - 1]))) {
        const m = /^[A-Za-z]+/.exec(rest.slice(i))[0].toUpperCase();
        if (KW.includes(m) && (i + m.length >= rest.length || /\s|"|'|\[|\(/.test(rest[i + m.length]))) { out.push(cur); cur = { k: m === 'PICT' ? 'PICTURE' : m === 'COLO' ? 'COLOR' : m, v: '' }; i += m.length; continue; }
      }
      cur.v += c; i++;
    }
    out.push(cur); return out.map(x => ({ k: x.k, v: x.v.trim() }));
  }
  function maskOf(pic) {
    if (!pic) return null; const m = /^["'](.*)["']$/.exec(pic.trim()); if (!m) return null; let p = m[1];
    p = p.replace(/^@[A-Z!]+\s*/i, ''); if (!p) return null;
    if (/^[9.,\/\-() ]+$/.test(p) && /[\/\-() ]/.test(p)) return p.replace(/9/g, '#');
    return null;
  }
  function picLen(pic) { const m = /^["'](.*)["']$/.exec((pic || '').trim()); if (!m) return 0; const p = m[1].replace(/^@[A-Z!]+\s*/i, ''); return p.length; }

  // ---------------------------------------------------------------- tradutor de uma rotina
  class Routine {
    constructor(conv, file, name, kind, params, isStatic) { this.conv = conv; this.file = file; this.name = name; this.kind = kind; this.params = params; this.isStatic = isStatic; this.L = []; this.stack = []; this.screen = { items: [] }; this.locals = new Set(); this.labels = 0; this.statics = []; }
  }
  class Converter {
    constructor() {
      this.report = { warns: [], todo: 0, screens: 0, dbf: [], fns: new Map() };
      this.funcs = new Map(); // nome minúsculo -> { name (VB), file, isFunc }
      this.forms = []; // arquivos .frm gerados
      this.publics = new Set();
      this.formNames = new Set();
      this.consoleUsed = false;
      this.fields = new Map(); // campos de todas as tabelas .dbf (minúsculo -> nome)
      this.tables = new Map(); // tabelas .dbf (minúsculo -> nome)
      this.indexKey = new Map(); // arquivo de índice -> campo da chave
      this.fieldRefs = 0; this.dbCount = 0;
    }
    ctxFor(r) {
      const self = this;
      return {
        funcs: new Set([...this.funcs.keys()]), db: false,
        funcName: n => (self.funcs.get(n.toLowerCase()) || { name: safe(n) }).name,
        varName: n => { const k = n.toLowerCase(); if (self.fields.has(k) && !(r && r.isDeclared && r.isDeclared(k)) && !self.publics.has(safe(n))) { self.fieldRefs++; return `NKFld("${self.fields.get(k)}")`; } return safe(n); },
        todo: msg => { self.report.todo++; r && r.todos && r.todos.push(msg); },
        unknownFn: n => { const k = n.toLowerCase(); self.report.fns.set(k, (self.report.fns.get(k) || 0) + 1); },
      };
    }
    // --- coleta das rotinas de um arquivo
    scanFile(path, text) {
      const defines = new Map(); const lines = preprocess(text, defines);
      const base = path.split('/').pop().replace(/\.prg$/i, ''); const fileId = base.replace(/[^A-Za-z0-9_]/g, '_');
      const routines = []; let cur = { name: null, kind: 'proc', params: [], isStatic: false, body: [], line: 1, top: true };
      for (const ln of lines) {
        const m = /^(static\s+|init\s+|exit\s+)?(function|func|procedure|proc)\s+([A-Za-z_]\w*)\s*(\((.*)\))?/i.exec(ln.text);
        if (m && ln.text[0] !== '\u0001') {
          routines.push(cur);
          cur = { name: m[3], kind: /^func/i.test(m[2]) ? 'func' : 'proc', params: (m[5] || '').split(',').map(x => x.trim()).filter(Boolean), isStatic: !!(m[1] && /static/i.test(m[1])), body: [], line: ln.line };
          continue;
        }
        cur.body.push({ line: ln.line, text: ln.text[0] === '\u0001' ? ln.text : applyDefines(ln.text, defines) });
      }
      routines.push(cur);
      const top = routines[0]; const hasTop = top.body.some(b => !/^(memvar|field|external|request|announce|dynamic)\b/i.test(b.text));
      const out = routines.filter(r => r !== top || hasTop);
      if (hasTop) { top.name = routines.some(r => r !== top && r.name && r.name.toLowerCase() === base.toLowerCase()) ? base + '_Main' : base; top.top = true; }
      for (const r of out) { r.vbName = safe(r.name.replace(/[^A-Za-z0-9_]/g, '_')); const k = r.name.toLowerCase(); if (!this.funcs.has(k) || !r.isStatic) this.funcs.set(k, { name: r.vbName, file: fileId, isFunc: r.kind === 'func' }); }
      return { path, base, fileId, routines: out };
    }
    // --- tradução de uma rotina
    translate(fileInfo, r) {
      const R = new Routine(this, fileInfo, r.vbName, r.kind, r.params.slice(), r.isStatic); R.todos = [];
      R.isDeclared = k => R.locals.has(safe(k)) || R.locals.has(k) || R.params.some(p => p.toLowerCase() === k) || R.statics.some(x => x.toLowerCase() === k || x.toLowerCase() === k + '_');
      const ctx = this.ctxFor(R); R.ctx = ctx;
      const E = s => exprOf(s, ctx);
      const ind = () => '    '.repeat(R.stack.length + 1);
      const emit = s => R.L.push(ind() + s);
      const note = (src, why) => { ctx.todo(why || 'not converted'); emit(`' [Clipper] ${src.replace(/\r?\n/g, ' ')}`); };
      const loopTop = () => { for (let i = R.stack.length - 1; i >= 0; i--) if (R.stack[i].k === 'do' || R.stack[i].k === 'for') return R.stack[i]; return null; };
      const isFunc = r.kind === 'func' && !r.top;
      let lastWasReturn = false;
      for (let bi = 0; bi < r.body.length; bi++) {
        const { text } = r.body[bi];
        if (text[0] === '\u0001') { const t = text.slice(1); emit(`NKQOut ${vbStr(t)}`); this.consoleUsed = true; continue; }
        if (/^text$/i.test(text) || /^endtext$/i.test(text)) continue;
        const up = text.toUpperCase(); const w = (/^[A-Za-z_?@!]+/.exec(text) || [''])[0].toUpperCase();
        lastWasReturn = false;
        try {
          // declarações
          let m;
          if ((m = /^(local|private|public|static|memvar|field)\s+(.*)$/i.exec(text))) {
            const kind = m[1].toLowerCase(); if (kind === 'memvar' || kind === 'field') continue;
            for (const part of splitTop(m[2], ',')) {
              const a = /^([A-Za-z_]\w*)\s*(\[(.*)\])?\s*(:=\s*(.*))?(\s+as\s+\w+)?$/i.exec(part); if (!a) { note(text, 'declaration'); break; }
              const vn = safe(a[1]);
              if (kind === 'public') { this.publics.add(vn); } else if (kind === 'static') { R.statics.push(vn); } else if (!R.params.some(p => p.toLowerCase() === a[1].toLowerCase())) R.locals.add(vn);
              if (a[3]) emit(`${vn} = NKArrayN(${splitTop(a[3], ',').map(E).join(', ')})`);
              else if (a[5] !== undefined) { if (kind === 'static') emit(`If IsEmpty(${vn}) Then ${vn} = ${E(a[5])}`); else emit(`${vn} = ${E(a[5])}`); }
            }
            continue;
          }
          if ((m = /^parameters?\s+(.*)$/i.exec(text))) { for (const p of m[1].split(',').map(x => x.trim()).filter(Boolean)) if (!R.params.includes(p)) R.params.push(p); continue; }
          if ((m = /^(declare|dimension)\s+(.*)$/i.exec(text))) { for (const part of splitTop(m[2], ',')) { const a = /^([A-Za-z_]\w*)\s*[\[(](.*)[\])]$/.exec(part); if (a) emit(`${safe(a[1])} = NKArrayN(${splitTop(a[2], ',').map(E).join(', ')})`); } continue; }
          // controle de fluxo
          if (/^if\b/i.test(text) && !(/^if\s*\(/i.test(text) && /\)\s*$/.test(text) && splitTop(text.replace(/^if\s*\(/i, '').replace(/\)\s*$/, ''), ',').length === 3 && !/\)\s*\S/.test(text.replace(/^if\s*\(/i, '').replace(/\)\s*$/, '').replace(/\([^()]*\)/g, '')))) {
            const cond = text.replace(/^if\s*/i, ''); emit(`If ${E(cond)} Then`); R.stack.push({ k: 'if' }); continue;
          }
          if ((m = /^elseif\s+(.*)$/i.exec(text))) { R.stack.pop(); emit(`ElseIf ${E(m[1])} Then`); R.stack.push({ k: 'if' }); continue; }
          if (/^else$/i.test(text)) { const top = R.stack.pop(); emit(top && (top.k === 'case' || top.k === 'casebody') ? 'Case Else' : 'Else'); R.stack.push(top || { k: 'if' }); continue; }
          if (/^(endif|end\s*if)$/i.test(text)) { R.stack.pop(); emit('End If'); continue; }
          if ((m = /^(do\s+while|while)\s+(.*)$/i.exec(text))) { emit(`Do While ${E(m[2])}`); R.stack.push({ k: 'do', label: null }); continue; }
          if (/^(enddo|end\s*do|end\s*while)$/i.test(text) || (/^end$/i.test(text) && R.stack.length && R.stack[R.stack.length - 1].k === 'do')) { const top = R.stack.pop(); if (top && top.label) R.L.push('    '.repeat(R.stack.length + 1) + top.label + ':'); emit('Loop'); continue; }
          if (/^end$/i.test(text) && R.stack.length) { if (R.stack[R.stack.length - 1].k === 'casebody') R.stack.pop(); const top = R.stack.pop(); emit(top.k === 'if' ? 'End If' : top.k === 'case' || top.k === 'casebody' ? 'End Select' : top.k === 'for' ? 'Next' : top.k === 'seq' ? `' [Clipper] END SEQUENCE` : 'End If'); continue; }
          if ((m = /^for\s+each\s+(\w+)\s+in\s+(.*)$/i.exec(text))) { emit(`For Each ${safe(m[1])} In ${E(m[2])}`); R.stack.push({ k: 'for' }); continue; }
          if ((m = /^for\s+(\w+)\s*(:=|=)\s*(.*?)\s+to\s+(.*?)(\s+step\s+(.*))?$/i.exec(text))) { emit(`For ${safe(m[1])} = ${E(m[3])} To ${E(m[4])}${m[6] ? ' Step ' + E(m[6]) : ''}`); R.stack.push({ k: 'for', label: null }); continue; }
          if (/^next(\s+\w+)?$/i.test(text)) { const top = R.stack.pop(); if (top && top.label) R.L.push('    '.repeat(R.stack.length + 1) + top.label + ':'); emit('Next'); continue; }
          if (/^do\s+case$/i.test(text)) { emit('Select Case True'); R.stack.push({ k: 'case' }); continue; }
          if ((m = /^case\s+(.*)$/i.exec(text)) || /^otherwise$/i.test(text)) { if (R.stack.length && R.stack[R.stack.length - 1].k === 'casebody') R.stack.pop(); emit(m ? `Case ${E(m[1])}` : 'Case Else'); R.stack.push({ k: 'casebody' }); continue; }
          if (/^(endcase|end\s*case)$/i.test(text)) { if (R.stack.length && R.stack[R.stack.length - 1].k === 'casebody') R.stack.pop(); R.stack.pop(); emit('End Select'); continue; }
          if (/^exit$/i.test(text)) { const lp = loopTop(); emit(lp ? (lp.k === 'for' ? 'Exit For' : 'Exit Do') : (isFunc ? 'Exit Function' : 'Exit Sub')); continue; }
          if (/^loop$/i.test(text)) { const lp = loopTop(); if (!lp) { note(text); continue; } if (!lp.label) lp.label = 'NKLoop' + (++R.labels); emit('GoTo ' + lp.label); continue; }
          if (/^begin\s+sequence$/i.test(text)) { emit(`' [Clipper] BEGIN SEQUENCE`); R.stack.push({ k: 'seq' }); continue; }
          if ((m = /^recover(\s+using\s+(\w+))?$/i.exec(text))) { emit(`If False Then ' [Clipper] RECOVER${m[2] ? ' USING ' + m[2] : ''}`); R.stack[R.stack.length - 1] = { k: 'if' }; continue; }
          if (/^end\s*sequence$/i.test(text)) { const top = R.stack.pop(); emit(top && top.k === 'if' ? 'End If' : `' [Clipper] END SEQUENCE`); continue; }
          if (/^break(\s|$)/i.test(text)) { note(text, 'BREAK'); continue; }
          if ((m = /^return\s*(.*)$/i.exec(text)) || /^return$/i.test(text)) {
            const v = m ? m[1].trim() : ''; const last = !r.body.slice(bi + 1).some(b => b.text.trim());
            if (isFunc) { if (v) emit(`${r.vbName} = ${E(v)}`); if (!last || R.stack.length) emit('Exit Function'); }
            else if (!last || R.stack.length) emit('Exit Sub');
            lastWasReturn = true; continue;
          }
          if (/^(quit|cancel)$/i.test(text)) { emit('NKQuit'); continue; }
          // tela
          if (/^(clear(\s+screen)?|cls|clear\s+all)$/i.test(text) && !/^clear\s+(gets|memory|typeahead)/i.test(text)) { R.screen = { items: [] }; emit('NKCls'); continue; }
          if (/^clear\s+gets$/i.test(text)) { R.screen.items = R.screen.items.filter(it => it.k !== 'get'); continue; }
          if (/^@/.test(text)) { this.screenCmd(R, text, emit, E, note); continue; }
          if (/^read(\s+save)?$/i.test(text)) { this.flushRead(R, emit, E); continue; }
          if ((m = /^menu\s+to\s+(\w+)$/i.exec(text))) { this.flushMenu(R, emit, E, safe(m[1])); continue; }
          if ((m = /^\?\?\s*(.*)$/.exec(text))) { emit(`NKQQOut ${splitTop(m[1], ',').filter(Boolean).map(E).join(', ') || '""'}`); this.consoleUsed = true; continue; }
          if ((m = /^\?\s*(.*)$/.exec(text))) { emit(`NKQOut ${splitTop(m[1], ',').filter(Boolean).map(E).join(', ') || '""'}`); this.consoleUsed = true; continue; }
          if ((m = /^wait\s*(.*?)(\s+to\s+(\w+))?$/i.exec(text))) { const msg = m[1] ? E(m[1]) : '""'; emit(m[3] ? `${safe(m[3])} = NKWait(${msg})` : `NKWait ${msg}`); continue; }
          if ((m = /^(accept|input)\s+(.*?)\s+to\s+(\w+)$/i.exec(text))) { emit(`${safe(m[3])} = NK${m[1].toLowerCase() === 'accept' ? 'Accept' : 'Input'}(${E(m[2])})`); continue; }
          if ((m = /^do\s+([A-Za-z_]\w*)(\s+with\s+(.*))?$/i.exec(text)) && !/^do\s+(while|case)\b/i.test(text)) {
            const f = this.funcs.get(m[1].toLowerCase()); const args = m[3] ? splitTop(m[3], ',').map(E) : [];
            if (!f) { ctx.unknownFn(m[1]); }
            emit(`${f ? f.name : safe(m[1])}${args.length ? ' ' + args.join(', ') : ''}`); continue;
          }
          if ((m = /^store\s+(.*)\s+to\s+(.*)$/i.exec(text))) { const v = E(m[1]); for (const x of m[2].split(',')) emit(`${safe(x.trim())} = ${v}`); continue; }
          // banco de dados (tabelas .dbf importadas para o banco do projeto)
          if (this.dbCmd(R, text, emit, E, note)) { this.dbCount++; ctx.db = true; continue; }
          if (/^(set|run|!|keyboard|restore|save|release|external|request|announce|dynamic|setkey|set\s+key|setcancel|altd|__setcentury|tone|printer|eject|notes?)\b/i.test(text) || /^(set)\s/i.test(text)) { emit(`' [Clipper] ${text}`); continue; }
          // atribuições
          if ((m = /^([A-Za-z_]\w*(?:->\w+)?(?:\s*\[[^\]]*\])*)\s*(:=|\+=|-=|\*=|\/=|=)\s*(.*)$/.exec(text))) {
            const target = exprOf(m[1], ctx); const v = E(m[3]);
            const fm = /^NK(?:Field\("[^"]*", |Fld\()("[^"]+")\)$/.exec(target);
            if (fm) { emit(`NKReplace ${fm[1]}, ${v}`); continue; }
            const op = m[2]; emit(op === ':=' || op === '=' ? `${target} = ${v}` : `${target} = ${target} ${op[0]} (${v})`); continue;
          }
          if ((m = /^([A-Za-z_]\w*)\s*(\+\+|--)$/.exec(text)) || (m = /^(\+\+|--)\s*([A-Za-z_]\w*)$/.exec(text))) { const v = safe(/\w/.test(m[1][0]) ? m[1] : m[2]); const plus = (m[2] === '++' || m[1] === '++'); emit(`${v} = ${v} ${plus ? '+' : '-'} 1`); continue; }
          // chamada de função como comando
          if (/^[A-Za-z_]\w*\s*\(/.test(text)) { const x = E(text); emit(/\)$/.test(x) ? 'Call ' + x : x); continue; }
          if (/^[A-Za-z_]\w*$/.test(text)) { const f = this.funcs.get(text.toLowerCase()); if (f) { emit(f.name); continue; } }
          note(text);
        } catch (e) { note(text, 'error: ' + e.message); }
      }
      while (R.stack.length) { const top = R.stack.pop(); if (top.k === 'casebody') continue; emit(top.k === 'do' ? 'Loop' : top.k === 'for' ? 'Next' : top.k === 'case' ? 'End Select' : 'End If'); ctx.todo('block not closed'); }
      // cabeçalho
      const params = R.params.map(p => 'Optional ' + safe(p.replace(/^@/, '')));
      const vis = r.isStatic ? 'Private' : 'Public';
      const head = [`${vis} ${isFunc ? 'Function' : 'Sub'} ${r.vbName}(${params.join(', ')})`];
      if (R.locals.size) head.push(`    Dim ${[...R.locals].join(', ')}`);
      if (R.statics.length) head.push(`    Static ${R.statics.join(', ')}`);
      const lines = [...head, ...R.L, isFunc ? 'End Function' : 'End Sub'];
      return { lines, db: ctx.db, todos: R.todos.length };
    }
    // ----- comandos de banco de dados
    keyField(expr) { const m = /([A-Za-z_]\w*)/.exec(String(expr || '').replace(/^\s*(upper|lower|alltrim|trim|rtrim|ltrim|str|dtos|descend)\s*\(/i, '')); if (!m) return ''; const k = m[1].toLowerCase(); return this.fields.get(k) || ''; }
    dbCmd(R, text, emit, E, note) {
      let m; const t = text.trim(); const S = vbStr;
      const clause = (src, kw) => { const re = new RegExp('\\b' + kw + '\\b\\s+(.*?)(?=\\s+\\b(?:ALIAS|INDEX|NEW|EXCLUSIVE|SHARED|READONLY|VIA|FOR|WHILE|NEXT|ALL|REST|RECORD|TO|WITH)\\b|$)', 'i'); const x = re.exec(src); return x ? x[1].trim() : null; };
      const scopeNote = src => { if (/\b(for|while|all|next|rest)\b/i.test(src)) { const f = /\bfor\s+(.*?)(?=\s+\b(?:while|next|rest|all)\b|$)/i.exec(src); return f ? f[1] : (/\ball\b/i.test(src) ? '.T.' : null); } return null; };
      if ((m = /^use(\s+(.*))?$/i.exec(t))) {
        if (!m[2]) { emit('NKClose'); return true; }
        const rest = m[2]; const tbl = (/^\(?\s*([A-Za-z_][\w.\\/:]*)/.exec(rest) || [])[1] || ''; const name = tbl.replace(/^.*[\\/]/, '').replace(/\.dbf$/i, '');
        const als = clause(rest, 'ALIAS'); const idx = clause(rest, 'INDEX');
        emit(`NKUse ${S(this.tables.get(name.toLowerCase()) || name)}, ${S(als || name)}, ${/\bnew\b/i.test(rest) ? 'True' : 'False'}`);
        if (idx) { const f = idx.split(/\s*,\s*/)[0].replace(/^.*[\\/]/, '').replace(/\.(ntx|cdx|ndx|idx|mdx)$/i, '').toLowerCase(); const key = this.indexKey.get(f); if (key) emit(`NKSetIndexField ${S(key)}`); }
        return true;
      }
      if ((m = /^select\s+(.+)$/i.exec(t)) && !/\bfrom\b/i.test(t)) { const a = m[1].trim(); emit(`NKSelectArea ${/^\d+$/.test(a) ? a : /^\(/.test(a) ? E(a) : S(a)}`); return true; }
      if ((m = /^go(?:to)?\s+(top|bottom|.+)$/i.exec(t))) { const w = m[1].trim(); emit(/^top$/i.test(w) ? 'NKGoTop' : /^bottom$/i.test(w) ? 'NKGoBottom' : `NKGoTo ${E(w)}`); return true; }
      if ((m = /^skip(\s+(.*))?$/i.exec(t))) { emit(m[2] ? `NKSkip ${E(m[2])}` : 'NKSkip'); return true; }
      if (/^append\s+blank$/i.test(t)) { emit('NKAppend'); return true; }
      if ((m = /^replace\s+(.*)$/i.exec(t))) {
        const body = m[1].replace(/\s+\b(all|rest|next\s+\d+|for\s+.*|while\s+.*)$/i, ''); const cond = scopeNote(m[1].slice(body.length));
        const pairs = splitTop(body, ',').map(x => /^([A-Za-z_]\w*(?:->\w+)?)\s+with\s+(.*)$/i.exec(x)).filter(Boolean);
        if (!pairs.length) return false;
        const lines = pairs.map(p => { const f = p[1].replace(/^.*->/, ''); return `NKReplace ${S(this.fields.get(f.toLowerCase()) || f)}, ${E(p[2])}`; });
        if (cond) { emit('NKGoTop'); emit('Do While Not NKEof()'); emit(`    If ${E(cond)} Then`); for (const l of lines) emit('        ' + l); emit('    End If'); emit('    NKSkip'); emit('Loop'); }
        else for (const l of lines) emit(l);
        return true;
      }
      if ((m = /^delete(\s+(.*))?$/i.exec(t)) && !/^delete\s+file\b/i.test(t)) {
        const cond = m[2] ? scopeNote(m[2]) : null;
        if (cond) { emit('NKGoTop'); emit('Do While Not NKEof()'); emit(`    If ${E(cond)} Then NKDelete`); emit('    NKSkip'); emit('Loop'); } else emit('NKDelete');
        return true;
      }
      if (/^recall\b/i.test(t) || /^pack$/i.test(t) || /^(commit|unlock(\s+all)?)$/i.test(t) || /^reindex\b/i.test(t)) { emit(`' [Clipper] ${t} (not needed: the table is in the project database)`); return true; }
      if (/^zap$/i.test(t)) { emit('NKZap'); return true; }
      if ((m = /^index\s+on\s+(.+?)\s+to\s+(\S+)/i.exec(t))) { const key = this.keyField(m[1]); const f = m[2].replace(/^.*[\\/]/, '').replace(/\.\w+$/, '').toLowerCase(); if (key) { this.indexKey.set(f, key); emit(`NKSetIndexField ${S(key)}`); } else emit(`' [Clipper] ${t}`); return true; }
      if ((m = /^set\s+index\s+to\s*(.*)$/i.exec(t))) { const f = (m[1] || '').split(/\s*,\s*/)[0].replace(/^.*[\\/]/, '').replace(/\.\w+$/, '').toLowerCase(); const key = this.indexKey.get(f); emit(key ? `NKSetIndexField ${S(key)}` : `' [Clipper] ${t}`); return true; }
      if (/^set\s+(order|filter|relation|deleted|exclusive|softseek|unique)\b/i.test(t)) { emit(`' [Clipper] ${t}`); return true; }
      if ((m = /^seek\s+(.+)$/i.exec(t))) { emit(`NKSeek ${E(m[1])}`); return true; }
      if ((m = /^locate\s+for\s+(.+?)(\s+while\s+.*)?$/i.exec(t))) { R.locate = m[1]; emit('NKGoTop'); emit('Do While Not NKEof()'); emit(`    If ${E(m[1])} Then Exit Do`); emit('    NKSkip'); emit('Loop'); emit('NKSetFound Not NKEof()'); return true; }
      if (/^continue$/i.test(t)) { if (!R.locate) return false; emit('NKSkip'); emit('Do While Not NKEof()'); emit(`    If ${E(R.locate)} Then Exit Do`); emit('    NKSkip'); emit('Loop'); emit('NKSetFound Not NKEof()'); return true; }
      if ((m = /^close(\s+(.*))?$/i.exec(t))) { const w = (m[2] || '').trim(); emit(!w ? 'NKClose' : /^(all|databases|data)$/i.test(w) ? 'NKCloseAll' : /^(index|indexes|format|alternate|procedure)$/i.test(w) ? `' [Clipper] ${t}` : `NKCloseArea ${S(w)}`); return true; }
      if ((m = /^count\s+to\s+(\w+)(.*)$/i.exec(t))) { const v = safe(m[1]); const cond = scopeNote(m[2]) || '.T.'; emit(`${v} = 0`); emit('NKGoTop'); emit('Do While Not NKEof()'); emit(`    If ${E(cond)} Then ${v} = ${v} + 1`); emit('    NKSkip'); emit('Loop'); return true; }
      if ((m = /^sum\s+(.+?)\s+to\s+(.+?)(\s+(for|while|all)\b.*)?$/i.exec(t))) { const ex = splitTop(m[1], ','), vs = m[2].split(',').map(x => safe(x.trim())); const cond = m[3] ? scopeNote(m[3]) || '.T.' : '.T.'; vs.forEach(v => emit(`${v} = 0`)); emit('NKGoTop'); emit('Do While Not NKEof()'); emit(`    If ${E(cond)} Then`); vs.forEach((v, i) => emit(`        ${v} = ${v} + ${E(ex[i] || '0')}`)); emit('    End If'); emit('    NKSkip'); emit('Loop'); return true; }
      if (/^(average|total|sort|copy|update|join|create|modify|browse|list|display|edit|change|dbedit)\b/i.test(t)) { note(t, 'database command not converted yet'); return true; }
      return false;
    }
    // ----- comandos @
    screenCmd(R, text, emit, E, note) {
      const body = text.replace(/^@\s*/, '');
      // @ r1, c1, r2, c2 BOX "..."   |  @ r1, c1 TO r2, c2 [DOUBLE]
      const cl = atClauses(body);
      const pos = splitTop(cl[0].v, ',');
      const rowE = pos[0], colE = pos[1];
      const r0 = numOrNull(rowE), c0 = numOrNull(colE);
      const item = (o) => { o.row = r0 != null ? r0 : (R.screen.lastRow != null ? R.screen.lastRow + 1 : 1); o.col = c0 != null ? c0 : (R.screen.lastCol || 2); if (r0 == null || c0 == null) o.dynPos = true; R.screen.lastRow = o.row; R.screen.lastCol = o.col; R.screen.items.push(o); return o; };
      if (pos.length >= 4 && cl.some(x => x.k === 'BOX')) { const r2 = numOrNull(pos[2]), c2 = numOrNull(pos[3]); item({ k: 'box', r2: r2 ?? r0, c2: c2 ?? c0 }); return; }
      const to = cl.find(x => x.k === 'TO');
      if (to) { const p2 = splitTop(to.v, ','); item({ k: 'box', r2: numOrNull(p2[0]) ?? r0, c2: numOrNull(p2[1]) ?? c0, double: cl.some(x => x.k === 'DOUBLE') }); return; }
      if (cl.some(x => x.k === 'CLEAR') || cl.length === 1) { // limpar região: remove itens dessa linha
        if (r0 != null) R.screen.items = R.screen.items.filter(it => it.k === 'box' || it.row !== r0 || (c0 != null && it.col < c0));
        return;
      }
      const say = cl.find(x => x.k === 'SAY'), get = cl.find(x => x.k === 'GET'), prompt = cl.find(x => x.k === 'PROMPT');
      const pics = cl.filter(x => x.k === 'PICTURE'); const sayPic = say && pics.length && cl.indexOf(pics[0]) < (get ? cl.indexOf(get) : 999) ? pics[0].v : null; const getPic = get ? (cl.slice(cl.indexOf(get)).find(x => x.k === 'PICTURE') || {}).v : null;
      if (prompt) { const it = item({ k: 'prompt', text: prompt.v, msg: (cl.find(x => x.k === 'MESSAGE') || {}).v }); return; }
      let sayItem = null;
      if (say) {
        const lit = /^("[^"]*"|'[^']*'|\[[^\]]*\])$/.test(say.v.trim()) ? say.v.trim().slice(1, -1) : null;
        sayItem = item({ k: 'say', text: lit, expr: lit == null ? E(sayPic ? `Transform(${say.v}, ${sayPic})` : say.v) : null, len: lit != null ? lit.length : Math.max(10, picLen(sayPic)) });
      }
      if (get) {
        const v = get.v.trim(); const vn = /^[A-Za-z_]\w*(->\w+)?$/.test(v) ? v : null;
        const isFld = vn && !/->/.test(vn) && this.fields.has(vn.toLowerCase()) && !(R.isDeclared && R.isDeclared(vn.toLowerCase()));
        const fld = vn && /->/.test(vn) ? vn.replace(/^.*->/, '') : isFld ? vn : null;
        const it = { k: 'get', var: vn && !fld ? safe(vn) : null, field: fld ? (this.fields.get(fld.toLowerCase()) || fld) : null, src: v, pic: getPic, mask: maskOf(getPic), upper: /^["']@[A-Z]*!/i.test(getPic || '') || /^["']!+["']$/.test(getPic || ''), len: picLen(getPic) || 12,
          valid: (cl.find(x => x.k === 'VALID') || {}).v, when: (cl.find(x => x.k === 'WHEN') || {}).v, range: (cl.find(x => x.k === 'RANGE') || {}).v };
        if (sayItem) { it.row = sayItem.row; it.col = sayItem.col + (sayItem.len || 10) + 1; R.screen.items.push(it); }
        else item(it);
        if (!it.var && !it.field) { R.ctx.todo('GET of an expression'); }
      }
      if (!say && !get && !prompt) note(text, '@ command');
    }
    newFormName(R, kind) {
      let base = 'frm' + R.name.replace(/_/g, '').slice(0, 24) + (kind === 'menu' ? 'Menu' : ''); let i = 1; while (this.formNames.has((base + i).toLowerCase())) i++; this.formNames.add((base + i).toLowerCase()); return base + i;
    }
    flushRead(R, emit, E) {
      const items = R.screen.items; const gets = items.filter(x => x.k === 'get');
      if (!gets.length) { emit(`' [Clipper] READ (no GET on the screen)`); return; }
      const fname = this.newFormName(R, 'read');
      const f = this.buildForm(fname, items, 'read', R);
      this.forms.push(f); this.report.screens++;
      emit(`' [Clipper] READ — screen shown by the form ${fname}`);
      for (const d of f.dyn) emit(`${fname}.${d.ctl}.Caption = NKToText(${d.expr})`);
      if (f.dynTitle) emit(`${fname}.Caption = NKToText(${f.dynTitle})`);
      for (const g of f.gets) emit(`${fname}.${g.ctl}.Text = ${g.var ? `NKGetText(${g.var})` : g.field ? `NKGetText(NKFld("${g.field}"))` : '""'}`);
      emit(`${fname}.Show vbModal`);
      emit(`NKSetLastKey ${fname}.Result`);
      emit(`If ${fname}.Result <> 27 Then`);
      for (const g of f.gets) if (g.var) emit(`    ${g.var} = NKFromText(${fname}.${g.ctl}.Text, ${g.var})`); else if (g.field) emit(`    NKReplace "${g.field}", NKFromText(${fname}.${g.ctl}.Text, NKFld("${g.field}"))`); else emit(`    ' [Clipper] GET ${g.src} = ${fname}.${g.ctl}.Text`);
      emit('End If');
      emit(`Unload ${fname}`);
      for (const g of f.gets) { if (g.valid) emit(`' [Clipper] VALID ${g.valid} (${g.src}) is not checked yet`); }
      R.screen.items = items.filter(x => x.k !== 'get');
    }
    flushMenu(R, emit, E, target) {
      const items = R.screen.items; const prompts = items.filter(x => x.k === 'prompt');
      if (!prompts.length) { emit(`${target} = 0 ' [Clipper] MENU TO without PROMPT`); return; }
      const fname = this.newFormName(R, 'menu');
      const f = this.buildForm(fname, items, 'menu', R);
      this.forms.push(f); this.report.screens++;
      emit(`' [Clipper] MENU TO ${target} — menu shown by the form ${fname}`);
      for (const d of f.dyn) emit(`${fname}.${d.ctl}.Caption = NKToText(${d.expr})`);
      if (f.dynTitle) emit(`${fname}.Caption = NKToText(${f.dynTitle})`);
      emit(`${fname}.Result = 0`);
      emit(`${fname}.Show vbModal`);
      emit(`${target} = ${fname}.Result`);
      emit(`NKSetLastKey IIf(${target} = 0, 27, 13)`);
      emit(`Unload ${fname}`);
      R.screen.items = items.filter(x => x.k !== 'prompt');
    }
    // ----- gera o .frm de uma tela
    buildForm(fname, items, mode, R) {
      const rows = items.flatMap(it => it.k === 'box' ? [it.row, it.r2] : [it.row]); const cols = items.flatMap(it => it.k === 'box' ? [it.col, it.c2] : [it.col, it.col + (it.k === 'get' ? it.len : it.k === 'prompt' ? stripQ(it.text).length + 2 : (it.len || 10))]);
      const minR = Math.max(0, Math.min(...rows)), maxR = Math.max(...rows), minC = Math.max(0, Math.min(...cols)), maxC = Math.max(...cols);
      const X = c => (c - minC) * CW + 12, Y = r => (r - minR) * RH + 12;
      const tw = v => Math.round(v * 15);
      const L = ['VERSION 5.00', `Begin VB.Form ${fname} `];
      const P = (ind, k, v) => L.push(' '.repeat(ind) + k.padEnd(16) + '=   ' + v);
      const titleSay = items.find(it => it.k === 'say' && it.text && it.row === minR);
      const caption = (titleSay && titleSay.text.trim()) || (mode === 'menu' ? 'Menu' : 'Screen') + ' — ' + R.name;
      const W = (maxC - minC + 1) * CW + 24, Hh = (maxR - minR + 1) * RH + 24 + (mode === 'read' ? 44 : 8);
      const CWd = Math.max(W, mode === 'read' ? 260 : 160);
      P(3, 'BorderStyle', '3  \'Fixed Dialog'); P(3, 'Caption', vbStr(caption)); P(3, 'ClientHeight', String(tw(Hh))); P(3, 'ClientLeft', '45'); P(3, 'ClientTop', '435'); P(3, 'ClientWidth', String(tw(CWd)));
      P(3, 'KeyPreview', '-1  \'True'); P(3, 'LinkTopic', vbStr(fname)); P(3, 'MaxButton', '0   \'False'); P(3, 'MinButton', '0   \'False'); P(3, 'ScaleHeight', String(tw(Hh))); P(3, 'ScaleWidth', String(tw(CWd))); P(3, 'StartUpPosition', '1  \'CenterOwner');
      const dyn = [], gets = []; let tab = 0; let nL = 0, nT = 0, nB = 0, nC = 0;
      // caixas primeiro (ficam atrás)
      for (const it of items.filter(x => x.k === 'box')) { nB++; L.push(`   Begin NK.Bevel Bevel${nB} `); P(6, 'Height', String(tw((it.r2 - it.row) * RH + RH - 4))); P(6, 'Left', String(tw(X(it.col) - 4))); P(6, 'Shape', it.double ? '1' : '0'); P(6, 'Top', String(tw(Y(it.row) - 2))); P(6, 'Width', String(tw((it.c2 - it.col + 1) * CW + 4))); L.push('   End'); }
      for (const it of items) {
        if (it.k === 'say') {
          if (it === titleSay && mode !== 'menu' && items.filter(x => x.k === 'say').length > 1) { /* também vai no título; mantém como rótulo */ }
          nL++; const nm = 'Label' + nL; L.push(`   Begin VB.Label ${nm} `); P(6, 'AutoSize', '-1  \'True'); P(6, 'BackStyle', '0  \'Transparent'); P(6, 'Caption', vbStr(it.text != null ? it.text.replace(/\s+$/, '') : '')); P(6, 'Height', String(tw(17))); P(6, 'Left', String(tw(X(it.col)))); P(6, 'Top', String(tw(Y(it.row) + 3))); P(6, 'Width', String(tw(Math.max(8, (it.len || 10) * CW)))); L.push('   End');
          if (it.expr) dyn.push({ ctl: nm, expr: it.expr });
        } else if (it.k === 'get') {
          nT++; const nm = 'Text' + nT; L.push(`   Begin VB.TextBox ${nm} `); P(6, 'Height', String(tw(RH - 2))); P(6, 'Left', String(tw(X(it.col)))); if (it.len) P(6, 'MaxLength', String(it.len)); if (it.mask) P(6, 'Mask', vbStr(it.mask)); P(6, 'TabIndex', String(tab++)); P(6, 'Tag', vbStr(it.src + (it.upper ? ' (upper)' : ''))); P(6, 'Text', '""'); P(6, 'Top', String(tw(Y(it.row)))); P(6, 'Width', String(tw(Math.max(40, it.len * CW + 10)))); L.push('   End');
          gets.push({ ctl: nm, var: it.var, field: it.field, src: it.src, valid: it.valid, upper: it.upper });
        } else if (it.k === 'prompt') {
          nC++; const t = stripQ(it.text); L.push(`   Begin VB.CommandButton Command${nC} `); P(6, 'Caption', vbStr(t.trim())); P(6, 'Height', String(tw(RH))); P(6, 'Left', String(tw(X(it.col) - 4))); P(6, 'TabIndex', String(tab++)); if (it.msg) P(6, 'ToolTipText', it.msg); P(6, 'Top', String(tw(Y(it.row) - 1))); P(6, 'Width', String(tw(Math.max(60, t.trim().length * CW + 24)))); L.push('   End');
        }
      }
      if (mode === 'read') {
        const bw = 75, bh = 25, by = Hh - bh - 10;
        L.push('   Begin VB.CommandButton cmdOK '); P(6, 'Caption', '"OK"'); P(6, 'Default', '-1  \'True'); P(6, 'Height', String(tw(bh))); P(6, 'Left', String(tw(CWd - 2 * bw - 18))); P(6, 'TabIndex', String(tab++)); P(6, 'Top', String(tw(by))); P(6, 'Width', String(tw(bw))); L.push('   End');
        L.push('   Begin VB.CommandButton cmdCancel '); P(6, 'Cancel', '-1  \'True'); P(6, 'Caption', '"Cancel"'); P(6, 'Height', String(tw(bh))); P(6, 'Left', String(tw(CWd - bw - 10))); P(6, 'TabIndex', String(tab++)); P(6, 'Top', String(tw(by))); P(6, 'Width', String(tw(bw))); L.push('   End');
      }
      L.push('End', `Attribute VB_Name = ${vbStr(fname)}`, 'Attribute VB_GlobalNameSpace = False', 'Attribute VB_Creatable = False', 'Attribute VB_PredeclaredId = True', 'Attribute VB_Exposed = False',
        `' Screen converted by Neo Kiva from the Clipper routine ${R.name} (${R.file.base}.prg)`, 'Public Result As Integer', '');
      if (mode === 'read') {
        L.push('Private Sub cmdOK_Click()', '    Result = 13', '    Me.Hide', 'End Sub', '', 'Private Sub cmdCancel_Click()', '    Result = 27', '    Me.Hide', 'End Sub', '');
        const up = gets.filter(g => g.upper);
        for (const g of up) L.push(`Private Sub ${g.ctl}_Change()`, `    Dim p As Long: p = ${g.ctl}.SelStart`, `    If ${g.ctl}.Text <> UCase(${g.ctl}.Text) Then ${g.ctl}.Text = UCase(${g.ctl}.Text): ${g.ctl}.SelStart = p`, 'End Sub', '');
      } else {
        for (let i = 1; i <= nC; i++) L.push(`Private Sub Command${i}_Click()`, `    Result = ${i}`, '    Me.Hide', 'End Sub', '');
        L.push('Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)', '    If KeyCode = 27 Then Result = 0: Me.Hide', 'End Sub', '');
      }
      L.push('Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)', '    If UnloadMode = 0 Then', mode === 'read' ? '        Result = 27' : '        Result = 0', '        Cancel = True', '        Me.Hide', '    End If', 'End Sub', '');
      return { name: fname, path: fname + '.frm', text: L.join('\r\n'), dyn, gets, dynTitle: titleSay ? null : ((items.find(it => it.k === 'say' && it.row === minR && it.expr) || {}).expr || null) };
    }
  }
  const stripQ = s => { const t = String(s || '').trim(); return /^(".*"|'.*'|\[.*\])$/.test(t) ? t.slice(1, -1) : t; };

  // ---------------------------------------------------------------- DBF -> tabela do banco do projeto
  function readDbf(bytes, memoBytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const n = dv.getUint32(4, true), hlen = dv.getUint16(8, true), rlen = dv.getUint16(10, true);
    const fields = []; const seen = new Set();
    for (let p = 32; p + 32 <= hlen && bytes[p] !== 0x0D; p += 32) {
      let name = ''; for (let i = 0; i < 11 && bytes[p + i]; i++) name += String.fromCharCode(bytes[p + i]);
      name = name.trim().replace(/[^A-Za-z0-9_]/g, '_') || 'FIELD' + (fields.length + 1); if (/^\d/.test(name)) name = 'F' + name;
      let k = name, j = 2; while (seen.has(k.toLowerCase())) k = name + (j++); seen.add(k.toLowerCase());
      const type = String.fromCharCode(bytes[p + 11]).toUpperCase(), len = bytes[p + 16], dec = bytes[p + 17];
      let kind = 'text';
      if (type === 'N' || type === 'F') kind = dec > 0 || len > 9 ? 'double' : 'long';
      else if (type === 'D') kind = 'date'; else if (type === 'L') kind = 'bool'; else if (type === 'M') kind = 'memo'; else if (type === 'C' && len > 255) kind = 'memo';
      fields.push({ name: k, type, len, dec, kind });
    }
    const memo = blk => { if (!memoBytes || !blk) return ''; const off = blk * 512; if (off >= memoBytes.length) return ''; let e = off; while (e < memoBytes.length && !(memoBytes[e] === 0x1A && memoBytes[e + 1] === 0x1A) && e - off < 65536) e++; return decode(memoBytes.subarray(off, e)).replace(/\x8D\n/g, '\n').replace(/\r?\n$/, ''); };
    const rows = []; let deleted = 0;
    for (let i = 0; i < n && hlen + (i + 1) * rlen <= bytes.length; i++) {
      const base = hlen + i * rlen; if (bytes[base] === 0x2A) { deleted++; continue; } let off = base + 1; const row = [];
      for (const f of fields) {
        const raw = bytes.subarray(off, off + f.len); off += f.len; const s = decode(raw);
        let v = null;
        switch (f.kind) {
          case 'long': { const t = s.trim(); v = t === '' || isNaN(+t) ? null : Math.round(+t); break; }
          case 'double': { const t = s.trim(); v = t === '' || isNaN(+t) ? null : +t; break; }
          case 'date': { const t = s.trim(); v = /^\d{8}$/.test(t) && t !== '00000000' ? `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6)} 00:00:00` : null; break; }
          case 'bool': { const t = s.trim(); v = /^[TtYySs]/.test(t) ? -1 : /^[FfNn]/.test(t) ? 0 : null; break; }
          case 'memo': v = f.type === 'M' ? memo(parseInt(s.trim(), 10) || 0) : s.replace(/\s+$/, ''); break;
          default: v = s.replace(/\s+$/, '');
        }
        row.push(v);
      }
      rows.push(row);
    }
    return { fields, rows, deleted };
  }

  // ---------------------------------------------------------------- DBF -> CSV
  function dbfToCsv(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const n = dv.getUint32(4, true), hlen = dv.getUint16(8, true), rlen = dv.getUint16(10, true);
    const fields = []; for (let p = 32; p + 32 <= hlen && bytes[p] !== 0x0D; p += 32) { let name = ''; for (let i = 0; i < 11 && bytes[p + i]; i++) name += String.fromCharCode(bytes[p + i]); fields.push({ name, type: String.fromCharCode(bytes[p + 11]), len: bytes[p + 16], dec: bytes[p + 17] }); }
    const q = s => /[",\r\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    const rows = [fields.map(f => q(f.name)).join(',')];
    let count = 0;
    for (let i = 0; i < n && hlen + (i + 1) * rlen <= bytes.length; i++) {
      const base = hlen + i * rlen; if (bytes[base] === 0x2A) continue; let off = base + 1; const vals = [];
      for (const f of fields) { let s = decode(bytes.subarray(off, off + f.len)).trim(); off += f.len; if (f.type === 'D' && /^\d{8}$/.test(s)) s = `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6)}`; if (f.type === 'L') s = /^[TtYy]/.test(s) ? 'True' : /^[FfNn]/.test(s) ? 'False' : ''; vals.push(q(s)); }
      rows.push(vals.join(',')); count++;
    }
    return { csv: rows.join('\r\n') + '\r\n', fields, count };
  }

  // ---------------------------------------------------------------- módulo de compatibilidade (VB)
  const COMPAT = `Attribute VB_Name = "ClipperCompat"
' Clipper compatibility functions created by Neo Kiva.
' Screens become forms; ? and ?? write to the console window (frmNKConsole).
' Database functions (DBF) are placeholders in this version: EOF() is always True.
Public NKLastKeyValue As Long
Public NKConsoleText As String

Public Function NKArray(ParamArray items() As Variant) As Variant
    Dim n As Long, i As Long, r() As Variant
    n = UBound(items) - LBound(items) + 1
    If n <= 0 Then
        ReDim r(1 To 1)
        NKArray = r
        Exit Function
    End If
    ReDim r(1 To n)
    For i = 1 To n
        r(i) = items(LBound(items) + i - 1)
    Next
    NKArray = r
End Function
Public Function NKArrayN(Optional n1 As Variant, Optional n2 As Variant) As Variant
    Dim r() As Variant, i As Long
    If IsMissing(n1) Then n1 = 0
    If n1 < 1 Then ReDim r(1 To 1) Else ReDim r(1 To n1)
    If Not IsMissing(n2) Then
        For i = 1 To n1
            r(i) = NKArrayN(n2)
        Next
    End If
    NKArrayN = r
End Function
Public Function NKAt(a As Variant, i As Variant, Optional j As Variant) As Variant
    If IsMissing(j) Then NKAt = a(i) Else NKAt = a(i)(j)
End Function
Public Function NKLen(x As Variant) As Long
    If IsArray(x) Then
        NKLen = UBound(x) - LBound(x) + 1
        If NKLen = 1 Then
            If IsEmpty(x(LBound(x))) Then NKLen = 0
        End If
    ElseIf IsNull(x) Or IsEmpty(x) Then
        NKLen = 0
    Else
        NKLen = Len(CStr(x))
    End If
End Function
Public Sub NKAAdd(a As Variant, v As Variant)
    Dim n As Long
    n = NKLen(a)
    If n = 0 Then
        ReDim a(1 To 1)
    Else
        ReDim Preserve a(1 To n + 1)
    End If
    a(n + 1) = v
End Sub
Public Sub NKASize(a As Variant, n As Long)
    If n < 1 Then
        ReDim a(1 To 1)
    Else
        ReDim Preserve a(1 To n)
    End If
End Sub
Public Function NKAScan(a As Variant, v As Variant) As Long
    Dim i As Long
    For i = 1 To NKLen(a)
        If a(i) = v Then NKAScan = i: Exit Function
    Next
End Function
Public Sub NKADel(a As Variant, i As Long)
    Dim k As Long
    For k = i To NKLen(a) - 1
        a(k) = a(k + 1)
    Next
    a(NKLen(a)) = Empty
End Sub
Public Sub NKAIns(a As Variant, i As Long)
    Dim k As Long
    For k = NKLen(a) To i + 1 Step -1
        a(k) = a(k - 1)
    Next
    a(i) = Empty
End Sub
Public Function NKAClone(a As Variant) As Variant
    NKAClone = a
End Function
Public Sub NKACopy(a As Variant, b As Variant)
    Dim i As Long
    For i = 1 To NKLen(a)
        If i <= NKLen(b) Then b(i) = a(i)
    Next
End Sub
Public Sub NKAFill(a As Variant, v As Variant)
    Dim i As Long
    For i = 1 To NKLen(a)
        a(i) = v
    Next
End Sub
Public Sub NKASort(a As Variant)
    Dim i As Long, j As Long, t As Variant
    For i = 1 To NKLen(a) - 1
        For j = i + 1 To NKLen(a)
            If a(j) < a(i) Then t = a(i): a(i) = a(j): a(j) = t
        Next
    Next
End Sub
Public Function NKATail(a As Variant) As Variant
    If NKLen(a) > 0 Then NKATail = a(NKLen(a))
End Function
Public Function NKLast(ParamArray items() As Variant) As Variant
    NKLast = items(UBound(items))
End Function
Public Function NKStr(n As Variant, Optional nLen As Variant, Optional nDec As Variant) As String
    Dim s As String
    If IsMissing(nDec) Then
        If n = Int(n) Then s = CStr(n) Else s = Replace(Format(n, "0.00"), ",", ".")
    Else
        If nDec > 0 Then s = Replace(Format(n, "0." & String(nDec, "0")), ",", ".") Else s = CStr(Round(n))
    End If
    If IsMissing(nLen) Then nLen = 10
    If Len(s) < nLen Then s = Space(nLen - Len(s)) & s
    NKStr = s
End Function
Public Function NKStrZero(n As Variant, Optional nLen As Variant, Optional nDec As Variant) As String
    Dim s As String
    s = Trim(NKStr(n, 1, nDec))
    If IsMissing(nLen) Then nLen = 10
    If Len(s) < nLen Then s = String(nLen - Len(s), "0") & s
    NKStrZero = s
End Function
Public Function NKReplicate(s As Variant, n As Variant) As String
    Dim i As Long, r As String
    For i = 1 To n
        r = r & s
    Next
    NKReplicate = r
End Function
Public Function NKPadR(v As Variant, n As Long, Optional c As Variant) As String
    Dim s As String
    If IsMissing(c) Then c = " "
    s = NKToText(v)
    If Len(s) >= n Then NKPadR = Left(s, n) Else NKPadR = s & NKReplicate(c, n - Len(s))
End Function
Public Function NKPadL(v As Variant, n As Long, Optional c As Variant) As String
    Dim s As String
    If IsMissing(c) Then c = " "
    s = NKToText(v)
    If Len(s) >= n Then NKPadL = Right(s, n) Else NKPadL = NKReplicate(c, n - Len(s)) & s
End Function
Public Function NKPadC(v As Variant, n As Long, Optional c As Variant) As String
    Dim s As String, k As Long
    If IsMissing(c) Then c = " "
    s = Trim(NKToText(v))
    If Len(s) >= n Then NKPadC = Left(s, n): Exit Function
    k = (n - Len(s)) \\ 2
    NKPadC = NKReplicate(c, k) & s & NKReplicate(c, n - Len(s) - k)
End Function
Public Function NKStrTran(s As Variant, a As Variant, Optional b As Variant) As String
    If IsMissing(b) Then b = ""
    NKStrTran = Replace(s, a, b)
End Function
Public Function NKEmpty(v As Variant) As Boolean
    If IsArray(v) Then
        NKEmpty = (NKLen(v) = 0)
    ElseIf IsEmpty(v) Or IsNull(v) Then
        NKEmpty = True
    ElseIf VarType(v) = vbString Then
        NKEmpty = (Trim(v) = "")
    ElseIf VarType(v) = vbBoolean Then
        NKEmpty = Not v
    ElseIf IsNumeric(v) Then
        NKEmpty = (v = 0)
    Else
        NKEmpty = False
    End If
End Function
Public Function NKValType(v As Variant) As String
    If IsArray(v) Then
        NKValType = "A"
    ElseIf IsEmpty(v) Or IsNull(v) Then
        NKValType = "U"
    ElseIf VarType(v) = vbString Then
        NKValType = "C"
    ElseIf VarType(v) = vbBoolean Then
        NKValType = "L"
    ElseIf VarType(v) = vbDate Then
        NKValType = "D"
    ElseIf IsNumeric(v) Then
        NKValType = "N"
    Else
        NKValType = "O"
    End If
End Function
Public Function NKType(s As Variant) As String
    NKType = "U"
End Function
Public Function NKMax(a As Variant, b As Variant) As Variant
    If a > b Then NKMax = a Else NKMax = b
End Function
Public Function NKMin(a As Variant, b As Variant) As Variant
    If a < b Then NKMin = a Else NKMin = b
End Function
Public Function NKMod(a As Variant, b As Variant) As Variant
    NKMod = a Mod b
End Function
Public Function NKCToD(s As Variant) As Variant
    If Trim(Replace(Replace(s, "/", ""), "-", "")) = "" Then NKCToD = Empty: Exit Function
    If IsDate(s) Then NKCToD = CDate(s) Else NKCToD = Empty
End Function
Public Function NKDToC(d As Variant) As String
    If IsEmpty(d) Or IsNull(d) Then NKDToC = "  /  /    ": Exit Function
    NKDToC = Format(d, "dd/mm/yyyy")
End Function
Public Function NKDToS(d As Variant) As String
    If IsEmpty(d) Or IsNull(d) Then NKDToS = "        ": Exit Function
    NKDToS = Format(d, "yyyymmdd")
End Function
Public Function NKSToD(s As Variant) As Variant
    If Len(Trim(s)) < 8 Then NKSToD = Empty: Exit Function
    NKSToD = DateSerial(Val(Left(s, 4)), Val(Mid(s, 5, 2)), Val(Mid(s, 7, 2)))
End Function
Public Function NKCDoW(d As Variant) As String
    NKCDoW = WeekdayName(Weekday(d))
End Function
Public Function NKCMonth(d As Variant) As String
    NKCMonth = MonthName(Month(d))
End Function
Public Function NKTransform(v As Variant, Optional pic As Variant) As String
    Dim p As String, i As Long, s As String, k As Long, dec As Long
    If IsMissing(pic) Then pic = ""
    p = pic
    If Left(p, 2) = "@!" Then NKTransform = UCase(NKToText(v)): Exit Function
    If Left(p, 1) = "@" Then p = Trim(Mid(p, InStr(p & " ", " ") + 1))
    If IsNumeric(v) And VarType(v) <> vbString And p <> "" Then
        k = InStr(p, ".")
        If k > 0 Then dec = Len(p) - k Else dec = 0
        If dec > 0 Then s = Format(v, "#,##0." & String(dec, "0")) Else s = Format(v, "#,##0")
        If InStr(p, ",") = 0 Then s = Replace(s, ".", "")
        If Len(s) < Len(p) Then s = Space(Len(p) - Len(s)) & s
        NKTransform = s
    Else
        NKTransform = NKToText(v)
    End If
End Function
Public Function NKToText(v As Variant) As String
    If IsArray(v) Then
        NKToText = "{...}"
    ElseIf IsEmpty(v) Or IsNull(v) Then
        NKToText = ""
    ElseIf VarType(v) = vbBoolean Then
        If v Then NKToText = "T" Else NKToText = "F"
    ElseIf VarType(v) = vbDate Then
        NKToText = Format(v, "dd/mm/yyyy")
    Else
        NKToText = CStr(v)
    End If
End Function
Public Function NKGetText(v As Variant) As String
    If VarType(v) = vbString Then NKGetText = RTrim(v) Else NKGetText = NKToText(v)
End Function
Public Function NKFromText(s As String, old As Variant) As Variant
    If VarType(old) = vbString Then
        If Len(old) > 0 And Len(s) < Len(old) Then NKFromText = s & Space(Len(old) - Len(s)) Else NKFromText = s
    ElseIf VarType(old) = vbBoolean Then
        NKFromText = (UCase(Left(Trim(s), 1)) = "T" Or UCase(Left(Trim(s), 1)) = "Y" Or UCase(Left(Trim(s), 1)) = "S")
    ElseIf VarType(old) = vbDate Or (IsEmpty(old) And IsDate(s)) Then
        If IsDate(s) Then NKFromText = CDate(s) Else NKFromText = Empty
    ElseIf IsNumeric(old) And Not IsEmpty(old) Then
        NKFromText = Val(Replace(Replace(s, ".", ""), ",", "."))
        If InStr(s, ",") = 0 Then NKFromText = Val(s)
    Else
        NKFromText = s
    End If
End Function
Public Function NKIsAlpha(s As Variant) As Boolean
    NKIsAlpha = (UCase(Left(s, 1)) <> LCase(Left(s, 1)))
End Function
Public Function NKIsDigit(s As Variant) As Boolean
    NKIsDigit = (Left(s, 1) >= "0" And Left(s, 1) <= "9" And Len(s) > 0)
End Function
Public Function NKIsUpper(s As Variant) As Boolean
    NKIsUpper = NKIsAlpha(s) And (Left(s, 1) = UCase(Left(s, 1)))
End Function
Public Function NKIsLower(s As Variant) As Boolean
    NKIsLower = NKIsAlpha(s) And (Left(s, 1) = LCase(Left(s, 1)))
End Function
Public Function NKDescend(v As Variant) As Variant
    NKDescend = v
End Function
Public Function NKSoundex(s As Variant) As String
    NKSoundex = UCase(Left(s, 1)) & "000"
End Function
Public Function NKMacro(v As Variant) As Variant
    NKMacro = v
End Function
' ---- teclado e tela
Public Sub NKSetLastKey(k As Variant)
    NKLastKeyValue = k
End Sub
Public Function NKLastKey() As Long
    NKLastKey = NKLastKeyValue
End Function
Public Function NKNextKey() As Long
    NKNextKey = 0
End Function
Public Function NKInkey(Optional secs As Variant) As Long
    If Not IsMissing(secs) Then
        If secs = 0 Then
            MsgBox "Press OK to continue.", vbInformation
            NKLastKeyValue = 13
            NKInkey = 13
            Exit Function
        End If
    End If
    NKInkey = 0
End Function
Public Function NKWait(Optional msg As Variant) As String
    If IsMissing(msg) Then msg = "Press any key to continue..."
    If msg = "" Then msg = "Press any key to continue..."
    MsgBox msg, vbInformation
    NKLastKeyValue = 13
    NKWait = ""
End Function
Public Function NKAccept(Optional prompt As Variant) As String
    If IsMissing(prompt) Then prompt = ""
    NKAccept = InputBox(prompt)
End Function
Public Function NKInput(Optional prompt As Variant) As Variant
    Dim s As String
    If IsMissing(prompt) Then prompt = ""
    s = InputBox(prompt)
    If IsNumeric(s) Then NKInput = Val(s) Else NKInput = s
End Function
Public Function NKAlert(msg As Variant, Optional opts As Variant) As Long
    Dim i As Long, n As Long, r As Long
    n = 0
    If Not IsMissing(opts) Then n = NKLen(opts)
    msg = Replace(msg, ";", vbCrLf)
    If n <= 1 Then
        MsgBox msg, vbExclamation
        NKAlert = 1
    ElseIf n = 2 Then
        r = MsgBox(msg & vbCrLf & vbCrLf & "Yes = " & opts(1) & "    No = " & opts(2), vbYesNo + vbQuestion)
        If r = vbYes Then NKAlert = 1 Else NKAlert = 2
    Else
        r = MsgBox(msg & vbCrLf & vbCrLf & "Yes = " & opts(1) & "    No = " & opts(2) & "    Cancel = " & opts(3), vbYesNoCancel + vbQuestion)
        If r = vbYes Then
            NKAlert = 1
        ElseIf r = vbNo Then
            NKAlert = 2
        Else
            NKAlert = 3
        End If
    End If
End Function
Public Function NKAChoice(Optional t As Variant, Optional l As Variant, Optional b As Variant, Optional r As Variant, Optional items As Variant) As Long
    Dim i As Long
    If IsMissing(items) Then Exit Function
    frmNKChoice.lstItems.Clear
    For i = 1 To NKLen(items)
        frmNKChoice.lstItems.AddItem NKToText(items(i))
    Next
    frmNKChoice.Result = 0
    frmNKChoice.Show vbModal
    NKAChoice = frmNKChoice.Result
    If NKAChoice = 0 Then NKLastKeyValue = 27 Else NKLastKeyValue = 13
    Unload frmNKChoice
End Function
Public Function NKSetColor(Optional c As Variant) As String
    NKSetColor = "W/N"
End Function
Public Function NKSaveScreen(Optional a As Variant, Optional b As Variant, Optional c As Variant, Optional d As Variant) As String
    NKSaveScreen = ""
End Function
Public Sub NKRestScreen(Optional a As Variant, Optional b As Variant, Optional c As Variant, Optional d As Variant, Optional e As Variant)
End Sub
Public Function NKRow() As Long
    NKRow = 0
End Function
Public Function NKCol() As Long
    NKCol = 0
End Function
Public Function NKMaxRow() As Long
    NKMaxRow = 24
End Function
Public Function NKMaxCol() As Long
    NKMaxCol = 79
End Function
Public Sub NKSetPos(Optional r As Variant, Optional c As Variant)
End Sub
Public Sub NKTone(Optional f As Variant, Optional d As Variant)
    Beep
End Sub
Public Function NKSetFn(Optional a As Variant, Optional b As Variant) As Variant
    NKSetFn = Empty
End Function
Public Function NKOS() As String
    NKOS = "Neo Kiva"
End Function
Public Function NKVersion() As String
    NKVersion = "Clipper (Neo Kiva)"
End Function
Public Sub NKKeyboard(Optional s As Variant)
End Sub
Public Function NKReadVar() As String
    NKReadVar = ""
End Function
Public Function NKUpdated() As Boolean
    NKUpdated = True
End Function
Public Function NKErrorLevel(Optional n As Variant) As Long
    NKErrorLevel = 0
End Function
Public Function NKFile(f As Variant) As Boolean
    NKFile = False
End Function
Public Function NKMemoLine(s As Variant, Optional n As Variant, Optional i As Variant) As String
    Dim a As Variant
    a = Split(Replace(s, vbCrLf, vbLf), vbLf)
    If IsMissing(i) Then i = 1
    If i - 1 <= UBound(a) Then NKMemoLine = a(i - 1)
End Function
Public Function NKMLCount(s As Variant, Optional n As Variant) As Long
    NKMLCount = UBound(Split(Replace(s, vbCrLf, vbLf), vbLf)) + 1
End Function
Public Function NKHardCR(s As Variant) As String
    NKHardCR = s
End Function
Public Function NKMemoTran(s As Variant, Optional a As Variant, Optional b As Variant) As String
    NKMemoTran = Replace(s, vbCrLf, " ")
End Function
' ---- console (? e ??)
Public Sub NKQOut(ParamArray items() As Variant)
    Dim i As Long, s As String
    For i = LBound(items) To UBound(items)
        If i > LBound(items) Then s = s & " "
        s = s & NKToText(items(i))
    Next
    NKConsoleWrite vbCrLf & s
End Sub
Public Sub NKQQOut(ParamArray items() As Variant)
    Dim i As Long, s As String
    For i = LBound(items) To UBound(items)
        If i > LBound(items) Then s = s & " "
        s = s & NKToText(items(i))
    Next
    NKConsoleWrite s
End Sub
Public Sub NKConsoleWrite(s As String)
    NKConsoleText = NKConsoleText & s
    If Left(NKConsoleText, 2) = vbCrLf Then NKConsoleText = Mid(NKConsoleText, 3)
    frmNKConsole.txtOut.Text = NKConsoleText
    frmNKConsole.txtOut.SelStart = Len(NKConsoleText)
    If Not frmNKConsole.Visible Then frmNKConsole.Show
End Sub
Public Sub NKCls()
    NKConsoleText = ""
    If frmNKConsole.Visible Then frmNKConsole.txtOut.Text = ""
End Sub
Public Sub NKQuit()
    End
End Sub
' ---- banco de dados: as tabelas .dbf foram importadas para o banco do projeto (NKDbName)
Public NKDbName As String
Private nkDbObj As Variant
Private nkRs As Variant
Private nkAls As Variant
Private nkTbl As Variant
Private nkIdx As Variant
Private nkCur As Long
Private nkFoundFlag As Boolean

Private Sub NKInit()
    If IsArray(nkRs) Then Exit Sub
    nkRs = NKArrayN(32)
    nkAls = NKArrayN(32)
    nkTbl = NKArrayN(32)
    nkIdx = NKArrayN(32)
    If nkCur < 1 Then nkCur = 1
End Sub
Private Function NKDB() As Object
    If IsEmpty(nkDbObj) Then Set nkDbObj = OpenDatabase(NKDbName)
    Set NKDB = nkDbObj
End Function
Private Function NKHasRs() As Boolean
    NKInit
    If nkCur < 1 Then nkCur = 1
    NKHasRs = IsObject(nkRs(nkCur))
End Function
Private Function NKAreaOf(a As Variant) As Long
    Dim i As Long
    NKInit
    For i = 1 To 32
        If nkAls(i) & "" = UCase(Trim(a)) And nkAls(i) & "" <> "" Then NKAreaOf = i: Exit Function
    Next
End Function
Public Sub NKUse(tbl As Variant, Optional als As Variant, Optional newArea As Variant)
    Dim i As Long
    If IsMissing(als) Then als = tbl
    NKInit
    If Not IsMissing(newArea) Then
        If newArea Then
            For i = 1 To 32
                If Not IsObject(nkRs(i)) Then nkCur = i: Exit For
            Next
        End If
    End If
    If IsObject(nkRs(nkCur)) Then nkRs(nkCur).Close
    Set nkRs(nkCur) = NKDB().OpenRecordset(CStr(tbl))
    nkAls(nkCur) = UCase(Trim(als))
    nkTbl(nkCur) = CStr(tbl)
    nkIdx(nkCur) = ""
    If Not nkRs(nkCur).EOF Then nkRs(nkCur).MoveFirst
End Sub
Public Sub NKSelectArea(a As Variant)
    Dim i As Long
    NKInit
    If IsNumeric(a) Then
        If a = 0 Then
            For i = 1 To 32
                If Not IsObject(nkRs(i)) Then nkCur = i: Exit Sub
            Next
        Else
            nkCur = a
        End If
    Else
        i = NKAreaOf(a)
        If i > 0 Then nkCur = i
    End If
End Sub
Public Sub NKSetIndexField(f As Variant)
    NKInit
    nkIdx(nkCur) = f
End Sub
Public Function NKFld(f As Variant) As Variant
    Dim v As Variant, t As Long
    If Not NKHasRs() Then NKFld = "": Exit Function
    If nkRs(nkCur).EOF Or nkRs(nkCur).BOF Then
        t = nkRs(nkCur).Fields(f).Type
        If t = 4 Or t = 7 Or t = 6 Or t = 3 Or t = 2 Or t = 5 Then
            NKFld = 0
        ElseIf t = 1 Then
            NKFld = False
        Else
            NKFld = ""
        End If
        Exit Function
    End If
    v = nkRs(nkCur).Fields(f).Value
    If IsNull(v) Then
        t = nkRs(nkCur).Fields(f).Type
        If t = 4 Or t = 7 Or t = 6 Or t = 3 Or t = 2 Or t = 5 Then
            v = 0
        ElseIf t = 1 Then
            v = False
        ElseIf t = 8 Then
            v = Empty
        Else
            v = ""
        End If
    End If
    NKFld = v
End Function
Public Function NKField(a As Variant, f As Variant) As Variant
    Dim k As Long, old As Long
    old = nkCur
    If a <> "" Then
        k = NKAreaOf(a)
        If k > 0 Then nkCur = k
    End If
    NKField = NKFld(f)
    nkCur = old
End Function
Public Sub NKReplace(f As Variant, v As Variant)
    If Not NKHasRs() Then Exit Sub
    If nkRs(nkCur).EOF Or nkRs(nkCur).BOF Then Exit Sub
    nkRs(nkCur).Edit
    If VarType(v) = vbString Then
        nkRs(nkCur).Fields(f).Value = RTrim(v)
    Else
        nkRs(nkCur).Fields(f).Value = v
    End If
    nkRs(nkCur).Update
End Sub
Public Function NKEof() As Boolean
    If Not NKHasRs() Then NKEof = True Else NKEof = nkRs(nkCur).EOF
End Function
Public Function NKBof() As Boolean
    If Not NKHasRs() Then NKBof = True Else NKBof = nkRs(nkCur).BOF
End Function
Public Function NKRecNo() As Long
    If Not NKHasRs() Then Exit Function
    If nkRs(nkCur).EOF Then NKRecNo = nkRs(nkCur).RecordCount + 1 Else NKRecNo = nkRs(nkCur).AbsolutePosition + 1
End Function
Public Function NKRecCount() As Long
    If NKHasRs() Then NKRecCount = nkRs(nkCur).RecordCount
End Function
Public Sub NKSetFound(b As Boolean)
    nkFoundFlag = b
End Sub
Public Function NKFound() As Boolean
    NKFound = nkFoundFlag
End Function
Public Function NKDeleted() As Boolean
    NKDeleted = False
End Function
Public Function NKAlias(Optional n As Variant) As String
    NKInit
    NKAlias = nkAls(nkCur) & ""
End Function
Public Function NKSelect(Optional a As Variant) As Long
    If IsMissing(a) Then NKSelect = nkCur Else NKSelect = NKAreaOf(a)
End Function
Public Function NKUsed() As Boolean
    NKUsed = NKHasRs()
End Function
Public Function NKNetErr() As Boolean
    NKNetErr = False
End Function
Public Function NKLock(Optional a As Variant) As Boolean
    NKLock = True
End Function
Public Sub NKSkip(Optional n As Variant)
    Dim i As Long
    If Not NKHasRs() Then Exit Sub
    If IsMissing(n) Then n = 1
    If n >= 0 Then
        For i = 1 To n
            If nkRs(nkCur).EOF Then Exit For
            nkRs(nkCur).MoveNext
        Next
    Else
        For i = 1 To -n
            If nkRs(nkCur).BOF Then Exit For
            nkRs(nkCur).MovePrevious
        Next
        If nkRs(nkCur).BOF And nkRs(nkCur).RecordCount > 0 Then nkRs(nkCur).MoveFirst
    End If
End Sub
Public Sub NKGoTop()
    If Not NKHasRs() Then Exit Sub
    If nkRs(nkCur).RecordCount > 0 Then nkRs(nkCur).MoveFirst
End Sub
Public Sub NKGoBottom()
    If Not NKHasRs() Then Exit Sub
    If nkRs(nkCur).RecordCount > 0 Then nkRs(nkCur).MoveLast
End Sub
Public Sub NKGoTo(Optional n As Variant)
    If Not NKHasRs() Then Exit Sub
    If nkRs(nkCur).RecordCount = 0 Then Exit Sub
    nkRs(nkCur).MoveFirst
    If n > 1 Then nkRs(nkCur).Move n - 1
End Sub
Public Function NKSeek(Optional v As Variant, Optional b As Variant) As Boolean
    Dim f As String, crit As String
    If Not NKHasRs() Then Exit Function
    f = nkIdx(nkCur)
    If f = "" Then f = nkRs(nkCur).Fields(0).Name
    If VarType(v) = vbString Then
        crit = "[" & f & "] LIKE '" & Replace(RTrim(v), "'", "''") & "*'"
    ElseIf VarType(v) = vbDate Then
        crit = "[" & f & "] = #" & Format(v, "mm/dd/yyyy") & "#"
    Else
        crit = "[" & f & "] = " & Replace(CStr(v), ",", ".")
    End If
    If nkRs(nkCur).RecordCount = 0 Then nkFoundFlag = False: NKSeek = False: Exit Function
    nkRs(nkCur).FindFirst crit
    nkFoundFlag = Not nkRs(nkCur).NoMatch
    If Not nkFoundFlag Then
        nkRs(nkCur).MoveLast
        nkRs(nkCur).MoveNext
    End If
    NKSeek = nkFoundFlag
End Function
Public Sub NKAppend()
    If Not NKHasRs() Then Exit Sub
    nkRs(nkCur).AddNew
    nkRs(nkCur).Update
    nkRs(nkCur).Bookmark = nkRs(nkCur).LastModified
End Sub
Public Sub NKDelete()
    If Not NKHasRs() Then Exit Sub
    If nkRs(nkCur).EOF Or nkRs(nkCur).BOF Then Exit Sub
    nkRs(nkCur).Delete
End Sub
Public Sub NKZap()
    If Not NKHasRs() Then Exit Sub
    NKDB().Execute "DELETE FROM [" & nkTbl(nkCur) & "]"
    nkRs(nkCur).Requery
End Sub
Public Sub NKCommit()
End Sub
Public Sub NKUnlock()
End Sub
Public Sub NKClose()
    If NKHasRs() Then nkRs(nkCur).Close
    NKInit
    nkRs(nkCur) = Empty
    nkAls(nkCur) = ""
End Sub
Public Sub NKCloseArea(a As Variant)
    Dim k As Long, old As Long
    k = NKAreaOf(a)
    If k = 0 Then Exit Sub
    old = nkCur: nkCur = k: NKClose: nkCur = old
End Sub
Public Sub NKCloseAll()
    Dim i As Long
    NKInit
    For i = 1 To 32
        If IsObject(nkRs(i)) Then nkRs(i).Close
        nkRs(i) = Empty
        nkAls(i) = ""
    Next
    nkCur = 1
End Sub
Public Function NKFieldGet(Optional n As Variant) As Variant
    If NKHasRs() Then NKFieldGet = NKFld(nkRs(nkCur).Fields(n - 1).Name)
End Function
Public Sub NKFieldPut(Optional n As Variant, Optional v As Variant)
    If NKHasRs() Then NKReplace nkRs(nkCur).Fields(n - 1).Name, v
End Sub
Public Function NKFieldName(Optional n As Variant) As String
    If NKHasRs() Then NKFieldName = nkRs(nkCur).Fields(n - 1).Name
End Function
Public Function NKFCount() As Long
    If NKHasRs() Then NKFCount = nkRs(nkCur).Fields.Count
End Function
Public Function NKSetOrder(Optional n As Variant) As Long
    NKSetOrder = 0
End Function
Public Function NKIndexOrd() As Long
    NKIndexOrd = 0
End Function
`;
  const CONSOLE_FRM = `VERSION 5.00
Begin VB.Form frmNKConsole
   BackColor       =   &H00000000&
   Caption         =   "Console"
   ClientHeight    =   6000
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   9600
   LinkTopic       =   "frmNKConsole"
   ScaleHeight     =   6000
   ScaleWidth      =   9600
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtOut
      BackColor       =   &H00000000&
      BeginProperty Font
         Name            =   "Courier New"
         Size            =   10
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C0C0C0&
      Height          =   6000
      Left            =   0
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Top             =   0
      Width           =   9600
   End
End
Attribute VB_Name = "frmNKConsole"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Console window for the Clipper ? and ?? commands (Neo Kiva)
Private Sub Form_Resize()
    On Error Resume Next
    txtOut.Move 0, 0, Me.ScaleWidth, Me.ScaleHeight
End Sub
`;
  const CHOICE_FRM = `VERSION 5.00
Begin VB.Form frmNKChoice
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Choose"
   ClientHeight    =   3600
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   4200
   KeyPreview      =   -1  'True
   LinkTopic       =   "frmNKChoice"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3600
   ScaleWidth      =   4200
   StartUpPosition =   1  'CenterOwner
   Begin VB.ListBox lstItems
      Height          =   2700
      Left            =   180
      TabIndex        =   0
      Top             =   180
      Width           =   3840
   End
   Begin VB.CommandButton cmdOK
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   1740
      TabIndex        =   1
      Top             =   3060
      Width           =   1095
   End
   Begin VB.CommandButton cmdCancel
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2925
      TabIndex        =   2
      Top             =   3060
      Width           =   1095
   End
End
Attribute VB_Name = "frmNKChoice"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' List used by ACHOICE() (Neo Kiva)
Public Result As Integer
Private Sub cmdOK_Click()
    Result = lstItems.ListIndex + 1
    Me.Hide
End Sub
Private Sub cmdCancel_Click()
    Result = 0
    Me.Hide
End Sub
Private Sub lstItems_DblClick()
    cmdOK_Click
End Sub
Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If UnloadMode = 0 Then Cancel = True: Result = 0: Me.Hide
End Sub
`;

  // ---------------------------------------------------------------- projeto
  function convertProject(files) {
    const C = new Converter(); const rep = []; const warn = s => C.report.warns.push(s);
    const prgs = files.filter(f => /\.prg$/i.test(f.path));
    if (!prgs.length) throw new Error('No .prg files were found.');
    // pasta do projeto: a mais comum entre os .prg
    const dirs = prgs.map(f => f.path.includes('/') ? f.path.slice(0, f.path.lastIndexOf('/')) : '');
    const dir = dirs.sort((a, b) => dirs.filter(x => x === b).length - dirs.filter(x => x === a).length)[0] || '';
    // tabelas .dbf: entram no banco do projeto; os nomes dos campos ajudam a traduzir o código
    const tables = [];
    for (const f of files.filter(x => /\.dbf$/i.test(x.path))) {
      try {
        const stem = f.path.replace(/\.dbf$/i, '').toLowerCase(); const dbt = files.find(x => /\.(dbt|fpt)$/i.test(x.path) && x.path.replace(/\.\w+$/, '').toLowerCase() === stem);
        let nm = f.path.split('/').pop().replace(/\.dbf$/i, '').replace(/[^A-Za-z0-9_]/g, '_'); if (/^\d/.test(nm)) nm = 'T' + nm;
        if (C.tables.has(nm.toLowerCase())) continue;
        const t = readDbf(f.bytes, dbt && dbt.bytes); t.name = nm; tables.push(t); C.tables.set(nm.toLowerCase(), nm);
        for (const fl of t.fields) if (!C.fields.has(fl.name.toLowerCase())) C.fields.set(fl.name.toLowerCase(), fl.name);
      } catch (e) { warn(`${f.path}: could not read the table (${e.message})`); }
    }
    const infos = [];
    for (const f of prgs) { try { infos.push(C.scanFile(f.path, decode(f.bytes))); } catch (e) { warn(`${f.path}: could not read (${e.message})`); } }
    // ponto de entrada: .rmk/.lnk/.clp com a lista; senão MAIN; senão o .prg com o nome da pasta; senão o primeiro com código solto
    let entry = null;
    const lst = files.find(f => /\.(clp|lnk|rmk)$/i.test(f.path));
    if (lst) { const t = decode(lst.bytes); const m = /([A-Za-z0-9_]+)(\.prg|\.obj)?/i.exec(t.replace(/^\s*(#|\/\/|\*).*$/gm, '').replace(/^\s*(fi|file|output|blinker|lib|search)\s+/gim, '')); if (m) entry = infos.find(i => i.base.toLowerCase() === m[1].toLowerCase()); }
    if (!entry) entry = infos.find(i => i.routines.some(r => r.name && r.name.toLowerCase() === 'main'));
    if (!entry) { const folder = (dir.split('/').pop() || '').toLowerCase(); entry = infos.find(i => i.base.toLowerCase() === folder); }
    if (!entry) entry = infos.find(i => i.routines.some(r => r.top)) || infos[0];
    const entryRoutine = entry.routines.find(r => r.name && r.name.toLowerCase() === 'main') || entry.routines.find(r => r.top) || entry.routines[0];
    const out = [];
    let modDb = 0, totalTodo = 0;
    for (const fi of infos) {
      const L = [`Attribute VB_Name = "prg${fi.fileId}"`, `' Converted from the Clipper program ${fi.base}.prg by Neo Kiva`, `' Search for [Clipper] to find what still needs attention.`, ''];
      for (const r of fi.routines) {
        const res = C.translate(fi, r); L.push(...res.lines, ''); if (res.db) modDb++;
      }
      out.push({ path: `prg${fi.fileId}.bas`, text: L.join('\r\n') });
    }
    // variáveis PUBLIC -> módulo
    let projectName0 = (dir.split('/').pop() || entry.base || 'ClipperProject').replace(/[^A-Za-z0-9_]/g, '_'); if (!/^[A-Za-z]/.test(projectName0)) projectName0 = 'P' + projectName0;
    const dbName = projectName0 + '.db';
    const startup = [`Attribute VB_Name = "ClipperStartup"`, `' Program start (Sub Main) created by Neo Kiva`, ...[...C.publics].map(v => `Public ${v}`), '', 'Public Sub Main()', ...(tables.length ? [`    NKDbName = "${dbName}"`] : []), `    ${entryRoutine.vbName}`, 'End Sub', ''];
    out.push({ path: 'ClipperStartup.bas', text: startup.join('\r\n') });
    out.push({ path: 'ClipperCompat.bas', text: COMPAT.replace(/\n/g, '\r\n') });
    out.push({ path: 'frmNKConsole.frm', text: CONSOLE_FRM.replace(/\n/g, '\r\n') });
    out.push({ path: 'frmNKChoice.frm', text: CHOICE_FRM.replace(/\n/g, '\r\n') });
    for (const f of C.forms) out.push({ path: f.path, text: f.text });
    let projectName = (dir.split('/').pop() || entry.base || 'ClipperProject').replace(/[^A-Za-z0-9_]/g, '_'); if (!/^[A-Za-z]/.test(projectName)) projectName = 'P' + projectName;
    const R = C.report;
    rep.push(`Clipper project: ${projectName}`, `Programs: ${infos.length} (.prg) · routines: ${infos.reduce((t, i) => t + i.routines.length, 0)} · screens converted to forms: ${R.screens}`);
    rep.push(`Program start: ${entry.base}.prg → ${entryRoutine.name} (Sub Main in ClipperStartup.bas)`);
    rep.push(R.todo ? `${R.todo} item(s) need review — search for [Clipper] in the code.` : 'All statements were converted.');
    if (tables.length) { rep.push('', `Tables imported into the project database ${dbName} (MySQL):`); for (const t of tables) rep.push(`  ${t.name}: ${t.rows.length} record(s), ${t.fields.length} field(s) (${t.fields.map(x => x.name).join(', ')})${t.deleted ? ` — ${t.deleted} deleted record(s) left out` : ''}`); }
    if (C.dbCount) rep.push('', `${C.dbCount} database command(s) (USE, SKIP, SEEK, REPLACE, APPEND…) now work with these tables.`);
    const unknown = [...R.fns.entries()].filter(([k]) => !C.funcs.has(k)).sort((a, b) => b[1] - a[1]);
    if (unknown.length) { rep.push('', 'Functions not found in the project or in the Clipper library (check them):'); rep.push('  ' + unknown.slice(0, 40).map(([k, n]) => `${k}()${n > 1 ? ' ×' + n : ''}`).join(', ')); }
    if (R.warns.length) { rep.push('', 'Notes:'); for (const w of R.warns) rep.push('  ' + w); }
    return { files: out, reportText: rep.join('\r\n'), projectName, dir, report: R, tables, dbName };
  }
  return { convertProject, lex, exprOf, decode, dbfToCsv, preprocess };
})();
if (typeof module !== 'undefined') module.exports = NKClipper;
