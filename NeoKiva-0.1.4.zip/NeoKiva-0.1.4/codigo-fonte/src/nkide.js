// ===== Neo Kiva 0.1 — Resource Explorer (aba de documento) e importação de projetos Clipper =====
'use strict';

// ---------------------------------------------------------------- arquivos gerados -> projeto
function nkUniqueModuleName(base) {
  let n = String(base || 'Form1').replace(/[^A-Za-z0-9_]/g, '_').replace(/^([^A-Za-z])/, 'f$1').slice(0, 39) || 'Form1';
  const used = new Set((IDE.project ? IDE.project.modules : []).map(m => m.name.toLowerCase()));
  let k = n, i = 2; while (used.has(k.toLowerCase())) k = n + (i++); return k;
}
// files: [{ path, text | bytes }]; pending: { formName: { ctlName: {mime, bytes} } }
async function nkAddGenerated(files, opts = {}) {
  const map = new Map();
  for (const f of files) map.set(f.path.toLowerCase(), { name: f.path.split('/').pop(), path: f.path, bytes: f.bytes || encode1252(f.text) });
  const applyPending = (proj) => {
    for (const m of proj.modules) {
      const pf = opts.pending && opts.pending[m.name]; if (!pf || m.kind !== 'form') continue;
      for (const n of allNodes(m)) { const pic = pf[n.name]; if (pic) { const url = 'data:' + pic.mime + ';base64,' + u8ToB64(pic.bytes); n._pending = Object.assign({}, n._pending, { picture: { url, bytes: pic.bytes } }); } }
    }
  };
  if (!IDE.project || opts.newProject) {
    if (IDE.project && !(await confirmDiscard())) return false;
    const forms = files.filter(f => /\.frm$/i.test(f.path)); const others = files.filter(f => /\.(bas|cls)$/i.test(f.path));
    const name = (opts.projectName || 'Project1').replace(/[^A-Za-z0-9_]/g, '_').replace(/^([^A-Za-z])/, 'P$1').slice(0, 39);
    if (!files.some(f => /\.vbp$/i.test(f.path))) {
      const start = opts.startup || (forms[0] ? forms[0].path.replace(/\.frm$/i, '').split('/').pop() : 'Sub Main');
      const vbp = ['Type=Exe', ...forms.map(f => 'Form=' + f.path), ...others.map(f => /\.bas$/i.test(f.path) ? `Module=${f.path.replace(/\.bas$/i, '')}; ${f.path}` : `Class=${f.path.replace(/\.cls$/i, '')}; ${f.path}`), `Startup="${start}"`, `Name="${name}"`, `Title="${opts.title || name}"`, 'ExeName32="' + name + '.exe"', 'MajorVer=1', 'MinorVer=0'].join('\r\n') + '\r\n';
      map.set((name + '.vbp').toLowerCase(), { name: name + '.vbp', path: name + '.vbp', bytes: encode1252(vbp) });
    }
    const key = [...map.keys()].find(k => k.endsWith('.vbp'));
    const { proj } = loadProjectFromMap(map, key);
    applyPending(proj);
    for (const m of proj.modules) m.dirty = true; proj.dirty = true;
    IDE.dirHandle = opts.dirHandle || null;
    setProject(proj);
    return proj;
  }
  const { proj } = loadProjectFromMap(map, null);
  applyPending(proj);
  for (const m of proj.modules) { if (findModule(m.name)) { await IDE.ui.msgBox(`A module named ${m.name} already exists in the project.`, 48, APP_NAME); continue; } m.dirty = true; IDE.project.modules.push(m); }
  markDirty(); refreshExplorer();
  return IDE.project;
}

// ---------------------------------------------------------------- Resource Explorer
async function nkOpenExe(file) {
  if (!file) { pickFiles('.exe,.dll,.ocx,.res,.bpl,.cpl,.scr,.sys,.mui,.ax,.drv,.efi', fs => { if (fs[0]) nkOpenExe(fs[0]); }); return; }
  setStatus('Reading ' + file.name + '…');
  let R;
  try { const bytes = new Uint8Array(await file.arrayBuffer()); R = NKRes.open(bytes, file.name); }
  catch (e) { setStatus('Ready'); await IDE.ui.msgBox('Could not read ' + file.name + ':\n\n' + e.message, 16, APP_NAME); return; }
  setStatus('Ready');
  const d = { kind: 'res', title: file.name, R, el: h('div', { class: 'doc nkres' }), sel: null, view: 'auto', open: new Set() };
  $('#docs').appendChild(d.el); IDE.docs.push(d);
  nkBuildResDoc(d); activateDoc(d);
  $('#welcome').style.display = 'none';
  log(`${file.name}: ${R.res.length} resources.`);
}
function nkResGroups(R) {
  const groups = new Map();
  for (const r of R.res) { const k = typeof r.type === 'number' ? 'n' + String(r.type).padStart(5, '0') : 's' + r.type; if (!groups.has(k)) groups.set(k, { type: r.type, items: [] }); groups.get(k).items.push(r); }
  return [...groups.entries()].sort((a, b) => a[0] < b[0] ? -1 : 1).map(x => x[1]);
}
function nkBuildResDoc(d) {
  const R = d.R; const info = R.info;
  d.el.innerHTML = `<div class="nkres-bar"><span class="nkres-file"></span><span class="nkres-tags"></span><span class="grow"></span>
    <button class="nb-btn nkr-form" disabled>Create Form</button><button class="nb-btn nkr-all">Create Project…</button><button class="nb-btn nkr-save" disabled>Save Resource…</button><button class="nb-btn nkr-rc">Save .rc…</button></div>
    <div class="nkres-main"><div class="nkres-tree"></div><div class="nkres-view"><div class="nkres-head"></div><div class="nkres-tabs"></div><div class="nkres-body"></div></div></div>`;
  $('.nkres-file', d.el).textContent = d.title;
  const tags = [];
  if (info.kind === 'pe') tags.push(info.machine, info.subsystem, info.dll ? 'DLL' : 'EXE');
  else tags.push('.res file');
  if (info.delphi) tags.push('Delphi / C++Builder');
  if (info.vb) tags.push('Visual Basic 5/6');
  $('.nkres-tags', d.el).innerHTML = tags.map(t => `<span>${esc(t)}</span>`).join('');
  const groups = nkResGroups(R);
  const formCount = R.res.filter(r => r.type === 5 || (r.type === 10 && r.data.length > 4 && r.data[0] === 0x54 && r.data[1] === 0x50 && r.data[2] === 0x46 && r.data[3] === 0x30)).length;
  $('.nkr-all', d.el).disabled = !formCount;
  $('.nkr-all', d.el).title = formCount ? `${formCount} form(s) or dialog(s) found` : 'No dialogs or Delphi forms in this file';
  $('.nkr-all', d.el).onclick = () => nkResCreateAll(d);
  $('.nkr-rc', d.el).onclick = () => nkResSaveRc(d);
  $('.nkr-save', d.el).onclick = () => { if (!d.sel) return; const v = NKRes.viewFor(R, d.sel); downloadBlob(new Blob([v.save.bytes]), `${NKRes.typeName(d.sel.type).replace(/\s+/g, '')}_${NKRes.resName(d.sel.name)}.${v.save.ext}`); };
  $('.nkr-form', d.el).onclick = () => { if (d.sel) nkResCreateForm(d, d.sel); };
  const tree = $('.nkres-tree', d.el);
  if (info.vb) {
    const vbn = h('div', { class: 'nkr-node nkr-info', html: `<i class="ic">${NK_ICONS.exe}</i><span>Visual Basic project</span>` });
    vbn.onclick = () => { $$('.nkr-node', tree).forEach(x => x.classList.remove('on')); vbn.classList.add('on'); d.sel = null; nkShowVbInfo(d); };
    tree.appendChild(vbn);
  }
  if (!groups.length) tree.appendChild(h('div', { class: 'nkr-empty', html: 'This file has no resources.' }));
  for (const g of groups) {
    const key = String(g.type); const open = d.open.has(key) || g.type === 5 || (g.type === 10 && info.delphi);
    if (open) d.open.add(key);
    const head = h('div', { class: 'nkr-type' + (open ? ' open' : ''), html: `<i></i><span>${esc(NKRes.typeName(g.type))}</span><em>${g.items.length}</em>` });
    const box = h('div', { class: 'nkr-items' }); box.style.display = open ? '' : 'none';
    head.onclick = () => { const o = box.style.display === 'none'; box.style.display = o ? '' : 'none'; head.classList.toggle('open', o); if (o) d.open.add(key); else d.open.delete(key); };
    for (const r of g.items) {
      const isForm = r.type === 5 || (r.type === 10 && r.data.length > 4 && r.data[0] === 0x54 && r.data[1] === 0x50 && r.data[2] === 0x46 && r.data[3] === 0x30);
      const n = h('div', { class: 'nkr-node' + (isForm ? ' form' : ''), title: `${NKRes.typeName(r.type)} ${NKRes.resName(r.name)} — language ${NKRes.langName(r.lang)} — ${r.data.length} bytes` }, h('span', null, String(NKRes.resName(r.name))), h('em', null, String(r.lang ?? '')));
      n.onclick = () => { $$('.nkr-node', tree).forEach(x => x.classList.remove('on')); n.classList.add('on'); d.sel = r; d.view = 'auto'; nkShowRes(d); };
      n.ondblclick = () => { if (isForm) nkResCreateForm(d, r); };
      box.appendChild(n);
    }
    tree.appendChild(head); tree.appendChild(box);
  }
  // seleciona o primeiro formulário (ou o ícone) para começar
  const isDfm = r => r.type === 10 && r.data[0] === 0x54 && r.data[1] === 0x50 && r.data[2] === 0x46; const first = R.res.find(r => r.type === 5) || R.res.find(r => isDfm(r) && /principal|main/i.test(String(r.name))) || R.res.find(r => isDfm(r) && /^T(FRM|FORM)/i.test(String(r.name))) || R.res.find(isDfm) || R.res.find(r => r.type === 14) || R.res[0];
  if (info.vb) { tree.querySelector('.nkr-info').click(); }
  else if (first) { const idx = R.res.indexOf(first); const nodes = $$('.nkr-node', tree); const el = nodes.find(x => x.title.startsWith(`${NKRes.typeName(first.type)} ${NKRes.resName(first.name)} `)); if (el) el.click(); else { d.sel = first; nkShowRes(d); } }
  else nkShowSummary(d);
}
function nkShowSummary(d) { $('.nkres-head', d.el).textContent = d.title; $('.nkres-tabs', d.el).innerHTML = ''; $('.nkres-body', d.el).innerHTML = '<div class="nkr-msg">Select a resource on the left.</div>'; }
function nkShowVbInfo(d) {
  const vb = d.R.info.vb; $('.nkr-form', d.el).disabled = true; $('.nkr-save', d.el).disabled = true;
  $('.nkres-head', d.el).innerHTML = `<b>${esc(vb.projectName || 'Visual Basic program')}</b> <span>${esc(vb.exeName || '')}</span>`;
  $('.nkres-tabs', d.el).innerHTML = '';
  const rows = vb.objects.map(o => `<tr><td>${esc(o.name)}</td><td>${esc(o.kind)}</td><td>${o.methods}</td></tr>`).join('');
  $('.nkres-body', d.el).innerHTML = `<div class="nkr-doc"><p>This program was made with <b>Visual Basic 5 or 6</b>. Its forms are compiled inside the program code (not in Windows resources), so this version of Neo Kiva lists them but cannot rebuild their layout yet.</p>
    <p>If you have the project files (.vbp, .frm, .bas), open them with <b>File › Open Project Folder</b> — Neo Kiva opens Visual Basic projects directly.</p>
    <table class="nkr-table"><thead><tr><th>Object</th><th>Kind</th><th>Methods</th></tr></thead><tbody>${rows || '<tr><td colspan="3">No objects found</td></tr>'}</tbody></table></div>`;
}
function nkShowRes(d) {
  const r = d.sel; if (!r) return nkShowSummary(d);
  const v = NKRes.viewFor(d.R, r); d.cur = v;
  $('.nkr-form', d.el).disabled = !v.canForm; $('.nkr-save', d.el).disabled = false;
  $('.nkres-head', d.el).innerHTML = `<b>${esc(NKRes.typeName(r.type))}</b> <span>${esc(String(NKRes.resName(r.name)))}</span> <span class="dim">language ${esc(NKRes.langName(r.lang))} · ${r.data.length.toLocaleString('en-US')} bytes</span>`;
  const tabs = [];
  if (v.kind === 'image' || v.kind === 'dialog' || v.kind === 'dfm') tabs.push(['preview', v.kind === 'image' ? 'Image' : 'Form']);
  if (v.script) tabs.push(['script', v.kind === 'dfm' ? 'DFM' : 'Script']);
  if (v.kind === 'text') tabs.push(['text', 'Text']);
  tabs.push(['hex', 'Binary']);
  if (d.view === 'auto' || !tabs.some(t => t[0] === d.view)) d.view = tabs[0][0];
  const tb = $('.nkres-tabs', d.el); tb.innerHTML = '';
  for (const [k, l] of tabs) { const b = h('span', { class: d.view === k ? 'on' : '' }, l); b.onclick = () => { d.view = k; nkShowRes(d); }; tb.appendChild(b); }
  const body = $('.nkres-body', d.el); body.innerHTML = '';
  if (v.error) body.appendChild(h('div', { class: 'nkr-msg err' }, 'This resource could not be decoded: ' + v.error));
  if (d.view === 'hex') { body.appendChild(h('pre', { class: 'nkr-pre' }, NKRes.hexDump(r.data))); return; }
  if (d.view === 'script' || d.view === 'text') { body.appendChild(h('pre', { class: 'nkr-pre' + (d.view === 'text' ? ' wrap' : '') }, d.view === 'text' ? v.text : v.script)); return; }
  if (v.kind === 'image') {
    const url = 'data:' + v.img.mime + ';base64,' + u8ToB64(v.img.bytes);
    const wrap = h('div', { class: 'nkr-imgs' });
    for (const z of [1, 2]) { const im = h('img', { src: url, class: 'nkr-img' }); if (z === 2) im.style.zoom = 2; wrap.appendChild(im); }
    body.appendChild(wrap);
    if (v.meta) body.appendChild(h('div', { class: 'nkr-msg' }, v.meta.join(' · ')));
    return;
  }
  if (v.kind === 'dialog') {
    const fr = NKRes.dialogToFrm(v.dlg, 'frmPreview', { R: d.R, resName: r.name, file: d.title });
    nkPreviewFrm(body, fr.text, fr.pending);
    body.appendChild(h('div', { class: 'nkr-msg' }, `${v.dlg.items.length} control(s) · ${v.dlg.font ? v.dlg.font + ' ' + v.dlg.pt + ' pt' : 'system font'} · double-click the resource or press "Create Form" to add it to the project`));
    return;
  }
  if (v.kind === 'dfm') {
    let conv = null;
    try { conv = nkDfmToProjectFiles(d, [r]); } catch (e) { body.appendChild(h('div', { class: 'nkr-msg err' }, 'The form could not be converted: ' + e.message)); }
    const frm = conv && conv.files.find(f => /\.frm$/i.test(f.path));
    if (frm) nkPreviewFrm(body, frm.text || new TextDecoder('windows-1252').decode(frm.bytes), null, conv.files);
    body.appendChild(h('div', { class: 'nkr-msg' }, `Delphi form ${v.dfm ? v.dfm.cls : ''} · ${(v.dfm ? nkCountDfm(v.dfm) : 0)} component(s) · press "Create Form" to add it to the project`));
  }
}
function nkCountDfm(n) { return n.children.reduce((t, c) => t + 1 + nkCountDfm(c), 0); }
// mostra um .frm como no designer (só visualização)
function nkPreviewFrm(body, text, pending, files) {
  const holder = h('div', { class: 'nkr-preview' }); body.appendChild(holder);
  try {
    const frm = parseFrm(text, 'preview.frm');
    const frxMap = {}; if (files) for (const f of files) if (/\.frx$/i.test(f.path) && f.bytes) frxMap[f.path.split('/').pop().toLowerCase()] = f.bytes;
    const lookup = name => frxMap[String(name).split(/[\\/]/).pop().toLowerCase()] || null;
    const root = frm.root; const P = nodeProps(root, lookup);
    const w = h('div', { class: 'vb-window design skin-' + NB_SKIN });
    w.innerHTML = `<div class="vb-title"><span class="vb-ticon"></span><span class="vb-tcap"></span><span class="vb-tbtns"><b class="tb-min"></b><b class="tb-max"></b><b class="tb-close"></b></span></div><div class="vb-menubar"></div><div class="vb-client"></div>`;
    w.querySelector('.vb-tcap').textContent = P.caption || '';
    const mb = w.querySelector('.vb-menubar'); const menus = root.children.filter(c => /\.menu$/i.test(c.type));
    if (menus.length) for (const mn of menus) mb.appendChild(h('span', { class: 'vb-mtop', html: mnemonicHtml(nodeProps(mn).caption || '') })); else mb.style.display = 'none';
    const client = w.querySelector('.vb-client'); const cw = (P.clientwidth || 4680) / 15, ch = (P.clientheight || 3195) / 15;
    Object.assign(client.style, { width: cw + 'px', height: ch + 'px', backgroundColor: vbColorCss(P.backcolor) }); w.style.width = (cw + 2) + 'px';
    applyFont(client, P.font);
    const put = (node, cont) => { for (const c of node.children) { if (/\.menu$/i.test(c.type)) continue; const cp = nodeProps(c, lookup); if (pending && pending[c.name]) cp.picture = { url: 'data:' + pending[c.name].mime + ';base64,' + u8ToB64(pending[c.name].bytes) }; const el = createCtlElement(c.type, cp, { design: true, scale: 1 / 15 }); cont.appendChild(el); if (c.children.length) put(c, el.querySelector('.nb-panel-body') || el); } };
    put(root, client);
    holder.appendChild(w);
  } catch (e) { holder.appendChild(h('div', { class: 'nkr-msg err' }, 'Preview not available: ' + e.message)); }
}
// ----- DFM (Delphi) -> arquivos do projeto, com uma unidade .pas mínima para cada formulário
function nkDfmToProjectFiles(d, list, opts = {}) {
  const files = []; const units = [];
  const used = new Set();
  for (const r of list) {
    const tree = DelphiImport.parseDfmBinary(r.data);
    const cls = tree.cls; let inst = tree.name || cls.replace(/^T/i, '');
    let unit = 'u' + inst.replace(/^(frm|form|fm|dm)/i, m => m) ; unit = unit.replace(/[^A-Za-z0-9_]/g, '_'); while (used.has(unit.toLowerCase())) unit += '_'; used.add(unit.toLowerCase());
    const events = new Set(); const fields = [];
    const walk = (n, top) => { for (const p of n.props.values()) if (/^On[A-Z]/.test(p.key) && p.v.t === 'ident' && p.v.v) events.add(p.v.v); for (const c of n.children) { if (c.name) fields.push(`    ${c.name}: ${c.cls};`); walk(c); } };
    walk(tree, true);
    const ancestor = /datamodule/i.test(cls) || tree.props.has('oldcreateorder') && !tree.props.has('clientwidth') && !tree.props.has('caption') ? 'TDataModule' : 'TForm';
    const pas = [`unit ${unit};`, '', 'interface', '', 'uses', '  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs, StdCtrls, ExtCtrls;', '', 'type', `  ${cls} = class(${ancestor})`, ...fields, ...[...events].map(e => `    procedure ${e}(Sender: TObject);`), '  end;', '', 'var', `  ${inst}: ${cls};`, '', 'implementation', '', '{$R *.dfm}', '',
      ...[...events].map(e => `procedure ${cls}.${e}(Sender: TObject);\nbegin\n  { [Neo Kiva] the original code of this event is compiled inside the .exe and could not be recovered }\nend;\n`), 'end.', ''].join('\r\n');
    files.push({ path: unit + '.pas', bytes: encode1252(pas) }, { path: unit + '.dfm', bytes: r.data });
    units.push({ unit, inst, cls, size: r.data.length });
  }
  const main = opts.main || units.find(u => /principal|main/i.test(u.inst)) || units.slice().sort((a, b) => b.size - a.size)[0];
  const order = [main, ...units.filter(u => u !== main)];
  const name = (opts.projectName || (d.title || 'Project').replace(/\.[^.]*$/, '')).replace(/[^A-Za-z0-9_]/g, '_') || 'Project1';
  const dpr = [`program ${name};`, '', 'uses', '  Forms,', ...order.map((u, i) => `  ${u.unit} in '${u.unit}.pas' {${u.inst}}${i === order.length - 1 ? ';' : ','}`), '', '{$R *.res}', '', 'begin', '  Application.Initialize;', ...order.filter(u => !/datamodule/i.test(u.cls)).slice(0, opts.createAll ? 999 : 1).map(u => `  Application.CreateForm(${u.cls}, ${u.inst});`), '  Application.Run;', 'end.', ''].join('\r\n');
  files.push({ path: name + '.dpr', bytes: encode1252(dpr) });
  const res = DelphiConvert.convertProject(files);
  return res;
}
async function nkResCreateForm(d, r) {
  const v = NKRes.viewFor(d.R, r);
  try {
    if (r.type === 5) {
      const base = nkUniqueModuleName('frmDialog' + (typeof r.name === 'number' ? r.name : String(r.name).replace(/[^A-Za-z0-9]/g, '')));
      const fr = NKRes.dialogToFrm(v.dlg, base, { R: d.R, resName: r.name, file: d.title });
      const ok = await nkAddGenerated([{ path: base + '.frm', text: fr.text }], { pending: { [base]: fr.pending }, projectName: d.title.replace(/\.[^.]*$/, ''), startup: base });
      if (!ok) return;
      const m = findModule(base); if (m) openDesigner(m);
      setStatus(`Form ${base} created from dialog ${NKRes.resName(r.name)}.` + (fr.notes.length ? ' ' + fr.notes.length + ' custom control(s) became Panels.' : ''));
      if (fr.notes.length) imm("' " + base + ':\n' + fr.notes.map(n => "'   " + n).join('\n') + '\n');
    } else if (v.kind === 'dfm') {
      const res = nkDfmToProjectFiles(d, [r], { projectName: 'Converted' });
      const want = res.files.filter(f => /\.(frm|frx)$/i.test(f.path));
      // nomes únicos no projeto aberto
      const frmF = want.find(f => /\.frm$/i.test(f.path)); const nm = frmF.path.replace(/\.frm$/i, '');
      if (IDE.project && findModule(nm)) { await IDE.ui.msgBox(`The project already has a module named ${nm}.`, 48, APP_NAME); return; }
      const extra = IDE.project ? res.files.filter(f => /\.(bas|cls)$/i.test(f.path) && !findModule(f.path.replace(/\.(bas|cls)$/i, ''))) : res.files.filter(f => /\.(bas|cls)$/i.test(f.path));
      const ok = await nkAddGenerated([...want, ...extra].map(f => ({ path: f.path, text: f.text, bytes: f.bytes })), { projectName: d.title.replace(/\.[^.]*$/, ''), startup: nm });
      if (!ok) return;
      const m = findModule(nm); if (m) openDesigner(m);
      setStatus(`Form ${nm} created from the Delphi form inside ${d.title}.`);
    }
  } catch (e) { await IDE.ui.msgBox('Could not create the form:\n\n' + e.message, 16, APP_NAME); }
}
async function nkResCreateAll(d) {
  const R = d.R;
  const dfms = R.res.filter(r => r.type === 10 && r.data.length > 4 && r.data[0] === 0x54 && r.data[1] === 0x50 && r.data[2] === 0x46 && r.data[3] === 0x30);
  const dlgs = R.res.filter(r => r.type === 5);
  const n = dfms.length + dlgs.length; if (!n) return;
  const ok = await IDE.ui.msgBox(`${d.title} has ${dfms.length ? dfms.length + ' Delphi form(s)' : ''}${dfms.length && dlgs.length ? ' and ' : ''}${dlgs.length ? dlgs.length + ' dialog(s)' : ''}.\n\nNeo Kiva will create a new project with all of them. The program code itself is compiled inside the .exe, so event procedures are created empty.\n\nCreate the project now?`, 1 + 32, 'Create Project from Forms');
  if (ok !== 1) return;
  setStatus('Creating forms…');
  try {
    const files = []; const pending = {}; let report = '';
    if (dfms.length) { const res = nkDfmToProjectFiles(d, dfms, { createAll: false }); for (const f of res.files) if (/\.(frm|frx|bas|cls)$/i.test(f.path)) files.push({ path: f.path, text: f.text, bytes: f.bytes }); report = res.reportText || ''; }
    const used = new Set(files.map(f => f.path.replace(/\.[^.]*$/, '').toLowerCase()));
    for (const r of dlgs) {
      let base = 'frmDialog' + (typeof r.name === 'number' ? r.name : String(r.name).replace(/[^A-Za-z0-9]/g, '')); let k = base, i = 2; while (used.has(k.toLowerCase())) k = base + (i++); used.add(k.toLowerCase());
      const fr = NKRes.dialogToFrm(NKRes.viewFor(R, r).dlg, k, { R, resName: r.name, file: d.title }); files.push({ path: k + '.frm', text: fr.text }); pending[k] = fr.pending;
    }
    const firstForm = files.find(f => /\.frm$/i.test(f.path));
    const proj = await nkAddGenerated(files, { newProject: true, pending, projectName: d.title.replace(/\.[^.]*$/, ''), startup: firstForm ? firstForm.path.replace(/\.frm$/i, '') : 'Sub Main' });
    setStatus('Ready');
    if (!proj) return;
    const f = proj.modules.find(m => m.kind === 'form'); if (f) openDesigner(f);
    if (report) imm("' Forms from " + d.title + ':\n' + report.split(/\r?\n/).slice(0, 80).map(l => "' " + l).join('\n') + '\n');
    log(`Project created with ${proj.modules.filter(m => m.kind === 'form').length} form(s) from ${d.title}.`);
  } catch (e) { setStatus('Ready'); await IDE.ui.msgBox('Could not create the project:\n\n' + e.message, 16, APP_NAME); }
}
function nkResSaveRc(d) {
  const L = [`// Resource script extracted by ${APP_NAME} ${APP_VERSION} from ${d.title}`, ''];
  for (const r of d.R.res) {
    const v = NKRes.viewFor(d.R, r);
    if (v.script && v.kind !== 'dfm') L.push(v.script, '');
    else if (r.type === 10) L.push(`${NKRes.resName(r.name)} RCDATA "${String(NKRes.resName(r.name)).toLowerCase()}.${v.save.ext}"`, '');
    else if (r.type === 24) L.push(`${NKRes.resName(r.name)} 24 "manifest.xml"`, '');
  }
  downloadBlob(new Blob([L.join('\r\n')], { type: 'text/plain' }), d.title.replace(/\.[^.]*$/, '') + '.rc');
}

// ---------------------------------------------------------------- tabelas (.dbf) -> banco do projeto
async function nkImportTables(dbName, tables) {
  const P = IDE.project; const stem = dbName.toLowerCase().replace(/\.[^.]*$/, '');
  const cache = IDE.host.dbCache || (IDE.host.dbCache = new Map());
  if (!cache.has(stem) && !findDbFile(dbName)) {
    const SQL = await nbSqlEngine(); const db = new SQL.Database(); registerSqlFunctions(db);
    cache.set(stem, { name: dbName, stem, db, dirty: true, onChange: IDE.host.onDbChange, fromAccess: false });
    P.dbFiles = P.dbFiles || []; P.dbFiles.push({ name: dbName, path: dbName, bytes: new Uint8Array(0), inFolder: false });
  }
  const db = await ideOpenDb(dbName); const sq = db.sqlite;
  ensureMetaTables(sq);
  let total = 0;
  sq.run('BEGIN');
  try {
    for (const t of tables) {
      if (db.findTable(t.name)) sq.run(`DROP TABLE ${qi(t.name)}`);
      sq.run('DELETE FROM _nb_cols WHERE tbl = ?', [t.name]); sq.run('DELETE FROM _nb_fieldui WHERE tbl = ?', [t.name]);
      sq.run(`CREATE TABLE ${qi(t.name)} (${t.fields.map(f => qi(f.name) + ' ' + SQLT_OF[f.kind]).join(', ')})`);
      t.fields.forEach((f, k) => { sq.run('INSERT INTO _nb_cols VALUES (?,?,?,?,?,0)', [t.name, f.name, DAO_OF[f.kind], f.kind === 'text' ? Math.max(1, f.len) : 0, k]); sq.run('INSERT INTO _nb_fieldui VALUES (?,?,?,?)', [t.name, f.name, f.kind, f.name]); });
      if (t.fields.length) { const st = sq.prepare(`INSERT INTO ${qi(t.name)} VALUES (${t.fields.map(() => '?').join(',')})`); for (const row of t.rows) st.run(row); st.free(); }
      total += t.rows.length;
    }
    sq.run('COMMIT');
  } catch (e) { try { sq.run('ROLLBACK'); } catch (e2) { } throw e; }
  const entry = cache.get(stem); if (entry) { entry.dirty = true; entry.colMeta = null; }
  P.dbDirty = true; markDirty(); refreshExplorer(); await refreshDataPanel();
  log(`${tables.length} table(s) and ${total} record(s) copied into ${dbName}.`);
}

// ---------------------------------------------------------------- Clipper
async function nkImportClipper(map, dirHandle) {
  const prgs = [...map.keys()].filter(k => /\.prg$/i.test(k));
  if (!prgs.length) { await IDE.ui.msgBox('No Clipper program was found in this folder.\n\nChoose the folder that contains the .prg files.', 48, APP_NAME); return; }
  const nDbf = [...map.keys()].filter(k => /\.dbf$/i.test(k)).length;
  const ok = await IDE.ui.msgBox(`This folder has ${prgs.length} Clipper program file(s) (.prg)${nDbf ? ` and ${nDbf} table(s) (.dbf)` : ''}.\n\nNeo Kiva will convert the screens (@ SAY / GET, MENU TO, boxes) into forms and the code into modules${nDbf ? ', and copy the tables with all their records into the project database (MySQL)' : ''}. The original files are not changed: the converted project is saved next to them as new files.\n\nConvert now?`, 1 + 32, 'Import Clipper Project');
  if (ok !== 1) return;
  setStatus('Converting the Clipper project…');
  const files = []; for (const [k, e] of map) if (/\.(prg|ch|dbf|dbt|fpt|rmk|lnk|clp|mak)$/i.test(k)) files.push({ path: e.path, bytes: e.bytes });
  let res;
  try { res = NKClipper.convertProject(files); }
  catch (e) { setStatus('Ready'); await IDE.ui.msgBox('The Clipper project could not be converted:\n\n' + e.message, 16, APP_NAME); return; }
  setStatus('Ready');
  const proj = await nkAddGenerated(res.files, { newProject: true, projectName: res.projectName, startup: 'Sub Main' });
  if (!proj) return;
  if (dirHandle) { IDE.dirHandle = res.dir ? await subDirHandle(dirHandle, res.dir) : dirHandle; rememberDir(); }
  proj.clipperReport = res.reportText;
  if (res.tables && res.tables.length) {
    setStatus('Copying the tables into the project database…');
    try { await nkImportTables(res.dbName, res.tables); }
    catch (e) { await IDE.ui.msgBox('The tables could not be copied into the database:\n\n' + (e.description || e.message), 16, APP_NAME); }
    setStatus('Ready');
  }
  log(`Clipper project "${proj.name}" converted (${proj.modules.length} modules).`);
  imm("' Clipper import:\n" + res.reportText.split(/\r?\n/).map(l => "' " + l).join('\n') + '\n');
  const main = proj.modules.find(m => m.kind === 'std' && /main/i.test(m.name)) || proj.modules.find(m => m.kind === 'std'); if (main) openCode(main);
  await ideDialog('Clipper Import', (c, done) => {
    c.innerHTML = `<div style="margin-bottom:8px"><b>The Clipper project was converted.</b></div><textarea spellcheck="false" readonly style="width:560px;height:280px;font:12px 'NB Mono',monospace"></textarea><div style="margin-top:6px;opacity:.8">Press F5 to run it. Save (Ctrl+S) writes the Neo Kiva files next to the .prg files and stores the tables in MySQL. In the code, search for <b>[Clipper]</b> to find what needs attention.</div><div class="btns"><button class="nb-btn">OK</button></div>`;
    c.querySelector('textarea').value = res.reportText; const b = c.querySelector('button'); b.onclick = () => done(true); return b;
  });
}

// ---------- 0.1.4: aviso de versão nova instalada ----------
// Uma janela do Neo Kiva que já estava aberta continua com a versão antiga na memória, mesmo depois de
// instalar uma nova. Ao voltar para a janela, confere a versão do arquivo e oferece recarregar.
(function nkVersionWatch() {
  if (!/^https?:/.test(location.protocol)) return;
  let last = 0, shown = false;
  const check = async () => {
    if (shown || Date.now() - last < 15000) return; last = Date.now();
    try {
      const t = await fetch(location.pathname, { cache: 'no-store' }).then(r => r.ok ? r.text() : '');
      const m = /const APP_VERSION = '([^']+)'/.exec(t);
      if (!m || m[1] === APP_VERSION) return;
      shown = true;
      const bar = document.createElement('div');
      bar.style.cssText = 'position:fixed;left:50%;top:10px;transform:translateX(-50%);z-index:99999;display:flex;gap:12px;align-items:center;padding:10px 12px 10px 18px;background:#fff8e1;border:1px solid #f0c36d;border-radius:999px;box-shadow:0 6px 18px rgba(0,0,0,.18);font:13px "NB Inter",sans-serif;color:#3a2a00';
      bar.innerHTML = `<span>Neo Kiva <b>${m[1]}</b> is installed, but this window is still running <b>${APP_VERSION}</b>. Save your work, then reload.</span>`;
      const b = document.createElement('button'); b.textContent = 'Reload';
      b.style.cssText = 'border:none;border-radius:999px;background:#005fb8;color:#fff;padding:6px 16px;font:600 12px "NB Inter",sans-serif;cursor:default';
      b.onclick = async () => {
        const dirty = IDE.project && (IDE.project.dirty || IDE.project.modules.some(x => x.dirty));
        if (dirty && !(await IDE.ui.msgBox('This project has unsaved changes. Reload anyway?', 4 + 48, APP_NAME) === 6)) return;
        window.onbeforeunload = null; location.reload();
      };
      const x = document.createElement('button'); x.textContent = '✕'; x.title = 'Later';
      x.style.cssText = 'border:none;background:transparent;color:#6b5500;font-size:13px;cursor:default';
      x.onclick = () => bar.remove();
      bar.append(b, x); document.body.appendChild(bar);
    } catch (e) { }
  };
  window.addEventListener('focus', check);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
  setTimeout(check, 20000);
})();
