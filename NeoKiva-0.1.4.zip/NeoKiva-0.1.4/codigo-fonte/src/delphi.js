// ===== Neo Kiva — importador de projetos Delphi (.dpr, .dproj, .dfm, .pas) =====
// Converte um projeto Delphi VCL em um projeto Neo Kiva/VB (.vbp, .frm, .bas, .cls).
// Fase 1: formulários (DFM texto e binário), controles VCL comuns, eventos e o código
// Object Pascal mais usado (procedimentos, funções, if/for/while/repeat/case/with/try).
// O que não for traduzido fica comentado no código com a marca  ' [Delphi]
const DelphiImport = (() => {
  'use strict';

  // ---------------------------------------------------------------- texto
  function decodeBytes(u8) {
    if (typeof u8 === 'string') return u8;
    if (u8.length >= 3 && u8[0] === 0xEF && u8[1] === 0xBB && u8[2] === 0xBF) return new TextDecoder('utf-8').decode(u8.subarray(3));
    if (u8.length >= 2 && u8[0] === 0xFF && u8[1] === 0xFE) return new TextDecoder('utf-16le').decode(u8.subarray(2));
    try { return new TextDecoder('utf-8', { fatal: true }).decode(u8); } catch (e) { return new TextDecoder('windows-1252').decode(u8); }
  }
  const vbStr = s => '"' + String(s).replace(/"/g, '""') + '"';
  // string com quebras/tabs/controles -> expressão VB
  function vbStrExpr(s) {
    s = String(s);
    if (!/[\x00-\x1f]/.test(s)) return vbStr(s);
    const parts = []; let buf = '';
    const flush = () => { if (buf) { parts.push(vbStr(buf)); buf = ''; } };
    for (let i = 0; i < s.length; i++) {
      const c = s[i], n = s.charCodeAt(i);
      if (c === '\r' && s[i + 1] === '\n') { flush(); parts.push('vbCrLf'); i++; }
      else if (c === '\r') { flush(); parts.push('vbCr'); }
      else if (c === '\n') { flush(); parts.push('vbLf'); }
      else if (c === '\t') { flush(); parts.push('vbTab'); }
      else if (n < 32) { flush(); parts.push(`Chr(${n})`); }
      else buf += c;
    }
    flush();
    return parts.join(' & ') || '""';
  }

  // ---------------------------------------------------------------- DFM (texto)
  function lexDfm(src) {
    const toks = []; let i = 0; const n = src.length;
    const isId = c => /[\p{L}\p{N}_.]/u.test(c);
    while (i < n) {
      const c = src[i];
      if (c === ' ' || c === '\t' || c === '\r' || c === '\n') { i++; continue; }
      if (c === "'" || c === '#') {
        // sequência de strings e #códigos, possivelmente unidas por '+' entre linhas
        let s = '';
        for (;;) {
          if (src[i] === "'") {
            i++;
            for (;;) { if (i >= n) break; if (src[i] === "'") { if (src[i + 1] === "'") { s += "'"; i += 2; continue; } i++; break; } s += src[i++]; }
          } else if (src[i] === '#') {
            i++; let num = '';
            if (src[i] === '$') { i++; while (/[0-9A-Fa-f]/.test(src[i] || '')) num += src[i++]; s += String.fromCharCode(parseInt(num, 16)); }
            else { while (/[0-9]/.test(src[i] || '')) num += src[i++]; s += String.fromCharCode(parseInt(num, 10)); }
          } else {
            // '+' continuando na próxima linha
            let j = i; while (j < n && /[ \t]/.test(src[j])) j++;
            if (src[j] === '+') { j++; while (j < n && /\s/.test(src[j])) j++; if (src[j] === "'" || src[j] === '#') { i = j; continue; } }
            break;
          }
        }
        toks.push({ t: 'str', v: s }); continue;
      }
      if (c === '{') { let j = src.indexOf('}', i); if (j < 0) j = n; toks.push({ t: 'bin', v: src.slice(i + 1, j).replace(/\s+/g, '') }); i = j + 1; continue; }
      if (c === '$' || /[0-9]/.test(c) || ((c === '-' || c === '+') && /[0-9$.]/.test(src[i + 1] || ''))) {
        let j = i + 1; while (j < n && /[0-9A-Fa-f.xXeE$]/.test(src[j])) { if ((src[j] === 'e' || src[j] === 'E') && (src[j + 1] === '-' || src[j + 1] === '+')) j++; j++; }
        const raw = src.slice(i, j); i = j;
        let v;
        if (/\$/.test(raw)) { const neg = raw[0] === '-'; v = parseInt(raw.replace(/[-+$]/g, ''), 16); if (neg) v = -v; if (v > 0x7fffffff && !neg) v = v - 0x100000000; toks.push({ t: 'int', v }); }
        else if (/[.eE]/.test(raw)) toks.push({ t: 'float', v: parseFloat(raw) });
        else toks.push({ t: 'int', v: parseInt(raw, 10) });
        continue;
      }
      if (/[\p{L}_]/u.test(c)) { let j = i; while (j < n && isId(src[j])) j++; toks.push({ t: 'id', v: src.slice(i, j) }); i = j; continue; }
      toks.push({ t: 'sym', v: c }); i++;
    }
    toks.push({ t: 'eof' });
    return toks;
  }
  function parseDfmText(src) {
    const toks = lexDfm(src); let p = 0;
    const peek = () => toks[p], next = () => toks[p++];
    const isKw = (t, w) => t.t === 'id' && t.v.toLowerCase() === w;
    const expectSym = s => { const t = next(); if (t.t !== 'sym' || t.v !== s) throw new Error(`DFM: expected '${s}'`); };
    function value() {
      const t = next();
      if (t.t === 'str' || t.t === 'int' || t.t === 'float' || t.t === 'bin') return t;
      if (t.t === 'id') { const l = t.v.toLowerCase(); if (l === 'true' || l === 'false') return { t: 'bool', v: l === 'true' }; return { t: 'ident', v: t.v }; }
      if (t.t === 'sym' && t.v === '[') { const v = []; while (!(peek().t === 'sym' && peek().v === ']')) { const x = next(); if (x.t === 'id' || x.t === 'int') v.push(x.v); } next(); return { t: 'set', v }; }
      if (t.t === 'sym' && t.v === '(') { const v = []; while (!(peek().t === 'sym' && peek().v === ')')) { if (peek().t === 'sym' && peek().v === ',') { next(); continue; } v.push(value()); } next(); return { t: 'list', v }; }
      if (t.t === 'sym' && t.v === '<') {
        const items = [];
        while (!(peek().t === 'sym' && peek().v === '>')) {
          const it = next();
          if (isKw(it, 'item')) {
            const props = new Map();
            if (peek().t === 'sym' && peek().v === '[') { next(); next(); expectSym(']'); }
            while (!isKw(peek(), 'end')) { const k = next(); expectSym('='); props.set(k.v.toLowerCase(), { key: k.v, v: value() }); }
            next(); items.push(props);
          } else if (it.t === 'eof') break;
        }
        next(); return { t: 'coll', v: items };
      }
      if (t.t === 'sym' && t.v === '-' && peek().t === 'int') { const x = next(); return { t: 'int', v: -x.v }; }
      return { t: 'ident', v: t.v || '' };
    }
    function object() {
      const kw = next(); // object | inherited | inline
      let name = '', cls = '';
      const a = next();
      if (peek().t === 'sym' && peek().v === ':') { next(); name = a.v; cls = next().v; } else cls = a.v;
      if (peek().t === 'sym' && peek().v === '[') { next(); while (!(peek().t === 'sym' && peek().v === ']')) next(); next(); }
      const node = { kind: kw.v.toLowerCase(), name, cls, props: new Map(), children: [] };
      for (;;) {
        const t = peek();
        if (t.t === 'eof') break;
        if (isKw(t, 'end')) { next(); break; }
        if (isKw(t, 'object') || isKw(t, 'inherited') || isKw(t, 'inline')) { node.children.push(object()); continue; }
        if (t.t === 'id') { next(); expectSym('='); node.props.set(t.v.toLowerCase(), { key: t.v, v: value() }); continue; }
        next();
      }
      return node;
    }
    while (p < toks.length && !(isKw(peek(), 'object') || isKw(peek(), 'inherited') || isKw(peek(), 'inline'))) { if (peek().t === 'eof') throw new Error('DFM: no object found'); p++; }
    return object();
  }

  // ---------------------------------------------------------------- DFM (binário, "TPF0")
  function parseDfmBinary(u8) {
    let p = 4; const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const byte = () => u8[p++];
    const sstr = () => { const l = byte(); const s = new TextDecoder('windows-1252').decode(u8.subarray(p, p + l)); p += l; return s; };
    const lstr = () => { const l = dv.getUint32(p, true); p += 4; const s = new TextDecoder('windows-1252').decode(u8.subarray(p, p + l)); p += l; return s; };
    function val() {
      const t = byte();
      switch (t) {
        case 0: return { t: 'ident', v: '' };
        case 1: { const v = []; while (u8[p] !== 0) v.push(val()); p++; return { t: 'list', v }; }
        case 2: { const v = dv.getInt8(p); p += 1; return { t: 'int', v }; }
        case 3: { const v = dv.getInt16(p, true); p += 2; return { t: 'int', v }; }
        case 4: { const v = dv.getInt32(p, true); p += 4; return { t: 'int', v }; }
        case 5: { // extended 80 bits
          const lo = dv.getUint32(p, true), hi = dv.getUint32(p + 4, true), se = dv.getUint16(p + 8, true); p += 10;
          const sign = se & 0x8000 ? -1 : 1, e = se & 0x7fff; const mant = hi * 4294967296 + lo;
          return { t: 'float', v: e === 0 && mant === 0 ? 0 : sign * mant * Math.pow(2, e - 16383 - 63) };
        }
        case 6: return { t: 'str', v: sstr() };
        case 7: return { t: 'ident', v: sstr() };
        case 8: return { t: 'bool', v: false };
        case 9: return { t: 'bool', v: true };
        case 10: { const l = dv.getUint32(p, true); p += 4; const h = [...u8.subarray(p, p + l)].map(b => b.toString(16).padStart(2, '0')).join(''); p += l; return { t: 'bin', v: h }; }
        case 11: { const v = []; for (;;) { const s = sstr(); if (!s) break; v.push(s); } return { t: 'set', v }; }
        case 12: return { t: 'str', v: lstr() };
        case 13: return { t: 'ident', v: 'nil' };
        case 14: { const items = []; while (u8[p] !== 0) { const tag = u8[p]; if (tag >= 2 && tag <= 4) val(); if (u8[p] === 1) p++; /* vaList de cada item */ const props = new Map(); while (u8[p] !== 0) { const k = sstr(); props.set(k.toLowerCase(), { key: k, v: val() }); } p++; items.push(props); } p++; return { t: 'coll', v: items }; }
        case 15: { const v = dv.getFloat32(p, true); p += 4; return { t: 'float', v }; }
        case 16: { const lo = dv.getUint32(p, true), hi = dv.getInt32(p + 4, true); p += 8; return { t: 'float', v: (hi * 4294967296 + lo) / 10000 }; }
        case 17: { const v = dv.getFloat64(p, true); p += 8; return { t: 'float', v }; }
        case 18: { const l = dv.getUint32(p, true); p += 4; const s = new TextDecoder('utf-16le').decode(u8.subarray(p, p + l * 2)); p += l * 2; return { t: 'str', v: s }; }
        case 19: { const lo = dv.getUint32(p, true), hi = dv.getInt32(p + 4, true); p += 8; return { t: 'int', v: hi * 4294967296 + lo }; }
        case 20: { const l = dv.getUint32(p, true); p += 4; const s = new TextDecoder('utf-8').decode(u8.subarray(p, p + l)); p += l; return { t: 'str', v: s }; }
        case 21: { const v = dv.getFloat64(p, true); p += 8; return { t: 'float', v }; }
        default: throw new Error('DFM: unknown binary value type ' + t);
      }
    }
    function object() {
      let kind = 'object';
      if ((u8[p] & 0xF0) === 0xF0) { const f = byte(); if (f & 1) kind = 'inherited'; if (f & 4) kind = 'inline'; if (f & 2) val(); }
      const cls = sstr(), name = sstr();
      const node = { kind, name, cls, props: new Map(), children: [] };
      while (u8[p] !== 0) { const k = sstr(); node.props.set(k.toLowerCase(), { key: k, v: val() }); }
      p++;
      while (u8[p] !== 0) node.children.push(object());
      p++;
      return node;
    }
    return object();
  }
  function parseDfm(data) {
    if (typeof data !== 'string' && data.length > 4 && data[0] === 0x54 && data[1] === 0x50 && data[2] === 0x46 && data[3] === 0x30) return parseDfmBinary(data);
    return parseDfmText(decodeBytes(data));
  }
  const pv = (node, key) => { const e = node.props.get(key.toLowerCase()); return e ? e.v : undefined; };
  const pStr = (node, key, def) => { const v = pv(node, key); if (!v) return def; if (v.t === 'str' || v.t === 'ident') return String(v.v); if (v.t === 'int' || v.t === 'float') return String(v.v); return def; };
  const pNum = (node, key, def) => { const v = pv(node, key); return v && (v.t === 'int' || v.t === 'float') ? v.v : def; };
  const pBool = (node, key, def) => { const v = pv(node, key); return v && v.t === 'bool' ? v.v : def; };
  const pIdent = (node, key, def) => { const v = pv(node, key); return v && v.t === 'ident' ? v.v : def; };
  const pList = (node, key) => { const v = pv(node, key); return v && v.t === 'list' ? v.v.map(x => x.t === 'str' ? x.v : String(x.v)) : null; };
  const pSet = (node, key) => { const v = pv(node, key); return v && v.t === 'set' ? v.v.map(s => String(s).toLowerCase()) : null; };

  // ---------------------------------------------------------------- cores
  const SYS = { clscrollbar: 0, clbackground: 1, clactivecaption: 2, clinactivecaption: 3, clmenu: 4, clwindow: 5, clwindowframe: 6, clmenutext: 7, clwindowtext: 8, clcaptiontext: 9, clactiveborder: 10, clinactiveborder: 11, clappworkspace: 12, clhighlight: 13, clhighlighttext: 14, clbtnface: 15, clbtnshadow: 16, clgraytext: 17, clbtntext: 18, clinactivecaptiontext: 19, clbtnhighlight: 20, cl3ddkshadow: 21, cl3dlight: 22, clinfotext: 23, clinfobk: 24, clhotlight: 26, clgradientactivecaption: 27, clgradientinactivecaption: 28, clmenuhighlight: 29, clmenubar: 30 };
  const NAMED = { clblack: 0x000000, clmaroon: 0x000080, clgreen: 0x008000, clolive: 0x008080, clnavy: 0x800000, clpurple: 0x800080, clteal: 0x808000, clgray: 0x808080, clsilver: 0xC0C0C0, clred: 0x0000FF, cllime: 0x00FF00, clyellow: 0x00FFFF, clblue: 0xFF0000, clfuchsia: 0xFF00FF, claqua: 0xFFFF00, clltgray: 0xC0C0C0, cldkgray: 0x808080, clwhite: 0xFFFFFF, clmoneygreen: 0xC0DCC0, clskyblue: 0xF0CAA6, clcream: 0xF0FBFF, clmedgray: 0xA4A0A0, clwebwhite: 0xFFFFFF, clwebblack: 0, clweborange: 0x00A5FF, clwebgold: 0x00D7FF };
  // devolve número de cor VB (sistema: &H800000xx) ou null
  function colorValue(v) {
    if (!v) return null;
    if (v.t === 'int') { const n = v.v; if (n < 0 || n >= 0x80000000) { const idx = (n >>> 0) & 0xFF; return 0x80000000 + idx; } return n & 0xFFFFFF; }
    if (v.t === 'ident') { const k = v.v.toLowerCase(); if (k in SYS) return 0x80000000 + SYS[k]; if (k in NAMED) return NAMED[k]; if (k === 'cldefault' || k === 'clnone') return null; }
    return null;
  }
  const colorRawVB = n => '&H' + (n >>> 0).toString(16).toUpperCase().padStart(8, '0') + '&';
  function colorIdentVB(name) { const k = name.toLowerCase(); if (k in SYS) return colorRawVB(0x80000000 + SYS[k]); if (k in NAMED) return colorRawVB(NAMED[k]); return null; }

  // ---------------------------------------------------------------- mapeamento VCL -> VB
  const KIND = {
    tlabel: 'label', tstatictext: 'label', tdbtext: 'label',
    tedit: 'edit', tmaskedit: 'edit', tlabelededit: 'edit', tdbedit: 'edit', tbuttonededit: 'edit', tspinedit: 'edit', tnumberbox: 'edit', tsearchbox: 'edit',
    tmemo: 'memo', tdbmemo: 'memo', trichedit: 'rich', tdbrichedit: 'rich',
    tbutton: 'button', tbitbtn: 'button', tspeedbutton: 'button',
    tcheckbox: 'check', tdbcheckbox: 'check', ttoggleswitch: 'check',
    tradiobutton: 'radio',
    tlistbox: 'list', tdblistbox: 'list', tchecklistbox: 'list',
    tcombobox: 'combo', tdbcombobox: 'combo', tcomboboxex: 'combo', tdblookupcombobox: 'combo',
    tgroupbox: 'group', tradiogroup: 'radiogroup', tdbradiogroup: 'radiogroup',
    tpanel: 'panel', tflowpanel: 'panel', tgridpanel: 'panel', tscrollbox: 'panel', tcategorypanel: 'panel', trelativepanel: 'panel', tcard: 'panel', tcardpanel: 'panel',
    timage: 'image', tdbimage: 'image', tpaintbox: 'paintbox',
    tshape: 'shape', tbevel: 'bevel',
    ttimer: 'timer',
    tscrollbar: 'scrollbar', ttrackbar: 'trackbar', tprogressbar: 'progress', tupdown: 'skip',
    tpagecontrol: 'pages', ttabcontrol: 'pages', ttabsheet: 'sheet',
    tstringgrid: 'grid', tdrawgrid: 'grid', tdbgrid: 'grid', tlistview: 'grid', tvaluelisteditor: 'grid',
    tdatetimepicker: 'date', tmonthcalendar: 'date', tcalendarpicker: 'date', tdatepicker: 'date',
    ttreeview: 'tree',
    tstatusbar: 'status',
    tmainmenu: 'mainmenu', tpopupmenu: 'popupmenu', tmenuitem: 'menuitem',
    topendialog: 'opendlg', tsavedialog: 'savedlg', topenpicturedialog: 'opendlg', tsavepicturedialog: 'savedlg', topentextfiledialog: 'opendlg', tsavetextfiledialog: 'savedlg',
    tcolordialog: 'colordlg', tfontdialog: 'fontdlg', tprintdialog: 'printdlg', tprintersetupdialog: 'printdlg', tfindialog: 'skipnv', treplacedialog: 'skipnv',
    ttoolbar: 'toolbar', ttoolbutton: 'toolbutton', tcoolbar: 'panel', tcontrolbar: 'panel',
    tactionlist: 'actionlist', tactionmanager: 'actionmanager', taction: 'action',
    tsplitter: 'skip', tformtabsbar: 'skip', tactionmainmenubar: 'actionmenubar', tactiontoolbar: 'skip',
    timagelist: 'skipnv', tvirtualimagelist: 'skipnv', timagecollection: 'skipnv', tapplicationevents: 'skipnv', ttrayicon: 'skipnv', tballoonhint: 'skipnv', tstylebook: 'skipnv',
    tdbnavigator: 'navigator',
    twebbrowser: 'web', tedgebrowser: 'web',
  };
  const DATA_CLASSES = /^t(table|query|datasource|database|session|fdconnection|fdquery|fdtable|fdmemtable|fdstoredproc|fdtransaction|fdphysmysqldriverlink|fdphyssqlitedriverlink|fdguixwaitcursor|adoconnection|adoquery|adotable|adodataset|adocommand|clientdataset|datasetprovider|sqlconnection|sqlquery|sqltable|sqldataset|ibdatabase|ibquery|ibtable|ibtransaction|sqlite.*|zconnection|zquery|ztable|uniconnection|uniquery|unitable|mysqlconnection|mysqlquery|bindingslist|bindsourcedb|bindsourcedbx|prototypebindsource|fdbatchmove.*|fdscript|rest.*|indy.*|id.*)$/i;

  // ---------------------------------------------------------------- escritor de .frm
  class FrmWriter {
    constructor() { this.lines = []; }
    prop(ind, name, value, comment) { this.lines.push(' '.repeat(ind) + name.padEnd(16) + '=   ' + value + (comment ? '   \'' + comment : '')); }
    raw(ind, s) { this.lines.push(' '.repeat(ind) + s); }
  }
  const vbBool = b => b ? '-1  \'True' : '0   \'False';

  // contexto de conversão de um formulário
  // imagem embutida (Picture.Data / Glyph.Data / Icon.Data) -> bytes do arquivo de imagem
  function delphiPicture(v, isGlyph) {
    if (!v || v.t !== 'bin' || !v.v) return null;
    const hex = v.v; const b = new Uint8Array(hex.length >> 1);
    for (let i = 0; i < b.length; i++) b[i] = parseInt(hex.substr(i * 2, 2), 16);
    let p = 0;
    if (!isGlyph) { const n = b[0]; if (n > 0 && n < 64 && 1 + n <= b.length) p = 1 + n; }
    const magic = (q) => (b[q] === 0x89 && b[q + 1] === 0x50 && b[q + 2] === 0x4E && b[q + 3] === 0x47) || (b[q] === 0xFF && b[q + 1] === 0xD8) || (b[q] === 0x42 && b[q + 1] === 0x4D) || (b[q] === 0x47 && b[q + 1] === 0x49 && b[q + 2] === 0x46) || (b[q] === 0 && b[q + 1] === 0 && b[q + 2] === 1 && b[q + 3] === 0);
    for (let q = p; q < Math.min(b.length - 4, p + 16); q++) if (magic(q)) return b.subarray(q);
    return null;
  }
  class FormConv {
    constructor(root, unitName, report, opts) {
      this.frxParts = []; this.frxSize = 0;
      this.root = root; this.unitName = unitName; this.report = report; this.opts = opts || {};
      this.ppi = pNum(root, 'PixelsPerInch', 96) || 96;
      this.k = 1440 / this.ppi; // px -> twips
      this.controls = new Map(); // nome minúsculo -> {name, vcl, kind, vbType, extra}
      this.events = []; // {ctl, vclEvent, handler, kind, vbType}
      this.init = []; // linhas VB para Form_Load (antes do OnCreate)
      this.extraCode = []; // subs auxiliares
      this.actions = new Map(); // nome -> {caption, onExecute, std, enabled, visible, checked, hint}
      this.menuNames = new Set();
      this.names = new Set();
      this.isMDI = /fsmdiform/i.test(pIdent(root, 'FormStyle', ''));
      this.isMDIChild = /fsmdichild/i.test(pIdent(root, 'FormStyle', ''));
      this.formFont = this.fontOf(root, null);
      this.radioGroups = new Map();
      this.pages = new Map();
      this.panelCaps = new Map();
      this.modalButtons = [];
    }
    tw(px) { return Math.round((px || 0) * this.k); }
    warn(msg) { this.report.warn(`${this.unitName}: ${msg}`); }
    uniq(name) { let n = name, i = 2; while (this.names.has(n.toLowerCase())) n = name + (i++); this.names.add(n.toLowerCase()); return n; }
    fontOf(node, parentFont) {
      const base = parentFont ? Object.assign({}, parentFont) : { name: 'MS Sans Serif', size: 8.25, bold: false, italic: false, underline: false, strike: false, color: null };
      const parentFontFlag = pBool(node, 'ParentFont', !!parentFont && !node.props.has('font.name') && !node.props.has('font.height') && !node.props.has('font.size') && !node.props.has('font.style'));
      if (parentFont && parentFontFlag && !node.props.has('font.name') && !node.props.has('font.height')) { const c = colorValue(pv(node, 'Font.Color')); if (c != null) base.color = c; return base; }
      const nm = pStr(node, 'Font.Name', null); if (nm && nm.toLowerCase() !== 'default') base.name = nm;
      const h = pNum(node, 'Font.Height', null); const sz = pNum(node, 'Font.Size', null);
      if (h != null) base.size = Math.round(Math.abs(h) * 72 / this.ppi * 4) / 4; else if (sz != null) base.size = sz;
      const st = pSet(node, 'Font.Style');
      if (st) { base.bold = st.includes('fsbold'); base.italic = st.includes('fsitalic'); base.underline = st.includes('fsunderline'); base.strike = st.includes('fsstrikeout'); }
      const c = colorValue(pv(node, 'Font.Color')); if (c != null) base.color = c;
      return base;
    }
    writeFont(w, ind, f) {
      if (!f) return;
      if (f.name === 'MS Sans Serif' && f.size === 8.25 && !f.bold && !f.italic && !f.underline && !f.strike) return;
      w.raw(ind, 'BeginProperty Font ');
      w.prop(ind + 3, 'Name', vbStr(f.name)); w.prop(ind + 3, 'Size', String(f.size)); w.prop(ind + 3, 'Charset', '0');
      w.prop(ind + 3, 'Weight', f.bold ? '700' : '400'); w.prop(ind + 3, 'Underline', vbBool(f.underline)); w.prop(ind + 3, 'Italic', vbBool(f.italic)); w.prop(ind + 3, 'Strikethrough', vbBool(f.strike));
      w.raw(ind, 'EndProperty');
    }
    // ----- coleta: ações, nomes
    collect(node) {
      for (const ch of node.children) {
        const cls = ch.cls.toLowerCase();
        if (ch.name) this.names.add(ch.name.toLowerCase());
        if (/action/.test(KIND[cls] || '') || /^t(action|editcut|editcopy|editpaste|editselectall|editundo|editdelete|fileexit|fileopen|filesaveas|windowcascade|windowtilehorizontal|windowtilevertical|windowminimizeall|windowclose|windowarrange|helpabout|fileprintsetup|searchfind)/.test(cls) || /^t(edit|file|window|help|search|format|list|dataset)\w+$/.test(cls) && node.cls && /tactionlist|tactionmanager/i.test(node.cls)) {
          if (cls !== 'tactionlist' && cls !== 'tactionmanager') this.actions.set(ch.name.toLowerCase(), { name: ch.name, cls, caption: pStr(ch, 'Caption', null), onExecute: pIdent(ch, 'OnExecute', null), enabled: pBool(ch, 'Enabled', true), visible: pBool(ch, 'Visible', true), checked: pBool(ch, 'Checked', false), hint: pStr(ch, 'Hint', null), shortcut: pNum(ch, 'ShortCut', null) });
        }
        this.collect(ch);
      }
    }
    stdActionCaption(a) {
      const m = { teditcut: 'Cu&t', teditcopy: '&Copy', teditpaste: '&Paste', teditselectall: 'Select &All', teditundo: '&Undo', teditdelete: '&Delete', tfileexit: 'E&xit', tfileopen: '&Open...', tfilesaveas: 'Save &As...', twindowcascade: '&Cascade', twindowtilehorizontal: 'Tile &Horizontally', twindowtilevertical: 'Tile &Vertically', twindowminimizeall: '&Minimize All', twindowclose: 'C&lose', twindowarrange: '&Arrange', thelpabout: '&About...', tfileprintsetup: 'Print Set&up...' };
      return a.caption != null ? a.caption : (m[a.cls] || a.name);
    }
    // código VB que executa uma ação (para menus/botões ligados a Action)
    actionCall(a, senderExpr) {
      if (a.onExecute) return `${a.onExecute} ${senderExpr}`;
      switch (a.cls) {
        case 'tfileexit': return 'Unload Me';
        case 'twindowcascade': return 'Me.Arrange 0';
        case 'twindowtilehorizontal': return 'Me.Arrange 1';
        case 'twindowtilevertical': return 'Me.Arrange 2';
        case 'twindowarrange': return 'Me.Arrange 3';
        case 'twindowclose': return 'If Not Me.ActiveForm Is Nothing Then Unload Me.ActiveForm';
        case 'twindowminimizeall': return 'Dim f As Object\nFor Each f In Forms\n    If f.MDIChild Then f.WindowState = 1\nNext';
        case 'teditcut': case 'teditcopy': case 'teditpaste': case 'teditselectall': case 'teditundo': case 'teditdelete': return `' [Delphi] standard action ${a.name} (${a.cls.slice(1)}) is not supported yet`;
        default: return `' [Delphi] action ${a.name} has no OnExecute handler`;
      }
    }
    // grava a imagem no .frx do formulário e devolve o valor da propriedade
    addPicture(bytes) {
      const off = this.frxSize; const hdr = new Uint8Array(4); new DataView(hdr.buffer).setUint32(0, bytes.length, true);
      this.frxParts.push(hdr, bytes); this.frxSize += 4 + bytes.length;
      return `"${this.formName}.frx":${off.toString(16).toUpperCase().padStart(4, '0')}`;
    }
    frxBytes() { if (!this.frxSize) return null; const out = new Uint8Array(this.frxSize); let p = 0; for (const x of this.frxParts) { out.set(x, p); p += x.length; } return out; }
    // ----- conversão
    convert() {
      this.collect(this.root);
      const w = new FrmWriter();
      const R = this.root;
      const formName = R.name || this.unitName;
      this.formName = formName;
      w.raw(0, 'VERSION 5.00');
      w.raw(0, `Begin VB.${this.isMDI ? 'MDIForm' : 'Form'} ${formName} `);
      const ind = 3;
      const bs = pIdent(R, 'BorderStyle', 'bsSizeable').toLowerCase();
      const bsMap = { bsnone: 0, bssingle: 1, bssizeable: 2, bsdialog: 3, bstoolwindow: 4, bssizetoolwin: 5 };
      if (!this.isMDI && bs !== 'bssizeable') w.prop(ind, 'BorderStyle', String(bsMap[bs] ?? 2));
      const bg = colorValue(pv(R, 'Color'));
      if (bg != null && bg !== 0x8000000F) w.prop(ind, 'BackColor', colorRawVB(bg));
      w.prop(ind, 'Caption', vbStr(pStr(R, 'Caption', formName)));
      const cw = pNum(R, 'ClientWidth', null) ?? (pNum(R, 'Width', 400) - 16);
      const ch = pNum(R, 'ClientHeight', null) ?? (pNum(R, 'Height', 300) - 39);
      this.clientW = cw; this.clientH = ch;
      w.prop(ind, 'ClientHeight', String(this.tw(ch)));
      w.prop(ind, 'ClientLeft', String(this.tw(pNum(R, 'Left', 100))));
      w.prop(ind, 'ClientTop', String(this.tw(pNum(R, 'Top', 100))));
      w.prop(ind, 'ClientWidth', String(this.tw(cw)));
      if (!this.isMDI) this.writeFont(w, ind, this.formFont);
      const fc = this.formFont && this.formFont.color; if (!this.isMDI && fc != null && fc !== 0x80000012 && fc !== 0) w.prop(ind, 'ForeColor', colorRawVB(fc));
      if (pBool(R, 'KeyPreview', false)) w.prop(ind, 'KeyPreview', vbBool(true));
      const icons = pSet(R, 'BorderIcons');
      if (icons && !this.isMDI) { if (!icons.includes('bimaximize')) w.prop(ind, 'MaxButton', vbBool(false)); if (!icons.includes('biminimize')) w.prop(ind, 'MinButton', vbBool(false)); if (!icons.includes('bisystemmenu')) w.prop(ind, 'ControlBox', vbBool(false)); }
      else if (bs === 'bsdialog' && !this.isMDI) { w.prop(ind, 'MaxButton', vbBool(false)); w.prop(ind, 'MinButton', vbBool(false)); }
      if (this.isMDIChild) w.prop(ind, 'MDIChild', vbBool(true));
      if (!this.isMDI) w.prop(ind, 'ScaleMode', '3  \'Pixel');
      const pos = pIdent(R, 'Position', 'poDesigned').toLowerCase();
      const posMap = { podesigned: 0, podefault: 3, podefaultposonly: 3, podefaultsizeonly: 0, poscreencenter: 2, podesktopcenter: 2, pomainformcenter: 1, poownerformcenter: 1 };
      w.prop(ind, 'StartUpPosition', String(posMap[pos] ?? 0));
      const ws = pIdent(R, 'WindowState', 'wsNormal').toLowerCase();
      if (ws === 'wsmaximized') w.prop(ind, 'WindowState', '2  \'Maximized'); else if (ws === 'wsminimized') w.prop(ind, 'WindowState', '1  \'Minimized');
      if (R.props.has('hint') && pStr(R, 'Hint', '')) { /* forms have no tooltip in VB */ }
      // eventos do formulário
      this.addEvents(R, null, 'form');
      // filhos (menus primeiro para o VB, depois controles)
      const menus = R.children.filter(c => /^(tmainmenu)$/i.test(c.cls));
      const popups = R.children.filter(c => /^(tpopupmenu)$/i.test(c.cls));
      const amb = this.findActionMenuBar(R);
      for (const c of R.children) this.convertNode(w, c, ind, this.formFont, { w: cw, h: ch }, null);
      for (const m of menus) for (const it of m.children) this.convertMenu(w, it, ind);
      if (!menus.length && amb) this.convertActionMenu(w, amb, ind);
      for (const pm of popups) { const top = this.uniq(pm.name); this.controls.set(pm.name.toLowerCase(), { name: top, vcl: 'tpopupmenu', kind: 'popupmenu', vbType: 'VB.Menu' }); w.raw(ind, `Begin VB.Menu ${top} `); w.prop(ind + 3, 'Caption', vbStr(pm.name)); w.prop(ind + 3, 'Visible', vbBool(false)); for (const it of pm.children) this.convertMenu(w, it, ind + 3); w.raw(ind, 'End'); }
      w.raw(0, 'End');
      w.raw(0, `Attribute VB_Name = "${formName}"`);
      w.raw(0, 'Attribute VB_GlobalNameSpace = False');
      w.raw(0, 'Attribute VB_Creatable = False');
      w.raw(0, 'Attribute VB_PredeclaredId = True');
      w.raw(0, 'Attribute VB_Exposed = False');
      return w.lines.join('\r\n') + '\r\n';
    }
    findActionMenuBar(node) { for (const c of node.children) { if (/^tactionmainmenubar$/i.test(c.cls)) return c; const r = this.findActionMenuBar(c); if (r) return r; } return null; }
    // eventos de um componente
    addEvents(node, ctlName, kind, vbType) {
      for (const [k, e] of node.props) {
        if (!/^on[a-z]/.test(k) || e.v.t !== 'ident') continue;
        this.events.push({ ctl: ctlName, vclEvent: e.key, handler: e.v.v, kind, vbType, vcl: node.cls.toLowerCase(), node });
      }
      const act = pIdent(node, 'Action', null);
      if (act && ctlName && this.actions.has(act.toLowerCase())) this.events.push({ ctl: ctlName, vclEvent: 'OnClick', action: this.actions.get(act.toLowerCase()), kind, vbType, vcl: node.cls.toLowerCase(), node });
    }
    common(w, ind, node, P, opts = {}) {
      // posição e tamanho (twips), em relação ao contêiner
      if (!opts.noPos) {
        w.prop(ind, 'Height', String(this.tw(P.h)));
        w.prop(ind, 'Left', String(this.tw(P.l)));
        if (!opts.noTab) { const to = pNum(node, 'TabOrder', null); if (to != null) w.prop(ind, 'TabIndex', String(to)); }
        if (opts.tabStop === false || pBool(node, 'TabStop', true) === false) w.prop(ind, 'TabStop', vbBool(false));
        w.prop(ind, 'Top', String(this.tw(P.t)));
        w.prop(ind, 'Width', String(this.tw(P.w)));
      }
      if (pBool(node, 'Visible', true) === false) w.prop(ind, 'Visible', vbBool(false));
      if (pBool(node, 'Enabled', true) === false) w.prop(ind, 'Enabled', vbBool(false));
      const hint = pStr(node, 'Hint', ''); if (hint && !opts.noHint) { if (/[\r\n]/.test(hint)) this.init.push(`${P.name}.ToolTipText = ${vbStrExpr(hint)}`); else w.prop(ind, 'ToolTipText', vbStr(hint)); }
      const tag = pNum(node, 'Tag', null); if (tag) w.prop(ind, 'Tag', vbStr(String(tag)));
    }
    geom(node, parentSize) {
      let l = pNum(node, 'Left', 0), t = pNum(node, 'Top', 0), wd = pNum(node, 'Width', null), ht = pNum(node, 'Height', null);
      const al = pIdent(node, 'Align', 'alNone').toLowerCase();
      if (wd == null) wd = al === 'alclient' || al === 'altop' || al === 'albottom' ? parentSize.w : 100;
      if (ht == null) ht = al === 'alclient' || al === 'alleft' || al === 'alright' ? parentSize.h : 25;
      return { l, t, w: wd, h: ht, align: al };
    }
    color(w, ind, node, prop, vbProp, def) {
      const c = colorValue(pv(node, prop)); if (c != null && c !== def) w.prop(ind, vbProp, colorRawVB(c));
    }
    fore(w, ind, f, def) { if (f && f.color != null && f.color !== (def ?? 0x80000012) && !(f.color === 0 && (def ?? 0x80000012) === 0x80000012)) w.prop(ind, 'ForeColor', colorRawVB(f.color)); }
    alignment(w, ind, node) { const a = pIdent(node, 'Alignment', 'taLeftJustify').toLowerCase(); const m = { taleftjustify: 0, tarightjustify: 1, tacenter: 2 }; if (m[a]) w.prop(ind, 'Alignment', String(m[a])); }
    // converte um componente; devolve nada (escreve no writer)
    convertNode(w, node, ind, parentFont, parentSize, parentInfo) {
      const cls = node.cls.toLowerCase();
      let kind = KIND[cls];
      if (!node.name) { if (node.children.length) for (const c of node.children) this.convertNode(w, c, ind, parentFont, parentSize, parentInfo); return; }
      if (!kind) {
        if (DATA_CLASSES.test(cls) || /^t(fd|ado|sql|ib|db|zeos|uni)/.test(cls)) { this.report.data(`${this.unitName}: ${node.name} (${node.cls})`); this.controls.set(node.name.toLowerCase(), { name: node.name, vcl: cls, kind: 'data' }); return; }
        if (/^tmenuitem$/.test(cls) || /^taction/.test(cls) || this.actions.has(node.name.toLowerCase())) return;
        const hasGeom = node.props.has('width') || node.props.has('left');
        if (!hasGeom && !node.children.length) { this.warn(`non-visual component ${node.name} (${node.cls}) was skipped`); this.controls.set(node.name.toLowerCase(), { name: node.name, vcl: cls, kind: 'unknown' }); return; }
        kind = node.children.length ? 'panel' : 'unknownvis';
      }
      if (kind === 'skip' || kind === 'skipnv' || kind === 'actionlist' || kind === 'actionmanager' || kind === 'action' || kind === 'actionmenubar' || kind === 'mainmenu' || kind === 'popupmenu' || kind === 'menuitem') {
        if (kind === 'skip' && node.props.has('width')) this.warn(`${node.name} (${node.cls}) is not supported yet and was skipped`);
        if (kind === 'skipnv' && !/imagelist|imagecollection|virtualimagelist/i.test(cls)) this.warn(`${node.name} (${node.cls}) is not supported yet and was skipped`);
        this.controls.set(node.name.toLowerCase(), { name: node.name, vcl: cls, kind });
        return;
      }
      const name = node.name;
      const g = this.geom(node, parentSize);
      const P = { name, l: g.l, t: g.t, w: g.w, h: g.h };
      const font = this.fontOf(node, parentFont);
      const info = { name, vcl: cls, kind };
      this.controls.set(name.toLowerCase(), info);
      const begin = type => { info.vbType = type; w.raw(ind, `Begin ${type} ${name} `); };
      const end = () => w.raw(ind, 'End');
      const i2 = ind + 3;
      switch (kind) {
        case 'label': case 'unknownvis': {
          begin('VB.Label');
          this.alignment(w, i2, node);
          const auto = pBool(node, 'AutoSize', kind === 'label' && cls !== 'tstatictext');
          if (auto) w.prop(i2, 'AutoSize', vbBool(true));
          const transparent = pBool(node, 'Transparent', false);
          if (transparent) w.prop(i2, 'BackStyle', '0  \'Transparent');
          this.color(w, i2, node, 'Color', 'BackColor', 0x8000000F);
          if (cls === 'tstatictext' && /bssunken|bssingle/i.test(pIdent(node, 'BorderStyle', ''))) w.prop(i2, 'BorderStyle', '1  \'Fixed Single');
          const cap = kind === 'unknownvis' ? `[${node.cls}]` : pStr(node, 'Caption', cls === 'tdbtext' ? '' : name);
          if (kind === 'unknownvis') this.warn(`${name} (${node.cls}) is not supported yet; a label was placed in its spot`);
          if (/[\r\n\x00-\x08]/.test(cap)) this.init.push(`${name}.Caption = ${vbStrExpr(cap)}`); else w.prop(i2, 'Caption', vbStr(cap));
          this.common(w, i2, node, P, { noTab: true });
          this.writeFont(w, i2, font); this.fore(w, i2, font);
          if (pBool(node, 'WordWrap', false)) w.prop(i2, 'WordWrap', vbBool(true));
          end(); break;
        }
        case 'edit': case 'memo': {
          begin('VB.TextBox');
          if (kind === 'memo') {
            w.prop(i2, 'MultiLine', vbBool(true));
            const sb = pIdent(node, 'ScrollBars', 'ssNone').toLowerCase(); const sm = { ssnone: 0, sshorizontal: 1, ssvertical: 2, ssboth: 3 };
            if (sm[sb]) w.prop(i2, 'ScrollBars', String(sm[sb]));
            const lines = pList(node, 'Lines.Strings'); if (lines && lines.length) this.init.push(`${name}.Text = ${vbStrExpr(lines.join('\r\n'))}`);
          } else {
            let txt = pStr(node, 'Text', ''); if (cls === 'tspinedit' || cls === 'tnumberbox') txt = String(pNum(node, 'Value', 0));
            if (txt) { if (/[\x00-\x1f]/.test(txt)) this.init.push(`${name}.Text = ${vbStrExpr(txt)}`); else w.prop(i2, 'Text', vbStr(txt)); }
            const pc = pv(node, 'PasswordChar'); if (pc && pc.t === 'str' && pc.v && pc.v !== '\0') w.prop(i2, 'PasswordChar', vbStr(pc.v));
            if (cls === 'tlabelededit') { const lc = pStr(node, 'EditLabel.Caption', ''); if (lc) this.warn(`the caption "${lc}" of ${name} (TLabeledEdit) was not created`); }
          }
          if (kind === 'edit' || !node.props.has('text')) { /* nada */ }
          this.alignment(w, i2, node);
          this.color(w, i2, node, 'Color', 'BackColor', 0x80000005);
          if (/bsnone/i.test(pIdent(node, 'BorderStyle', ''))) w.prop(i2, 'BorderStyle', '0  \'None');
          if (pBool(node, 'ReadOnly', false)) w.prop(i2, 'Locked', vbBool(true));
          const ml = pNum(node, 'MaxLength', 0); if (ml) w.prop(i2, 'MaxLength', String(ml));
          this.common(w, i2, node, P);
          this.writeFont(w, i2, font); this.fore(w, i2, font, 0x80000008);
          end(); break;
        }
        case 'rich': {
          begin('NB.RichTextBox');
          const lines = pList(node, 'Lines.Strings'); if (lines && lines.length) this.init.push(`${name}.Text = ${vbStrExpr(lines.join('\r\n'))}`);
          this.common(w, i2, node, P);
          end(); break;
        }
        case 'button': case 'toolbutton': {
          begin('VB.CommandButton');
          let cap = pStr(node, 'Caption', null);
          const act = pIdent(node, 'Action', null);
          const a = act ? this.actions.get(act.toLowerCase()) : null;
          if (cap == null && a) cap = this.stdActionCaption(a).replace(/\.\.\.$/, '');
          if (cap == null) cap = kind === 'toolbutton' ? '' : name;
          w.prop(i2, 'Caption', vbStr(cap));
          if (pBool(node, 'Default', false)) w.prop(i2, 'Default', vbBool(true));
          if (pBool(node, 'Cancel', false)) w.prop(i2, 'Cancel', vbBool(true));
          if (node.props.has('glyph.data')) { const img = delphiPicture(pv(node, 'Glyph.Data'), true); if (img) { w.prop(i2, 'Style', '1  \'Graphical'); w.prop(i2, 'Picture', this.addPicture(img)); } }
          if (a && !a.enabled) w.prop(i2, 'Enabled', vbBool(false));
          const hintA = !pStr(node, 'Hint', '') && a && a.hint ? a.hint.split('|')[0] : null; if (hintA) w.prop(i2, 'ToolTipText', vbStr(hintA));
          this.common(w, i2, node, P, { tabStop: cls === 'tspeedbutton' || kind === 'toolbutton' ? false : undefined });
          this.writeFont(w, i2, font); this.fore(w, i2, font);
          const mr = pv(node, 'ModalResult');
          if (mr) { const mrv = mr.t === 'int' ? mr.v : ({ mrnone: 0, mrok: 1, mrcancel: 2, mrabort: 3, mrretry: 4, mrignore: 5, mryes: 6, mrno: 7, mrclose: 8, mrhelp: 9, mrall: 12, mrnotoall: 13, mryestoall: 14 })[String(mr.v).toLowerCase()]; if (mrv) this.modalButtons.push({ name, value: mrv }); }
          const kindBtn = pIdent(node, 'Kind', null);
          if (kindBtn && !mr) { const km = { bkok: 1, bkcancel: 2, bkyes: 6, bkno: 7, bkabort: 3, bkretry: 4, bkignore: 5, bkall: 12 }; const v = km[kindBtn.toLowerCase()]; if (v) this.modalButtons.push({ name, value: v }); if (kindBtn.toLowerCase() === 'bkclose') this.events.push({ ctl: name, vclEvent: 'OnClick', raw: 'Unload Me', kind, vbType: 'VB.CommandButton', vcl: cls, node }); }
          end();
          break;
        }
        case 'check': {
          begin('VB.CheckBox');
          w.prop(i2, 'Caption', vbStr(pStr(node, 'Caption', name)));
          const st = pIdent(node, 'State', null);
          if (pBool(node, 'Checked', false) || /cbchecked/i.test(st || '') || /tsson/i.test(st || '')) w.prop(i2, 'Value', '1  \'Checked'); else if (/cbgrayed/i.test(st || '')) w.prop(i2, 'Value', '2  \'Grayed');
          if (/tarightjustify/i.test(pIdent(node, 'Alignment', '')) === false && /taleftjustify/i.test(pIdent(node, 'Alignment', ''))) w.prop(i2, 'Alignment', '1  \'Right Justify');
          this.color(w, i2, node, 'Color', 'BackColor', 0x8000000F);
          this.common(w, i2, node, P); this.writeFont(w, i2, font); this.fore(w, i2, font);
          end(); break;
        }
        case 'radio': {
          begin('VB.OptionButton');
          w.prop(i2, 'Caption', vbStr(pStr(node, 'Caption', name)));
          if (pBool(node, 'Checked', false)) w.prop(i2, 'Value', vbBool(true));
          this.color(w, i2, node, 'Color', 'BackColor', 0x8000000F);
          this.common(w, i2, node, P); this.writeFont(w, i2, font); this.fore(w, i2, font);
          end(); break;
        }
        case 'list': case 'combo': {
          const type = kind === 'list' ? 'VB.ListBox' : 'VB.ComboBox';
          begin(type);
          if (kind === 'combo') {
            const st = pIdent(node, 'Style', 'csDropDown').toLowerCase(); const sm = { csdropdown: 0, cssimple: 1, csdropdownlist: 2, csownerdrawfixed: 2, csownerdrawvariable: 2 };
            if (sm[st]) w.prop(i2, 'Style', String(sm[st]) + (sm[st] === 2 ? '  \'Dropdown List' : '  \'Simple Combo'));
            const txt = pStr(node, 'Text', ''); if (txt && sm[st] !== 2) w.prop(i2, 'Text', vbStr(txt));
          } else {
            if (pBool(node, 'MultiSelect', false)) w.prop(i2, 'MultiSelect', pBool(node, 'ExtendedSelect', true) ? '2  \'Extended' : '1  \'Simple');
            if (cls === 'tchecklistbox') w.prop(i2, 'Style', '1  \'Checkbox');
          }
          if (pBool(node, 'Sorted', false)) w.prop(i2, 'Sorted', vbBool(true));
          this.color(w, i2, node, 'Color', 'BackColor', 0x80000005);
          this.common(w, i2, node, P); this.writeFont(w, i2, font); this.fore(w, i2, font, 0x80000008);
          end();
          const items = pList(node, 'Items.Strings');
          if (items) for (const s of items) this.init.push(`${name}.AddItem ${vbStrExpr(s)}`);
          const ii = pNum(node, 'ItemIndex', -1); if (ii >= 0) this.init.push(`${name}.ListIndex = ${ii}`); break;
        }
        case 'group': case 'radiogroup': {
          begin('VB.Frame');
          w.prop(i2, 'Caption', vbStr(pStr(node, 'Caption', '')));
          this.color(w, i2, node, 'Color', 'BackColor', 0x8000000F);
          this.common(w, i2, node, P); this.writeFont(w, i2, font); this.fore(w, i2, font);
          for (const c of node.children) this.convertNode(w, c, i2, font, { w: g.w, h: g.h }, info);
          if (kind === 'radiogroup') {
            const items = pList(node, 'Items.Strings') || [];
            const cols = Math.max(1, pNum(node, 'Columns', 1));
            const optName = this.uniq(name + 'Opt');
            const rows = Math.ceil(items.length / cols) || 1;
            const top = 16, avail = Math.max(10, g.h - top - 6), rh = Math.min(24, avail / rows), cw2 = (g.w - 16) / cols;
            const idx = pNum(node, 'ItemIndex', -1);
            items.forEach((s, i) => {
              const r = i % rows, c = Math.floor(i / rows);
              w.raw(i2, `Begin VB.OptionButton ${optName} `);
              w.prop(i2 + 3, 'Caption', vbStr(s)); w.prop(i2 + 3, 'Height', String(this.tw(Math.min(20, rh))));
              w.prop(i2 + 3, 'Index', String(i)); w.prop(i2 + 3, 'Left', String(this.tw(8 + c * cw2)));
              w.prop(i2 + 3, 'Top', String(this.tw(top + r * rh))); if (i === idx) w.prop(i2 + 3, 'Value', vbBool(true));
              w.prop(i2 + 3, 'Width', String(this.tw(cw2 - 4)));
              this.writeFont(w, i2 + 3, font);
              w.raw(i2, 'End');
            });
            info.optName = optName; this.radioGroups.set(name.toLowerCase(), optName);
            this.controls.set(optName.toLowerCase(), { name: optName, vcl: 'tradiobutton', kind: 'radio', vbType: 'VB.OptionButton', array: true });
            info.vbType = 'VB.Frame';
            for (const [k, e] of node.props) if (/^on(click|change)$/i.test(k) && e.v.t === 'ident') this.events.push({ ctl: optName, vclEvent: 'OnClick', handler: e.v.v, kind: 'radiogroup', vbType: 'VB.OptionButton', array: true, sender: name, vcl: cls, node });
          }
          end(); break;
        }
        case 'panel': case 'toolbar': case 'status': case 'paintbox': {
          begin('VB.PictureBox');
          const bevel = pIdent(node, 'BevelOuter', kind === 'panel' ? 'bvRaised' : 'bvNone').toLowerCase();
          const bst = pIdent(node, 'BorderStyle', 'bsNone').toLowerCase();
          w.prop(i2, 'BorderStyle', (bst === 'bssingle' || (kind === 'panel' && bevel === 'bvlowered')) ? '1  \'Fixed Single' : '0  \'None');
          const bgc = colorValue(pv(node, 'Color')); w.prop(i2, 'BackColor', colorRawVB(bgc != null ? bgc : (kind === 'paintbox' ? 0x8000000F : 0x8000000F)));
          if (kind === 'paintbox') w.prop(i2, 'AutoRedraw', vbBool(true));
          if (!parentInfo) {
            const alD = node.props.has('align') ? g.align : (kind === 'status' ? 'albottom' : kind === 'toolbar' ? 'altop' : 'alnone');
            const am = { altop: 1, albottom: 2, alleft: 3, alright: 4 };
            const av = am[alD] || (this.isMDI ? 1 : 0);
            if (av) { w.prop(i2, 'Align', String(av)); info.aligned = true; }
          }
          w.prop(i2, 'ScaleMode', '3  \'Pixel');
          this.common(w, i2, node, P, { tabStop: false }); this.writeFont(w, i2, font); this.fore(w, i2, font);
          if (kind === 'status') {
            // barra de status: rótulo dentro da caixa
            const capName = this.uniq(name + 'Text'); info.capName = capName;
            const panels = pv(node, 'Panels'); const ptxt = panels && panels.t === 'coll' && panels.v.length ? (panels.v[0].get('text') || { v: { v: '' } }).v.v : '';
            w.raw(i2, `Begin VB.Label ${capName} `);
            w.prop(i2 + 3, 'BackStyle', '0  \'Transparent'); w.prop(i2 + 3, 'Caption', vbStr(pStr(node, 'SimpleText', ptxt || '')));
            w.prop(i2 + 3, 'Height', String(this.tw(Math.max(10, g.h - 4)))); w.prop(i2 + 3, 'Left', String(this.tw(4))); w.prop(i2 + 3, 'Top', String(this.tw(3))); w.prop(i2 + 3, 'Width', String(this.tw(Math.max(10, g.w - 8))));
            this.writeFont(w, i2 + 3, font); w.raw(i2, 'End');
            this.controls.set(capName.toLowerCase(), { name: capName, vcl: 'tlabel', kind: 'label', vbType: 'VB.Label' });
            if (!node.props.has('align')) { /* ok */ }
          } else if (kind === 'panel' && pStr(node, 'Caption', '') && pBool(node, 'ShowCaption', true) && cls === 'tpanel') {
            const capName = this.uniq(name + 'Caption'); info.capName = capName;
            const al = pIdent(node, 'Alignment', 'taCenter').toLowerCase();
            w.raw(i2, `Begin VB.Label ${capName} `);
            w.prop(i2 + 3, 'Alignment', String(({ taleftjustify: 0, tarightjustify: 1, tacenter: 2 })[al] ?? 2)); w.prop(i2 + 3, 'BackStyle', '0  \'Transparent');
            w.prop(i2 + 3, 'Caption', vbStr(pStr(node, 'Caption', '')));
            const fh = Math.round(font.size * this.ppi / 72 * 1.25);
            w.prop(i2 + 3, 'Height', String(this.tw(fh))); w.prop(i2 + 3, 'Left', String(this.tw(4))); w.prop(i2 + 3, 'Top', String(this.tw(Math.max(0, (g.h - fh) / 2))));
            w.prop(i2 + 3, 'Width', String(this.tw(Math.max(10, g.w - 8)))); this.writeFont(w, i2 + 3, font); this.fore(w, i2 + 3, font);
            w.raw(i2, 'End');
            this.controls.set(capName.toLowerCase(), { name: capName, vcl: 'tlabel', kind: 'label', vbType: 'VB.Label' });
          }
          if (kind === 'toolbar') {
            // botões da barra lado a lado
            let x = pNum(node, 'Indent', 0) + 2; const bh = Math.max(16, g.h - 6);
            for (const c of node.children) {
              if (!/ttoolbutton/i.test(c.cls)) { this.convertNode(w, c, i2, font, { w: g.w, h: g.h }, info); continue; }
              if (/tbsseparator|tbsdivider/i.test(pIdent(c, 'Style', ''))) { x += pNum(c, 'Width', 8); continue; }
              const act = pIdent(c, 'Action', null); const a = act ? this.actions.get(act.toLowerCase()) : null;
              const cap = pStr(c, 'Caption', null) ?? (a ? this.stdActionCaption(a) : c.name);
              const bw = Math.max(23, Math.min(150, 16 + cap.replace(/&/g, '').length * 7));
              c.props.set('left', { key: 'Left', v: { t: 'int', v: x } }); c.props.set('top', { key: 'Top', v: { t: 'int', v: 3 } });
              c.props.set('width', { key: 'Width', v: { t: 'int', v: bw } }); c.props.set('height', { key: 'Height', v: { t: 'int', v: bh } });
              if (!c.props.has('caption')) c.props.set('caption', { key: 'Caption', v: { t: 'str', v: cap.replace(/\.\.\.$/, '') } });
              this.convertNode(w, c, i2, font, { w: g.w, h: g.h }, info);
              x += bw + 1;
            }
          } else if (kind !== 'status') {
            for (const c of node.children) this.convertNode(w, c, i2, font, { w: g.w, h: g.h }, info);
          }
          end(); break;
        }
        case 'image': {
          begin('VB.Image');
          if (pBool(node, 'Stretch', false)) w.prop(i2, 'Stretch', vbBool(true));
          if (node.props.has('picture.data')) { const img = delphiPicture(pv(node, 'Picture.Data')); if (img) w.prop(i2, 'Picture', this.addPicture(img)); else this.warn(`the picture inside ${name} was not imported (this image format is not supported)`); }
          this.common(w, i2, node, P, { noTab: true });
          end(); break;
        }
        case 'shape': case 'bevel': {
          begin('VB.Shape');
          if (kind === 'shape') {
            const sh = pIdent(node, 'Shape', 'stRectangle').toLowerCase(); const sm = { strectangle: 0, stsquare: 1, stellipse: 2, stcircle: 3, stroundrect: 4, stroundsquare: 5 };
            if (sm[sh]) w.prop(i2, 'Shape', String(sm[sh]));
            const bc = colorValue(pv(node, 'Brush.Color')); const bst = pIdent(node, 'Brush.Style', 'bsSolid').toLowerCase();
            if (bst !== 'bsclear') { w.prop(i2, 'BackStyle', '1  \'Opaque'); w.prop(i2, 'BackColor', colorRawVB(bc != null ? bc : 0xFFFFFF)); w.prop(i2, 'FillStyle', '1  \'Transparent'); }
            const pc = colorValue(pv(node, 'Pen.Color')); if (pc != null) w.prop(i2, 'BorderColor', colorRawVB(pc));
            const pw = pNum(node, 'Pen.Width', 1); if (pw > 1) w.prop(i2, 'BorderWidth', String(pw));
          } else {
            w.prop(i2, 'BorderColor', '&H80000010&');
          }
          this.common(w, i2, node, P, { noTab: true, noHint: true });
          end(); break;
        }
        case 'timer': {
          begin('VB.Timer');
          w.prop(i2, 'Enabled', vbBool(pBool(node, 'Enabled', true)));
          w.prop(i2, 'Interval', String(pNum(node, 'Interval', 1000)));
          w.prop(i2, 'Left', String(this.tw(pNum(node, 'Left', 0) || 0))); w.prop(i2, 'Top', String(this.tw(pNum(node, 'Top', 0) || 0)));
          end(); break;
        }
        case 'scrollbar': {
          const horiz = !/sbvertical/i.test(pIdent(node, 'Kind', 'sbHorizontal'));
          const type = horiz ? 'VB.HScrollBar' : 'VB.VScrollBar'; begin(type);
          w.prop(i2, 'Max', String(pNum(node, 'Max', 100))); const mn = pNum(node, 'Min', 0); if (mn) w.prop(i2, 'Min', String(mn));
          const pos = pNum(node, 'Position', 0); if (pos) w.prop(i2, 'Value', String(pos));
          const lc = pNum(node, 'LargeChange', 1); if (lc > 1) w.prop(i2, 'LargeChange', String(lc));
          this.common(w, i2, node, P); end(); break;
        }
        case 'trackbar': case 'progress': {
          const type = kind === 'trackbar' ? 'NB.Slider' : 'NB.ProgressBar'; begin(type);
          this.common(w, i2, node, P); end();
          const pos = pNum(node, 'Position', 0); if (pos) this.init.push(`${name}.Value = ${pos}`); break;
        }
        case 'pages': {
          // TPageControl: caixa com botões de aba e uma caixa por página
          begin('VB.PictureBox');
          w.prop(i2, 'BorderStyle', '0  \'None'); w.prop(i2, 'BackColor', '&H8000000F&'); w.prop(i2, 'ScaleMode', '3  \'Pixel');
          this.common(w, i2, node, P, { tabStop: false }); this.writeFont(w, i2, font);
          const sheets = node.children.filter(c => /ttabsheet/i.test(c.cls));
          const tabsName = this.uniq(name + 'Tab');
          const tabs = cls === 'ttabcontrol' ? (pList(node, 'Tabs.Strings') || []) : sheets.map(s => pStr(s, 'Caption', s.name));
          let x = 2; const tabH = 22;
          tabs.forEach((t, i) => {
            const bw = Math.max(50, 16 + t.replace(/&/g, '').length * 7);
            w.raw(i2, `Begin VB.CommandButton ${tabsName} `);
            w.prop(i2 + 3, 'Caption', vbStr(t)); w.prop(i2 + 3, 'Height', String(this.tw(tabH))); w.prop(i2 + 3, 'Index', String(i));
            w.prop(i2 + 3, 'Left', String(this.tw(x))); w.prop(i2 + 3, 'TabStop', vbBool(false)); w.prop(i2 + 3, 'Top', String(this.tw(0))); w.prop(i2 + 3, 'Width', String(this.tw(bw)));
            this.writeFont(w, i2 + 3, font); w.raw(i2, 'End'); x += bw;
          });
          this.controls.set(tabsName.toLowerCase(), { name: tabsName, vcl: 'tbutton', kind: 'button', vbType: 'VB.CommandButton', array: true });
          const sheetNames = [];
          const ap = pIdent(node, 'ActivePage', null);
          let active = Math.max(0, sheets.findIndex(s => ap && s.name.toLowerCase() === ap.toLowerCase()));
          if (cls === 'ttabcontrol') active = Math.max(0, pNum(node, 'TabIndex', 0));
          sheets.forEach((s, i) => {
            const sn = s.name; sheetNames.push(sn);
            const sw = g.w - 4, sh = g.h - tabH - 2;
            w.raw(i2, `Begin VB.PictureBox ${sn} `);
            w.prop(i2 + 3, 'BorderStyle', '1  \'Fixed Single'); const sbg = colorValue(pv(s, 'Color')); w.prop(i2 + 3, 'BackColor', colorRawVB(sbg != null ? sbg : 0x8000000F)); w.prop(i2 + 3, 'ScaleMode', '3  \'Pixel');
            w.prop(i2 + 3, 'Height', String(this.tw(sh))); w.prop(i2 + 3, 'Left', String(this.tw(2))); w.prop(i2 + 3, 'TabStop', vbBool(false));
            w.prop(i2 + 3, 'Top', String(this.tw(tabH))); if (i !== active) w.prop(i2 + 3, 'Visible', vbBool(false)); w.prop(i2 + 3, 'Width', String(this.tw(sw)));
            this.writeFont(w, i2 + 3, font);
            const sInfo = { name: sn, vcl: 'ttabsheet', kind: 'sheet', vbType: 'VB.PictureBox', pages: name, index: i };
            this.controls.set(sn.toLowerCase(), sInfo);
            for (const c of s.children) this.convertNode(w, c, i2 + 3, font, { w: sw - 2, h: sh - 2 }, sInfo);
            w.raw(i2, 'End');
          });
          if (cls === 'ttabcontrol') for (const c of node.children) if (!/ttabsheet/i.test(c.cls)) this.convertNode(w, c, i2, font, { w: g.w, h: g.h }, info);
          info.tabsName = tabsName; info.sheets = sheetNames;
          this.pages.set(name.toLowerCase(), { name, tabsName, sheets: sheetNames, count: tabs.length, onChange: pIdent(node, 'OnChange', null), onChanging: pIdent(node, 'OnChanging', null), active });
          end(); break;
        }
        case 'grid': case 'date': case 'tree': case 'web': case 'navigator': {
          const type = { grid: 'NB.DataGrid', date: 'NB.DatePicker', tree: 'NB.TreeView', web: 'NB.WebBrowser', navigator: 'NB.NavigationBar' }[kind];
          begin(type); this.common(w, i2, node, P); end();
          if (kind === 'grid') this.warn(`${name} (${node.cls}) became a DataGrid; cells and data binding are not converted yet`);
          if (kind === 'tree') this.warn(`${name} (TTreeView) items are not converted yet`); break;
        }
        case 'opendlg': case 'savedlg': case 'colordlg': case 'fontdlg': case 'printdlg': {
          begin('MSComDlg.CommonDialog');
          const filt = pStr(node, 'Filter', ''); if (filt) w.prop(i2, 'Filter', vbStr(filt));
          const de = pStr(node, 'DefaultExt', ''); if (de) w.prop(i2, 'DefaultExt', vbStr(de));
          const ti = pStr(node, 'Title', ''); if (ti) w.prop(i2, 'DialogTitle', vbStr(ti));
          const fn = pStr(node, 'FileName', ''); if (fn) w.prop(i2, 'FileName', vbStr(fn));
          w.prop(i2, 'Left', String(this.tw(pNum(node, 'Left', 0) || 0))); w.prop(i2, 'Top', String(this.tw(pNum(node, 'Top', 0) || 0)));
          end(); this.usesComDlg = true; break;
        }
        case 'sheet': {
          for (const c of node.children) this.convertNode(w, c, ind, font, parentSize, parentInfo); break;
        }
        default: this.warn(`${name} (${node.cls}) was skipped`);
      }
      if (info.vbType && kind !== 'radiogroup' && kind !== 'pages') this.addEvents(node, name, kind, info.vbType);
      // filhos de controles que não são contêineres em VB
      if (!['group', 'radiogroup', 'panel', 'toolbar', 'status', 'paintbox', 'pages', 'sheet'].includes(kind) && node.children.length) {
        for (const c of node.children) if (!/^t(menuitem|action)/i.test(c.cls)) this.warn(`${c.name || c.cls} inside ${name} was skipped (that control cannot hold others in Neo Kiva)`);
      }
    }
    shortcutText(sc) {
      if (!sc) return null;
      const key = sc & 0xFF, ctrl = sc & 0x4000, shift = sc & 0x2000, alt = sc & 0x8000;
      if (alt) return null;
      let k = null;
      if (key >= 0x41 && key <= 0x5A) k = String.fromCharCode(key);
      else if (key >= 0x70 && key <= 0x7B) k = '{F' + (key - 0x6F) + '}';
      else if (key === 0x2E) k = '{DEL}'; else if (key === 0x2D) k = '{INSERT}';
      if (!k) return null;
      return (ctrl ? '^' : '') + (shift ? '+' : '') + k;
    }
    convertMenu(w, node, ind) {
      if (!/tmenuitem/i.test(node.cls)) return;
      const act = pIdent(node, 'Action', null); const a = act ? this.actions.get(act.toLowerCase()) : null;
      let cap = pStr(node, 'Caption', null); if (cap == null && a) cap = this.stdActionCaption(a); if (cap == null) cap = node.name;
      const name = node.name ? this.uniq(node.name) : this.uniq('mnuItem');
      if (node.name && name !== node.name) { /* renomeado */ }
      this.controls.set((node.name || name).toLowerCase(), { name, vcl: 'tmenuitem', kind: 'menuitem', vbType: 'VB.Menu' });
      w.raw(ind, `Begin VB.Menu ${name} `);
      w.prop(ind + 3, 'Caption', vbStr(cap));
      if (pBool(node, 'Checked', a ? a.checked : false)) w.prop(ind + 3, 'Checked', vbBool(true));
      if (pBool(node, 'Enabled', a ? a.enabled : true) === false) w.prop(ind + 3, 'Enabled', vbBool(false));
      const sc = this.shortcutText(pNum(node, 'ShortCut', a ? a.shortcut : null)); if (sc) w.prop(ind + 3, 'Shortcut', sc);
      if (pBool(node, 'Visible', a ? a.visible : true) === false) w.prop(ind + 3, 'Visible', vbBool(false));
      if (/\bfsmdiform\b/i.test(pIdent(this.root, 'FormStyle', '')) && node === (this.windowMenuNode || null)) w.prop(ind + 3, 'WindowList', vbBool(true));
      for (const c of node.children) this.convertMenu(w, c, ind + 3);
      w.raw(ind, 'End');
      if (cap !== '-') this.addEvents(node, name, 'menuitem', 'VB.Menu');
    }
    // menu de TActionManager / TActionMainMenuBar: usa ActionBars do gerenciador
    convertActionMenu(w, bar, ind) {
      const mgrName = pIdent(bar, 'ActionManager', null);
      const mgr = mgrName ? this.findNode(this.root, mgrName) : null;
      if (!mgr) { this.warn('the action menu bar could not be converted (ActionManager not found)'); return; }
      const bars = pv(mgr, 'ActionBars');
      if (!bars || bars.t !== 'coll') return;
      // encontra a barra que pertence ao menu
      let items = null;
      for (const b of bars.v) { const ctl = b.get('actionbar'); if (ctl && ctl.v.v && ctl.v.v.toLowerCase() === bar.name.toLowerCase()) { const it = b.get('items'); if (it && it.v.t === 'coll') items = it.v.v; } }
      if (!items) return;
      const walk = (list, ind2) => {
        for (const it of list) {
          const actE = it.get('action'); const capE = it.get('caption');
          const a = actE ? this.actions.get(String(actE.v.v).toLowerCase()) : null;
          let cap = capE ? String(capE.v.v) : (a ? this.stdActionCaption(a) : '-');
          const sub = it.get('items');
          const nm = this.uniq('mnu' + (cap.replace(/[^A-Za-z0-9]/g, '') || 'Sep'));
          w.raw(ind2, `Begin VB.Menu ${nm} `); w.prop(ind2 + 3, 'Caption', vbStr(cap));
          if (a && !a.enabled) w.prop(ind2 + 3, 'Enabled', vbBool(false));
          const sc = a ? this.shortcutText(a.shortcut) : null; if (sc) w.prop(ind2 + 3, 'Shortcut', sc);
          if (sub && sub.v.t === 'coll') walk(sub.v.v, ind2 + 3);
          w.raw(ind2, 'End');
          this.controls.set(nm.toLowerCase(), { name: nm, vcl: 'tmenuitem', kind: 'menuitem', vbType: 'VB.Menu' });
          if (a) this.events.push({ ctl: nm, vclEvent: 'OnClick', action: a, kind: 'menuitem', vbType: 'VB.Menu', vcl: 'tmenuitem' });
        }
      };
      walk(items, ind);
    }
    findNode(node, name) { for (const c of node.children) { if (c.name && c.name.toLowerCase() === name.toLowerCase()) return c; const r = this.findNode(c, name); if (r) return r; } return null; }
  }

  // ---------------------------------------------------------------- Object Pascal: léxico
  const PAS_KW = new Set(['and', 'array', 'as', 'asm', 'begin', 'case', 'class', 'const', 'constructor', 'destructor', 'div', 'do', 'downto', 'else', 'end', 'except', 'exports', 'file', 'finalization', 'finally', 'for', 'function', 'goto', 'if', 'implementation', 'in', 'inherited', 'initialization', 'inline', 'interface', 'is', 'label', 'library', 'mod', 'nil', 'not', 'object', 'of', 'or', 'packed', 'procedure', 'program', 'property', 'raise', 'record', 'repeat', 'resourcestring', 'set', 'shl', 'shr', 'string', 'then', 'threadvar', 'to', 'try', 'type', 'unit', 'until', 'uses', 'var', 'while', 'with', 'xor', 'out']);
  function lexPas(src) {
    const toks = []; let i = 0, line = 1; const n = src.length;
    while (i < n) {
      const c = src[i];
      if (c === '\n') { line++; i++; continue; }
      if (c === ' ' || c === '\t' || c === '\r' || c === '\f') { i++; continue; }
      if (c === '/' && src[i + 1] === '/') { const j = src.indexOf('\n', i); const txt = src.slice(i + 2, j < 0 ? n : j); toks.push({ t: 'comment', v: txt.replace(/\r$/, ''), line }); i = j < 0 ? n : j; continue; }
      if (c === '{') {
        const j = src.indexOf('}', i); const body = src.slice(i + 1, j < 0 ? n : j);
        for (const ch of body) if (ch === '\n') line++;
        if (body[0] === '$') toks.push({ t: 'directive', v: body.slice(1), line }); else toks.push({ t: 'comment', v: body, line, block: true });
        i = j < 0 ? n : j + 1; continue;
      }
      if (c === '(' && src[i + 1] === '*') { const j = src.indexOf('*)', i + 2); const body = src.slice(i + 2, j < 0 ? n : j); for (const ch of body) if (ch === '\n') line++; if (body[0] === '$') toks.push({ t: 'directive', v: body.slice(1), line }); else toks.push({ t: 'comment', v: body, line, block: true }); i = j < 0 ? n : j + 2; continue; }
      if (c === "'" || (c === '#' && /[0-9$]/.test(src[i + 1] || ''))) {
        const pieces = []; // ['s', text] ou ['c', code]
        while (i < n && (src[i] === "'" || src[i] === '#')) {
          if (src[i] === "'") {
            i++; let s = '';
            for (;;) { if (i >= n || src[i] === '\n') break; if (src[i] === "'") { if (src[i + 1] === "'") { s += "'"; i += 2; continue; } i++; break; } s += src[i++]; }
            pieces.push(['s', s]);
          } else {
            i++; let num = '';
            if (src[i] === '$') { i++; while (/[0-9A-Fa-f]/.test(src[i] || '')) num += src[i++]; pieces.push(['c', parseInt(num, 16)]); }
            else { while (/[0-9]/.test(src[i] || '')) num += src[i++]; pieces.push(['c', parseInt(num, 10)]); }
          }
        }
        toks.push({ t: 'str', pieces, line }); continue;
      }
      if (c === '$' && /[0-9A-Fa-f]/.test(src[i + 1] || '')) { let j = i + 1; while (/[0-9A-Fa-f]/.test(src[j] || '')) j++; toks.push({ t: 'num', v: parseInt(src.slice(i + 1, j), 16), raw: src.slice(i, j), hex: true, line }); i = j; continue; }
      if (/[0-9]/.test(c)) {
        let j = i; while (/[0-9]/.test(src[j] || '')) j++;
        if (src[j] === '.' && /[0-9]/.test(src[j + 1] || '')) { j++; while (/[0-9]/.test(src[j] || '')) j++; }
        if (/[eE]/.test(src[j] || '') && /[-+0-9]/.test(src[j + 1] || '')) { j++; if (/[-+]/.test(src[j])) j++; while (/[0-9]/.test(src[j] || '')) j++; }
        const raw = src.slice(i, j); toks.push({ t: 'num', v: parseFloat(raw), raw, float: /[.eE]/.test(raw), line }); i = j; continue;
      }
      if (/[\p{L}_&]/u.test(c) && (c !== '&' || /[\p{L}_]/u.test(src[i + 1] || ''))) {
        let j = i + (c === '&' ? 1 : 0); while (/[\p{L}\p{N}_]/u.test(src[j] || '')) j++;
        const v = src.slice(c === '&' ? i + 1 : i, j); const l = v.toLowerCase();
        toks.push({ t: PAS_KW.has(l) && c !== '&' ? 'kw' : 'id', v, l, line }); i = j; continue;
      }
      const two = src.slice(i, i + 2);
      if ([':=', '<=', '>=', '<>', '..', '+=', '-=', '*=', '/='].includes(two)) { toks.push({ t: 'op', v: two, line }); i += 2; continue; }
      toks.push({ t: 'op', v: c, line }); i++;
    }
    toks.push({ t: 'eof', v: '', line });
    return toks;
  }

  // ---------------------------------------------------------------- Object Pascal: parser
  class PasParser {
    constructor(src) {
      this.all = lexPas(src);
      // comentários viram atributos dos tokens seguintes (para preservar no VB)
      this.toks = []; let pend = [];
      // diretivas de compilação condicional ($IFDEF / $IFNDEF / $IF / $ELSE / $ENDIF)
      const DEF = new Set(['mswindows', 'win32', 'win64', 'cpux86', 'unicode', 'conditionalexpressions', 'delphi', 'vcl', 'release', 'ver150', 'ver180', 'ver350', 'ver360', 'assembler']);
      const stack = []; let active = true;
      const filtered = [];
      for (const t of this.all) {
        if (t.t === 'directive') {
          const m = /^\s*(\w+)\s*(.*)$/.exec(t.v); const d = m ? m[1].toLowerCase() : ''; const arg = m ? m[2].trim() : '';
          if (d === 'ifdef' || d === 'ifndef' || d === 'if' || d === 'ifopt') {
            let cond;
            if (d === 'ifdef') cond = DEF.has(arg.split(/\s/)[0].toLowerCase());
            else if (d === 'ifndef') cond = !DEF.has(arg.split(/\s/)[0].toLowerCase());
            else if (d === 'ifopt') cond = false;
            else { const a = arg.toLowerCase(); cond = /defined\s*\(\s*(\w+)\s*\)/.test(a) ? (/not\s+defined/.test(a) ? !DEF.has(/defined\s*\(\s*(\w+)/.exec(a)[1]) : DEF.has(/defined\s*\(\s*(\w+)/.exec(a)[1])) : true; }
            stack.push({ parent: active, taken: cond }); active = active && cond; continue;
          }
          if (d === 'elseif') { const top = stack[stack.length - 1]; if (top) { const c = !top.taken; active = top.parent && c; if (c) top.taken = true; } continue; }
          if (d === 'else') { const top = stack[stack.length - 1]; if (top) { active = top.parent && !top.taken; top.taken = true; } continue; }
          if (d === 'endif' || d === 'ifend') { const top = stack.pop(); active = top ? top.parent : true; continue; }
          if (d === 'define' && active) { DEF.add(arg.split(/\s/)[0].toLowerCase()); continue; }
          if (d === 'undef' && active) { DEF.delete(arg.split(/\s/)[0].toLowerCase()); continue; }
        }
        if (!active && t.t !== 'eof') continue;
        filtered.push(t);
      }
      this.all = filtered;
      for (const t of this.all) {
        if (t.t === 'comment') { pend.push(t); continue; }
        if (t.t === 'directive') { if (/^R\s/i.test(t.v) || /^I\s/i.test(t.v) && false) continue; pend.push({ t: 'comment', v: '{$' + t.v + '}', line: t.line }); continue; }
        if (pend.length) { t.comments = pend; pend = []; }
        this.toks.push(t);
      }
      this.p = 0;
    }
    get cur() { return this.toks[this.p]; }
    peek(k = 1) { return this.toks[this.p + k] || this.toks[this.toks.length - 1]; }
    next() { return this.toks[this.p++]; }
    isKw(w) { const t = this.cur; return t.t === 'kw' && t.l === w; }
    isOp(o) { const t = this.cur; return t.t === 'op' && t.v === o; }
    isId(w) { const t = this.cur; return t.t === 'id' && t.l === w; }
    eatKw(w) { if (this.isKw(w)) { this.p++; return true; } return false; }
    eatOp(o) { if (this.isOp(o)) { this.p++; return true; } return false; }
    expectKw(w) { if (!this.eatKw(w)) this.fail(`expected '${w}'`); }
    expectOp(o) { if (!this.eatOp(o)) this.fail(`expected '${o}'`); }
    fail(msg) { const e = new Error(`line ${this.cur.line}: ${msg} (found '${this.cur.v || this.cur.t}')`); e.line = this.cur.line; throw e; }
    ident() { const t = this.cur; if (t.t === 'id' || (t.t === 'kw' && ['string', 'object', 'file'].includes(t.l))) { this.p++; return t.v; } if (t.t === 'kw') { this.p++; return t.v; } this.fail('expected identifier'); }
    // nome qualificado (Unit.Nome, TForm1.Metodo)
    qualIdent() { let s = this.ident(); while (this.isOp('.') && (this.peek().t === 'id' || this.peek().t === 'kw')) { this.p++; s += '.' + this.ident(); } return s; }
    skipTo(pred) { while (this.cur.t !== 'eof' && !pred()) this.p++; }
    // ---------- tipos
    parseType() {
      const t = this.cur;
      if (this.eatKw('packed')) return this.parseType();
      if (this.isKw('array')) {
        this.p++; let dims = null;
        if (this.eatOp('[')) { dims = []; do { const lo = this.parseExpr(); if (this.eatOp('..')) { const hi = this.parseExpr(); dims.push({ lo, hi }); } else dims.push({ typeName: lo }); } while (this.eatOp(',')); this.expectOp(']'); }
        this.expectKw('of'); const of = this.eatKw('const') ? { name: 'Variant' } : this.parseType();
        return { kind: 'array', dims, of };
      }
      if (this.isKw('record')) { this.p++; const fields = this.parseFieldList(['end']); this.expectKw('end'); return { kind: 'record', fields }; }
      if (this.isKw('set')) { this.p++; this.expectKw('of'); const of = this.parseType(); return { kind: 'set', of }; }
      if (this.isKw('file')) { this.p++; if (this.eatKw('of')) this.parseType(); return { kind: 'file' }; }
      if (this.isOp('^')) { this.p++; const of = this.parseType(); return { kind: 'pointer', of }; }
      if (this.isOp('(')) { this.p++; const items = []; do { const nm = this.ident(); let v = null; if (this.eatOp('=')) v = this.parseExpr(); items.push({ name: nm, value: v }); } while (this.eatOp(',')); this.expectOp(')'); return { kind: 'enum', items }; }
      if (this.isKw('procedure') || this.isKw('function') || this.isId('reference')) { this.skipProcType(); return { kind: 'proc' }; }
      if (this.isKw('string')) { this.p++; if (this.eatOp('[')) { const len = this.parseExpr(); this.expectOp(']'); return { name: 'string', len }; } return { name: 'string' }; }
      if (this.isKw('class')) { this.p++; if (this.eatKw('of')) { this.qualIdent(); return { name: 'TClass' }; } return { kind: 'class' }; }
      // subfaixa: 1..10 ou 'a'..'z'
      const save = this.p;
      if (t.t === 'num' || t.t === 'str' || (t.t === 'op' && t.v === '-')) { const lo = this.parseExpr(); if (this.eatOp('..')) { this.parseExpr(); return { name: 'Integer' }; } this.p = save; }
      const nm = this.qualIdent();
      if (this.isOp('..')) { this.p++; this.parseExpr(); return { name: 'Integer' }; }
      if (this.isOp('<')) { let d = 0; do { if (this.isOp('<')) d++; if (this.isOp('>')) d--; this.p++; } while (d > 0 && this.cur.t !== 'eof'); return { name: nm, generic: true }; }
      return { name: nm };
    }
    skipProcType() {
      if (this.isId('reference')) { this.p++; this.p++; }
      const isFn = this.isKw('function'); this.p++;
      if (this.isOp('(')) this.parseParams();
      if (isFn && this.eatOp(':')) this.parseType();
      if (this.isKw('of')) { this.p++; this.p++; }
    }
    parseFieldList(stops) {
      const fields = [];
      while (!stops.some(s => this.isKw(s)) && this.cur.t !== 'eof') {
        if (this.isKw('case')) { // registro variante
          this.p++; this.ident(); if (this.eatOp(':')) this.ident(); this.expectKw('of');
          while (!this.isKw('end') && this.cur.t !== 'eof') { this.parseExpr(); while (this.eatOp(',')) this.parseExpr(); this.expectOp(':'); this.expectOp('('); fields.push(...this.parseFieldList([])); while (!this.isOp(')') && this.cur.t !== 'eof') this.p++; this.expectOp(')'); this.eatOp(';'); }
          break;
        }
        if (this.isOp(')')) break;
        if (['private', 'public', 'protected', 'published', 'strict'].includes(this.cur.l)) { this.p++; continue; }
        if (this.isKw('procedure') || this.isKw('function') || this.isKw('constructor') || this.isKw('class') || this.isKw('property')) { this.skipMember(); continue; }
        const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident());
        this.expectOp(':'); const type = this.parseType(); this.eatOp(';');
        for (const nm of names) fields.push({ name: nm, type });
      }
      return fields;
    }
    skipMember() { let depth = 0; while (this.cur.t !== 'eof') { if (this.isOp('(')) depth++; if (this.isOp(')')) depth--; if (depth === 0 && this.isOp(';')) { this.p++; break; } this.p++; } while (['virtual', 'override', 'overload', 'static', 'abstract', 'reintroduce', 'dynamic', 'stdcall', 'cdecl', 'register', 'inline', 'final', 'message', 'default'].includes(this.cur.l)) { while (!this.isOp(';') && this.cur.t !== 'eof') this.p++; this.p++; } }
    parseParams() {
      const ps = [];
      this.expectOp('(');
      while (!this.isOp(')') && this.cur.t !== 'eof') {
        let mode = 'val';
        if (this.eatKw('var')) mode = 'var'; else if (this.eatKw('const')) mode = 'const'; else if (this.eatKw('out')) mode = 'var';
        else if (this.isId('constref')) { this.p++; mode = 'const'; }
        const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident());
        let type = { name: 'Variant' };
        if (this.eatOp(':')) type = this.parseType();
        let def = null; if (this.eatOp('=')) def = this.parseExpr();
        for (const nm of names) ps.push({ name: nm, mode, type, def });
        if (!this.eatOp(';')) break;
      }
      this.expectOp(')');
      return ps;
    }
    // ---------- unidade
    parseUnit() {
      const U = { kind: 'unit', name: '', ifaceUses: [], implUses: [], ifaceDecls: [], implDecls: [], routines: [], init: null, fin: null, classes: [], program: false, main: null };
      if (this.eatKw('unit')) { U.name = this.qualIdent(); while (!this.isOp(';')) this.p++; this.p++; }
      else if (this.eatKw('program') || this.eatKw('library')) { U.program = true; U.name = this.ident(); this.skipTo(() => this.isOp(';')); this.p++; }
      const parseUses = list => { this.p++; do { const nm = this.qualIdent(); let file = null; if (this.eatKw('in')) { const s = this.next(); file = s.pieces ? s.pieces.map(x => x[0] === 's' ? x[1] : '').join('') : ''; } list.push({ name: nm, file }); } while (this.eatOp(',')); this.eatOp(';'); };
      if (U.program) {
        if (this.isKw('uses')) parseUses(U.ifaceUses);
        this.parseDeclSection(U.implDecls, U, false);
        if (this.isKw('begin')) U.main = this.parseCompound();
        return U;
      }
      if (this.eatKw('interface')) {
        if (this.isKw('uses')) parseUses(U.ifaceUses);
        this.parseDeclSection(U.ifaceDecls, U, true);
      }
      if (this.eatKw('implementation')) {
        if (this.isKw('uses')) parseUses(U.implUses);
        this.parseDeclSection(U.implDecls, U, false);
      }
      if (this.eatKw('initialization')) U.init = this.parseStatementList(['finalization', 'end']);
      else if (this.isKw('begin')) U.init = this.parseCompound().body;
      if (this.eatKw('finalization')) U.fin = this.parseStatementList(['end']);
      return U;
    }
    skipAttribute() { let d = 0; do { if (this.isOp('[')) d++; if (this.isOp(']')) d--; this.p++; } while (d > 0 && this.cur.t !== 'eof'); }
    parseDeclSection(out, U, iface) {
      for (;;) {
        const t = this.cur;
        if (t.t === 'eof') return;
        if (this.isOp('[')) { this.skipAttribute(); continue; }
        if (this.isKw('type')) { this.p++; while (this.cur.t === 'id' && this.peek().t === 'op' && (this.peek().v === '=' || this.peek().v === '<')) out.push(this.parseTypeDecl(U)); continue; }
        if (this.isKw('var') || this.isKw('threadvar')) { this.p++; while (this.cur.t === 'id') out.push(...this.parseVarDecl('var')); continue; }
        if (this.isKw('const') || this.isKw('resourcestring')) { this.p++; while (this.cur.t === 'id') out.push(this.parseConstDecl()); continue; }
        if (this.isKw('label')) { this.skipTo(() => this.isOp(';')); this.p++; continue; }
        if (this.isKw('uses')) { this.skipTo(() => this.isOp(';')); this.p++; continue; }
        if (this.isKw('class') && (this.peek().l === 'procedure' || this.peek().l === 'function')) { this.p++; continue; }
        if (this.isKw('procedure') || this.isKw('function') || this.isKw('constructor') || this.isKw('destructor')) {
          const r = this.parseRoutine(iface);
          if (r) { if (iface) { r.forward = true; out.push({ kind: 'routineDecl', routine: r }); } else U.routines.push(r); }
          continue;
        }
        if (this.isKw('exports')) { this.skipTo(() => this.isOp(';')); this.p++; continue; }
        return;
      }
    }
    parseTypeDecl(U) {
      const name = this.ident();
      if (this.isOp('<')) { while (!this.isOp('=') && this.cur.t !== 'eof') this.p++; }
      this.expectOp('=');
      this.eatKw('type');
      if (this.isKw('class') && !(this.peek().l === 'of')) {
        this.p++;
        if (this.isOp(';')) { this.p++; return { kind: 'classFwd', name }; }
        let parent = null;
        if (this.eatOp('(')) { parent = this.qualIdent(); while (this.eatOp(',')) this.qualIdent(); this.expectOp(')'); }
        if (this.isOp(';')) { this.p++; return { kind: 'class', name, parent, fields: [], methods: [], props: [] }; }
        const C = { kind: 'class', name, parent, fields: [], methods: [], props: [] };
        let vis = 'published';
        while (!this.isKw('end') && this.cur.t !== 'eof') {
          const l = this.cur.l;
          if (this.isOp('[')) { this.skipAttribute(); continue; }
          if (['private', 'public', 'protected', 'published', 'automated'].includes(l)) { vis = l; this.p++; continue; }
          if (l === 'strict') { this.p++; continue; }
          if (this.isKw('procedure') || this.isKw('function') || this.isKw('constructor') || this.isKw('destructor')) { const r = this.parseRoutineHeader(); r.vis = vis; C.methods.push(r); continue; }
          if (this.isKw('class')) { this.p++; continue; }
          if (this.isKw('property')) { this.p++; const pn = this.ident(); let ptype = null; if (this.isOp('[')) { while (!this.isOp(']')) this.p++; this.p++; } if (this.eatOp(':')) ptype = this.parseType(); const pr = { name: pn, type: ptype, read: null, write: null, vis }; while (!this.isOp(';') && this.cur.t !== 'eof') { if (this.cur.l === 'read') { this.p++; pr.read = this.qualIdent(); continue; } if (this.cur.l === 'write') { this.p++; pr.write = this.qualIdent(); continue; } this.p++; } this.p++; if (this.cur.l === 'default') { this.p++; this.eatOp(';'); } C.props.push(pr); continue; }
          if (this.isKw('var') || this.isKw('const') || this.isKw('type')) { this.p++; continue; }
          if (this.cur.t === 'id') { const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident()); this.expectOp(':'); const type = this.parseType(); this.eatOp(';'); for (const nm of names) C.fields.push({ name: nm, type, vis }); continue; }
          this.p++;
        }
        this.expectKw('end'); this.eatOp(';');
        U.classes.push(C);
        return C;
      }
      if (this.isKw('interface') || this.isId('dispinterface')) { let d = 0; this.p++; while (this.cur.t !== 'eof') { if (this.isKw('end') && d === 0) { this.p++; break; } if (this.isKw('record') || this.isKw('class')) d++; if (this.isKw('end')) d--; this.p++; } this.eatOp(';'); return { kind: 'skipType', name }; }
      if (this.isKw('record') || (this.isKw('packed') && this.peek().l === 'record')) {
        this.eatKw('packed'); this.p++;
        const fields = [];
        while (!this.isKw('end') && this.cur.t !== 'eof') {
          if (this.isKw('case')) { fields.push(...this.parseFieldList(['end'])); continue; }
          if (this.isKw('procedure') || this.isKw('function') || this.isKw('constructor') || this.isKw('class') || this.isKw('property')) { this.skipMember(); continue; }
          if (['private', 'public', 'strict'].includes(this.cur.l)) { this.p++; continue; }
          if (this.isKw('var') || this.isKw('const')) { this.p++; continue; }
          const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident());
          this.expectOp(':'); const type = this.parseType(); this.eatOp(';');
          for (const nm of names) fields.push({ name: nm, type });
        }
        this.expectKw('end'); this.eatOp(';');
        return { kind: 'record', name, fields };
      }
      const type = this.parseType();
      while (!this.isOp(';') && this.cur.t !== 'eof') this.p++;
      this.eatOp(';');
      if (type.kind === 'enum') return { kind: 'enum', name, items: type.items };
      return { kind: 'alias', name, type };
    }
    parseVarDecl(kind) {
      const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident());
      this.expectOp(':'); const type = this.parseType();
      let init = null;
      if (this.eatOp('=')) init = this.parseConstValue();
      while (this.cur.t === 'id' && ['absolute', 'platform', 'deprecated'].includes(this.cur.l)) { this.p++; if (this.cur.t !== 'op') this.p++; }
      this.eatOp(';');
      return names.map(nm => ({ kind, name: nm, type, init }));
    }
    parseConstValue() { if (this.isOp('(')) { const save = this.p; try { this.p++; const items = []; do { if (this.isOp('(')) items.push(this.parseConstValue()); else if (this.cur.t === 'id' && this.peek().t === 'op' && this.peek().v === ':') { this.p += 2; items.push(this.parseExpr()); } else items.push(this.parseExpr()); } while (this.eatOp(',') || this.eatOp(';')); this.expectOp(')'); return { k: 'arrlit', items }; } catch (e) { this.p = save; } } return this.parseExpr(); }
    parseConstDecl() {
      const name = this.ident(); let type = null;
      if (this.eatOp(':')) type = this.parseType();
      this.expectOp('=');
      const value = this.parseConstValue();
      while (!this.isOp(';') && this.cur.t !== 'eof') this.p++;
      this.eatOp(';');
      return { kind: 'const', name, type, value };
    }
    parseRoutineHeader() {
      const kwTok = this.next(); const kind = kwTok.l; // procedure/function/constructor/destructor
      let name = this.ident();
      for (;;) { if (this.isOp('<')) { let d = 0; do { if (this.isOp('<')) d++; if (this.isOp('>')) d--; this.p++; } while (d > 0 && this.cur.t !== 'eof'); continue; } if (this.isOp('.') && (this.peek().t === 'id' || this.peek().t === 'kw')) { this.p++; name += '.' + this.ident(); continue; } break; }
      let params = []; if (this.isOp('(')) params = this.parseParams();
      let ret = null; if (this.eatOp(':')) ret = this.parseType();
      this.eatOp(';');
      const dirs = [];
      while (this.cur.t === 'id' && ['virtual', 'override', 'overload', 'static', 'abstract', 'reintroduce', 'dynamic', 'stdcall', 'cdecl', 'register', 'pascal', 'safecall', 'inline', 'final', 'message', 'forward', 'external', 'assembler', 'varargs', 'deprecated', 'platform', 'experimental'].includes(this.cur.l) || this.isKw('inline')) {
        const d = this.cur.l; dirs.push(d); this.p++;
        while (!this.isOp(';') && this.cur.t !== 'eof') this.p++; this.eatOp(';');
      }
      return { kind, name, params, ret, dirs, comments: kwTok.comments, line: kwTok.line };
    }
    parseRoutine(iface) {
      const r = this.parseRoutineHeader();
      if (iface || r.dirs.includes('forward') || r.dirs.includes('external')) return r;
      r.locals = []; r.nested = [];
      for (;;) {
        if (this.isKw('var')) { this.p++; while (this.cur.t === 'id') r.locals.push(...this.parseVarDecl('var')); continue; }
        if (this.isKw('const')) { this.p++; while (this.cur.t === 'id') r.locals.push(this.parseConstDecl()); continue; }
        if (this.isKw('type')) { this.p++; while (this.cur.t === 'id' && this.peek().v === '=') r.locals.push(this.parseTypeDecl({ classes: [] })); continue; }
        if (this.isKw('label')) { this.skipTo(() => this.isOp(';')); this.p++; continue; }
        if (this.isKw('procedure') || this.isKw('function')) { r.nested.push(this.parseRoutine(false)); continue; }
        break;
      }
      if (this.isKw('asm')) { this.skipTo(() => this.isKw('end')); this.p++; this.eatOp(';'); r.body = { k: 'block', body: [{ k: 'raw', text: "' [Delphi] assembler code was not converted" }] }; return r; }
      r.body = this.parseCompound();
      this.eatOp(';');
      return r;
    }
    // ---------- comandos
    parseCompound() { const b = this.cur; this.expectKw('begin'); const body = this.parseStatementList(['end']); const e = this.cur; this.expectKw('end'); return { k: 'block', body, line: b.line, endComments: e.comments }; }
    parseStatementList(stops) {
      const body = [];
      while (!stops.some(s => this.isKw(s)) && this.cur.t !== 'eof') {
        if (this.eatOp(';')) continue;
        const st = this.parseStatement(); if (st) body.push(st);
        if (!this.eatOp(';')) { if (!stops.some(s => this.isKw(s))) { if (this.cur.t === 'eof') break; /* tolera */ } }
      }
      return body;
    }
    parseStatement() {
      const t = this.cur; const comments = t.comments; const line = t.line;
      const st = this.parseStatementInner();
      if (st) { st.line = st.line || line; if (comments) st.comments = comments; }
      else if (comments) return { k: 'empty', comments, line };
      return st;
    }
    parseStatementInner() {
      const t = this.cur;
      // rótulo:
      if ((t.t === 'id' || t.t === 'num') && this.peek().t === 'op' && this.peek().v === ':' && !(this.peek(2).t === 'op' && this.peek(2).v === '=')) { this.p += 2; return { k: 'label', name: String(t.v) }; }
      if (t.t === 'kw') {
        switch (t.l) {
          case 'begin': return this.parseCompound();
          case 'if': { this.p++; const cond = this.parseExpr(); this.expectKw('then'); const then = this.isOp(';') || this.isKw('else') ? null : this.parseStatement(); let els = null; if (this.eatKw('else')) els = this.isOp(';') || this.isKw('end') ? null : this.parseStatement(); return { k: 'if', cond, then, els }; }
          case 'while': { this.p++; const cond = this.parseExpr(); this.expectKw('do'); const body = this.isOp(';') ? null : this.parseStatement(); return { k: 'while', cond, body }; }
          case 'repeat': { this.p++; const body = this.parseStatementList(['until']); this.expectKw('until'); const cond = this.parseExpr(); return { k: 'repeat', body, cond }; }
          case 'for': {
            this.p++;
            if (this.isKw('var')) this.p++;
            const v = this.parseDesignator();
            if (this.isOp(':')) { this.p++; this.parseType(); }
            if (this.eatKw('in')) { const coll = this.parseExpr(); this.expectKw('do'); const body = this.isOp(';') ? null : this.parseStatement(); return { k: 'forin', v, coll, body }; }
            this.expectOp(':='); const from = this.parseExpr(); let down = false;
            if (this.eatKw('downto')) down = true; else this.expectKw('to');
            const to = this.parseExpr(); this.expectKw('do'); const body = this.isOp(';') ? null : this.parseStatement();
            return { k: 'for', v, from, to, down, body };
          }
          case 'case': {
            this.p++; const sel = this.parseExpr(); this.expectKw('of'); const arms = []; let els = null;
            while (!this.isKw('end') && !this.isKw('else') && this.cur.t !== 'eof') {
              if (this.eatOp(';')) continue;
              const labels = [];
              do { const a = this.parseExpr(); if (this.eatOp('..')) labels.push({ range: [a, this.parseExpr()] }); else labels.push({ value: a }); } while (this.eatOp(','));
              this.expectOp(':');
              const st = this.isOp(';') ? null : this.parseStatement();
              arms.push({ labels, st }); this.eatOp(';');
            }
            if (this.eatKw('else')) els = this.parseStatementList(['end']);
            this.expectKw('end');
            return { k: 'case', sel, arms, els };
          }
          case 'with': { this.p++; const objs = [this.parseExpr()]; while (this.eatOp(',')) objs.push(this.parseExpr()); this.expectKw('do'); const body = this.isOp(';') ? null : this.parseStatement(); return { k: 'with', objs, body }; }
          case 'try': {
            this.p++; const body = this.parseStatementList(['except', 'finally']);
            if (this.eatKw('finally')) { const fin = this.parseStatementList(['end']); this.expectKw('end'); return { k: 'tryfinally', body, fin }; }
            this.expectKw('except');
            const handlers = []; let els = null; let plain = null;
            if (this.cur.t === 'id' && this.cur.l === 'on') {
              while (this.cur.t === 'id' && this.cur.l === 'on') {
                this.p++; let vn = null, tn;
                if (this.peek().t === 'op' && this.peek().v === ':') { vn = this.ident(); this.p++; }
                tn = this.qualIdent(); this.expectKw('do');
                const st = this.isOp(';') ? null : this.parseStatement(); this.eatOp(';');
                handlers.push({ v: vn, type: tn, st });
              }
              if (this.eatKw('else')) els = this.parseStatementList(['end']);
            } else plain = this.parseStatementList(['end']);
            this.expectKw('end');
            return { k: 'tryexcept', body, handlers, els, plain };
          }
          case 'raise': { this.p++; if (this.isOp(';') || this.isKw('end') || this.isKw('else')) return { k: 'raise', expr: null }; const e = this.parseExpr(); if (this.cur.t === 'id' && this.cur.l === 'at') { this.p++; this.parseExpr(); } return { k: 'raise', expr: e }; }
          case 'goto': { this.p++; const lb = this.next(); return { k: 'goto', name: String(lb.v) }; }
          case 'inherited': { this.p++; if (this.cur.t === 'id') { const d = this.parseDesignator(); return { k: 'inherited', d }; } return { k: 'inherited' }; }
          case 'var': { // var inline (Delphi 10.3+)
            this.p++; const names = [this.ident()]; while (this.eatOp(',')) names.push(this.ident());
            let type = null; if (this.eatOp(':')) type = this.parseType();
            let init = null; if (this.eatOp(':=')) init = this.parseExpr();
            return { k: 'inlinevar', names, type, init };
          }
          case 'const': { this.p++; const name = this.ident(); let type = null; if (this.eatOp(':')) type = this.parseType(); this.expectOp('='); const init = this.parseExpr(); return { k: 'inlinevar', names: [name], type, init, isConst: true }; }
          case 'asm': { this.skipTo(() => this.isKw('end')); this.p++; return { k: 'raw', text: "' [Delphi] assembler code was not converted" }; }
        }
      }
      // atribuição ou chamada
      const d = this.parseExpr();
      if (this.eatOp(':=')) { const e = this.parseExpr(); return { k: 'assign', target: d, value: e }; }
      for (const op of ['+=', '-=', '*=', '/=']) if (this.eatOp(op)) { const e = this.parseExpr(); return { k: 'assign', target: d, value: { k: 'bin', op: op[0], a: d, b: e } }; }
      return { k: 'call', expr: d };
    }
    // ---------- expressões
    parseExpr() {
      let a = this.parseSimple();
      for (;;) {
        const t = this.cur;
        let op = null;
        if (t.t === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(t.v)) op = t.v;
        else if (t.t === 'kw' && (t.l === 'in' || t.l === 'is')) op = t.l;
        else if (t.t === 'kw' && t.l === 'not' && this.peek().t === 'kw' && this.peek().l === 'in') { this.p++; op = 'notin'; }
        if (!op) break;
        this.p++;
        if (op === 'is') { const tn = this.qualIdent(); a = { k: 'is', a, type: tn }; continue; }
        const b = this.parseSimple(); a = { k: 'bin', op, a, b };
      }
      return a;
    }
    parseSimple() {
      let a;
      if (this.isOp('-')) { this.p++; a = { k: 'neg', a: this.parseTerm() }; }
      else if (this.isOp('+')) { this.p++; a = this.parseTerm(); }
      else a = this.parseTerm();
      for (;;) {
        const t = this.cur; let op = null;
        if (t.t === 'op' && (t.v === '+' || t.v === '-')) op = t.v;
        else if (t.t === 'kw' && (t.l === 'or' || t.l === 'xor')) op = t.l;
        if (!op) break;
        this.p++; const b = this.parseTerm(); a = { k: 'bin', op, a, b };
      }
      return a;
    }
    parseTerm() {
      let a = this.parseFactor();
      for (;;) {
        const t = this.cur; let op = null;
        if (t.t === 'op' && (t.v === '*' || t.v === '/')) op = t.v;
        else if (t.t === 'kw' && ['div', 'mod', 'and', 'shl', 'shr', 'as'].includes(t.l)) op = t.l;
        if (!op) break;
        this.p++;
        if (op === 'as') { const tn = this.qualIdent(); a = { k: 'as', a, type: tn }; continue; }
        const b = this.parseFactor(); a = { k: 'bin', op, a, b };
      }
      return a;
    }
    parseFactor() {
      const t = this.cur;
      if (t.t === 'kw' && t.l === 'not') { this.p++; return { k: 'not', a: this.parseFactor() }; }
      if (t.t === 'op' && t.v === '-') { this.p++; return { k: 'neg', a: this.parseFactor() }; }
      if (t.t === 'op' && t.v === '+') { this.p++; return this.parseFactor(); }
      if (t.t === 'op' && t.v === '@') { this.p++; return { k: 'addr', a: this.parseFactor() }; }
      if (t.t === 'num') { this.p++; return { k: 'num', v: t.v, raw: t.raw, float: t.float, hex: t.hex }; }
      if (t.t === 'str') { this.p++; let e = { k: 'str', pieces: t.pieces }; return this.parsePostfix(e); }
      if (t.t === 'kw' && t.l === 'nil') { this.p++; return { k: 'nil' }; }
      if (t.t === 'op' && t.v === '(') { this.p++; const e = this.parseExpr(); this.expectOp(')'); return this.parsePostfix({ k: 'paren', a: e }); }
      if (t.t === 'op' && t.v === '[') {
        this.p++; const items = [];
        while (!this.isOp(']') && this.cur.t !== 'eof') { const a = this.parseExpr(); if (this.eatOp('..')) items.push({ range: [a, this.parseExpr()] }); else items.push({ value: a }); if (!this.eatOp(',')) break; }
        this.expectOp(']'); return { k: 'set', items };
      }
      if (t.t === 'kw' && t.l === 'inherited') { this.p++; const d = this.parseDesignator(); return { k: 'inheritedExpr', d }; }
      if (t.t === 'kw' && (t.l === 'procedure' || t.l === 'function')) {
        // método anônimo
        this.p++; if (this.isOp('(')) this.parseParams(); if (t.l === 'function' && this.eatOp(':')) this.parseType();
        while (this.isKw('var') || this.isKw('const')) { this.p++; while (this.cur.t === 'id') { if (this.peek().v === '=' ) this.parseConstDecl(); else this.parseVarDecl('var'); } }
        const body = this.parseCompound();
        return { k: 'anon', body };
      }
      if (t.t === 'kw' && (t.l === 'string' || t.l === 'file')) { this.p++; return this.parsePostfix({ k: 'id', name: t.v }); }
      if (t.t === 'id' || (t.t === 'kw' && ['object'].includes(t.l))) return this.parseDesignator();
      this.fail('expected expression');
    }
    // TDictionary<string, TObject>.Create  /  Foo<Integer>(x)
    skipGenericArgs() {
      if (!this.isOp('<')) return false;
      let j = this.p, d = 0;
      for (; j < this.toks.length; j++) {
        const t = this.toks[j];
        if (t.t === 'op' && t.v === '<') d++;
        else if (t.t === 'op' && t.v === '>') { d--; if (d === 0) break; }
        else if (t.t === 'op' && (t.v === '<>' || t.v === '>=' || t.v === '<=')) return false;
        else if (!(t.t === 'id' || (t.t === 'kw' && ['string', 'class', 'record', 'constructor', 'array', 'of'].includes(t.l)) || (t.t === 'op' && [',', '.', ':', ';'].includes(t.v)))) return false;
      }
      const after = this.toks[j + 1];
      if (d !== 0 || !after) return false;
      if (!(after.t === 'op' && ['.', '(', ')', ';', ',', '[', ']'].includes(after.v)) && !(after.t === 'kw' && ['do', 'then', 'of', 'end', 'else'].includes(after.l))) return false;
      this.p = j + 1; return true;
    }
    parseDesignator() {
      const t = this.cur;
      if (!(t.t === 'id' || t.t === 'kw')) this.fail('expected identifier');
      this.p++;
      if (/^[A-Z]/.test(t.v) || /^t[A-Z]/.test(t.v)) this.skipGenericArgs();
      return this.parsePostfix({ k: 'id', name: t.v });
    }
    parsePostfix(e) {
      for (;;) {
        if (this.isOp('.')) { this.p++; const nt = this.cur; this.p++; this.skipGenericArgs(); e = { k: 'mem', obj: e, name: nt.v }; continue; }
        if (this.isOp('[')) { this.p++; const idx = []; do idx.push(this.parseExpr()); while (this.eatOp(',')); this.expectOp(']'); e = { k: 'index', obj: e, idx }; continue; }
        if (this.isOp('(')) { this.p++; const args = []; while (!this.isOp(')') && this.cur.t !== 'eof') { let a = this.parseExpr(); if (this.isOp(':') && a.k !== 'id') { this.p++; this.parseExpr(); if (this.eatOp(':')) this.parseExpr(); } else if (this.isOp(':')) { this.p++; const w = this.parseExpr(); let dg = null; if (this.eatOp(':')) dg = this.parseExpr(); a = { k: 'fmtw', a, w, d: dg }; } args.push(a); if (!this.eatOp(',')) break; } this.expectOp(')'); e = { k: 'call', fn: e, args }; continue; }
        if (this.isOp('^')) { this.p++; continue; }
        break;
      }
      return e;
    }
  }

  return { decodeBytes, parseDfm, parseDfmText, parseDfmBinary, FormConv, lexPas, PasParser, vbStr, vbStrExpr, colorValue, colorRawVB, colorIdentVB, KIND, DATA_CLASSES, pv, pStr, pNum, pBool, pIdent, pList, pSet };
})();
if (typeof module !== 'undefined') module.exports = DelphiImport;
