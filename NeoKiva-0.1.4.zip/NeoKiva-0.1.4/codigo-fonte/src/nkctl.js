// ===== Neo Kiva 0.1 — componentes da paleta no estilo Delphi (designer + execução) =====
'use strict';

// ---------- enumerações e tipos de propriedade dos componentes novos ----------
Object.assign(ENUMS, {
  nkbevelshape: E([0, '0 - bsBox'], [1, '1 - bsFrame'], [2, '2 - bsTopLine'], [3, '3 - bsBottomLine'], [4, '4 - bsLeftLine'], [5, '5 - bsRightLine'], [6, '6 - bsSpacer']),
  nkbevelstyle: E([0, '0 - bsLowered'], [1, '1 - bsRaised']),
  nkalign: E([0, '0 - alNone'], [1, '1 - alTop'], [2, '2 - alBottom'], [3, '3 - alLeft'], [4, '4 - alRight'], [5, '5 - alClient']),
  nkviewstyle: E([0, '0 - vsIcon'], [1, '1 - vsSmallIcon'], [2, '2 - vsList'], [3, '3 - vsReport']),
  nkorient: E([0, '0 - udVertical'], [1, '1 - udHorizontal']),
  nkgaugekind: E([0, '0 - gkHorizontalBar'], [1, '1 - gkVerticalBar'], [2, '2 - gkPie'], [3, '3 - gkNeedle'], [4, '4 - gkText']),
  nkcharttype: E([0, '0 - Bar'], [1, '1 - Line'], [2, '2 - Pie'], [3, '3 - Area']),
  nklabelpos: E([0, '0 - lpAbove'], [1, '1 - lpLeft']),
  nktoggle: E([0, '0 - tssOff'], [1, '1 - tssOn']),
});
Object.assign(PROP_TYPES, {
  colcount: 'num', rowcount: 'num', fixedcols: 'num', fixedrows: 'num', defaultcolwidth: 'num', defaultrowheight: 'num', cells: 'text', editing: 'bool', gridlines: 'bool',
  shape: 'enum', align: 'enum', panels: 'text', simpletext: 'text', simplepanel: 'bool', buttons: 'text', showcaptions: 'bool', increment: 'num', orientation: 'enum', wrap: 'bool', associate: 'text',
  columns: 'text', items: 'text', viewstyle: 'enum', rowselect: 'bool', sections: 'text', state: 'enum', oncaption: 'text', offcaption: 'text', animate: 'bool', selected: 'color', hotkey: 'text',
  kind: 'enum', progress: 'num', labelposition: 'enum', itemindex: 'num', tabs: 'text', tabindex: 'num', opened: 'bool', series: 'text', charttype: 'enum', title: 'text', delphiclass: 'text',
  filter: 'text', filename: 'text', initialdir: 'text', defaultext: 'text', dialogtitle: 'text', options: 'text', connectionstring: 'text', sql: 'text', tablename: 'text', dataset: 'text', active: 'bool',
  flat: 'bool', groupindex: 'num', down: 'bool', allowallup: 'bool', commonavi: 'text', url: 'text', placeholder: 'text', format: 'text', checkboxes: 'bool',
});
const NK_BASE = ['Name', 'Index', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Enabled', 'Tag', 'ToolTipText'];
const NK_FOCUS = [...P_COMMON];
const NK_FONT = ['BackColor', 'ForeColor', 'Font'];
const NK_NV = ['Name', 'DelphiClass', 'Left', 'Top', 'Tag'];
Object.assign(CTL, {
  'NK.Bevel': { tool: 'Bevel', w: 750, h: 750, props: ['Name', 'Index', 'Shape:nkbevelshape', 'Style:nkbevelstyle', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Tag'], events: [], noFocus: true },
  'NK.SpeedButton': { tool: 'SpeedButton', w: 345, h: 330, props: [...NK_BASE, 'Caption', 'Picture', 'Flat', 'GroupIndex', 'Down', 'AllowAllUp', ...NK_FONT], events: ['Click', 'DblClick', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click', noFocus: true },
  'NK.StringGrid': { tool: 'StringGrid', w: 4800, h: 1800, props: [...NK_FOCUS, 'ColCount', 'RowCount', 'FixedCols', 'FixedRows', 'DefaultColWidth', 'DefaultRowHeight', 'Cells', 'Editing', 'GridLines', 'Align:nkalign', ...NK_FONT], events: ['Click', 'DblClick', 'SelectCell', 'SetEditText', 'KeyDown', 'KeyPress'], defEvent: 'Click' },
  'NK.ScrollBox': { tool: 'ScrollBox', w: 2775, h: 2775, props: [...NK_BASE, 'Align:nkalign', 'BorderStyle:borderstyle', 'BackColor'], events: ['Click', 'DblClick'], defEvent: 'Click', container: true },
  'NK.SplitView': { tool: 'SplitView', w: 3000, h: 3000, props: [...NK_BASE, 'Align:nkalign', 'Opened', 'BackColor', 'ForeColor', 'Font'], events: ['Click', 'Opened', 'Closed'], defEvent: 'Click', container: true },
  'NK.Splitter': { tool: 'Splitter', w: 45, h: 1500, props: ['Name', 'Align:nkalign', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Tag', 'BackColor'], events: ['Moved'], defEvent: 'Moved', noFocus: true },
  'NK.StatusBar': { tool: 'StatusBar', w: 4800, h: 285, props: [...NK_BASE, 'Align:nkalign', 'Panels', 'SimplePanel', 'SimpleText', ...NK_FONT], events: ['Click', 'DblClick'], defEvent: 'Click', noFocus: true },
  'NK.ToolBar': { tool: 'ToolBar', w: 4800, h: 435, props: [...NK_BASE, 'Align:nkalign', 'Buttons', 'ShowCaptions', ...NK_FONT], events: ['ButtonClick'], defEvent: 'ButtonClick', noFocus: true },
  'NK.UpDown': { tool: 'UpDown', w: 255, h: 375, props: [...NK_FOCUS, 'Min', 'Max', 'Value', 'Increment', 'Orientation:nkorient', 'Wrap', 'Associate'], events: ['Change', 'Click'], defEvent: 'Click' },
  'NK.SpinEdit': { tool: 'SpinEdit', w: 1815, h: 345, props: [...NK_FOCUS, 'Value', 'Min', 'Max', 'Increment', ...NK_FONT], events: ['Change', 'KeyPress', 'GotFocus', 'LostFocus'], defEvent: 'Change' },
  'NK.ListView': { tool: 'ListView', w: 3750, h: 2250, props: [...NK_FOCUS, 'ViewStyle:nkviewstyle', 'Columns', 'Items', 'RowSelect', 'GridLines', 'Checkboxes', 'Align:nkalign', ...NK_FONT], events: ['Click', 'DblClick', 'SelectItem', 'ColumnClick'], defEvent: 'SelectItem' },
  'NK.HeaderControl': { tool: 'HeaderControl', w: 4800, h: 255, props: [...NK_BASE, 'Sections', 'Align:nkalign', ...NK_FONT], events: ['SectionClick'], defEvent: 'SectionClick', noFocus: true },
  'NK.MonthCalendar': { tool: 'MonthCalendar', w: 3375, h: 2400, props: [...NK_FOCUS, 'Value', ...NK_FONT], events: ['Click', 'Change'], defEvent: 'Change' },
  'NK.TimePicker': { tool: 'TimePicker', w: 1500, h: 345, props: [...NK_FOCUS, 'Value', ...NK_FONT], events: ['Change'], defEvent: 'Change' },
  'NK.ToggleSwitch': { tool: 'ToggleSwitch', w: 1095, h: 300, props: [...NK_FOCUS, 'State:nktoggle', 'OnCaption', 'OffCaption', ...NK_FONT], events: ['Click'], defEvent: 'Click' },
  'NK.ActivityIndicator': { tool: 'ActivityIndicator', w: 480, h: 480, props: [...NK_BASE, 'Animate', 'ForeColor'], events: [], noFocus: true },
  'NK.ColorBox': { tool: 'ColorBox', w: 2175, h: 330, props: [...NK_FOCUS, 'Selected', ...NK_FONT], events: ['Change', 'Click'], defEvent: 'Change' },
  'NK.ColorListBox': { tool: 'ColorListBox', w: 1815, h: 1455, props: [...NK_FOCUS, 'Selected', ...NK_FONT], events: ['Click', 'DblClick'], defEvent: 'Click' },
  'NK.ColorGrid': { tool: 'ColorGrid', w: 1500, h: 1500, props: [...NK_BASE, 'Selected'], events: ['Change'], defEvent: 'Change', noFocus: true },
  'NK.HotKey': { tool: 'HotKey', w: 1815, h: 285, props: [...NK_FOCUS, 'HotKey', ...NK_FONT], events: ['Change'], defEvent: 'Change' },
  'NK.Animate': { tool: 'Animate', w: 1500, h: 1050, props: [...NK_BASE, 'CommonAVI', 'Active'], events: [], noFocus: true },
  'NK.MediaPlayer': { tool: 'MediaPlayer', w: 3795, h: 450, props: [...NK_BASE, 'FileName'], events: ['Click'], defEvent: 'Click', noFocus: true },
  'NK.Gauge': { tool: 'Gauge', w: 1500, h: 1500, props: [...NK_BASE, 'Kind:nkgaugekind', 'Min', 'Max', 'Progress', ...NK_FONT], events: [], noFocus: true },
  'NK.LabeledEdit': { tool: 'LabeledEdit', w: 1815, h: 345, props: [...NK_FOCUS, 'Caption', 'Text', 'LabelPosition:nklabelpos', 'MaxLength', 'PasswordChar', ...NK_FONT], events: ['Change', 'Click', 'KeyPress', 'KeyDown', 'GotFocus', 'LostFocus'], defEvent: 'Change' },
  'NK.RadioGroup': { tool: 'RadioGroup', w: 2775, h: 1575, props: [...NK_FOCUS, 'Caption', 'Items', 'ItemIndex', 'Columns', ...NK_FONT, 'DataSource', 'DataField'], events: ['Click'], defEvent: 'Click' },
  'NK.TabSet': { tool: 'TabSet', w: 3000, h: 315, props: [...NK_BASE, 'Tabs', 'TabIndex', 'Align:nkalign', ...NK_FONT], events: ['Change', 'Click'], defEvent: 'Change', noFocus: true },
  'NK.ButtonGroup': { tool: 'ButtonGroup', w: 2000, h: 2400, props: [...NK_BASE, 'Items', ...NK_FONT], events: ['ButtonClicked'], defEvent: 'ButtonClicked', noFocus: true },
  'NK.Chart': { tool: 'Chart', w: 6000, h: 3750, props: [...NK_BASE, 'Title', 'ChartType:nkcharttype', 'Series', 'Align:nkalign', ...NK_FONT, 'DataSource'], events: ['Click'], defEvent: 'Click', noFocus: true },
  'NK.Component': { tool: 'Component', w: 420, h: 420, fixedSize: true, invisible: true, props: [...NK_NV, 'Active', 'ConnectionString', 'SQL', 'TableName', 'DataSet'], events: [], noFocus: true },
  'NK.Dialog': { tool: 'Dialog', w: 420, h: 420, fixedSize: true, invisible: true, props: [...NK_NV, 'DialogTitle', 'Filter', 'FileName', 'InitialDir', 'DefaultExt', 'Options'], events: ['Close', 'Show'], noFocus: true },
});
const NK_BASENAME = { 'NK.Bevel': 'Bevel', 'NK.SpeedButton': 'SpeedButton', 'NK.StringGrid': 'StringGrid', 'NK.ScrollBox': 'ScrollBox', 'NK.SplitView': 'SplitView', 'NK.Splitter': 'Splitter', 'NK.StatusBar': 'StatusBar', 'NK.ToolBar': 'ToolBar', 'NK.UpDown': 'UpDown', 'NK.SpinEdit': 'SpinEdit', 'NK.ListView': 'ListView', 'NK.HeaderControl': 'HeaderControl', 'NK.MonthCalendar': 'MonthCalendar', 'NK.TimePicker': 'TimePicker', 'NK.ToggleSwitch': 'ToggleSwitch', 'NK.ActivityIndicator': 'ActivityIndicator', 'NK.ColorBox': 'ColorBox', 'NK.ColorListBox': 'ColorListBox', 'NK.ColorGrid': 'ColorGrid', 'NK.HotKey': 'HotKey', 'NK.Animate': 'Animate', 'NK.MediaPlayer': 'MediaPlayer', 'NK.Gauge': 'Gauge', 'NK.LabeledEdit': 'LabeledEdit', 'NK.RadioGroup': 'RadioGroup', 'NK.TabSet': 'TabSet', 'NK.ButtonGroup': 'ButtonGroup', 'NK.Chart': 'Chart', 'NK.Component': 'Component', 'NK.Dialog': 'Dialog' };

function nkDefaults(type, d) {
  switch (type) {
    case 'NK.Bevel': Object.assign(d, { shape: 0, style: 0 }); break;
    case 'NK.SpeedButton': Object.assign(d, { flat: false, groupindex: 0, down: false, allowallup: false }); break;
    case 'NK.StringGrid': Object.assign(d, { colcount: 5, rowcount: 5, fixedcols: 1, fixedrows: 1, defaultcolwidth: 64, defaultrowheight: 24, cells: '', editing: false, gridlines: true, align: 0, backcolor: -2147483643 }); break;
    case 'NK.ScrollBox': Object.assign(d, { align: 0, borderstyle: 1 }); break;
    case 'NK.SplitView': Object.assign(d, { align: 3, opened: true, backcolor: 0x2b2b2b, forecolor: 0xffffff }); break;
    case 'NK.Splitter': Object.assign(d, { align: 3 }); break;
    case 'NK.StatusBar': Object.assign(d, { align: 2, panels: '', simplepanel: true, simpletext: '' }); break;
    case 'NK.ToolBar': Object.assign(d, { align: 1, buttons: 'New|Open|Save|-|Cut|Copy|Paste', showcaptions: true }); break;
    case 'NK.UpDown': Object.assign(d, { min: 0, max: 100, value: 0, increment: 1, orientation: 0, wrap: false, associate: '' }); break;
    case 'NK.SpinEdit': Object.assign(d, { min: 0, max: 100, value: 0, increment: 1, backcolor: -2147483643 }); break;
    case 'NK.ListView': Object.assign(d, { viewstyle: 3, columns: 'Name|Value', items: '', rowselect: true, gridlines: false, checkboxes: false, align: 0, backcolor: -2147483643 }); break;
    case 'NK.HeaderControl': Object.assign(d, { sections: 'Section 1|Section 2|Section 3', align: 1 }); break;
    case 'NK.MonthCalendar': case 'NK.TimePicker': Object.assign(d, { value: '' }); break;
    case 'NK.ToggleSwitch': Object.assign(d, { state: 0, oncaption: 'On', offcaption: 'Off' }); break;
    case 'NK.ActivityIndicator': Object.assign(d, { animate: false, forecolor: 0 }); break;
    case 'NK.ColorBox': case 'NK.ColorListBox': case 'NK.ColorGrid': Object.assign(d, { selected: 0 }); break;
    case 'NK.HotKey': Object.assign(d, { hotkey: 'Alt+A' }); break;
    case 'NK.Animate': Object.assign(d, { commonavi: 'aviNone', active: false }); break;
    case 'NK.MediaPlayer': Object.assign(d, { filename: '' }); break;
    case 'NK.Gauge': Object.assign(d, { kind: 0, min: 0, max: 100, progress: 0, backcolor: 0xffffff, forecolor: 0x800000 }); break;
    case 'NK.LabeledEdit': Object.assign(d, { text: '', labelposition: 0, maxlength: 0, passwordchar: '', backcolor: -2147483643 }); break;
    case 'NK.RadioGroup': Object.assign(d, { items: '', itemindex: -1, columns: 1 }); break;
    case 'NK.TabSet': Object.assign(d, { tabs: 'Tab1|Tab2|Tab3', tabindex: 0, align: 0 }); break;
    case 'NK.ButtonGroup': Object.assign(d, { items: 'Button 1|Button 2|Button 3' }); break;
    case 'NK.Chart': Object.assign(d, { title: 'Chart', charttype: 0, series: 'Jan=10|Feb=25|Mar=18|Apr=32|May=27', align: 0, backcolor: 0xffffff }); break;
    case 'NK.Component': Object.assign(d, { delphiclass: 'TComponent', active: false, connectionstring: '', sql: '', tablename: '', dataset: '' }); break;
    case 'NK.Dialog': Object.assign(d, { delphiclass: 'TOpenDialog', dialogtitle: '', filter: '', filename: '', initialdir: '', defaultext: '', options: '' }); break;
  }
  return d;
}

// ---------- utilidades ----------
const nkEsc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const nkSplit = s => String(s == null ? '' : s).split(/\||\r?\n/).filter((x, i, a) => !(x === '' && i === a.length - 1));
function nkCells(P) {
  if (!P._cells) { P._cells = []; String(P.cells || '').split('|').forEach((row, r) => { if (row !== '' || r === 0) P._cells[r] = row.split(';'); }); if (P.cells === '' || P.cells == null) P._cells = []; }
  return P._cells;
}
function nkCellsText(P) { return (P._cells || []).map(r => (r || []).join(';')).join('|'); }
function nkItems(P, key) { if (!P['_' + key]) P['_' + key] = nkSplit(P[key]); return P['_' + key]; }
function nkColorCss(v) { return vbColorCss(v == null ? 0 : v) || '#000'; }
const NK_COLORS = [['clBlack', 0x000000], ['clMaroon', 0x000080], ['clGreen', 0x008000], ['clOlive', 0x008080], ['clNavy', 0x800000], ['clPurple', 0x800080], ['clTeal', 0x808000], ['clGray', 0x808080], ['clSilver', 0xC0C0C0], ['clRed', 0x0000FF], ['clLime', 0x00FF00], ['clYellow', 0x00FFFF], ['clBlue', 0xFF0000], ['clFuchsia', 0xFF00FF], ['clAqua', 0xFFFF00], ['clWhite', 0xFFFFFF], ['clMoneyGreen', 0xC0DCC0], ['clSkyBlue', 0xF0CAA6], ['clCream', 0xF0FBFF], ['clMedGray', 0xA4A0A0]];
function nkColorName(v) { const f = NK_COLORS.find(c => c[1] === Number(v)); return f ? f[0] : '$' + (Number(v) >>> 0).toString(16).toUpperCase().padStart(8, '0'); }
function nkDateParts(v) { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v || ''); const d = m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date(); return d; }
const nkPad = n => String(n).padStart(2, '0');
function nkIsoDate(d) { return `${d.getFullYear()}-${nkPad(d.getMonth() + 1)}-${nkPad(d.getDate())}`; }

// ---------- construção e atualização (chamadas por vbui.js) ----------
function nkBuildInner(type, P, ctx) {
  if (!/^NK\./.test(type)) return undefined;
  const d = document.createElement('div'); d.className = 'nk-fill';
  return d;
}
function nkAlign(el, P, W, H) {
  const st = el.style; const a = Number(P.align) || 0;
  st.right = ''; st.bottom = '';
  if (!a) return;
  if (a === 1) Object.assign(st, { left: '0px', top: '0px', width: '100%' });
  else if (a === 2) Object.assign(st, { left: '0px', top: 'auto', bottom: '0px', width: '100%' });
  else if (a === 3) Object.assign(st, { left: '0px', top: '0px', height: '100%' });
  else if (a === 4) Object.assign(st, { left: 'auto', right: '0px', top: '0px', height: '100%' });
  else if (a === 5) Object.assign(st, { left: '0px', top: '0px', width: '100%', height: '100%' });
}
function nkUpdate(el, type, P, ctx, W, H) {
  const f = el.querySelector(':scope > .nk-fill') || el.firstChild; if (!f) return;
  const bg = vbColorCss(P.backcolor), fg = vbColorCss(P.forecolor);
  const design = !!ctx.design;
  if ('align' in P) nkAlign(el, P, W, H);
  switch (type) {
    case 'NK.Bevel': {
      const cls = ['box', 'frame', 'top', 'bottom', 'left', 'right', 'spacer'][P.shape] || 'box';
      f.innerHTML = `<div class="nk-bevel ${cls} ${P.style === 1 ? 'hi' : 'lo'}"></div>`;
      if (design && cls === 'spacer') f.firstChild.style.borderColor = '#a0a0a0';
      break;
    }
    case 'NK.SpeedButton': {
      const pic = P.picture && P.picture.url ? `<img src="${P.picture.url}" alt="">` : '';
      f.innerHTML = `<div class="nk-speed${P.down ? ' down' : ''}" style="${P.flat ? '' : 'border-color:#adadad;background:#e1e1e1'}">${pic}<span>${mnemonicHtml(String(P.caption || ''))}</span></div>`;
      break;
    }
    case 'NK.StringGrid': {
      if (P._editing) return;
      const cells = nkCells(P), rows = Math.max(0, P.rowcount | 0), cols = Math.max(0, P.colcount | 0);
      const cw = Math.max(8, Number(P.defaultcolwidth) || 64), rh = Math.max(8, Number(P.defaultrowheight) || 24);
      let html = `<div class="nk-grid" style="background:${bg}"><table style="color:${fg}"><colgroup>${('<col style="width:' + (cw + 1) + 'px">').repeat(cols)}</colgroup>`;
      const shown = Math.min(rows, 500);
      for (let r = 0; r < shown; r++) {
        html += `<tr style="height:${rh + 1}px">`;
        for (let c = 0; c < cols; c++) { const fx = r < P.fixedrows || c < P.fixedcols; const sel = !design && r === P._row && c === P._col && !fx; html += `<td data-r="${r}" data-c="${c}" class="${fx ? 'fx' : ''}${sel ? ' sel' : ''}" style="height:${rh}px">${nkEsc((cells[r] || [])[c] || '')}</td>`; }
        html += '</tr>';
      }
      f.innerHTML = html + '</table></div>';
      if (P.gridlines === false) f.querySelectorAll('td:not(.fx)').forEach(td => { td.style.borderColor = 'transparent'; });
      break;
    }
    case 'NK.ScrollBox': { el.classList.toggle('vb-border1', P.borderstyle === 1); el.style.backgroundColor = bg; f.style.pointerEvents = 'none'; break; }
    case 'NK.SplitView': { el.style.backgroundColor = bg; el.style.color = fg; if (!design && P.opened === false) el.style.width = '48px'; break; }
    case 'NK.Splitter': { el.classList.toggle('design', design); el.classList.toggle('horz', P.align === 1 || P.align === 2); break; }
    case 'NK.StatusBar': {
      const panels = nkItems(P, 'panels');
      const parts = (P.simplepanel || !panels.length) ? `<span>${nkEsc(P.simpletext || '')}</span>` : panels.map(p => { const m = /^(.*?)(?:@(\d+))?$/.exec(p); return `<span style="${m[2] ? 'flex:none;width:' + m[2] + 'px' : ''}">${nkEsc(m[1])}</span>`; }).join('');
      f.innerHTML = `<div class="nk-status" style="${P.backcolor === -2147483633 ? '' : 'background:' + bg}">${parts}<i class="grip"></i></div>`;
      break;
    }
    case 'NK.ToolBar': {
      const btn = nkItems(P, 'buttons');
      const menu = /menubar/i.test(P.name || '') ;
      f.innerHTML = `<div class="nk-toolbar${menu ? ' menu' : ''}" style="${P.backcolor === -2147483633 ? '' : 'background:' + bg}">${btn.map((b, i) => b === '-' ? '<b class="sep"></b>' : `<b data-i="${i}">${P.showcaptions === false ? '&#9634;' : mnemonicHtml(b)}</b>`).join('')}</div>`;
      break;
    }
    case 'NK.UpDown': { f.innerHTML = `<div class="nk-updown${P.orientation === 1 ? ' horz' : ''}"><b class="u"></b><b class="d"></b></div>`; break; }
    case 'NK.SpinEdit': {
      const inp = f.querySelector('input');
      if (!inp) { f.innerHTML = `<div class="nk-spin" style="background:${bg}"><input spellcheck="false"${design ? ' readonly tabindex="-1"' : ''}><div class="nk-updown"><b class="u"></b><b class="d"></b></div></div>`; }
      const i2 = f.querySelector('input'); if (document.activeElement !== i2 || design) i2.value = String(P.value ?? 0); i2.style.color = fg; i2.disabled = !P.enabled && !design;
      break;
    }
    case 'NK.ListView': {
      const cols = nkItems(P, 'columns'); const items = nkItems(P, 'items').map(s => s.split(';'));
      const vs = Number(P.viewstyle);
      let html = `<div class="nk-lv" style="background:${bg};color:${fg}">`;
      if (vs === 3) {
        html += `<table><thead><tr>${cols.map((c, i) => `<th data-c="${i}">${nkEsc(c)}</th>`).join('')}</tr></thead><tbody>`;
        items.forEach((it, i) => { html += `<tr data-i="${i}" class="${P._sel === i ? 'sel' : ''}">${cols.map((c, k) => `<td style="${P.gridlines ? 'border:1px solid #f0f0f0' : ''}">${k === 0 && P.checkboxes ? '<span class="vb-box chk" style="display:inline-block;vertical-align:-2px;margin-right:4px"></span>' : ''}${nkEsc(it[k] || '')}</td>`).join('')}</tr>`; });
        html += '</tbody></table>';
      } else {
        html += `<div class="icons" style="${vs === 2 || vs === 1 ? 'flex-direction:column;flex-wrap:wrap;max-height:100%' : ''}">${items.map((it, i) => `<div data-i="${i}" style="${vs ? 'width:auto;text-align:left' : ''}${P._sel === i ? ';background:#cce8ff' : ''}">${nkEsc(it[0] || '')}</div>`).join('')}</div>`;
      }
      f.innerHTML = html + '</div>';
      if (vs !== 0 && vs !== 3) f.querySelectorAll('.icons div').forEach(x => x.classList.add('small'));
      break;
    }
    case 'NK.HeaderControl': { f.innerHTML = `<div class="nk-hdr">${nkItems(P, 'sections').map((s, i) => `<b data-i="${i}" style="width:${Math.max(40, (W / Math.max(1, nkItems(P, 'sections').length)) | 0)}px">${nkEsc(s)}</b>`).join('')}</div>`; break; }
    case 'NK.MonthCalendar': {
      const sel = nkDateParts(P.value); const cur = P._view ? new Date(P._view) : new Date(sel.getFullYear(), sel.getMonth(), 1);
      const first = new Date(cur.getFullYear(), cur.getMonth(), 1); const start = new Date(first); start.setDate(1 - first.getDay());
      const today = new Date(); const mn = first.toLocaleString(typeof NB_LOCALE !== 'undefined' ? NB_LOCALE : 'en-US', { month: 'long', year: 'numeric' });
      let g = ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(x => `<span class="dw">${x}</span>`).join('');
      for (let i = 0; i < 42; i++) { const d = new Date(start); d.setDate(start.getDate() + i); const cls = [d.getMonth() !== first.getMonth() ? 'o' : '', d.toDateString() === today.toDateString() ? 't' : '', d.toDateString() === sel.toDateString() && P.value ? 's' : ''].join(' '); g += `<span class="${cls}" data-d="${nkIsoDate(d)}">${d.getDate()}</span>`; }
      f.innerHTML = `<div class="nk-cal" style="background:${bg};color:${fg}"><div class="hd"><b data-m="-1">&#9664;</b><span>${nkEsc(mn.charAt(0).toUpperCase() + mn.slice(1))}</span><b data-m="1">&#9654;</b></div><div class="g">${g}</div></div>`;
      break;
    }
    case 'NK.TimePicker': {
      let inp = f.querySelector('input'); if (!inp) { f.innerHTML = '<input type="time" class="nk-time">'; inp = f.firstChild; if (design) { inp.readOnly = true; inp.tabIndex = -1; } }
      const v = P.value || (design ? '12:00' : ''); if (inp.value !== v) inp.value = v; inp.disabled = !P.enabled && !design; inp.style.color = fg;
      break;
    }
    case 'NK.ToggleSwitch': { f.innerHTML = `<div class="nk-toggle${Number(P.state) === 1 ? ' on' : ''}" style="color:${fg}"><i></i><span>${nkEsc(Number(P.state) === 1 ? P.oncaption : P.offcaption)}</span></div>`; break; }
    case 'NK.ActivityIndicator': {
      const c = P.forecolor ? nkColorCss(P.forecolor) : '#333';
      if (!f.firstChild) { let dots = ''; for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; dots += `<circle cx="${12 + 8 * Math.cos(a)}" cy="${12 + 8 * Math.sin(a)}" r="${1 + i * 0.25}" fill="${c}" opacity="${0.25 + i * 0.1}"/>`; } f.innerHTML = `<div class="nk-activity"><svg viewBox="0 0 24 24">${dots}</svg></div>`; }
      f.firstChild.classList.toggle('on', !!P.animate && !design); f.style.display = (!design && !P.animate) ? 'none' : '';
      break;
    }
    case 'NK.ColorBox': { f.innerHTML = `<div class="nk-colorbox"><i style="background:${nkColorCss(P.selected)}"></i><span>${nkColorName(P.selected)}</span><span class="vb-dd" style="flex:none;width:17px"></span></div>`; break; }
    case 'NK.ColorListBox': { f.innerHTML = `<div class="nk-clist" style="color:${fg}">${NK_COLORS.map(([n, v], i) => `<div data-i="${i}" class="${v === Number(P.selected) ? 'sel' : ''}"><i style="background:${nkColorCss(v)}"></i>${n}</div>`).join('')}</div>`; break; }
    case 'NK.ColorGrid': { f.innerHTML = `<div class="nk-cgrid">${NK_COLORS.slice(0, 16).map(([n, v], i) => `<div data-i="${i}" title="${n}" style="background:${nkColorCss(v)};${v === Number(P.selected) ? 'outline:2px solid #fff;outline-offset:-3px' : ''}"></div>`).join('')}</div>`; break; }
    case 'NK.HotKey': { if (!f.querySelector('input')) f.innerHTML = '<div class="nk-edit"><input readonly spellcheck="false"></div>'; f.querySelector('input').value = P.hotkey || 'None'; break; }
    case 'NK.Animate': { f.innerHTML = `<div class="nk-anim">${design ? '&#9654; Animate' : ''}</div>`; break; }
    case 'NK.MediaPlayer': { f.innerHTML = `<div class="nk-mplayer">${['&#9654;', '&#10074;&#10074;', '&#9632;', '&#9198;', '&#9197;', '&#9664;&#9664;', '&#9654;&#9654;', '&#9167;', '&#9210;'].map((x, i) => `<b data-i="${i}">${x}</b>`).join('')}</div>`; break; }
    case 'NK.Gauge': {
      const mn = Number(P.min) || 0, mx = Number(P.max) || 100, v = Number(P.progress) || 0; const fr = Math.max(0, Math.min(1, (v - mn) / ((mx - mn) || 1))); const pct = Math.round(fr * 100) + '%';
      const fc = nkColorCss(P.forecolor), bc = nkColorCss(P.backcolor);
      const k = Number(P.kind);
      if (k === 2) { const a = fr * 2 * Math.PI, x = 50 + 48 * Math.sin(a), y = 50 - 48 * Math.cos(a); f.innerHTML = `<div class="nk-gauge" style="background:${bc}"><svg viewBox="0 0 100 100" preserveAspectRatio="none"><ellipse cx="50" cy="50" rx="48" ry="48" fill="${bc}" stroke="#000"/>${fr >= 1 ? `<ellipse cx="50" cy="50" rx="48" ry="48" fill="${fc}"/>` : fr > 0 ? `<path d="M50 50 L50 2 A48 48 0 ${fr > .5 ? 1 : 0} 1 ${x} ${y} Z" fill="${fc}"/>` : ''}</svg><span>${pct}</span></div>`; }
      else if (k === 3) { const a = Math.PI * (1 - fr); f.innerHTML = `<div class="nk-gauge" style="background:${bc}"><svg viewBox="0 0 100 60" preserveAspectRatio="none"><path d="M4 56 A46 46 0 0 1 96 56" fill="none" stroke="#000"/><line x1="50" y1="56" x2="${50 + 44 * Math.cos(a)}" y2="${56 - 44 * Math.sin(a)}" stroke="${fc}" stroke-width="3"/></svg></div>`; }
      else if (k === 4) f.innerHTML = `<div class="nk-gauge" style="background:${bc}"><span style="mix-blend-mode:normal;color:${fc}">${pct}</span></div>`;
      else f.innerHTML = `<div class="nk-gauge" style="background:${bc}"><i style="background:${fc};${k === 1 ? `top:auto;right:0;height:${fr * 100}%` : `width:${fr * 100}%`}"></i><span>${pct}</span></div>`;
      break;
    }
    case 'NK.LabeledEdit': {
      if (!f.querySelector('input')) f.innerHTML = `<span class="nk-ledit-cap"></span><div class="nk-edit"><input spellcheck="false"${design ? ' readonly tabindex="-1"' : ''}></div>`;
      el.style.overflow = 'visible'; f.style.overflow = 'visible';
      const cap = f.querySelector('.nk-ledit-cap'); cap.innerHTML = mnemonicHtml(String(P.caption || '')); cap.classList.toggle('left', P.labelposition === 1);
      const inp = f.querySelector('input'); if (inp.value !== String(P.text ?? '')) inp.value = String(P.text ?? ''); inp.type = P.passwordchar ? 'password' : 'text';
      inp.parentNode.style.background = bg; inp.style.color = fg; if (!design) { inp.disabled = !P.enabled; if (P.maxlength) inp.maxLength = P.maxlength; }
      break;
    }
    case 'NK.RadioGroup': {
      const items = nkItems(P, 'items'); const cols = Math.max(1, Number(P.columns) || 1); const rows = Math.ceil(items.length / cols) || 1;
      f.innerHTML = `<div class="nk-rgroup" style="background:${bg};color:${fg}"><span class="cap" style="background:${bg}">${mnemonicHtml(String(P.caption || ''))}</span><div class="items" style="grid-template-columns:repeat(${cols},1fr);grid-template-rows:repeat(${rows},auto);grid-auto-flow:column">${items.map((it, i) => `<label class="it" data-i="${i}"><span class="vb-box opt${Number(P.itemindex) === i ? ' on' : ''}"></span><span>${mnemonicHtml(it)}</span></label>`).join('')}</div></div>`;
      el.style.overflow = 'visible'; f.style.overflow = 'visible';
      break;
    }
    case 'NK.TabSet': { const t = nkItems(P, 'tabs'); f.innerHTML = `<div class="nk-tabset">${t.map((x, i) => `<b data-i="${i}" class="${i === Number(P.tabindex) ? 'on' : ''}">${nkEsc(x)}</b>`).join('')}</div>`; break; }
    case 'NK.ButtonGroup': { f.innerHTML = `<div class="nk-btngroup" style="color:${fg}">${nkItems(P, 'items').map((x, i) => /^#/.test(x) ? `<div class="cat">${nkEsc(x.slice(1))}</div>` : `<b data-i="${i}">${nkEsc(x)}</b>`).join('')}</div>`; break; }
    case 'NK.Chart': {
      const pts = nkItems(P, 'series').map(s => { const m = /^(.*?)=(.*)$/.exec(s); return m ? [m[1], Number(m[2]) || 0] : [s, 0]; });
      const max = Math.max(1, ...pts.map(p => p[1])); const n = Math.max(1, pts.length); const pal = ['#4a7ebb', '#be4b48', '#98b954', '#7d60a0', '#46aac5', '#f79646', '#2c4d75', '#772c2a'];
      const k = Number(P.charttype); let s = '';
      if (k === 2) { let a0 = -Math.PI / 2; const tot = pts.reduce((t, p) => t + Math.max(0, p[1]), 0) || 1; pts.forEach((p, i) => { const a1 = a0 + 2 * Math.PI * Math.max(0, p[1]) / tot; const x0 = 50 + 38 * Math.cos(a0), y0 = 50 + 38 * Math.sin(a0), x1 = 50 + 38 * Math.cos(a1), y1 = 50 + 38 * Math.sin(a1); s += `<path d="M50 50L${x0} ${y0}A38 38 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1} ${y1}Z" fill="${pal[i % 8]}" stroke="#fff" stroke-width=".5"/>`; a0 = a1; }); s = `<svg viewBox="0 0 100 100">${s}</svg>`; }
      else {
        const gx = i => 10 + (i + .5) * 86 / n, gy = v => 88 - 80 * v / max;
        s += `<path d="M10 4V88H96" fill="none" stroke="#888" stroke-width=".4"/>`;
        for (let t = 1; t <= 4; t++) s += `<path d="M10 ${88 - 20 * t}H96" stroke="#ddd" stroke-width=".3"/>`;
        if (k === 0) pts.forEach((p, i) => { const bw = 86 / n * .6; s += `<rect x="${gx(i) - bw / 2}" y="${gy(p[1])}" width="${bw}" height="${88 - gy(p[1])}" fill="${pal[0]}"/>`; });
        else { const d = pts.map((p, i) => `${i ? 'L' : 'M'}${gx(i)} ${gy(p[1])}`).join(''); s += k === 3 ? `<path d="${d}L${gx(n - 1)} 88L${gx(0)} 88Z" fill="${pal[0]}" opacity=".6"/>` : `<path d="${d}" fill="none" stroke="${pal[0]}" stroke-width="1"/>`; }
        pts.forEach((p, i) => { s += `<text x="${gx(i)}" y="95" font-size="4" text-anchor="middle" fill="#333">${nkEsc(p[0])}</text>`; });
        s = `<svg viewBox="0 0 100 100" preserveAspectRatio="none">${s}</svg>`;
      }
      f.innerHTML = `<div class="nk-chart" style="background:${bg};color:${fg}">${P.title ? `<div class="ttl">${nkEsc(P.title)}</div>` : ''}${s}</div>`;
      break;
    }
    case 'NK.Component': case 'NK.Dialog': {
      const icon = typeof nkPaletteIcon === 'function' ? nkPaletteIcon(P.delphiclass) : '';
      f.innerHTML = design ? `<div class="nk-comp" title="${nkEsc(P.name)}: ${nkEsc(P.delphiclass)}">${icon || '&#9881;'}<span class="cap">${nkEsc(P.name)}</span></div>` : '';
      break;
    }
  }
}

// ---------- execução ----------
function nkWire(c) {
  const el = c.el, P = c.P, t = c.type; const ok = () => P.enabled && !c.form.modalBlocked();
  const fire = (ev, args) => c.fire(ev, args);
  switch (t) {
    case 'NK.SpeedButton': el.addEventListener('click', () => { if (!ok()) return; if (P.groupindex) { if (P.down && P.allowallup) P.down = false; else { P.down = true; for (const o of c.form.allControls) if (o !== c && o.type === 'NK.SpeedButton' && o.P.groupindex === P.groupindex && o.parentCtl === c.parentCtl) { o.P.down = false; o.refresh(); } } c.refresh(); } fire('click'); }); break;
    case 'NK.StringGrid': {
      el.addEventListener('mousedown', ev => { const td = ev.target.closest('td'); if (!td || !ok()) return; const r = +td.dataset.r, cc = +td.dataset.c; if (r < P.fixedrows || cc < P.fixedcols) return; P._row = r; P._col = cc; c.refresh(); fire('selectcell', [cc, r]); fire('click'); });
      el.addEventListener('dblclick', ev => {
        const td = ev.target.closest('td'); if (!td || !P.editing || !ok()) return; const r = +td.dataset.r, cc = +td.dataset.c; if (r < P.fixedrows || cc < P.fixedcols) return;
        const cells = nkCells(P); const inp = document.createElement('input'); inp.value = (cells[r] || [])[cc] || ''; td.textContent = ''; td.appendChild(inp); P._editing = true; inp.focus(); inp.select();
        const done = (save) => { if (!P._editing) return; P._editing = false; if (save) { while (cells.length <= r) cells.push([]); cells[r][cc] = inp.value; fire('setedittext', [cc, r, inp.value]); } c.refresh(); };
        inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(true); } else if (e.key === 'Escape') done(false); e.stopPropagation(); });
        inp.addEventListener('blur', () => done(true));
      });
      break;
    }
    case 'NK.UpDown': case 'NK.SpinEdit': {
      const step = async (dir) => { if (!ok()) return; let v = (Number(P.value) || 0) + dir * (Number(P.increment) || 1); const mn = Number(P.min) || 0, mx = Number(P.max); if (mx > mn) { if (v > mx) v = P.wrap ? mn : mx; if (v < mn) v = P.wrap ? mx : mn; } if (v === P.value) return; P.value = v; c.refresh(); if (P.associate) { const o = c.form.byName && c.form.getControl(String(P.associate).toLowerCase()); if (o && o.setMember) await o.setMember('text', String(v)); } await fire('change'); await fire('click', [dir > 0 ? 0 : 1]); };
      el.addEventListener('mousedown', ev => { const b = ev.target.closest('.nk-updown b'); if (!b) return; ev.preventDefault(); step(b.classList.contains('u') ? (P.orientation === 1 && t === 'NK.UpDown' ? 1 : 1) : -1); });
      if (t === 'NK.SpinEdit') { const inp = el.querySelector('input'); inp.addEventListener('input', () => { const n = Number(inp.value.replace(',', '.')); if (!isNaN(n)) { P.value = n; fire('change'); } }); inp.addEventListener('keydown', ev => { if (ev.key === 'ArrowUp') { ev.preventDefault(); step(1); } if (ev.key === 'ArrowDown') { ev.preventDefault(); step(-1); } }); }
      break;
    }
    case 'NK.ListView': el.addEventListener('mousedown', ev => { if (!ok()) return; const th = ev.target.closest('th'); if (th) { fire('columnclick', [+th.dataset.c]); return; } const r = ev.target.closest('[data-i]'); if (!r) return; P._sel = +r.dataset.i; c.refresh(); fire('selectitem', [P._sel]); fire('click'); }); break;
    case 'NK.HeaderControl': el.addEventListener('click', ev => { const b = ev.target.closest('[data-i]'); if (b && ok()) fire('sectionclick', [+b.dataset.i]); }); break;
    case 'NK.MonthCalendar': el.addEventListener('mousedown', ev => { if (!ok()) return; const m = ev.target.closest('[data-m]'); if (m) { ev.preventDefault(); const cur = P._view ? new Date(P._view) : new Date(nkDateParts(P.value).getFullYear(), nkDateParts(P.value).getMonth(), 1); cur.setMonth(cur.getMonth() + Number(m.dataset.m)); P._view = cur.getTime(); c.refresh(); return; } const d = ev.target.closest('[data-d]'); if (d) { P.value = d.dataset.d; P._view = null; c.refresh(); fire('change'); fire('click'); } }); break;
    case 'NK.TimePicker': el.addEventListener('change', ev => { P.value = ev.target.value; fire('change'); }); break;
    case 'NK.ToggleSwitch': el.addEventListener('click', () => { if (!ok()) return; P.state = Number(P.state) === 1 ? 0 : 1; c.refresh(); fire('click'); }); break;
    case 'NK.ColorBox': el.addEventListener('click', async () => { if (!ok() || !c.form.host.pickColor) return; const r = await c.form.host.pickColor(nkColorCss(P.selected)); if (r == null) return; P.selected = cssToVbColor(r); c.refresh(); fire('change'); fire('click'); }); break;
    case 'NK.ColorListBox': case 'NK.ColorGrid': el.addEventListener('mousedown', ev => { const r = ev.target.closest('[data-i]'); if (!r || !ok()) return; P.selected = NK_COLORS[+r.dataset.i][1]; c.refresh(); fire(t === 'NK.ColorGrid' ? 'change' : 'click'); }); break;
    case 'NK.HotKey': { const inp = el.querySelector('input'); inp.addEventListener('keydown', ev => { ev.preventDefault(); if (/^(Shift|Control|Alt|Meta)$/.test(ev.key)) return; const k = [ev.ctrlKey ? 'Ctrl' : '', ev.shiftKey ? 'Shift' : '', ev.altKey ? 'Alt' : '', ev.key.length === 1 ? ev.key.toUpperCase() : ev.key].filter(Boolean).join('+'); P.hotkey = k; c.refresh(); fire('change'); }); break; }
    case 'NK.MediaPlayer': el.addEventListener('click', ev => { const b = ev.target.closest('[data-i]'); if (b && ok()) fire('click', [+b.dataset.i]); }); break;
    case 'NK.LabeledEdit': { const inp = el.querySelector('input'); inp.addEventListener('input', () => { P.text = inp.value; fire('change'); }); inp.addEventListener('keydown', ev => c.onKeyDown(ev)); inp.addEventListener('focus', () => { c.form.activeCtl = c; fire('gotfocus'); }); inp.addEventListener('blur', () => fire('lostfocus')); break; }
    case 'NK.RadioGroup': el.addEventListener('click', ev => { const it = ev.target.closest('[data-i]'); if (!it || !ok()) return; ev.preventDefault(); const i = +it.dataset.i; if (i === Number(P.itemindex)) return; P.itemindex = i; c.refresh(); fire('click'); }); break;
    case 'NK.TabSet': el.addEventListener('mousedown', ev => { const b = ev.target.closest('[data-i]'); if (!b || !ok()) return; P.tabindex = +b.dataset.i; c.refresh(); fire('change', [P.tabindex]); fire('click'); }); break;
    case 'NK.ButtonGroup': el.addEventListener('click', ev => { const b = ev.target.closest('b[data-i]'); if (b && ok()) fire('buttonclicked', [+b.dataset.i]); }); break;
    case 'NK.ToolBar': el.addEventListener('click', ev => { const b = ev.target.closest('b[data-i]'); if (b && ok()) fire('buttonclick', [+b.dataset.i, stripMnemonic(nkItems(P, 'buttons')[+b.dataset.i] || '')]); }); break;
    case 'NK.Chart': case 'NK.StatusBar': el.addEventListener('click', () => { if (ok()) fire('click'); }); break;
    case 'NK.ScrollBox': case 'NK.SplitView': el.addEventListener('click', ev => { if (ok() && ev.target.closest('.vbc') === el) fire('click'); }); break;
  }
}
const nkArg = (a, i) => (a[i] === undefined || (typeof VBMissing !== 'undefined' && a[i] === VBMissing)) ? undefined : a[i];
// getMember: devolve undefined para seguir o caminho normal
async function nkGet(c, n, rt) {
  const P = c.P, t = c.type;
  if (t === 'NK.StringGrid') { if (n === 'row') return P._row ?? P.fixedrows; if (n === 'col') return P._col ?? P.fixedcols; if (n === 'cells') return new NKIndexed(c, 'cells'); }
  if (t === 'NK.RadioGroup' || t === 'NK.ListView' || t === 'NK.TabSet' || t === 'NK.ButtonGroup') { if (n === 'listcount' || n === 'count') return nkItems(P, t === 'NK.TabSet' ? 'tabs' : 'items').length; }
  if (t === 'NK.RadioGroup' && n === 'text') { const i = Number(P.itemindex); return i >= 0 ? stripMnemonic(nkItems(P, 'items')[i] || '') : ''; }
  if (t === 'NK.ListView') { if (n === 'selectedindex' || n === 'itemindex') return P._sel ?? -1; if (n === 'text') { const it = nkItems(P, 'items')[P._sel]; return it ? it.split(';')[0] : ''; } }
  if (t === 'NK.LabeledEdit' && n === 'text') { const i = c.el.querySelector('input'); return i ? i.value : P.text; }
  if (t === 'NK.SpinEdit' && (n === 'text')) return String(P.value ?? 0);
  if ((t === 'NK.MonthCalendar') && (n === 'value' || n === 'date')) { const d = nkDateParts(P.value); return typeof VBDate !== 'undefined' ? new VBDate(d) : d; }
  if (t === 'NK.TimePicker' && (n === 'value' || n === 'time')) return P.value || '';
  if (t === 'NK.ToggleSwitch' && (n === 'value' || n === 'ison')) return Number(P.state) === 1;
  if (t === 'NK.UpDown' && n === 'position') return P.value;
  if (t === 'NK.Gauge' && n === 'value') return P.progress;
  if (t === 'NK.StatusBar' && n === 'panels') return new NKIndexed(c, 'panels');
  if (t === 'NK.Dialog') { if (n === 'execute') return nkCall(c, 'execute', [], rt); if (n in P) return P[n] ?? ''; if (['color', 'fontname', 'fontsize', 'findtext', 'replacetext', 'copies'].includes(n)) return P[n] ?? (n === 'color' || n === 'copies' || n === 'fontsize' ? 0 : ''); }
  if (t === 'NK.Component') { if (['open', 'close', 'execsql', 'first', 'last', 'next', 'prior', 'refresh', 'post', 'cancel', 'append', 'edit', 'delete', 'popup'].includes(n)) return nkCall(c, n, [], rt); if (n === 'eof' || n === 'bof') return true; if (n === 'recordcount') return 0; if (n in P) return P[n]; return ''; }
  return undefined;
}
// propriedade com índice: Grid.Cells(c, r) e StatusBar.Panels(i)
class NKIndexed extends VBObject {
  constructor(c, kind) { super(); this.c = c; this.kind = kind; }
  get typeName() { return 'Indexed'; }
  async callMethod(n, a) { return nkCall(this.c, this.kind, a); }
}
async function nkSet(c, n, v, rt, idx) {
  const P = c.P, t = c.type;
  const S = x => typeof toStr === 'function' ? toStr(x) : String(x);
  const N = x => typeof toNum === 'function' ? toNum(x) : Number(x);
  if (idx && idx.length) {
    if (t === 'NK.StringGrid' && n === 'cells') { const cc = N(idx[0]) | 0, r = N(idx[1]) | 0; const cells = nkCells(P); while (cells.length <= r) cells.push([]); cells[r][cc] = S(v); c.refresh(); return true; }
    if (t === 'NK.StatusBar' && n === 'panels') { const it = nkItems(P, 'panels'); const i = N(idx[0]) | 0; while (it.length <= i) it.push(''); it[i] = S(v); P.simplepanel = false; c.refresh(); return true; }
    return false;
  }
  const re = () => { c.refresh(); return true; };
  if (['items', 'columns', 'tabs', 'buttons', 'sections', 'panels', 'series'].includes(n)) { P[n] = S(v); P['_' + n] = null; return re(); }
  if (t === 'NK.StringGrid') { if (n === 'cells') { P.cells = S(v); P._cells = null; return re(); } if (n === 'row') { P._row = N(v); return re(); } if (n === 'col') { P._col = N(v); return re(); } if (n === 'rowcount' || n === 'colcount' || n === 'fixedrows' || n === 'fixedcols' || n === 'defaultcolwidth' || n === 'defaultrowheight') { P[n] = N(v); return re(); } }
  if (t === 'NK.RadioGroup' && n === 'itemindex') { const nv = N(v) | 0; const was = Number(P.itemindex); P.itemindex = nv; c.refresh(); if (was !== nv) await c.fire('click'); return true; }
  if (t === 'NK.ListView' && (n === 'selectedindex' || n === 'itemindex')) { P._sel = N(v); return re(); }
  if (t === 'NK.LabeledEdit' && n === 'text') { const s = S(v); const old = P.text; P.text = s; c.refresh(); if (old !== s) await c.fire('change'); return true; }
  if ((t === 'NK.SpinEdit' || t === 'NK.UpDown') && (n === 'value' || n === 'position' || n === 'text')) { const nv = N(v); const was = P.value; P.value = nv; c.refresh(); if (was !== nv) await c.fire('change'); return true; }
  if (t === 'NK.MonthCalendar' && (n === 'value' || n === 'date')) { let d; if (v && v.d instanceof Date) d = v.d; else if (typeof v === 'number' && typeof VBDate !== 'undefined') d = VBDate.fromSerial(v).d; else d = new Date(S(v)); P.value = isNaN(d) ? '' : nkIsoDate(d); P._view = null; c.refresh(); await c.fire('change'); return true; }
  if (t === 'NK.TimePicker' && (n === 'value' || n === 'time')) { P.value = S(v).slice(0, 5); c.refresh(); await c.fire('change'); return true; }
  if (t === 'NK.ToggleSwitch' && (n === 'state' || n === 'value' || n === 'ison')) { P.state = (typeof v === 'boolean' ? v : N(v) !== 0) ? 1 : 0; return re(); }
  if (t === 'NK.UpDown' && n === 'position') { P.value = N(v); return re(); }
  if (t === 'NK.Gauge' && (n === 'progress' || n === 'value')) { P.progress = N(v); return re(); }
  if (t === 'NK.TabSet' && n === 'tabindex') { P.tabindex = N(v); c.refresh(); await c.fire('change', [P.tabindex]); return true; }
  if (t === 'NK.ActivityIndicator' && n === 'animate') { P.animate = typeof v === 'boolean' ? v : N(v) !== 0; return re(); }
  if (t === 'NK.SplitView' && n === 'opened') { P.opened = typeof v === 'boolean' ? v : N(v) !== 0; return re(); }
  if (t === 'NK.Dialog' || t === 'NK.Component') { P[n] = v; return true; }
  return false;
}
async function nkCall(c, n, a, rt) {
  const P = c.P, t = c.type; const host = c.form.host;
  const S = x => typeof toStr === 'function' ? toStr(x) : String(x);
  const N = x => typeof toNum === 'function' ? toNum(x) : Number(x);
  if (t === 'NK.StringGrid' && n === 'cells') { const cc = N(a[0]) | 0, r = N(a[1]) | 0; return (nkCells(P)[r] || [])[cc] || ''; }
  if (t === 'NK.StatusBar' && n === 'panels') return nkItems(P, 'panels')[N(a[0]) | 0] || '';
  if (t === 'NK.StringGrid' && (n === 'clear' || n === 'clearcells')) { P._cells = []; return c.refresh(); }
  const listKey = t === 'NK.TabSet' ? 'tabs' : t === 'NK.Chart' ? 'series' : 'items';
  if (['NK.RadioGroup', 'NK.ListView', 'NK.TabSet', 'NK.ButtonGroup', 'NK.Chart'].includes(t)) {
    if (n === 'additem' || n === 'add') { const it = nkItems(P, listKey); it.push(t === 'NK.Chart' ? `${S(a[0])}=${N(nkArg(a, 1) ?? 0)}` : [...a].filter(x => x !== undefined && (typeof VBMissing === 'undefined' || x !== VBMissing)).map(S).join(';')); c.refresh(); return it.length - 1; }
    if (n === 'clear') { P['_' + listKey] = []; if (t === 'NK.RadioGroup') P.itemindex = -1; if (t === 'NK.ListView') P._sel = -1; c.refresh(); return; }
    if (n === 'removeitem' || n === 'delete') { nkItems(P, listKey).splice(N(a[0]) | 0, 1); c.refresh(); return; }
    if (n === 'item' || n === 'list' || n === 'items') { const s = nkItems(P, listKey)[N(a[0]) | 0] || ''; if (t === 'NK.ListView' && a.length > 1 && nkArg(a, 1) !== undefined) return s.split(';')[N(a[1]) | 0] || ''; return t === 'NK.ListView' ? s.split(';')[0] : stripMnemonic(s); }
  }
  if (t === 'NK.Chart' && n === 'addpoint') return nkCall(c, 'add', a, rt);
  if (t === 'NK.SplitView' && (n === 'open' || n === 'close')) { P.opened = n === 'open'; c.refresh(); await c.fire(n === 'open' ? 'opened' : 'closed'); return; }
  if (t === 'NK.Dialog' && n === 'execute') {
    const cls = String(P.delphiclass || '').toLowerCase();
    if (/open|filedialog$/.test(cls) && !/save/.test(cls)) { const r = host.pickFileToVFS ? await host.pickFileToVFS(P.filter || '') : null; if (!r) return false; P.filename = r.path; return true; }
    if (/save/.test(cls)) { const nm = await host.inputBox('File name:', P.dialogtitle || 'Save As', P.filename ? String(P.filename).split('\\').pop() : ('file.' + (P.defaultext || 'txt'))); if (!nm) return false; P.filename = 'C:\\NeoKiva\\' + nm.replace(/^.*[\\/]/, ''); if (host.markDownload) host.markDownload(P.filename); return true; }
    if (/color/.test(cls)) { const r = host.pickColor ? await host.pickColor(nkColorCss(P.color || 0)) : null; if (r == null) return false; P.color = cssToVbColor(r); return true; }
    if (/find|replace/.test(cls)) { const r = await host.inputBox('Find what:', P.dialogtitle || 'Find', P.findtext || ''); if (r == null || r === '') return false; P.findtext = r; await c.fire('find'); return true; }
    if (/taskdialog/.test(cls)) { const r = await host.msgBox(String(P.text || P.dialogtitle || ''), 1 + 64, P.caption || P.dialogtitle || ''); return r === 1; }
    return true; // fonte, impressora, configurar página: aceitos como estão
  }
  if (t === 'NK.Component') {
    if (n === 'popup') { await c.fire('popup'); return; }
    if (['open', 'close', 'execsql', 'first', 'last', 'next', 'prior', 'refresh', 'post', 'cancel', 'append', 'edit', 'delete'].includes(n)) { if (n === 'open') P.active = true; if (n === 'close') P.active = false; if (!c._warned && c.form.rt && c.form.rt.debugPrint) { c._warned = true; } return; }
  }
  return undefined;
}
if (typeof module !== 'undefined') module.exports = { nkDefaults, nkBuildInner, nkUpdate, NK_BASENAME };
