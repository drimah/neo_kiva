#!/usr/bin/env python3
"""Neo Kiva 0.1 — Linux setup service (standard library only).

NeoKiva.sh opens the Neo Kiva main window first and runs this service on 127.0.0.1:43820.
The main window asks it what is happening and shows it to the user inside Neo Kiva:
  GET /status   -> {"stage": checking|starting|ask|running|done|error, "title", "text", "pct", "error", "log"}
  GET /install  -> the user clicked "Install MySQL"
  GET /exit     -> the user clicked "Exit" / "Close Neo Kiva"
Exit code: 0 = MySQL ready and the local MySQL service is running; 2 = closed by the user; 1 = error.
"""
import argparse, json, os, re, subprocess, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

DIR = os.path.dirname(os.path.abspath(__file__))
STATE_DIR = os.path.join(os.environ.get("XDG_STATE_HOME") or os.path.expanduser("~/.local/state"), "neokiva")
LOG = os.path.join(STATE_DIR, "mysql-install.log")
lock = threading.Lock()
ST = {"stage": "checking", "title": "", "text": "Checking MySQL Server…", "pct": 0, "error": "", "log": ""}
EVENTS = {"install": threading.Event(), "exit": threading.Event()}
LAST_POLL = [time.time()]


def update(**kw):
    with lock:
        ST.update(kw)


def boot(*args):
    return subprocess.run(["sh", os.path.join(DIR, "mysql-bootstrap.sh"), *args], capture_output=True, text=True)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/install":
            EVENTS["install"].set()
        elif path == "/exit":
            EVENTS["exit"].set()
        LAST_POLL[0] = time.time()
        with lock:
            body = json.dumps(ST, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")       # the main window is a file:// page
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


def run_root(mode):
    """Runs mysql-install-root.sh through pkexec, turning its "NN" / "# text" lines into progress."""
    os.makedirs(STATE_DIR, exist_ok=True)
    cmd = ["pkexec", "/bin/sh", os.path.join(DIR, "mysql-install-root.sh"), os.path.expanduser("~"),
           os.environ.get("USER") or str(os.getuid()), str(os.getuid()), str(os.getgid())]
    if mode == "stopped":
        cmd.append("--start-only")
    with open(LOG, "w") as log:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=log, text=True, bufsize=1)
        for line in proc.stdout:
            line = line.strip()
            if re.fullmatch(r"\d{1,3}", line):
                update(pct=min(100, int(line)))
            elif line.startswith("#"):
                update(text=line.lstrip("# ").strip())
        return proc.wait()


def last_error():
    try:
        errs = [l[7:].strip() for l in open(LOG, encoding="utf-8", errors="replace") if l.startswith("ERROR: ")]
        return errs[-1] if errs else ""
    except OSError:
        return ""


def fail(msg):
    update(stage="error", error=msg, log=LOG)
    # wait for the user to read it and click "Close Neo Kiva" (or for the window to disappear)
    while not EVENTS["exit"].wait(1):
        if time.time() - LAST_POLL[0] > 30:
            break
    return 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=43820)
    ap.add_argument("--bridge-port", type=int, default=43821)
    a = ap.parse_args()
    try:
        server = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    except OSError:
        return 1   # another Neo Kiva setup is already running
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        state = boot("status").stdout.strip()
        if state == "mariadb":
            return fail("This computer uses MariaDB. Neo Kiva requires MySQL Server and will not remove MariaDB, so your data stays safe.")
        if state == "missing":
            update(stage="ask", text="")
            while not (EVENTS["install"].is_set() or EVENTS["exit"].is_set()):
                time.sleep(0.2)
                if time.time() - LAST_POLL[0] > 120:   # the main window was closed
                    return 2
            if EVENTS["exit"].is_set():
                time.sleep(0.5)
                return 2
        if state != "ready":
            titles = {"missing": "Installing MySQL Server", "stopped": "Starting MySQL Server", "unconfigured": "Configuring MySQL Server"}
            update(stage="running", title=titles.get(state, "Installing MySQL Server"), pct=1,
                   text="Waiting for administrator permission (enter your Linux password)…")
            rc = run_root(state)
            if rc in (126, 127):
                return fail("Administrator permission was not given. Neo Kiva requires MySQL Server, so it will close.")
            if rc != 0 or boot("status").stdout.strip() != "ready":
                return fail(last_error() or "The MySQL Server installation did not finish.")
        update(stage="starting", title="Starting Neo Kiva", text="Connecting to MySQL Server…", pct=100)
        r = boot("bridge", DIR, str(a.bridge_port))
        if r.returncode != 0:
            return fail("The Neo Kiva local MySQL service did not start. Details: " + os.path.join(STATE_DIR, "bridge.log"))
        update(stage="done", text="MySQL Server is ready.", pct=100)
        end = time.time() + 6          # let the main window see "done" before this service stops
        start = LAST_POLL[0]
        while time.time() < end and LAST_POLL[0] == start:
            time.sleep(0.2)
        time.sleep(0.5)
        return 0
    finally:
        server.shutdown()


if __name__ == "__main__":
    sys.exit(main())
