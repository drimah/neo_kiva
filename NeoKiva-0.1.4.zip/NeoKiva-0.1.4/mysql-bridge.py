#!/usr/bin/env python3
"""Neo Kiva 0.1 — serviço local entre a IDE (navegador) e o MySQL Server.

* Escuta somente em 127.0.0.1 e serve os arquivos da pasta do Neo Kiva/aplicativo.
* Cada banco do Neo Kiva (ex.: Books.db do projeto Books) vira um banco MySQL próprio,
  com nome legível (nb_books_books) e as tabelas com os nomes reais (Exigido, Clientes...).
* A IDE continua usando o SQL.js em memória (DAO síncrono do VB5/6); a cada alteração
  o banco é gravado no MySQL de forma atômica (RENAME TABLE).
"""
import argparse, base64, hashlib, io, json, os, re, signal, sqlite3, ssl, sys, tempfile, threading
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlparse

BRIDGE_VERSION = "0.1"

try:
    import pymysql
except Exception as exc:  # pragma: no cover
    raise SystemExit("python3-pymysql is not installed: " + str(exc))

CONFIG = Path.home() / ".config" / "neobasic" / "mysql.json"
CATALOG = "__nb_catalog_v2"
OLD_CATALOG = "__nb_mysql_catalog"  # formato da 0.6.12 (tabelas nb_<hash>), migrado automaticamente
_locks = {}
_locks_guard = threading.Lock()


def lock_for(key):
    with _locks_guard:
        return _locks.setdefault(key, threading.Lock())


def config():
    with CONFIG.open("r", encoding="utf-8-sig") as f:   # -sig: aceita arquivo gravado com BOM no Windows
        return json.load(f)


def _ssl_context():
    # Windows: conexão TCP local com SSL (o MySQL gera os certificados sozinho).
    # Com SSL o PyMySQL autentica no caching_sha2_password sem precisar do pacote "cryptography".
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def connect(database=None):
    c = config()
    kw = dict(user=c["user"], password=c["password"], charset="utf8mb4", autocommit=True,
              cursorclass=pymysql.cursors.DictCursor, database=database or c["database"])
    sock = c.get("socket")
    if sock and os.path.exists(sock):
        kw["unix_socket"] = sock
    else:
        kw["host"] = c.get("host", "127.0.0.1"); kw["port"] = int(c.get("port", 3306))
        if c.get("ssl"):
            kw["ssl"] = _ssl_context()
    return pymysql.connect(**kw)


def q(name):
    return "`" + str(name).replace("`", "``") + "`"


def sha(text):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def slug(text, size):
    s = re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_")
    return (s or "db")[:size].strip("_") or "db"


def mysql_ident(name, used):
    """Nome válido no MySQL (máx. 64, único sem diferenciar maiúsculas)."""
    n = str(name)
    if len(n) > 64 or n.endswith(" ") or not n:
        n = (n.strip()[:54] or "col") + "_" + sha(name)[:8]
    base, i = n, 2
    while n.lower() in used:
        n = base[:60] + "_" + str(i); i += 1
    used.add(n.lower())
    return n


def ensure_catalog(cur):
    cur.execute(f"""CREATE TABLE IF NOT EXISTS {q(CATALOG)} (
        db_key CHAR(64) NOT NULL PRIMARY KEY,
        source_key TEXT,
        schema_name VARCHAR(64) NOT NULL,
        meta LONGTEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_schema (schema_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")


def catalog_get(cur, dbkey):
    cur.execute(f"SELECT * FROM {q(CATALOG)} WHERE db_key=%s", (dbkey,))
    return cur.fetchone()


def schema_for(cur, dbkey, source_key):
    row = catalog_get(cur, dbkey)
    if row:
        return row["schema_name"]
    project, _, path = str(source_key).partition("|")
    stem = re.split(r"[\\/]", path or project)[-1]
    stem = re.sub(r"\.(db|sqlite3?|mdb|accdb)$", "", stem, flags=re.I)
    base = "nb_" + slug(project, 20) + "_" + slug(stem, 26)
    name, i = base, 2
    while True:
        cur.execute(f"SELECT 1 FROM {q(CATALOG)} WHERE schema_name=%s", (name,))
        if not cur.fetchone():
            break
        name = base[:50] + "_" + str(i); i += 1
    return name


# ---------- tipos: escolhidos pelos valores reais (nunca falha no modo estrito do MySQL) ----------
ISO_DT = re.compile(r"^([1-9]\d{3})-(\d{2})-(\d{2})( (\d{2}):(\d{2}):(\d{2})(\.\d{1,6})?)?$")


def is_iso(v):
    m = ISO_DT.match(v)
    if not m:
        return None
    try:
        if m.group(4):
            datetime.strptime(v[:19], "%Y-%m-%d %H:%M:%S")
            if m.group(8):
                return None  # frações de segundo: mantém como texto para não perder formato
            return "dt"
        date.fromisoformat(v)
        return "d"
    except ValueError:
        return None


DAO_HINT = {1: "INT", 2: "INT", 3: "INT", 4: "INT", 5: "REAL", 6: "REAL", 7: "REAL", 8: "DATETIME", 12: "MEMO"}


def infer_type(declared, values):
    t = (declared or "").upper()
    vals = [v for v in values if v is not None]
    if not vals:
        if "INT" in t: return "BIGINT"
        if any(x in t for x in ("REAL", "FLOA", "DOUB")): return "DOUBLE"
        if "BLOB" in t: return "LONGBLOB"
        return "LONGTEXT"
    if all(isinstance(v, int) and not isinstance(v, bool) and -2**63 <= v < 2**63 for v in vals):
        return "BIGINT"
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in vals):
        if all(v == v and v not in (float("inf"), float("-inf")) for v in vals):
            return "DOUBLE"
        return "LONGTEXT"
    if any(isinstance(v, (bytes, bytearray, memoryview)) for v in vals):
        return "LONGBLOB"
    if all(isinstance(v, str) for v in vals) and any(x in t for x in ("DATE", "TIME")):
        kinds = {is_iso(v) for v in vals}
        if kinds == {"d"}: return "DATE"
        if kinds <= {"d", "dt"} and None not in kinds and "dt" in kinds: return "DATETIME"
    if all(len(str(v)) <= 255 for v in vals):
        return "VARCHAR(255)"
    return "LONGTEXT"


def to_mysql(v, ty):
    if isinstance(v, memoryview): return bytes(v)
    if ty == "LONGTEXT" and isinstance(v, (bytes, bytearray)): return bytes(v)
    if ty in ("LONGTEXT", "VARCHAR(255)") and not isinstance(v, (str, type(None))): return str(v) if not isinstance(v, (bytes, bytearray)) else v
    return v


def from_mysql(v, ty):
    if v is None: return None
    if isinstance(v, datetime): return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date): return v.isoformat()
    if isinstance(v, timedelta):
        s = int(v.total_seconds()); return "%02d:%02d:%02d" % (s // 3600, s % 3600 // 60, s % 60)
    if isinstance(v, time): return v.isoformat()
    if isinstance(v, Decimal): return float(v)
    if isinstance(v, memoryview): return bytes(v)
    if isinstance(v, bytearray): return bytes(v)
    return v


# ---------- SQLite (blob) -> MySQL ----------
def open_sqlite(blob):
    fd, path = tempfile.mkstemp(prefix="neokiva-db-", suffix=".sqlite")
    with os.fdopen(fd, "wb") as f:
        f.write(blob)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    return db, path


def import_snapshot(conn, dbkey, source_key, blob):
    db, tmp = open_sqlite(blob)
    try:
        with conn.cursor() as cur:
            ensure_catalog(cur)
            schema = schema_for(cur, dbkey, source_key)
            stage, old = schema[:54] + "__nbnew", schema[:54] + "__nbold"
            for s in (stage, old):
                cur.execute(f"DROP DATABASE IF EXISTS {q(s)}")
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {q(schema)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            cur.execute(f"CREATE DATABASE {q(stage)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            master = [dict(r) for r in db.execute(
                "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY rowid")]
            tables, used_t = [], set()
            # tipos DAO que o Neo Kiva guarda em _nb_cols (8 = Date, 4 = Long...) orientam o tipo no MySQL
            hints = {}
            try:
                for r in db.execute("SELECT tbl, col, type FROM _nb_cols"):
                    hints[(str(r[0]).lower(), str(r[1]).lower())] = DAO_HINT.get(r[2])
            except sqlite3.Error:
                pass
            for m in master:
                if m["type"] != "table":
                    continue
                name = m["name"]
                info = list(db.execute(f"PRAGMA table_info({q(name)})"))
                if not info:
                    continue
                cols = [r["name"] for r in info]
                rows = [tuple(r) for r in db.execute(f"SELECT {','.join(q(c) for c in cols)} FROM {q(name)}")]
                phys = mysql_ident(name, used_t)
                used_c, colmap, coldefs, types = set(), [], [], []
                for i, r in enumerate(info):
                    ty = infer_type(hints.get((name.lower(), r["name"].lower())) or r["type"], [row[i] for row in rows])
                    mc = mysql_ident(r["name"], used_c)
                    colmap.append([r["name"], mc]); types.append(ty)
                    coldefs.append(q(mc) + " " + ty + (" NOT NULL" if r["notnull"] else " NULL"))
                pk = [r for r in sorted(info, key=lambda x: x["pk"]) if r["pk"]]
                pk_idx = [cols.index(r["name"]) for r in pk]
                pk_ok = bool(pk) and all(types[i] not in ("LONGTEXT", "LONGBLOB") for i in pk_idx) \
                    and all(row[i] is not None for row in rows for i in pk_idx)
                auto = (len(pk) == 1 and types[pk_idx[0]] == "BIGINT" and "INT" in (pk[0]["type"] or "").upper())
                def create(with_pk):
                    defs = list(coldefs)
                    if with_pk:
                        if auto:
                            defs[pk_idx[0]] = q(colmap[pk_idx[0]][1]) + " BIGINT NOT NULL AUTO_INCREMENT"
                        defs.append("PRIMARY KEY (" + ",".join(q(colmap[i][1]) for i in pk_idx) + ")")
                    cur.execute(f"CREATE TABLE {q(stage)}.{q(phys)} ({','.join(defs)}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
                    if rows:
                        sql = (f"INSERT INTO {q(stage)}.{q(phys)} ({','.join(q(c[1]) for c in colmap)}) "
                               f"VALUES ({','.join(['%s'] * len(cols))})")
                        for k in range(0, len(rows), 500):
                            cur.executemany(sql, [tuple(to_mysql(v, types[i]) for i, v in enumerate(row)) for row in rows[k:k + 500]])
                try:
                    create(pk_ok)
                except pymysql.err.IntegrityError:
                    # ex.: chaves que diferem só em maiúsculas/minúsculas — grava sem a chave primária
                    cur.execute(f"DROP TABLE IF EXISTS {q(stage)}.{q(phys)}")
                    create(False)
                tables.append({"name": name, "physical": phys, "columns": colmap, "sql": m["sql"]})
            others = [{"type": m["type"], "name": m["name"], "sql": m["sql"]} for m in master if m["type"] != "table"]
            # troca atômica: tabelas novas entram, antigas saem
            cur.execute("SELECT table_name AS t FROM information_schema.tables WHERE table_schema=%s", (schema,))
            existing = [r["t"] for r in cur.fetchall()]
            cur.execute(f"CREATE DATABASE {q(old)}")
            moves = [f"{q(schema)}.{q(t)} TO {q(old)}.{q(t)}" for t in existing]
            moves += [f"{q(stage)}.{q(t['physical'])} TO {q(schema)}.{q(t['physical'])}" for t in tables]
            if moves:
                cur.execute("RENAME TABLE " + ", ".join(moves))
            meta = json.dumps({"tables": tables, "others": others}, ensure_ascii=False)
            cur.execute(f"REPLACE INTO {q(CATALOG)} (db_key,source_key,schema_name,meta) VALUES (%s,%s,%s,%s)",
                        (dbkey, source_key, schema, meta))
            cur.execute(f"DROP DATABASE IF EXISTS {q(old)}")
            cur.execute(f"DROP DATABASE IF EXISTS {q(stage)}")
            return schema
    finally:
        db.close()
        try: os.unlink(tmp)
        except OSError: pass


# ---------- MySQL -> SQLite (blob) ----------
def export_snapshot(conn, dbkey):
    with conn.cursor() as cur:
        row = catalog_get(cur, dbkey)
        schema = row["schema_name"]
        meta = json.loads(row["meta"] or "{}")
        cur.execute("SELECT table_name AS t FROM information_schema.tables WHERE table_schema=%s AND table_type='BASE TABLE'", (schema,))
        present = {r["t"].lower(): r["t"] for r in cur.fetchall()}
    fd, out_path = tempfile.mkstemp(prefix="neokiva-export-", suffix=".sqlite"); os.close(fd)
    out = sqlite3.connect(out_path)
    try:
        known = set()
        tables = list(meta.get("tables", []))
        # tabelas criadas direto no MySQL (Workbench, phpMyAdmin...) também aparecem no Neo Kiva
        for low, real in present.items():
            if low not in {t["physical"].lower() for t in tables}:
                tables.append({"name": real, "physical": real, "columns": None, "sql": None})
        for t in tables:
            if t["physical"].lower() not in present:
                continue  # apagada no MySQL
            with conn.cursor() as cur:
                cur.execute(f"SHOW COLUMNS FROM {q(schema)}.{q(present[t['physical'].lower()])}")
                mcols = [c["Field"] for c in cur.fetchall()]
            colmap = t["columns"] or [[c, c] for c in mcols]
            colmap = [c for c in colmap if c[1] in mcols]
            if t["sql"]:
                out.execute(t["sql"])
            else:
                out.execute("CREATE TABLE " + q(t["name"]) + " (" + ",".join(q(c[0]) for c in colmap) + ")")
            known.add(t["name"])
            if not colmap:
                continue
            with conn.cursor(pymysql.cursors.Cursor) as cur:
                cur.execute(f"SELECT {','.join(q(c[1]) for c in colmap)} FROM {q(schema)}.{q(present[t['physical'].lower()])}")
                ins = f"INSERT INTO {q(t['name'])} ({','.join(q(c[0]) for c in colmap)}) VALUES ({','.join('?' * len(colmap))})"
                while True:
                    batch = cur.fetchmany(1000)
                    if not batch:
                        break
                    out.executemany(ins, [tuple(from_mysql(v, None) for v in r) for r in batch])
        for o in meta.get("others", []):
            try: out.execute(o["sql"])
            except sqlite3.Error: pass  # índice/visão de tabela removida
        out.commit()
        out.close()
        return Path(out_path).read_bytes()
    finally:
        try: out.close()
        except Exception: pass
        try: os.unlink(out_path)
        except OSError: pass


def migrate_old(conn, dbkey, source_key):
    """Banco gravado pela 0.6.12 (tabelas nb_<hash>) -> formato legível."""
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=%s", (OLD_CATALOG,))
        if not cur.fetchone()["n"]:
            return False
        cur.execute(f"SELECT table_name,mysql_table,create_sql FROM {q(OLD_CATALOG)} WHERE db_key=%s", (dbkey,))
        items = cur.fetchall()
    if not items:
        return False
    fd, p = tempfile.mkstemp(suffix=".sqlite"); os.close(fd)
    out = sqlite3.connect(p)
    for it in items:
        with conn.cursor(pymysql.cursors.Cursor) as cur:
            cur.execute(f"SELECT * FROM {q(it['mysql_table'])}")
            names = [d[0] for d in cur.description]; rows = cur.fetchall()
        out.execute(it["create_sql"] or ("CREATE TABLE " + q(it["table_name"]) + " (" + ",".join(q(n) for n in names) + ")"))
        if rows:
            out.executemany(f"INSERT INTO {q(it['table_name'])} ({','.join(q(n) for n in names)}) VALUES ({','.join('?' * len(names))})",
                            [tuple(from_mysql(v, None) for v in r) for r in rows])
    out.commit(); out.close()
    blob = Path(p).read_bytes(); os.unlink(p)
    import_snapshot(conn, dbkey, source_key, blob)
    with conn.cursor() as cur:
        for it in items:
            cur.execute(f"DROP TABLE IF EXISTS {q(it['mysql_table'])}")
        cur.execute(f"DELETE FROM {q(OLD_CATALOG)} WHERE db_key=%s", (dbkey,))
    return True


def rename_db(conn, old_key, new_key):
    """Database renamed in the project: its MySQL database gets the new name too."""
    olddk, newdk = sha(old_key), sha(new_key)
    with conn.cursor() as cur:
        ensure_catalog(cur)
        row = catalog_get(cur, olddk)
        if not row:
            return None
        if olddk == newdk:
            return row["schema_name"]
        if catalog_get(cur, newdk):
            raise ValueError("MySQL already has a database for the new name.")
        old_schema = row["schema_name"]
        new_schema = schema_for(cur, newdk, new_key)
        if new_schema.lower() != old_schema.lower():
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {q(new_schema)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            cur.execute("SELECT table_name AS t FROM information_schema.tables WHERE table_schema=%s", (old_schema,))
            tables = [r["t"] for r in cur.fetchall()]
            if tables:
                cur.execute("RENAME TABLE " + ", ".join(f"{q(old_schema)}.{q(t)} TO {q(new_schema)}.{q(t)}" for t in tables))
            cur.execute(f"DROP DATABASE IF EXISTS {q(old_schema)}")
        cur.execute(f"UPDATE {q(CATALOG)} SET db_key=%s, source_key=%s, schema_name=%s WHERE db_key=%s",
                    (newdk, new_key, new_schema, olddk))
        return new_schema


def drop_db(conn, key):
    """Database removed from the project with "also delete the MySQL data"."""
    dbkey = sha(key)
    with conn.cursor() as cur:
        ensure_catalog(cur)
        row = catalog_get(cur, dbkey)
        if not row:
            return None
        cur.execute(f"DROP DATABASE IF EXISTS {q(row['schema_name'])}")
        cur.execute(f"DELETE FROM {q(CATALOG)} WHERE db_key=%s", (dbkey,))
        return row["schema_name"]


class Handler(SimpleHTTPRequestHandler):
    server_version = "NeoBasicMySQLBridge/" + BRIDGE_VERSION

    def translate_path(self, path):
        rel = unquote(urlparse(path).path).lstrip("/")
        root = self.server.web_root
        target = (root / rel).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            return str(root / "__not_found__")
        return str(target)

    def send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/api/health"):
            info = {"version": BRIDGE_VERSION, "root": str(self.server.web_root), "pid": os.getpid()}
            try:
                with connect() as conn, conn.cursor() as cur:
                    cur.execute("SELECT VERSION() AS v"); info.update(ok=True, mysql=cur.fetchone()["v"])
                return self.send_json(200, info)
            except Exception as exc:
                info.update(ok=False, error=str(exc)); return self.send_json(503, info)
        return super().do_GET()

    def do_POST(self):
        if self.path not in ("/api/db/open", "/api/db/save", "/api/db/rename", "/api/db/drop"):
            return self.send_json(404, {"error": "Endpoint not found."})
        try:
            if self.headers.get("X-NeoBasic-Token", "") != config().get("token"):
                return self.send_json(403, {"error": "Invalid local token."})
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 300 * 1024 * 1024:
                return self.send_json(413, {"error": "Invalid request size."})
            payload = json.loads(self.rfile.read(length))
            if self.path == "/api/db/rename":
                old_key, new_key = str(payload.get("old_key", "")), str(payload.get("new_key", ""))
                if not old_key or not new_key or len(old_key) > 1000 or len(new_key) > 1000:
                    return self.send_json(400, {"error": "Invalid database identifier."})
                if sha(old_key) == sha(new_key):
                    return self.send_json(200, {"ok": True})
                with lock_for(sha(old_key)), lock_for(sha(new_key)), connect() as conn:
                    return self.send_json(200, {"ok": True, "schema": rename_db(conn, old_key, new_key)})
            key = str(payload.get("key", ""))
            if not key or len(key) > 1000:
                return self.send_json(400, {"error": "Invalid database identifier."})
            dbkey = sha(key)
            if self.path == "/api/db/drop":
                with lock_for(dbkey), connect() as conn:
                    return self.send_json(200, {"ok": True, "schema": drop_db(conn, key)})
            with lock_for(dbkey), connect() as conn:
                with conn.cursor() as cur:
                    ensure_catalog(cur)
                    exists = bool(catalog_get(cur, dbkey))
                if self.path.endswith("/open"):
                    source = "mysql"
                    if not exists and migrate_old(conn, dbkey, key):
                        exists, source = True, "migrated"
                    if exists:
                        blob = export_snapshot(conn, dbkey)
                    elif payload.get("open_only"):
                        return self.send_json(404, {"error": "Database not found in MySQL."})
                    else:
                        blob = base64.b64decode(payload.get("sqlite_b64", ""), validate=True)
                        import_snapshot(conn, dbkey, key, blob); source = "imported"
                    with conn.cursor() as cur:
                        schema = catalog_get(cur, dbkey)["schema_name"]
                    return self.send_json(200, {"ok": True, "schema": schema, "source": source,
                                                "sqlite_b64": base64.b64encode(blob).decode("ascii")})
                blob = base64.b64decode(payload.get("sqlite_b64", ""), validate=True)
                schema = import_snapshot(conn, dbkey, key, blob)
                return self.send_json(200, {"ok": True, "schema": schema})
        except Exception as exc:
            print("ERROR", self.path, repr(exc), flush=True)
            return self.send_json(500, {"error": str(exc)})

    def send_head(self):
        path = self.translate_path(self.path)
        if path.lower().endswith((".html", ".htm")) and os.path.isfile(path):
            try:
                data = Path(path).read_bytes()
                inject = ("<script>window.NB_MYSQL_API_TOKEN=" + json.dumps(config()["token"]) +
                          ";window.NB_MYSQL_API_BASE=location.origin;</script>").encode("utf-8")
                low = data[:4096].lower(); idx = low.find(b"<head>")
                data = data[:idx + 6] + inject + data[idx + 6:] if idx >= 0 else inject + data
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                return io.BytesIO(data)
            except Exception as exc:
                self.send_error(500, str(exc)); return None
        return super().send_head()

    def log_message(self, fmt, *args):
        if "/api/health" not in (args[0] if args else ""):
            print("%s - %s" % (self.address_string(), fmt % args), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--port", type=int, default=43821)
    ap.add_argument("--pidfile")
    args = ap.parse_args()
    for stream in (sys.stdout, sys.stderr):
        try: stream.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except Exception: pass
    with connect() as conn, conn.cursor() as cur:
        ensure_catalog(cur)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.daemon_threads = True
    server.web_root = Path(args.root).resolve()
    if args.pidfile:
        Path(args.pidfile).write_text(str(os.getpid()))
    signal.signal(signal.SIGTERM, lambda *a: (server.server_close(), sys.exit(0)))
    print(f"Neo Kiva {BRIDGE_VERSION}: MySQL service running at http://127.0.0.1:{args.port}/ (folder {server.web_root})", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
